
-- @SqlSnippetPriority 600

-- The following source code ("Code") may only be used in accordance with the terms
-- and conditions of the license agreement you have with IBM Corporation. The Code 
-- is provided to you on an "AS IS" basis, without warranty of any kind.  
-- SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
-- WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
-- TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
-- PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
-- IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
-- CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
-- LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
-- ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
-- DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
-- INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
-- NOT APPLY TO YOU.




-- Notes
-- MDM_TODO: CDKWB0046I Statements are placed in the generated SQL file when user changes are required.
-- 1. Edit the following SQL files following any associated instructions.
-- 2. Connect to the database.
-- 3. Run each SQL file as shown below and in the same order.
-- 			db2 -vf MTTDBCustom_SETUP_ZOS.sql
-- 			db2 -vf MTTDBCustom_TRIGGERS_ZOS.sql
-- 			db2 -vf MTTDBCustom_CONSTRAINTS_ZOS.sql
--			db2 -vf MTTDBCustom_ERRORS_100_DB2.sql
-- 			db2 -vf MTTDBCustom_MetaData_ZOS.sql
-- 			db2 -vf CONFIG_XMLSERVICES_RESPONSE_ZOS.sql
-- 			db2 -vf MTTDBCustom_CODETABLES_ZOS.sql
--#SET TERMINATOR ;



INSERT INTO MDMDB.XCDCHANNELGRPTP ( lang_tp_cd, CHANNEL_GRP_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 'name1' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDCHANNELGRPTP ( lang_tp_cd, CHANNEL_GRP_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 2, 'name2' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDCHANNELGRPTP ( lang_tp_cd, CHANNEL_GRP_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 3, 'name3' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDCHANNELGRPTP ( lang_tp_cd, CHANNEL_GRP_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 4, 'name4' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDAGENTNUMTP ( lang_tp_cd, AGENT_NUM_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 'name1' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDAGENTNUMTP ( lang_tp_cd, AGENT_NUM_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 2, 'name2' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDAGENTNUMTP ( lang_tp_cd, AGENT_NUM_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 3, 'name3' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDAGENTNUMTP ( lang_tp_cd, AGENT_NUM_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 4, 'name4' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDUSERLOCALITYTP ( lang_tp_cd, USER_LOCALITY_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 'name1' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDUSERLOCALITYTP ( lang_tp_cd, USER_LOCALITY_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 2, 'name2' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDUSERLOCALITYTP ( lang_tp_cd, USER_LOCALITY_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 3, 'name3' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDUSERLOCALITYTP ( lang_tp_cd, USER_LOCALITY_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 4, 'name4' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDCUSCLASSTP ( lang_tp_cd, CUS_CLASS_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 'name1' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDCUSCLASSTP ( lang_tp_cd, CUS_CLASS_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 2, 'name2' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDCUSCLASSTP ( lang_tp_cd, CUS_CLASS_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 3, 'name3' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDCUSCLASSTP ( lang_tp_cd, CUS_CLASS_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 4, 'name4' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDINVTERMSTP ( lang_tp_cd, INV_TERMS_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 'name1' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDINVTERMSTP ( lang_tp_cd, INV_TERMS_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 2, 'name2' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDINVTERMSTP ( lang_tp_cd, INV_TERMS_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 3, 'name3' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDINVTERMSTP ( lang_tp_cd, INV_TERMS_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 4, 'name4' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDCUSGRPTP ( lang_tp_cd, CUS_GRP_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 'name1' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDCUSGRPTP ( lang_tp_cd, CUS_GRP_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 2, 'name2' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDCUSGRPTP ( lang_tp_cd, CUS_GRP_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 3, 'name3' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDCUSGRPTP ( lang_tp_cd, CUS_GRP_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 4, 'name4' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDINVSEQTP ( lang_tp_cd, INV_SEQ_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 'name1' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDINVSEQTP ( lang_tp_cd, INV_SEQ_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 2, 'name2' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDINVSEQTP ( lang_tp_cd, INV_SEQ_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 3, 'name3' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDINVSEQTP ( lang_tp_cd, INV_SEQ_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 4, 'name4' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDINVMODETP ( lang_tp_cd, INV_MODE_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 'name1' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDINVMODETP ( lang_tp_cd, INV_MODE_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 2, 'name2' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDINVMODETP ( lang_tp_cd, INV_MODE_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 3, 'name3' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDINVMODETP ( lang_tp_cd, INV_MODE_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 4, 'name4' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDORDERGUIDETP ( lang_tp_cd, ORDER_GUIDE_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 'name1' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDORDERGUIDETP ( lang_tp_cd, ORDER_GUIDE_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 2, 'name2' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDORDERGUIDETP ( lang_tp_cd, ORDER_GUIDE_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 3, 'name3' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDORDERGUIDETP ( lang_tp_cd, ORDER_GUIDE_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 4, 'name4' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDPRNCATINVBRKTP ( lang_tp_cd, PRN_CAT_INV_BRK_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 'name1' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDPRNCATINVBRKTP ( lang_tp_cd, PRN_CAT_INV_BRK_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 2, 'name2' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDPRNCATINVBRKTP ( lang_tp_cd, PRN_CAT_INV_BRK_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 3, 'name3' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDPRNCATINVBRKTP ( lang_tp_cd, PRN_CAT_INV_BRK_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 4, 'name4' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDINVRECAPSUMMARYTP ( lang_tp_cd, INV_RECAP_SUMMARY_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 'name1' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDINVRECAPSUMMARYTP ( lang_tp_cd, INV_RECAP_SUMMARY_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 2, 'name2' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDINVRECAPSUMMARYTP ( lang_tp_cd, INV_RECAP_SUMMARY_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 3, 'name3' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDINVRECAPSUMMARYTP ( lang_tp_cd, INV_RECAP_SUMMARY_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 4, 'name4' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDPICKUPDELIVERTP ( lang_tp_cd, PICKUP_DELIVER_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 'name1' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDPICKUPDELIVERTP ( lang_tp_cd, PICKUP_DELIVER_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 2, 'name2' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDPICKUPDELIVERTP ( lang_tp_cd, PICKUP_DELIVER_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 3, 'name3' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDPICKUPDELIVERTP ( lang_tp_cd, PICKUP_DELIVER_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 4, 'name4' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDUNITCASECOSTPRNTP ( lang_tp_cd, UNIT_CASE_COST_PRN_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 'name1' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDUNITCASECOSTPRNTP ( lang_tp_cd, UNIT_CASE_COST_PRN_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 2, 'name2' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDUNITCASECOSTPRNTP ( lang_tp_cd, UNIT_CASE_COST_PRN_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 3, 'name3' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDUNITCASECOSTPRNTP ( lang_tp_cd, UNIT_CASE_COST_PRN_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 4, 'name4' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDINVFORMATTP ( lang_tp_cd, INV_FORMAT_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 'name1' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDINVFORMATTP ( lang_tp_cd, INV_FORMAT_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 2, 'name2' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDINVFORMATTP ( lang_tp_cd, INV_FORMAT_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 3, 'name3' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDINVFORMATTP ( lang_tp_cd, INV_FORMAT_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 4, 'name4' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDDELPICKPACKINVTP ( lang_tp_cd, DEL_PICK_PACK_INV_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 'name1' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDDELPICKPACKINVTP ( lang_tp_cd, DEL_PICK_PACK_INV_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 2, 'name2' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDDELPICKPACKINVTP ( lang_tp_cd, DEL_PICK_PACK_INV_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 3, 'name3' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDDELPICKPACKINVTP ( lang_tp_cd, DEL_PICK_PACK_INV_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 4, 'name4' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDTOTESTP ( lang_tp_cd, TOTES_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 'name1' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDTOTESTP ( lang_tp_cd, TOTES_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 2, 'name2' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDTOTESTP ( lang_tp_cd, TOTES_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 3, 'name3' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDTOTESTP ( lang_tp_cd, TOTES_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 4, 'name4' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDINVTP ( lang_tp_cd, INV_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 'name1' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDINVTP ( lang_tp_cd, INV_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 2, 'name2' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDINVTP ( lang_tp_cd, INV_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 3, 'name3' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDINVTP ( lang_tp_cd, INV_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 4, 'name4' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDCOSTBASETP ( lang_tp_cd, COST_BASE_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 'name1' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDCOSTBASETP ( lang_tp_cd, COST_BASE_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 2, 'name2' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDCOSTBASETP ( lang_tp_cd, COST_BASE_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 3, 'name3' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDCOSTBASETP ( lang_tp_cd, COST_BASE_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 4, 'name4' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDSRPCOMPLIANCETP ( lang_tp_cd, SRP_COMPLIANCE_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 'name1' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDSRPCOMPLIANCETP ( lang_tp_cd, SRP_COMPLIANCE_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 2, 'name2' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDSRPCOMPLIANCETP ( lang_tp_cd, SRP_COMPLIANCE_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 3, 'name3' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDSRPCOMPLIANCETP ( lang_tp_cd, SRP_COMPLIANCE_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 4, 'name4' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDBRKNCASECALCTP ( lang_tp_cd, BRKN_CASE_CALC_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 'name1' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDBRKNCASECALCTP ( lang_tp_cd, BRKN_CASE_CALC_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 2, 'name2' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDBRKNCASECALCTP ( lang_tp_cd, BRKN_CASE_CALC_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 3, 'name3' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDBRKNCASECALCTP ( lang_tp_cd, BRKN_CASE_CALC_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 4, 'name4' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDPSRPTP ( lang_tp_cd, PSRP_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 'name1' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDPSRPTP ( lang_tp_cd, PSRP_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 2, 'name2' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDPSRPTP ( lang_tp_cd, PSRP_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 3, 'name3' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDPSRPTP ( lang_tp_cd, PSRP_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 4, 'name4' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDSTATEMENTMODETP ( lang_tp_cd, STATEMENT_MODE_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 'name1' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDSTATEMENTMODETP ( lang_tp_cd, STATEMENT_MODE_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 2, 'name2' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDSTATEMENTMODETP ( lang_tp_cd, STATEMENT_MODE_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 3, 'name3' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDSTATEMENTMODETP ( lang_tp_cd, STATEMENT_MODE_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 4, 'name4' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDGRACEDAYSTP ( lang_tp_cd, GRACE_DAYS_CAT_CD, GRACE_DAYS_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 1, 'name1' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDGRACEDAYSTP ( lang_tp_cd, GRACE_DAYS_CAT_CD, GRACE_DAYS_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 2, 'name2' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDGRACEDAYSTP ( lang_tp_cd, GRACE_DAYS_CAT_CD, GRACE_DAYS_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 3, 'name3' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDGRACEDAYSTP ( lang_tp_cd, GRACE_DAYS_CAT_CD, GRACE_DAYS_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 4, 'name4' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDCOLLECTORTP ( lang_tp_cd, COLLECTOR_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 'name1' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDCOLLECTORTP ( lang_tp_cd, COLLECTOR_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 2, 'name2' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDCOLLECTORTP ( lang_tp_cd, COLLECTOR_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 3, 'name3' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDCOLLECTORTP ( lang_tp_cd, COLLECTOR_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 4, 'name4' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDPAYMENTMETHODTP ( lang_tp_cd, PAYMENT_METHOD_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 'name1' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDPAYMENTMETHODTP ( lang_tp_cd, PAYMENT_METHOD_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 2, 'name2' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDPAYMENTMETHODTP ( lang_tp_cd, PAYMENT_METHOD_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 3, 'name3' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDPAYMENTMETHODTP ( lang_tp_cd, PAYMENT_METHOD_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 4, 'name4' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDBANKTP ( lang_tp_cd, BANK_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 'name1' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDBANKTP ( lang_tp_cd, BANK_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 2, 'name2' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDBANKTP ( lang_tp_cd, BANK_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 3, 'name3' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDBANKTP ( lang_tp_cd, BANK_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 4, 'name4' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDBANKACCOUNTTP ( lang_tp_cd, BANK_ACCOUNT_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 'name1' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDBANKACCOUNTTP ( lang_tp_cd, BANK_ACCOUNT_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 2, 'name2' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDBANKACCOUNTTP ( lang_tp_cd, BANK_ACCOUNT_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 3, 'name3' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDBANKACCOUNTTP ( lang_tp_cd, BANK_ACCOUNT_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 4, 'name4' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDSALESREPTP ( lang_tp_cd, SALES_REP_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 'name1' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDSALESREPTP ( lang_tp_cd, SALES_REP_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 2, 'name2' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDSALESREPTP ( lang_tp_cd, SALES_REP_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 3, 'name3' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDSALESREPTP ( lang_tp_cd, SALES_REP_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 4, 'name4' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDGRACEDAYSCAT ( lang_tp_cd, GRACE_DAYS_CAT_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 'name1' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDGRACEDAYSCAT ( lang_tp_cd, GRACE_DAYS_CAT_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 2, 'name2' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDGRACEDAYSCAT ( lang_tp_cd, GRACE_DAYS_CAT_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 3, 'name3' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDGRACEDAYSCAT ( lang_tp_cd, GRACE_DAYS_CAT_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 4, 'name4' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDIDENTIFIERSUBTP ( lang_tp_cd, IDENTIFIER_SUB_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 'name1' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDIDENTIFIERSUBTP ( lang_tp_cd, IDENTIFIER_SUB_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 2, 'name2' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDIDENTIFIERSUBTP ( lang_tp_cd, IDENTIFIER_SUB_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 3, 'name3' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDIDENTIFIERSUBTP ( lang_tp_cd, IDENTIFIER_SUB_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 4, 'name4' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDMSOTP ( lang_tp_cd, MSO_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 1, 'name1' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDMSOTP ( lang_tp_cd, MSO_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 2, 'name2' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDMSOTP ( lang_tp_cd, MSO_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 3, 'name3' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

INSERT INTO MDMDB.XCDMSOTP ( lang_tp_cd, MSO_TP_CD, name,  , description, last_update_dt, last_update_user ) 
   VALUES ( 100, 4, 'name4' , NULL, CURRENT_TIMESTAMP, 'cusadmin' );

