
-- @SqlSnippetPriority 200
-- @SqlModuleOrdering 4

-- The following source code ("Code") may only be used in accordance with the terms
-- and conditions of the license agreement you have with IBM Corporation. The Code 
-- is provided to you on an "AS IS" basis, without warranty of any kind.  
-- SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
-- WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
-- TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
-- PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
-- IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
-- CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
-- LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
-- ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
-- DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
-- INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
-- NOT APPLY TO YOU.

-- Notes
-- MDM_TODO: CDKWB0046I Statements are placed in the generated SQL file when user changes are required.
-- 1. Edit the following SQL files following any associated instructions.
-- 2. Connect to the database.
-- 3. Run each SQL file as shown below and in the same order.
-- 			sqlplus userid/password@host @MTTDBCustom_SETUP_ORACLE.sql
-- 			sqlplus userid/password@host @MTTDBCustom_TRIGGERS_ORACLE.sql
-- 			sqlplus userid/password@host @MTTDBCustom_CONSTRAINTS_ORACLE.sql
--			sqlplus userid/password@host @MTTDBCustom_ERRORS_100_ORACLE.sql
-- 			sqlplus userid/password@host @MTTDBCustom_MetaData_ORACLE.sql
-- 			sqlplus userid/password@host CONFIG_XMLSERVICES_RESPONSE_ORACLE.sql
-- 			sqlplus userid/password@host @MTTDBCustom_CODETABLES_ORACLE.sql


CREATE OR REPLACE TRIGGER MDMDB.i_MTT_ACCO9249a62a AFTER INSERT ON MDMDB.MTT_ACCOUNT_REPORTING
  REFERENCING NEW AS NEW OLD AS OLD
  FOR EACH ROW BEGIN
    INSERT INTO MDMDB.H_MTT_ACCOUNT_REPORTING
    ( H_MTT_ACT_REPORTING_ID
    , h_action_code
    , h_created_by
    , h_create_dt
    , h_end_dt
    , MTT_ACT_REPORTING_ID
    , CHANNEL_GRP_TP_CD
    , GOV_CONTRACT_IND
    , CAPRICORN_NUM
    , IGAD_PERISHABLE_IND
    , AGENT_NUM_TP_CD
    , USER_LOCALITY_TP_CD
    , CUS_CLASS_TP_CD
    , SHOW_PRICES_ON_WEB_IND
    , CONTRACT_ID
    , EXPORT_CUS_IND
    , last_update_dt
    , last_update_tx_id
    , last_update_user
    ) VALUES
    ( :NEW.MTT_ACT_REPORTING_ID
    , 'I'
    , NVL(:NEW.last_update_user,'-')
	, :NEW.last_update_dt
    , NULL
    , :NEW.MTT_ACT_REPORTING_ID
    , :NEW.CHANNEL_GRP_TP_CD
    , :NEW.GOV_CONTRACT_IND
    , :NEW.CAPRICORN_NUM
    , :NEW.IGAD_PERISHABLE_IND
    , :NEW.AGENT_NUM_TP_CD
    , :NEW.USER_LOCALITY_TP_CD
    , :NEW.CUS_CLASS_TP_CD
    , :NEW.SHOW_PRICES_ON_WEB_IND
    , :NEW.CONTRACT_ID
    , :NEW.EXPORT_CUS_IND
    , :NEW.last_update_dt
    , :NEW.last_update_tx_id
    , :NEW.last_update_user
    );
  END;
/

CREATE OR REPLACE TRIGGER MDMDB.u_MTT_ACCO9249a62a AFTER UPDATE ON MDMDB.MTT_ACCOUNT_REPORTING
  REFERENCING NEW AS NEW OLD AS OLD
  FOR EACH ROW
  DECLARE new_last_update_dt timestamp;
  BEGIN
  
  select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        

    UPDATE MDMDB.H_MTT_ACCOUNT_REPORTING
        SET h_end_dt = new_last_update_dt WHERE 
            H_MTT_ACT_REPORTING_ID=:NEW.MTT_ACT_REPORTING_ID AND 
            (h_action_code='U' or h_action_code='I') AND 
            h_end_dt IS NULL ;
            
    INSERT INTO MDMDB.H_MTT_ACCOUNT_REPORTING
    ( H_MTT_ACT_REPORTING_ID
    , h_action_code
    , h_created_by
    , h_create_dt
    , h_end_dt
    , MTT_ACT_REPORTING_ID
    , CHANNEL_GRP_TP_CD
    , GOV_CONTRACT_IND
    , CAPRICORN_NUM
    , IGAD_PERISHABLE_IND
    , AGENT_NUM_TP_CD
    , USER_LOCALITY_TP_CD
    , CUS_CLASS_TP_CD
    , SHOW_PRICES_ON_WEB_IND
    , CONTRACT_ID
    , EXPORT_CUS_IND
    , last_update_dt
    , last_update_tx_id
    , last_update_user
    ) VALUES
    ( :NEW.MTT_ACT_REPORTING_ID
    , 'U'
	, NVL(:NEW.last_update_user,'-')
	, :NEW.last_update_dt 
    , NULL
    , :NEW.MTT_ACT_REPORTING_ID
    , :NEW.CHANNEL_GRP_TP_CD
    , :NEW.GOV_CONTRACT_IND
    , :NEW.CAPRICORN_NUM
    , :NEW.IGAD_PERISHABLE_IND
    , :NEW.AGENT_NUM_TP_CD
    , :NEW.USER_LOCALITY_TP_CD
    , :NEW.CUS_CLASS_TP_CD
    , :NEW.SHOW_PRICES_ON_WEB_IND
    , :NEW.CONTRACT_ID
    , :NEW.EXPORT_CUS_IND
    , :NEW.last_update_dt
    , :NEW.last_update_tx_id
    , :NEW.last_update_user
    );
  END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_MTT_IDENTIFIER AFTER INSERT ON MDMDB.MTT_IDENTIFIER
  REFERENCING NEW AS NEW OLD AS OLD
  FOR EACH ROW BEGIN
    INSERT INTO MDMDB.H_MTT_IDENTIFIER
    ( H_MTT_IDENTIFIER_ID
    , h_action_code
    , h_created_by
    , h_create_dt
    , h_end_dt
    , MTT_IDENTIFIER_ID
    , IDENTIFIER_ID
    , IDENTIFIER_SUB_TP_CD
    , START_DT
    , END_DT
    , EXPIRY_DT
    , DESCRIPTION
    , last_update_dt
    , last_update_tx_id
    , last_update_user
    ) VALUES
    ( :NEW.MTT_IDENTIFIER_ID
    , 'I'
    , NVL(:NEW.last_update_user,'-')
	, :NEW.last_update_dt
    , NULL
    , :NEW.MTT_IDENTIFIER_ID
    , :NEW.IDENTIFIER_ID
    , :NEW.IDENTIFIER_SUB_TP_CD
    , :NEW.START_DT
    , :NEW.END_DT
    , :NEW.EXPIRY_DT
    , :NEW.DESCRIPTION
    , :NEW.last_update_dt
    , :NEW.last_update_tx_id
    , :NEW.last_update_user
    );
  END;
/

CREATE OR REPLACE TRIGGER MDMDB.u_MTT_IDENTIFIER AFTER UPDATE ON MDMDB.MTT_IDENTIFIER
  REFERENCING NEW AS NEW OLD AS OLD
  FOR EACH ROW
  DECLARE new_last_update_dt timestamp;
  BEGIN
  
  select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        

    UPDATE MDMDB.H_MTT_IDENTIFIER
        SET h_end_dt = new_last_update_dt WHERE 
            H_MTT_IDENTIFIER_ID=:NEW.MTT_IDENTIFIER_ID AND 
            (h_action_code='U' or h_action_code='I') AND 
            h_end_dt IS NULL ;
            
    INSERT INTO MDMDB.H_MTT_IDENTIFIER
    ( H_MTT_IDENTIFIER_ID
    , h_action_code
    , h_created_by
    , h_create_dt
    , h_end_dt
    , MTT_IDENTIFIER_ID
    , IDENTIFIER_ID
    , IDENTIFIER_SUB_TP_CD
    , START_DT
    , END_DT
    , EXPIRY_DT
    , DESCRIPTION
    , last_update_dt
    , last_update_tx_id
    , last_update_user
    ) VALUES
    ( :NEW.MTT_IDENTIFIER_ID
    , 'U'
	, NVL(:NEW.last_update_user,'-')
	, :NEW.last_update_dt 
    , NULL
    , :NEW.MTT_IDENTIFIER_ID
    , :NEW.IDENTIFIER_ID
    , :NEW.IDENTIFIER_SUB_TP_CD
    , :NEW.START_DT
    , :NEW.END_DT
    , :NEW.EXPIRY_DT
    , :NEW.DESCRIPTION
    , :NEW.last_update_dt
    , :NEW.last_update_tx_id
    , :NEW.last_update_user
    );
  END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_MTT_STORE AFTER INSERT ON MDMDB.MTT_STORE
  REFERENCING NEW AS NEW OLD AS OLD
  FOR EACH ROW BEGIN
    INSERT INTO MDMDB.H_MTT_STORE
    ( H_MTT_STORE_ID
    , h_action_code
    , h_created_by
    , h_create_dt
    , h_end_dt
    , MTT_STORE_ID
    , CONT_ID
    , MSO_TP_CD
    , STORE_OPEN_DT
    , STORE_CLOSE_DT
    , last_update_dt
    , last_update_tx_id
    , last_update_user
    ) VALUES
    ( :NEW.MTT_STORE_ID
    , 'I'
    , NVL(:NEW.last_update_user,'-')
	, :NEW.last_update_dt
    , NULL
    , :NEW.MTT_STORE_ID
    , :NEW.CONT_ID
    , :NEW.MSO_TP_CD
    , :NEW.STORE_OPEN_DT
    , :NEW.STORE_CLOSE_DT
    , :NEW.last_update_dt
    , :NEW.last_update_tx_id
    , :NEW.last_update_user
    );
  END;
/

CREATE OR REPLACE TRIGGER MDMDB.u_MTT_STORE AFTER UPDATE ON MDMDB.MTT_STORE
  REFERENCING NEW AS NEW OLD AS OLD
  FOR EACH ROW
  DECLARE new_last_update_dt timestamp;
  BEGIN
  
  select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        

    UPDATE MDMDB.H_MTT_STORE
        SET h_end_dt = new_last_update_dt WHERE 
            H_MTT_STORE_ID=:NEW.MTT_STORE_ID AND 
            (h_action_code='U' or h_action_code='I') AND 
            h_end_dt IS NULL ;
            
    INSERT INTO MDMDB.H_MTT_STORE
    ( H_MTT_STORE_ID
    , h_action_code
    , h_created_by
    , h_create_dt
    , h_end_dt
    , MTT_STORE_ID
    , CONT_ID
    , MSO_TP_CD
    , STORE_OPEN_DT
    , STORE_CLOSE_DT
    , last_update_dt
    , last_update_tx_id
    , last_update_user
    ) VALUES
    ( :NEW.MTT_STORE_ID
    , 'U'
	, NVL(:NEW.last_update_user,'-')
	, :NEW.last_update_dt 
    , NULL
    , :NEW.MTT_STORE_ID
    , :NEW.CONT_ID
    , :NEW.MSO_TP_CD
    , :NEW.STORE_OPEN_DT
    , :NEW.STORE_CLOSE_DT
    , :NEW.last_update_dt
    , :NEW.last_update_tx_id
    , :NEW.last_update_user
    );
  END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_MTT_ACCO223420a9 AFTER INSERT ON MDMDB.MTT_ACCOUNT_CREDIT_TAX
  REFERENCING NEW AS NEW OLD AS OLD
  FOR EACH ROW BEGIN
    INSERT INTO MDMDB.H_MTT_ACCOUNT_CREDIT_TAX
    ( H_MTT_ACT_CREDIT_TAX_ID
    , h_action_code
    , h_created_by
    , h_create_dt
    , h_end_dt
    , MTT_ACT_CREDIT_TAX_ID
    , CONTRACT_ID
    , INV_TERMS_TP_CD
    , GST_EXEMPT_IND
    , CUS_GRP_TP_CD
    , BANK_GUARANTEE_AMT
    , BANK_GUARANTEE_END_DT
    , CASH_DEPOSIT_AMT
    , CASH_DEPOSIT_RECV_DT
    , CASH_DEPOSIT_REL_DT
    , FIRST_MORTGAGE
    , SECOND_MORTGAGE
    , DEED_OF_PRIORITY
    , PPSR_DETAILS
    , PMSI_DETAILS
    , ALLPAP_DETAILS
    , ARREARS
    , CREDIT_HOLD
    , NATIONAL_HOLD
    , CREDIT_HOLD_DT
    , CREDIT_STATUS_OVERRIDE
    , CHEQUE_LIMIT_AMT
    , CHEQUE_LIMIT_CURRENCY_TP_CD
    , WET_EXEMPT_IND
    , DUTY_FREE_IND
    , CASH_ON_DELIVERY_IND
    , SALES_REP_TP_CD
    , last_update_dt
    , last_update_tx_id
    , last_update_user
    ) VALUES
    ( :NEW.MTT_ACT_CREDIT_TAX_ID
    , 'I'
    , NVL(:NEW.last_update_user,'-')
	, :NEW.last_update_dt
    , NULL
    , :NEW.MTT_ACT_CREDIT_TAX_ID
    , :NEW.CONTRACT_ID
    , :NEW.INV_TERMS_TP_CD
    , :NEW.GST_EXEMPT_IND
    , :NEW.CUS_GRP_TP_CD
    , :NEW.BANK_GUARANTEE_AMT
    , :NEW.BANK_GUARANTEE_END_DT
    , :NEW.CASH_DEPOSIT_AMT
    , :NEW.CASH_DEPOSIT_RECV_DT
    , :NEW.CASH_DEPOSIT_REL_DT
    , :NEW.FIRST_MORTGAGE
    , :NEW.SECOND_MORTGAGE
    , :NEW.DEED_OF_PRIORITY
    , :NEW.PPSR_DETAILS
    , :NEW.PMSI_DETAILS
    , :NEW.ALLPAP_DETAILS
    , :NEW.ARREARS
    , :NEW.CREDIT_HOLD
    , :NEW.NATIONAL_HOLD
    , :NEW.CREDIT_HOLD_DT
    , :NEW.CREDIT_STATUS_OVERRIDE
    , :NEW.CHEQUE_LIMIT_AMT
    , :NEW.CHEQUE_LIMIT_CURRENCY_TP_CD
    , :NEW.WET_EXEMPT_IND
    , :NEW.DUTY_FREE_IND
    , :NEW.CASH_ON_DELIVERY_IND
    , :NEW.SALES_REP_TP_CD
    , :NEW.last_update_dt
    , :NEW.last_update_tx_id
    , :NEW.last_update_user
    );
  END;
/

CREATE OR REPLACE TRIGGER MDMDB.u_MTT_ACCO223420a9 AFTER UPDATE ON MDMDB.MTT_ACCOUNT_CREDIT_TAX
  REFERENCING NEW AS NEW OLD AS OLD
  FOR EACH ROW
  DECLARE new_last_update_dt timestamp;
  BEGIN
  
  select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        

    UPDATE MDMDB.H_MTT_ACCOUNT_CREDIT_TAX
        SET h_end_dt = new_last_update_dt WHERE 
            H_MTT_ACT_CREDIT_TAX_ID=:NEW.MTT_ACT_CREDIT_TAX_ID AND 
            (h_action_code='U' or h_action_code='I') AND 
            h_end_dt IS NULL ;
            
    INSERT INTO MDMDB.H_MTT_ACCOUNT_CREDIT_TAX
    ( H_MTT_ACT_CREDIT_TAX_ID
    , h_action_code
    , h_created_by
    , h_create_dt
    , h_end_dt
    , MTT_ACT_CREDIT_TAX_ID
    , CONTRACT_ID
    , INV_TERMS_TP_CD
    , GST_EXEMPT_IND
    , CUS_GRP_TP_CD
    , BANK_GUARANTEE_AMT
    , BANK_GUARANTEE_END_DT
    , CASH_DEPOSIT_AMT
    , CASH_DEPOSIT_RECV_DT
    , CASH_DEPOSIT_REL_DT
    , FIRST_MORTGAGE
    , SECOND_MORTGAGE
    , DEED_OF_PRIORITY
    , PPSR_DETAILS
    , PMSI_DETAILS
    , ALLPAP_DETAILS
    , ARREARS
    , CREDIT_HOLD
    , NATIONAL_HOLD
    , CREDIT_HOLD_DT
    , CREDIT_STATUS_OVERRIDE
    , CHEQUE_LIMIT_AMT
    , CHEQUE_LIMIT_CURRENCY_TP_CD
    , WET_EXEMPT_IND
    , DUTY_FREE_IND
    , CASH_ON_DELIVERY_IND
    , SALES_REP_TP_CD
    , last_update_dt
    , last_update_tx_id
    , last_update_user
    ) VALUES
    ( :NEW.MTT_ACT_CREDIT_TAX_ID
    , 'U'
	, NVL(:NEW.last_update_user,'-')
	, :NEW.last_update_dt 
    , NULL
    , :NEW.MTT_ACT_CREDIT_TAX_ID
    , :NEW.CONTRACT_ID
    , :NEW.INV_TERMS_TP_CD
    , :NEW.GST_EXEMPT_IND
    , :NEW.CUS_GRP_TP_CD
    , :NEW.BANK_GUARANTEE_AMT
    , :NEW.BANK_GUARANTEE_END_DT
    , :NEW.CASH_DEPOSIT_AMT
    , :NEW.CASH_DEPOSIT_RECV_DT
    , :NEW.CASH_DEPOSIT_REL_DT
    , :NEW.FIRST_MORTGAGE
    , :NEW.SECOND_MORTGAGE
    , :NEW.DEED_OF_PRIORITY
    , :NEW.PPSR_DETAILS
    , :NEW.PMSI_DETAILS
    , :NEW.ALLPAP_DETAILS
    , :NEW.ARREARS
    , :NEW.CREDIT_HOLD
    , :NEW.NATIONAL_HOLD
    , :NEW.CREDIT_HOLD_DT
    , :NEW.CREDIT_STATUS_OVERRIDE
    , :NEW.CHEQUE_LIMIT_AMT
    , :NEW.CHEQUE_LIMIT_CURRENCY_TP_CD
    , :NEW.WET_EXEMPT_IND
    , :NEW.DUTY_FREE_IND
    , :NEW.CASH_ON_DELIVERY_IND
    , :NEW.SALES_REP_TP_CD
    , :NEW.last_update_dt
    , :NEW.last_update_tx_id
    , :NEW.last_update_user
    );
  END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_MTT_ACCOf5e15918 AFTER INSERT ON MDMDB.MTT_ACCOUNT_ORDER_INVOICE
  REFERENCING NEW AS NEW OLD AS OLD
  FOR EACH ROW BEGIN
    INSERT INTO MDMDB.H_MTT_ACCOUNT_ORDER_INVOICE
    ( H_MTT_ACT_ORDER_INV_ID
    , h_action_code
    , h_created_by
    , h_create_dt
    , h_end_dt
    , MTT_ACT_ORDER_INV_ID
    , CONTRACT_ID
    , PRN_RETAIL_IND
    , PRN_PRICE_MATCH_SUMMARY_IND
    , SUBSTITUTE_ITEM_IND
    , INV_SEQ_TP_CD
    , INV_COPIES_NUM
    , INV_MODE_TP_CD
    , ORDER_GUIDE_TP_CD
    , SEP_ORDER_ITEM_RESRV_IND
    , SPECIAL_INSTRUCTIONS
    , PRN_CAT_INV_BRK_TP_CD
    , INV_RECAP_SUMMARY_TP_CD
    , PO_NUM_REQ_IND
    , PICKUP_DELIVER_TP_CD
    , PRN_ALT_TOBACCO_LICENCE_IND
    , TOTES_IND
    , TOTES_TP_CD
    , UNIT_CASE_COST_PRN_TP_CD
    , INV_FORMAT_TP_CD
    , PICK_EACHES_IND
    , INV_TP_CD
    , INV_STOP_MSG
    , DEL_PICK_PACK_INV_TP_CD
    , PRN_HO_INV_IND
    , PRN_WHOLESALE_ON_INV_IND
    , SEP_INV_PER_CUS_PO_IND
    , ASN_REQ_IND
    , EASNMailbox
    , last_update_dt
    , last_update_tx_id
    , last_update_user
    ) VALUES
    ( :NEW.MTT_ACT_ORDER_INV_ID
    , 'I'
    , NVL(:NEW.last_update_user,'-')
	, :NEW.last_update_dt
    , NULL
    , :NEW.MTT_ACT_ORDER_INV_ID
    , :NEW.CONTRACT_ID
    , :NEW.PRN_RETAIL_IND
    , :NEW.PRN_PRICE_MATCH_SUMMARY_IND
    , :NEW.SUBSTITUTE_ITEM_IND
    , :NEW.INV_SEQ_TP_CD
    , :NEW.INV_COPIES_NUM
    , :NEW.INV_MODE_TP_CD
    , :NEW.ORDER_GUIDE_TP_CD
    , :NEW.SEP_ORDER_ITEM_RESRV_IND
    , :NEW.SPECIAL_INSTRUCTIONS
    , :NEW.PRN_CAT_INV_BRK_TP_CD
    , :NEW.INV_RECAP_SUMMARY_TP_CD
    , :NEW.PO_NUM_REQ_IND
    , :NEW.PICKUP_DELIVER_TP_CD
    , :NEW.PRN_ALT_TOBACCO_LICENCE_IND
    , :NEW.TOTES_IND
    , :NEW.TOTES_TP_CD
    , :NEW.UNIT_CASE_COST_PRN_TP_CD
    , :NEW.INV_FORMAT_TP_CD
    , :NEW.PICK_EACHES_IND
    , :NEW.INV_TP_CD
    , :NEW.INV_STOP_MSG
    , :NEW.DEL_PICK_PACK_INV_TP_CD
    , :NEW.PRN_HO_INV_IND
    , :NEW.PRN_WHOLESALE_ON_INV_IND
    , :NEW.SEP_INV_PER_CUS_PO_IND
    , :NEW.ASN_REQ_IND
    , :NEW.EASNMailbox
    , :NEW.last_update_dt
    , :NEW.last_update_tx_id
    , :NEW.last_update_user
    );
  END;
/

CREATE OR REPLACE TRIGGER MDMDB.u_MTT_ACCOf5e15918 AFTER UPDATE ON MDMDB.MTT_ACCOUNT_ORDER_INVOICE
  REFERENCING NEW AS NEW OLD AS OLD
  FOR EACH ROW
  DECLARE new_last_update_dt timestamp;
  BEGIN
  
  select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        

    UPDATE MDMDB.H_MTT_ACCOUNT_ORDER_INVOICE
        SET h_end_dt = new_last_update_dt WHERE 
            H_MTT_ACT_ORDER_INV_ID=:NEW.MTT_ACT_ORDER_INV_ID AND 
            (h_action_code='U' or h_action_code='I') AND 
            h_end_dt IS NULL ;
            
    INSERT INTO MDMDB.H_MTT_ACCOUNT_ORDER_INVOICE
    ( H_MTT_ACT_ORDER_INV_ID
    , h_action_code
    , h_created_by
    , h_create_dt
    , h_end_dt
    , MTT_ACT_ORDER_INV_ID
    , CONTRACT_ID
    , PRN_RETAIL_IND
    , PRN_PRICE_MATCH_SUMMARY_IND
    , SUBSTITUTE_ITEM_IND
    , INV_SEQ_TP_CD
    , INV_COPIES_NUM
    , INV_MODE_TP_CD
    , ORDER_GUIDE_TP_CD
    , SEP_ORDER_ITEM_RESRV_IND
    , SPECIAL_INSTRUCTIONS
    , PRN_CAT_INV_BRK_TP_CD
    , INV_RECAP_SUMMARY_TP_CD
    , PO_NUM_REQ_IND
    , PICKUP_DELIVER_TP_CD
    , PRN_ALT_TOBACCO_LICENCE_IND
    , TOTES_IND
    , TOTES_TP_CD
    , UNIT_CASE_COST_PRN_TP_CD
    , INV_FORMAT_TP_CD
    , PICK_EACHES_IND
    , INV_TP_CD
    , INV_STOP_MSG
    , DEL_PICK_PACK_INV_TP_CD
    , PRN_HO_INV_IND
    , PRN_WHOLESALE_ON_INV_IND
    , SEP_INV_PER_CUS_PO_IND
    , ASN_REQ_IND
    , EASNMailbox
    , last_update_dt
    , last_update_tx_id
    , last_update_user
    ) VALUES
    ( :NEW.MTT_ACT_ORDER_INV_ID
    , 'U'
	, NVL(:NEW.last_update_user,'-')
	, :NEW.last_update_dt 
    , NULL
    , :NEW.MTT_ACT_ORDER_INV_ID
    , :NEW.CONTRACT_ID
    , :NEW.PRN_RETAIL_IND
    , :NEW.PRN_PRICE_MATCH_SUMMARY_IND
    , :NEW.SUBSTITUTE_ITEM_IND
    , :NEW.INV_SEQ_TP_CD
    , :NEW.INV_COPIES_NUM
    , :NEW.INV_MODE_TP_CD
    , :NEW.ORDER_GUIDE_TP_CD
    , :NEW.SEP_ORDER_ITEM_RESRV_IND
    , :NEW.SPECIAL_INSTRUCTIONS
    , :NEW.PRN_CAT_INV_BRK_TP_CD
    , :NEW.INV_RECAP_SUMMARY_TP_CD
    , :NEW.PO_NUM_REQ_IND
    , :NEW.PICKUP_DELIVER_TP_CD
    , :NEW.PRN_ALT_TOBACCO_LICENCE_IND
    , :NEW.TOTES_IND
    , :NEW.TOTES_TP_CD
    , :NEW.UNIT_CASE_COST_PRN_TP_CD
    , :NEW.INV_FORMAT_TP_CD
    , :NEW.PICK_EACHES_IND
    , :NEW.INV_TP_CD
    , :NEW.INV_STOP_MSG
    , :NEW.DEL_PICK_PACK_INV_TP_CD
    , :NEW.PRN_HO_INV_IND
    , :NEW.PRN_WHOLESALE_ON_INV_IND
    , :NEW.SEP_INV_PER_CUS_PO_IND
    , :NEW.ASN_REQ_IND
    , :NEW.EASNMailbox
    , :NEW.last_update_dt
    , :NEW.last_update_tx_id
    , :NEW.last_update_user
    );
  END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_MTT_ACCO8917dc11 AFTER INSERT ON MDMDB.MTT_ACCOUNT_COST_CHARGES
  REFERENCING NEW AS NEW OLD AS OLD
  FOR EACH ROW BEGIN
    INSERT INTO MDMDB.H_MTT_ACCOUNT_COST_CHARGES
    ( H_MTT_ACT_COST_CHARGES_ID
    , h_action_code
    , h_created_by
    , h_create_dt
    , h_end_dt
    , MTT_ACT_COST_CHARGES_ID
    , CONTRACT_ID
    , COST_BASE_TP_CD
    , DIRECT_SHIP_APPROVED_IND
    , DO_NOT_APPLY_DIRECT_DISC_IND
    , SRP_COMPLIANCE_TP_CD
    , PRICE_MATCH_GAP_FEE_IND
    , BRKN_CASE_UPCHARGE_PCT
    , BRKN_CASE_UPCHARGE_CAP
    , BRKN_CASE_UPCHARGE_IND
    , BRKN_CASE_CALC_TP_CD
    , SHELF_LABEL_PRICED_IND
    , PSRP_TP_CD
    , ADD_FRT_RECOVERY_SRP_IND
    , SRP_FRT_RECOVERY_VAL
    , SRP_FRT_RECOVERY_DIR_VAL
    , last_update_dt
    , last_update_tx_id
    , last_update_user
    ) VALUES
    ( :NEW.MTT_ACT_COST_CHARGES_ID
    , 'I'
    , NVL(:NEW.last_update_user,'-')
	, :NEW.last_update_dt
    , NULL
    , :NEW.MTT_ACT_COST_CHARGES_ID
    , :NEW.CONTRACT_ID
    , :NEW.COST_BASE_TP_CD
    , :NEW.DIRECT_SHIP_APPROVED_IND
    , :NEW.DO_NOT_APPLY_DIRECT_DISC_IND
    , :NEW.SRP_COMPLIANCE_TP_CD
    , :NEW.PRICE_MATCH_GAP_FEE_IND
    , :NEW.BRKN_CASE_UPCHARGE_PCT
    , :NEW.BRKN_CASE_UPCHARGE_CAP
    , :NEW.BRKN_CASE_UPCHARGE_IND
    , :NEW.BRKN_CASE_CALC_TP_CD
    , :NEW.SHELF_LABEL_PRICED_IND
    , :NEW.PSRP_TP_CD
    , :NEW.ADD_FRT_RECOVERY_SRP_IND
    , :NEW.SRP_FRT_RECOVERY_VAL
    , :NEW.SRP_FRT_RECOVERY_DIR_VAL
    , :NEW.last_update_dt
    , :NEW.last_update_tx_id
    , :NEW.last_update_user
    );
  END;
/

CREATE OR REPLACE TRIGGER MDMDB.u_MTT_ACCO8917dc11 AFTER UPDATE ON MDMDB.MTT_ACCOUNT_COST_CHARGES
  REFERENCING NEW AS NEW OLD AS OLD
  FOR EACH ROW
  DECLARE new_last_update_dt timestamp;
  BEGIN
  
  select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        

    UPDATE MDMDB.H_MTT_ACCOUNT_COST_CHARGES
        SET h_end_dt = new_last_update_dt WHERE 
            H_MTT_ACT_COST_CHARGES_ID=:NEW.MTT_ACT_COST_CHARGES_ID AND 
            (h_action_code='U' or h_action_code='I') AND 
            h_end_dt IS NULL ;
            
    INSERT INTO MDMDB.H_MTT_ACCOUNT_COST_CHARGES
    ( H_MTT_ACT_COST_CHARGES_ID
    , h_action_code
    , h_created_by
    , h_create_dt
    , h_end_dt
    , MTT_ACT_COST_CHARGES_ID
    , CONTRACT_ID
    , COST_BASE_TP_CD
    , DIRECT_SHIP_APPROVED_IND
    , DO_NOT_APPLY_DIRECT_DISC_IND
    , SRP_COMPLIANCE_TP_CD
    , PRICE_MATCH_GAP_FEE_IND
    , BRKN_CASE_UPCHARGE_PCT
    , BRKN_CASE_UPCHARGE_CAP
    , BRKN_CASE_UPCHARGE_IND
    , BRKN_CASE_CALC_TP_CD
    , SHELF_LABEL_PRICED_IND
    , PSRP_TP_CD
    , ADD_FRT_RECOVERY_SRP_IND
    , SRP_FRT_RECOVERY_VAL
    , SRP_FRT_RECOVERY_DIR_VAL
    , last_update_dt
    , last_update_tx_id
    , last_update_user
    ) VALUES
    ( :NEW.MTT_ACT_COST_CHARGES_ID
    , 'U'
	, NVL(:NEW.last_update_user,'-')
	, :NEW.last_update_dt 
    , NULL
    , :NEW.MTT_ACT_COST_CHARGES_ID
    , :NEW.CONTRACT_ID
    , :NEW.COST_BASE_TP_CD
    , :NEW.DIRECT_SHIP_APPROVED_IND
    , :NEW.DO_NOT_APPLY_DIRECT_DISC_IND
    , :NEW.SRP_COMPLIANCE_TP_CD
    , :NEW.PRICE_MATCH_GAP_FEE_IND
    , :NEW.BRKN_CASE_UPCHARGE_PCT
    , :NEW.BRKN_CASE_UPCHARGE_CAP
    , :NEW.BRKN_CASE_UPCHARGE_IND
    , :NEW.BRKN_CASE_CALC_TP_CD
    , :NEW.SHELF_LABEL_PRICED_IND
    , :NEW.PSRP_TP_CD
    , :NEW.ADD_FRT_RECOVERY_SRP_IND
    , :NEW.SRP_FRT_RECOVERY_VAL
    , :NEW.SRP_FRT_RECOVERY_DIR_VAL
    , :NEW.last_update_dt
    , :NEW.last_update_tx_id
    , :NEW.last_update_user
    );
  END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_MTT_ACCObca8bc85 AFTER INSERT ON MDMDB.MTT_ACCOUNT_FINANCIAL
  REFERENCING NEW AS NEW OLD AS OLD
  FOR EACH ROW BEGIN
    INSERT INTO MDMDB.H_MTT_ACCOUNT_FINANCIAL
    ( H_MTT_ACT_FINANCIAL_ID
    , h_action_code
    , h_created_by
    , h_create_dt
    , h_end_dt
    , MTT_ACT_FINANCIAL_ID
    , CONTRACT_ID
    , STATEMENT_MODE_TP_CD
    , DUE_GRACE_DAYS_TP_CD
    , TOBACCO_GRACE_DAYS_TP_CD
    , BANK_TP_CD
    , BPAY_IND
    , STATEMENT_PRN_HOLD_IND
    , BPAY_CUS_REF_NUM
    , COLLECTOR_TP_CD
    , BANK_ACCOUNT_TP_CD
    , EXT_TERMS_BY_SHIPDATE_IND
    , SETTLEMENT_DISC_IND
    , ACCOUNT_DETAILS
    , DISC_GRACE_DAYS_TP_CD
    , PAYMENT_METHOD_TP_CD
    , LMAA_NUM
    , last_update_dt
    , last_update_tx_id
    , last_update_user
    ) VALUES
    ( :NEW.MTT_ACT_FINANCIAL_ID
    , 'I'
    , NVL(:NEW.last_update_user,'-')
	, :NEW.last_update_dt
    , NULL
    , :NEW.MTT_ACT_FINANCIAL_ID
    , :NEW.CONTRACT_ID
    , :NEW.STATEMENT_MODE_TP_CD
    , :NEW.DUE_GRACE_DAYS_TP_CD
    , :NEW.TOBACCO_GRACE_DAYS_TP_CD
    , :NEW.BANK_TP_CD
    , :NEW.BPAY_IND
    , :NEW.STATEMENT_PRN_HOLD_IND
    , :NEW.BPAY_CUS_REF_NUM
    , :NEW.COLLECTOR_TP_CD
    , :NEW.BANK_ACCOUNT_TP_CD
    , :NEW.EXT_TERMS_BY_SHIPDATE_IND
    , :NEW.SETTLEMENT_DISC_IND
    , :NEW.ACCOUNT_DETAILS
    , :NEW.DISC_GRACE_DAYS_TP_CD
    , :NEW.PAYMENT_METHOD_TP_CD
    , :NEW.LMAA_NUM
    , :NEW.last_update_dt
    , :NEW.last_update_tx_id
    , :NEW.last_update_user
    );
  END;
/

CREATE OR REPLACE TRIGGER MDMDB.u_MTT_ACCObca8bc85 AFTER UPDATE ON MDMDB.MTT_ACCOUNT_FINANCIAL
  REFERENCING NEW AS NEW OLD AS OLD
  FOR EACH ROW
  DECLARE new_last_update_dt timestamp;
  BEGIN
  
  select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        

    UPDATE MDMDB.H_MTT_ACCOUNT_FINANCIAL
        SET h_end_dt = new_last_update_dt WHERE 
            H_MTT_ACT_FINANCIAL_ID=:NEW.MTT_ACT_FINANCIAL_ID AND 
            (h_action_code='U' or h_action_code='I') AND 
            h_end_dt IS NULL ;
            
    INSERT INTO MDMDB.H_MTT_ACCOUNT_FINANCIAL
    ( H_MTT_ACT_FINANCIAL_ID
    , h_action_code
    , h_created_by
    , h_create_dt
    , h_end_dt
    , MTT_ACT_FINANCIAL_ID
    , CONTRACT_ID
    , STATEMENT_MODE_TP_CD
    , DUE_GRACE_DAYS_TP_CD
    , TOBACCO_GRACE_DAYS_TP_CD
    , BANK_TP_CD
    , BPAY_IND
    , STATEMENT_PRN_HOLD_IND
    , BPAY_CUS_REF_NUM
    , COLLECTOR_TP_CD
    , BANK_ACCOUNT_TP_CD
    , EXT_TERMS_BY_SHIPDATE_IND
    , SETTLEMENT_DISC_IND
    , ACCOUNT_DETAILS
    , DISC_GRACE_DAYS_TP_CD
    , PAYMENT_METHOD_TP_CD
    , LMAA_NUM
    , last_update_dt
    , last_update_tx_id
    , last_update_user
    ) VALUES
    ( :NEW.MTT_ACT_FINANCIAL_ID
    , 'U'
	, NVL(:NEW.last_update_user,'-')
	, :NEW.last_update_dt 
    , NULL
    , :NEW.MTT_ACT_FINANCIAL_ID
    , :NEW.CONTRACT_ID
    , :NEW.STATEMENT_MODE_TP_CD
    , :NEW.DUE_GRACE_DAYS_TP_CD
    , :NEW.TOBACCO_GRACE_DAYS_TP_CD
    , :NEW.BANK_TP_CD
    , :NEW.BPAY_IND
    , :NEW.STATEMENT_PRN_HOLD_IND
    , :NEW.BPAY_CUS_REF_NUM
    , :NEW.COLLECTOR_TP_CD
    , :NEW.BANK_ACCOUNT_TP_CD
    , :NEW.EXT_TERMS_BY_SHIPDATE_IND
    , :NEW.SETTLEMENT_DISC_IND
    , :NEW.ACCOUNT_DETAILS
    , :NEW.DISC_GRACE_DAYS_TP_CD
    , :NEW.PAYMENT_METHOD_TP_CD
    , :NEW.LMAA_NUM
    , :NEW.last_update_dt
    , :NEW.last_update_tx_id
    , :NEW.last_update_user
    );
  END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_XCDCHANNELGRPTP AFTER INSERT ON MDMDB.XCDCHANNELGRPTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW BEGIN
	INSERT INTO MDMDB.H_XCDCHANNELGRPTP
	( 
	h_lang_tp_cd
	, 
	  h_channel_grp_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, channel_grp_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.channel_grp_tp_cd
	, 'I'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.channel_grp_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/
	
CREATE OR REPLACE TRIGGER MDMDB.u_XCDCHANNELGRPTP AFTER UPDATE ON MDMDB.XCDCHANNELGRPTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW
	DECLARE new_last_update_dt timestamp;
	BEGIN
	
	select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        
	
	UPDATE MDMDB.H_XCDCHANNELGRPTP
		SET h_end_dt = new_last_update_dt
		WHERE h_lang_tp_cd=:NEW.lang_tp_cd AND
			h_channel_grp_tp_cd=:NEW.channel_grp_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
			
	INSERT INTO MDMDB.H_XCDCHANNELGRPTP
	( 
	h_lang_tp_cd
	, 
	h_channel_grp_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, channel_grp_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.channel_grp_tp_cd
	, 'U'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.channel_grp_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_XCDAGENTNUMTP AFTER INSERT ON MDMDB.XCDAGENTNUMTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW BEGIN
	INSERT INTO MDMDB.H_XCDAGENTNUMTP
	( 
	h_lang_tp_cd
	, 
	  h_agent_num_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, agent_num_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.agent_num_tp_cd
	, 'I'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.agent_num_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/
	
CREATE OR REPLACE TRIGGER MDMDB.u_XCDAGENTNUMTP AFTER UPDATE ON MDMDB.XCDAGENTNUMTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW
	DECLARE new_last_update_dt timestamp;
	BEGIN
	
	select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        
	
	UPDATE MDMDB.H_XCDAGENTNUMTP
		SET h_end_dt = new_last_update_dt
		WHERE h_lang_tp_cd=:NEW.lang_tp_cd AND
			h_agent_num_tp_cd=:NEW.agent_num_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
			
	INSERT INTO MDMDB.H_XCDAGENTNUMTP
	( 
	h_lang_tp_cd
	, 
	h_agent_num_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, agent_num_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.agent_num_tp_cd
	, 'U'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.agent_num_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_XCDUSERL2447a823 AFTER INSERT ON MDMDB.XCDUSERLOCALITYTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW BEGIN
	INSERT INTO MDMDB.H_XCDUSERLOCALITYTP
	( 
	h_lang_tp_cd
	, 
	  h_user_locality_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, user_locality_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.user_locality_tp_cd
	, 'I'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.user_locality_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/
	
CREATE OR REPLACE TRIGGER MDMDB.u_XCDUSERL2447a823 AFTER UPDATE ON MDMDB.XCDUSERLOCALITYTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW
	DECLARE new_last_update_dt timestamp;
	BEGIN
	
	select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        
	
	UPDATE MDMDB.H_XCDUSERLOCALITYTP
		SET h_end_dt = new_last_update_dt
		WHERE h_lang_tp_cd=:NEW.lang_tp_cd AND
			h_user_locality_tp_cd=:NEW.user_locality_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
			
	INSERT INTO MDMDB.H_XCDUSERLOCALITYTP
	( 
	h_lang_tp_cd
	, 
	h_user_locality_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, user_locality_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.user_locality_tp_cd
	, 'U'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.user_locality_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_XCDCUSCLASSTP AFTER INSERT ON MDMDB.XCDCUSCLASSTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW BEGIN
	INSERT INTO MDMDB.H_XCDCUSCLASSTP
	( 
	h_lang_tp_cd
	, 
	  h_cus_class_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, cus_class_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.cus_class_tp_cd
	, 'I'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.cus_class_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/
	
CREATE OR REPLACE TRIGGER MDMDB.u_XCDCUSCLASSTP AFTER UPDATE ON MDMDB.XCDCUSCLASSTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW
	DECLARE new_last_update_dt timestamp;
	BEGIN
	
	select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        
	
	UPDATE MDMDB.H_XCDCUSCLASSTP
		SET h_end_dt = new_last_update_dt
		WHERE h_lang_tp_cd=:NEW.lang_tp_cd AND
			h_cus_class_tp_cd=:NEW.cus_class_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
			
	INSERT INTO MDMDB.H_XCDCUSCLASSTP
	( 
	h_lang_tp_cd
	, 
	h_cus_class_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, cus_class_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.cus_class_tp_cd
	, 'U'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.cus_class_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_XCDINVTERMSTP AFTER INSERT ON MDMDB.XCDINVTERMSTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW BEGIN
	INSERT INTO MDMDB.H_XCDINVTERMSTP
	( 
	h_lang_tp_cd
	, 
	  h_inv_terms_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, inv_terms_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.inv_terms_tp_cd
	, 'I'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.inv_terms_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/
	
CREATE OR REPLACE TRIGGER MDMDB.u_XCDINVTERMSTP AFTER UPDATE ON MDMDB.XCDINVTERMSTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW
	DECLARE new_last_update_dt timestamp;
	BEGIN
	
	select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        
	
	UPDATE MDMDB.H_XCDINVTERMSTP
		SET h_end_dt = new_last_update_dt
		WHERE h_lang_tp_cd=:NEW.lang_tp_cd AND
			h_inv_terms_tp_cd=:NEW.inv_terms_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
			
	INSERT INTO MDMDB.H_XCDINVTERMSTP
	( 
	h_lang_tp_cd
	, 
	h_inv_terms_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, inv_terms_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.inv_terms_tp_cd
	, 'U'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.inv_terms_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_XCDCUSGRPTP AFTER INSERT ON MDMDB.XCDCUSGRPTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW BEGIN
	INSERT INTO MDMDB.H_XCDCUSGRPTP
	( 
	h_lang_tp_cd
	, 
	  h_cus_grp_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, cus_grp_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.cus_grp_tp_cd
	, 'I'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.cus_grp_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/
	
CREATE OR REPLACE TRIGGER MDMDB.u_XCDCUSGRPTP AFTER UPDATE ON MDMDB.XCDCUSGRPTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW
	DECLARE new_last_update_dt timestamp;
	BEGIN
	
	select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        
	
	UPDATE MDMDB.H_XCDCUSGRPTP
		SET h_end_dt = new_last_update_dt
		WHERE h_lang_tp_cd=:NEW.lang_tp_cd AND
			h_cus_grp_tp_cd=:NEW.cus_grp_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
			
	INSERT INTO MDMDB.H_XCDCUSGRPTP
	( 
	h_lang_tp_cd
	, 
	h_cus_grp_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, cus_grp_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.cus_grp_tp_cd
	, 'U'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.cus_grp_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_XCDINVSEQTP AFTER INSERT ON MDMDB.XCDINVSEQTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW BEGIN
	INSERT INTO MDMDB.H_XCDINVSEQTP
	( 
	h_lang_tp_cd
	, 
	  h_inv_seq_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, inv_seq_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.inv_seq_tp_cd
	, 'I'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.inv_seq_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/
	
CREATE OR REPLACE TRIGGER MDMDB.u_XCDINVSEQTP AFTER UPDATE ON MDMDB.XCDINVSEQTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW
	DECLARE new_last_update_dt timestamp;
	BEGIN
	
	select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        
	
	UPDATE MDMDB.H_XCDINVSEQTP
		SET h_end_dt = new_last_update_dt
		WHERE h_lang_tp_cd=:NEW.lang_tp_cd AND
			h_inv_seq_tp_cd=:NEW.inv_seq_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
			
	INSERT INTO MDMDB.H_XCDINVSEQTP
	( 
	h_lang_tp_cd
	, 
	h_inv_seq_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, inv_seq_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.inv_seq_tp_cd
	, 'U'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.inv_seq_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_XCDINVMODETP AFTER INSERT ON MDMDB.XCDINVMODETP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW BEGIN
	INSERT INTO MDMDB.H_XCDINVMODETP
	( 
	h_lang_tp_cd
	, 
	  h_inv_mode_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, inv_mode_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.inv_mode_tp_cd
	, 'I'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.inv_mode_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/
	
CREATE OR REPLACE TRIGGER MDMDB.u_XCDINVMODETP AFTER UPDATE ON MDMDB.XCDINVMODETP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW
	DECLARE new_last_update_dt timestamp;
	BEGIN
	
	select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        
	
	UPDATE MDMDB.H_XCDINVMODETP
		SET h_end_dt = new_last_update_dt
		WHERE h_lang_tp_cd=:NEW.lang_tp_cd AND
			h_inv_mode_tp_cd=:NEW.inv_mode_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
			
	INSERT INTO MDMDB.H_XCDINVMODETP
	( 
	h_lang_tp_cd
	, 
	h_inv_mode_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, inv_mode_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.inv_mode_tp_cd
	, 'U'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.inv_mode_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_XCDORDERGUIDETP AFTER INSERT ON MDMDB.XCDORDERGUIDETP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW BEGIN
	INSERT INTO MDMDB.H_XCDORDERGUIDETP
	( 
	h_lang_tp_cd
	, 
	  h_order_guide_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, order_guide_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.order_guide_tp_cd
	, 'I'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.order_guide_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/
	
CREATE OR REPLACE TRIGGER MDMDB.u_XCDORDERGUIDETP AFTER UPDATE ON MDMDB.XCDORDERGUIDETP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW
	DECLARE new_last_update_dt timestamp;
	BEGIN
	
	select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        
	
	UPDATE MDMDB.H_XCDORDERGUIDETP
		SET h_end_dt = new_last_update_dt
		WHERE h_lang_tp_cd=:NEW.lang_tp_cd AND
			h_order_guide_tp_cd=:NEW.order_guide_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
			
	INSERT INTO MDMDB.H_XCDORDERGUIDETP
	( 
	h_lang_tp_cd
	, 
	h_order_guide_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, order_guide_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.order_guide_tp_cd
	, 'U'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.order_guide_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_XCDPRNCAee1b1b29 AFTER INSERT ON MDMDB.XCDPRNCATINVBRKTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW BEGIN
	INSERT INTO MDMDB.H_XCDPRNCATINVBRKTP
	( 
	h_lang_tp_cd
	, 
	  h_prn_cat_inv_brk_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, prn_cat_inv_brk_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.prn_cat_inv_brk_tp_cd
	, 'I'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.prn_cat_inv_brk_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/
	
CREATE OR REPLACE TRIGGER MDMDB.u_XCDPRNCAee1b1b29 AFTER UPDATE ON MDMDB.XCDPRNCATINVBRKTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW
	DECLARE new_last_update_dt timestamp;
	BEGIN
	
	select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        
	
	UPDATE MDMDB.H_XCDPRNCATINVBRKTP
		SET h_end_dt = new_last_update_dt
		WHERE h_lang_tp_cd=:NEW.lang_tp_cd AND
			h_prn_cat_inv_brk_tp_cd=:NEW.prn_cat_inv_brk_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
			
	INSERT INTO MDMDB.H_XCDPRNCATINVBRKTP
	( 
	h_lang_tp_cd
	, 
	h_prn_cat_inv_brk_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, prn_cat_inv_brk_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.prn_cat_inv_brk_tp_cd
	, 'U'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.prn_cat_inv_brk_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_XCDINVRE5fc2bf3b AFTER INSERT ON MDMDB.XCDINVRECAPSUMMARYTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW BEGIN
	INSERT INTO MDMDB.H_XCDINVRECAPSUMMARYTP
	( 
	h_lang_tp_cd
	, 
	  h_inv_recap_summary_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, inv_recap_summary_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.inv_recap_summary_tp_cd
	, 'I'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.inv_recap_summary_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/
	
CREATE OR REPLACE TRIGGER MDMDB.u_XCDINVRE5fc2bf3b AFTER UPDATE ON MDMDB.XCDINVRECAPSUMMARYTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW
	DECLARE new_last_update_dt timestamp;
	BEGIN
	
	select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        
	
	UPDATE MDMDB.H_XCDINVRECAPSUMMARYTP
		SET h_end_dt = new_last_update_dt
		WHERE h_lang_tp_cd=:NEW.lang_tp_cd AND
			h_inv_recap_summary_tp_cd=:NEW.inv_recap_summary_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
			
	INSERT INTO MDMDB.H_XCDINVRECAPSUMMARYTP
	( 
	h_lang_tp_cd
	, 
	h_inv_recap_summary_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, inv_recap_summary_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.inv_recap_summary_tp_cd
	, 'U'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.inv_recap_summary_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_XCDPICKU2208c36c AFTER INSERT ON MDMDB.XCDPICKUPDELIVERTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW BEGIN
	INSERT INTO MDMDB.H_XCDPICKUPDELIVERTP
	( 
	h_lang_tp_cd
	, 
	  h_pickup_deliver_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, pickup_deliver_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.pickup_deliver_tp_cd
	, 'I'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.pickup_deliver_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/
	
CREATE OR REPLACE TRIGGER MDMDB.u_XCDPICKU2208c36c AFTER UPDATE ON MDMDB.XCDPICKUPDELIVERTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW
	DECLARE new_last_update_dt timestamp;
	BEGIN
	
	select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        
	
	UPDATE MDMDB.H_XCDPICKUPDELIVERTP
		SET h_end_dt = new_last_update_dt
		WHERE h_lang_tp_cd=:NEW.lang_tp_cd AND
			h_pickup_deliver_tp_cd=:NEW.pickup_deliver_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
			
	INSERT INTO MDMDB.H_XCDPICKUPDELIVERTP
	( 
	h_lang_tp_cd
	, 
	h_pickup_deliver_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, pickup_deliver_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.pickup_deliver_tp_cd
	, 'U'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.pickup_deliver_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_XCDUNITCfe703c8e AFTER INSERT ON MDMDB.XCDUNITCASECOSTPRNTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW BEGIN
	INSERT INTO MDMDB.H_XCDUNITCASECOSTPRNTP
	( 
	h_lang_tp_cd
	, 
	  h_unit_case_cost_prn_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, unit_case_cost_prn_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.unit_case_cost_prn_tp_cd
	, 'I'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.unit_case_cost_prn_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/
	
CREATE OR REPLACE TRIGGER MDMDB.u_XCDUNITCfe703c8e AFTER UPDATE ON MDMDB.XCDUNITCASECOSTPRNTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW
	DECLARE new_last_update_dt timestamp;
	BEGIN
	
	select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        
	
	UPDATE MDMDB.H_XCDUNITCASECOSTPRNTP
		SET h_end_dt = new_last_update_dt
		WHERE h_lang_tp_cd=:NEW.lang_tp_cd AND
			h_unit_case_cost_prn_tp_cd=:NEW.unit_case_cost_prn_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
			
	INSERT INTO MDMDB.H_XCDUNITCASECOSTPRNTP
	( 
	h_lang_tp_cd
	, 
	h_unit_case_cost_prn_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, unit_case_cost_prn_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.unit_case_cost_prn_tp_cd
	, 'U'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.unit_case_cost_prn_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_XCDINVFORMATTP AFTER INSERT ON MDMDB.XCDINVFORMATTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW BEGIN
	INSERT INTO MDMDB.H_XCDINVFORMATTP
	( 
	h_lang_tp_cd
	, 
	  h_inv_format_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, inv_format_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.inv_format_tp_cd
	, 'I'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.inv_format_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/
	
CREATE OR REPLACE TRIGGER MDMDB.u_XCDINVFORMATTP AFTER UPDATE ON MDMDB.XCDINVFORMATTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW
	DECLARE new_last_update_dt timestamp;
	BEGIN
	
	select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        
	
	UPDATE MDMDB.H_XCDINVFORMATTP
		SET h_end_dt = new_last_update_dt
		WHERE h_lang_tp_cd=:NEW.lang_tp_cd AND
			h_inv_format_tp_cd=:NEW.inv_format_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
			
	INSERT INTO MDMDB.H_XCDINVFORMATTP
	( 
	h_lang_tp_cd
	, 
	h_inv_format_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, inv_format_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.inv_format_tp_cd
	, 'U'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.inv_format_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_XCDDELPI1887cf41 AFTER INSERT ON MDMDB.XCDDELPICKPACKINVTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW BEGIN
	INSERT INTO MDMDB.H_XCDDELPICKPACKINVTP
	( 
	h_lang_tp_cd
	, 
	  h_del_pick_pack_inv_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, del_pick_pack_inv_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.del_pick_pack_inv_tp_cd
	, 'I'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.del_pick_pack_inv_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/
	
CREATE OR REPLACE TRIGGER MDMDB.u_XCDDELPI1887cf41 AFTER UPDATE ON MDMDB.XCDDELPICKPACKINVTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW
	DECLARE new_last_update_dt timestamp;
	BEGIN
	
	select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        
	
	UPDATE MDMDB.H_XCDDELPICKPACKINVTP
		SET h_end_dt = new_last_update_dt
		WHERE h_lang_tp_cd=:NEW.lang_tp_cd AND
			h_del_pick_pack_inv_tp_cd=:NEW.del_pick_pack_inv_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
			
	INSERT INTO MDMDB.H_XCDDELPICKPACKINVTP
	( 
	h_lang_tp_cd
	, 
	h_del_pick_pack_inv_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, del_pick_pack_inv_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.del_pick_pack_inv_tp_cd
	, 'U'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.del_pick_pack_inv_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_XCDTOTESTP AFTER INSERT ON MDMDB.XCDTOTESTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW BEGIN
	INSERT INTO MDMDB.H_XCDTOTESTP
	( 
	h_lang_tp_cd
	, 
	  h_totes_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, totes_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.totes_tp_cd
	, 'I'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.totes_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/
	
CREATE OR REPLACE TRIGGER MDMDB.u_XCDTOTESTP AFTER UPDATE ON MDMDB.XCDTOTESTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW
	DECLARE new_last_update_dt timestamp;
	BEGIN
	
	select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        
	
	UPDATE MDMDB.H_XCDTOTESTP
		SET h_end_dt = new_last_update_dt
		WHERE h_lang_tp_cd=:NEW.lang_tp_cd AND
			h_totes_tp_cd=:NEW.totes_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
			
	INSERT INTO MDMDB.H_XCDTOTESTP
	( 
	h_lang_tp_cd
	, 
	h_totes_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, totes_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.totes_tp_cd
	, 'U'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.totes_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_XCDINVTP AFTER INSERT ON MDMDB.XCDINVTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW BEGIN
	INSERT INTO MDMDB.H_XCDINVTP
	( 
	h_lang_tp_cd
	, 
	  h_inv_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, inv_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.inv_tp_cd
	, 'I'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.inv_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/
	
CREATE OR REPLACE TRIGGER MDMDB.u_XCDINVTP AFTER UPDATE ON MDMDB.XCDINVTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW
	DECLARE new_last_update_dt timestamp;
	BEGIN
	
	select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        
	
	UPDATE MDMDB.H_XCDINVTP
		SET h_end_dt = new_last_update_dt
		WHERE h_lang_tp_cd=:NEW.lang_tp_cd AND
			h_inv_tp_cd=:NEW.inv_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
			
	INSERT INTO MDMDB.H_XCDINVTP
	( 
	h_lang_tp_cd
	, 
	h_inv_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, inv_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.inv_tp_cd
	, 'U'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.inv_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_XCDCOSTBASETP AFTER INSERT ON MDMDB.XCDCOSTBASETP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW BEGIN
	INSERT INTO MDMDB.H_XCDCOSTBASETP
	( 
	h_lang_tp_cd
	, 
	  h_cost_base_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, cost_base_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.cost_base_tp_cd
	, 'I'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.cost_base_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/
	
CREATE OR REPLACE TRIGGER MDMDB.u_XCDCOSTBASETP AFTER UPDATE ON MDMDB.XCDCOSTBASETP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW
	DECLARE new_last_update_dt timestamp;
	BEGIN
	
	select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        
	
	UPDATE MDMDB.H_XCDCOSTBASETP
		SET h_end_dt = new_last_update_dt
		WHERE h_lang_tp_cd=:NEW.lang_tp_cd AND
			h_cost_base_tp_cd=:NEW.cost_base_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
			
	INSERT INTO MDMDB.H_XCDCOSTBASETP
	( 
	h_lang_tp_cd
	, 
	h_cost_base_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, cost_base_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.cost_base_tp_cd
	, 'U'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.cost_base_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_XCDSRPCOc2dae04f AFTER INSERT ON MDMDB.XCDSRPCOMPLIANCETP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW BEGIN
	INSERT INTO MDMDB.H_XCDSRPCOMPLIANCETP
	( 
	h_lang_tp_cd
	, 
	  h_srp_compliance_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, srp_compliance_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.srp_compliance_tp_cd
	, 'I'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.srp_compliance_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/
	
CREATE OR REPLACE TRIGGER MDMDB.u_XCDSRPCOc2dae04f AFTER UPDATE ON MDMDB.XCDSRPCOMPLIANCETP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW
	DECLARE new_last_update_dt timestamp;
	BEGIN
	
	select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        
	
	UPDATE MDMDB.H_XCDSRPCOMPLIANCETP
		SET h_end_dt = new_last_update_dt
		WHERE h_lang_tp_cd=:NEW.lang_tp_cd AND
			h_srp_compliance_tp_cd=:NEW.srp_compliance_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
			
	INSERT INTO MDMDB.H_XCDSRPCOMPLIANCETP
	( 
	h_lang_tp_cd
	, 
	h_srp_compliance_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, srp_compliance_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.srp_compliance_tp_cd
	, 'U'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.srp_compliance_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_XCDBRKNCdc6e1fad AFTER INSERT ON MDMDB.XCDBRKNCASECALCTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW BEGIN
	INSERT INTO MDMDB.H_XCDBRKNCASECALCTP
	( 
	h_lang_tp_cd
	, 
	  h_brkn_case_calc_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, brkn_case_calc_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.brkn_case_calc_tp_cd
	, 'I'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.brkn_case_calc_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/
	
CREATE OR REPLACE TRIGGER MDMDB.u_XCDBRKNCdc6e1fad AFTER UPDATE ON MDMDB.XCDBRKNCASECALCTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW
	DECLARE new_last_update_dt timestamp;
	BEGIN
	
	select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        
	
	UPDATE MDMDB.H_XCDBRKNCASECALCTP
		SET h_end_dt = new_last_update_dt
		WHERE h_lang_tp_cd=:NEW.lang_tp_cd AND
			h_brkn_case_calc_tp_cd=:NEW.brkn_case_calc_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
			
	INSERT INTO MDMDB.H_XCDBRKNCASECALCTP
	( 
	h_lang_tp_cd
	, 
	h_brkn_case_calc_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, brkn_case_calc_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.brkn_case_calc_tp_cd
	, 'U'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.brkn_case_calc_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_XCDPSRPTP AFTER INSERT ON MDMDB.XCDPSRPTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW BEGIN
	INSERT INTO MDMDB.H_XCDPSRPTP
	( 
	h_lang_tp_cd
	, 
	  h_psrp_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, psrp_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.psrp_tp_cd
	, 'I'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.psrp_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/
	
CREATE OR REPLACE TRIGGER MDMDB.u_XCDPSRPTP AFTER UPDATE ON MDMDB.XCDPSRPTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW
	DECLARE new_last_update_dt timestamp;
	BEGIN
	
	select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        
	
	UPDATE MDMDB.H_XCDPSRPTP
		SET h_end_dt = new_last_update_dt
		WHERE h_lang_tp_cd=:NEW.lang_tp_cd AND
			h_psrp_tp_cd=:NEW.psrp_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
			
	INSERT INTO MDMDB.H_XCDPSRPTP
	( 
	h_lang_tp_cd
	, 
	h_psrp_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, psrp_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.psrp_tp_cd
	, 'U'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.psrp_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_XCDSTATEMa04e595 AFTER INSERT ON MDMDB.XCDSTATEMENTMODETP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW BEGIN
	INSERT INTO MDMDB.H_XCDSTATEMENTMODETP
	( 
	h_lang_tp_cd
	, 
	  h_statement_mode_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, statement_mode_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.statement_mode_tp_cd
	, 'I'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.statement_mode_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/
	
CREATE OR REPLACE TRIGGER MDMDB.u_XCDSTATEMa04e595 AFTER UPDATE ON MDMDB.XCDSTATEMENTMODETP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW
	DECLARE new_last_update_dt timestamp;
	BEGIN
	
	select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        
	
	UPDATE MDMDB.H_XCDSTATEMENTMODETP
		SET h_end_dt = new_last_update_dt
		WHERE h_lang_tp_cd=:NEW.lang_tp_cd AND
			h_statement_mode_tp_cd=:NEW.statement_mode_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
			
	INSERT INTO MDMDB.H_XCDSTATEMENTMODETP
	( 
	h_lang_tp_cd
	, 
	h_statement_mode_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, statement_mode_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.statement_mode_tp_cd
	, 'U'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.statement_mode_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_XCDGRACEDAYSTP AFTER INSERT ON MDMDB.XCDGRACEDAYSTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW BEGIN
	INSERT INTO MDMDB.H_XCDGRACEDAYSTP
	( 
	h_lang_tp_cd
	, 
	  h_grace_days_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, grace_days_cat_cd
	, grace_days_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.grace_days_tp_cd
	, 'I'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.grace_days_cat_cd
	, :NEW.grace_days_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/
	
CREATE OR REPLACE TRIGGER MDMDB.u_XCDGRACEDAYSTP AFTER UPDATE ON MDMDB.XCDGRACEDAYSTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW
	DECLARE new_last_update_dt timestamp;
	BEGIN
	
	select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        
	
	UPDATE MDMDB.H_XCDGRACEDAYSTP
		SET h_end_dt = new_last_update_dt
		WHERE h_lang_tp_cd=:NEW.lang_tp_cd AND
			h_grace_days_tp_cd=:NEW.grace_days_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
			
	INSERT INTO MDMDB.H_XCDGRACEDAYSTP
	( 
	h_lang_tp_cd
	, 
	h_grace_days_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, grace_days_cat_cd
	, grace_days_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.grace_days_tp_cd
	, 'U'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.grace_days_cat_cd
	, :NEW.grace_days_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_XCDCOLLECTORTP AFTER INSERT ON MDMDB.XCDCOLLECTORTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW BEGIN
	INSERT INTO MDMDB.H_XCDCOLLECTORTP
	( 
	h_lang_tp_cd
	, 
	  h_collector_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, collector_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.collector_tp_cd
	, 'I'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.collector_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/
	
CREATE OR REPLACE TRIGGER MDMDB.u_XCDCOLLECTORTP AFTER UPDATE ON MDMDB.XCDCOLLECTORTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW
	DECLARE new_last_update_dt timestamp;
	BEGIN
	
	select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        
	
	UPDATE MDMDB.H_XCDCOLLECTORTP
		SET h_end_dt = new_last_update_dt
		WHERE h_lang_tp_cd=:NEW.lang_tp_cd AND
			h_collector_tp_cd=:NEW.collector_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
			
	INSERT INTO MDMDB.H_XCDCOLLECTORTP
	( 
	h_lang_tp_cd
	, 
	h_collector_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, collector_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.collector_tp_cd
	, 'U'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.collector_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_XCDPAYME8deb572a AFTER INSERT ON MDMDB.XCDPAYMENTMETHODTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW BEGIN
	INSERT INTO MDMDB.H_XCDPAYMENTMETHODTP
	( 
	h_lang_tp_cd
	, 
	  h_payment_method_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, payment_method_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.payment_method_tp_cd
	, 'I'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.payment_method_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/
	
CREATE OR REPLACE TRIGGER MDMDB.u_XCDPAYME8deb572a AFTER UPDATE ON MDMDB.XCDPAYMENTMETHODTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW
	DECLARE new_last_update_dt timestamp;
	BEGIN
	
	select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        
	
	UPDATE MDMDB.H_XCDPAYMENTMETHODTP
		SET h_end_dt = new_last_update_dt
		WHERE h_lang_tp_cd=:NEW.lang_tp_cd AND
			h_payment_method_tp_cd=:NEW.payment_method_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
			
	INSERT INTO MDMDB.H_XCDPAYMENTMETHODTP
	( 
	h_lang_tp_cd
	, 
	h_payment_method_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, payment_method_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.payment_method_tp_cd
	, 'U'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.payment_method_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_XCDBANKTP AFTER INSERT ON MDMDB.XCDBANKTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW BEGIN
	INSERT INTO MDMDB.H_XCDBANKTP
	( 
	h_lang_tp_cd
	, 
	  h_bank_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, bank_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.bank_tp_cd
	, 'I'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.bank_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/
	
CREATE OR REPLACE TRIGGER MDMDB.u_XCDBANKTP AFTER UPDATE ON MDMDB.XCDBANKTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW
	DECLARE new_last_update_dt timestamp;
	BEGIN
	
	select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        
	
	UPDATE MDMDB.H_XCDBANKTP
		SET h_end_dt = new_last_update_dt
		WHERE h_lang_tp_cd=:NEW.lang_tp_cd AND
			h_bank_tp_cd=:NEW.bank_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
			
	INSERT INTO MDMDB.H_XCDBANKTP
	( 
	h_lang_tp_cd
	, 
	h_bank_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, bank_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.bank_tp_cd
	, 'U'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.bank_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_XCDBANKACCOUNTTP AFTER INSERT ON MDMDB.XCDBANKACCOUNTTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW BEGIN
	INSERT INTO MDMDB.H_XCDBANKACCOUNTTP
	( 
	h_lang_tp_cd
	, 
	  h_bank_account_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, bank_account_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.bank_account_tp_cd
	, 'I'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.bank_account_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/
	
CREATE OR REPLACE TRIGGER MDMDB.u_XCDBANKACCOUNTTP AFTER UPDATE ON MDMDB.XCDBANKACCOUNTTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW
	DECLARE new_last_update_dt timestamp;
	BEGIN
	
	select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        
	
	UPDATE MDMDB.H_XCDBANKACCOUNTTP
		SET h_end_dt = new_last_update_dt
		WHERE h_lang_tp_cd=:NEW.lang_tp_cd AND
			h_bank_account_tp_cd=:NEW.bank_account_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
			
	INSERT INTO MDMDB.H_XCDBANKACCOUNTTP
	( 
	h_lang_tp_cd
	, 
	h_bank_account_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, bank_account_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.bank_account_tp_cd
	, 'U'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.bank_account_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_XCDSALESREPTP AFTER INSERT ON MDMDB.XCDSALESREPTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW BEGIN
	INSERT INTO MDMDB.H_XCDSALESREPTP
	( 
	h_lang_tp_cd
	, 
	  h_sales_rep_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, sales_rep_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.sales_rep_tp_cd
	, 'I'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.sales_rep_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/
	
CREATE OR REPLACE TRIGGER MDMDB.u_XCDSALESREPTP AFTER UPDATE ON MDMDB.XCDSALESREPTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW
	DECLARE new_last_update_dt timestamp;
	BEGIN
	
	select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        
	
	UPDATE MDMDB.H_XCDSALESREPTP
		SET h_end_dt = new_last_update_dt
		WHERE h_lang_tp_cd=:NEW.lang_tp_cd AND
			h_sales_rep_tp_cd=:NEW.sales_rep_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
			
	INSERT INTO MDMDB.H_XCDSALESREPTP
	( 
	h_lang_tp_cd
	, 
	h_sales_rep_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, sales_rep_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.sales_rep_tp_cd
	, 'U'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.sales_rep_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_XCDGRACEDAYSCAT AFTER INSERT ON MDMDB.XCDGRACEDAYSCAT
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW BEGIN
	INSERT INTO MDMDB.H_XCDGRACEDAYSCAT
	( 
	h_lang_tp_cd
	, 
	  h_grace_days_cat_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, grace_days_cat_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.grace_days_cat_cd
	, 'I'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.grace_days_cat_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/
	
CREATE OR REPLACE TRIGGER MDMDB.u_XCDGRACEDAYSCAT AFTER UPDATE ON MDMDB.XCDGRACEDAYSCAT
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW
	DECLARE new_last_update_dt timestamp;
	BEGIN
	
	select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        
	
	UPDATE MDMDB.H_XCDGRACEDAYSCAT
		SET h_end_dt = new_last_update_dt
		WHERE h_lang_tp_cd=:NEW.lang_tp_cd AND
			h_grace_days_cat_cd=:NEW.grace_days_cat_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
			
	INSERT INTO MDMDB.H_XCDGRACEDAYSCAT
	( 
	h_lang_tp_cd
	, 
	h_grace_days_cat_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, grace_days_cat_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.grace_days_cat_cd
	, 'U'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.grace_days_cat_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_XCDIDENT59e271ba AFTER INSERT ON MDMDB.XCDIDENTIFIERSUBTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW BEGIN
	INSERT INTO MDMDB.H_XCDIDENTIFIERSUBTP
	( 
	h_lang_tp_cd
	, 
	  h_identifier_sub_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, identifier_sub_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.identifier_sub_tp_cd
	, 'I'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.identifier_sub_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/
	
CREATE OR REPLACE TRIGGER MDMDB.u_XCDIDENT59e271ba AFTER UPDATE ON MDMDB.XCDIDENTIFIERSUBTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW
	DECLARE new_last_update_dt timestamp;
	BEGIN
	
	select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        
	
	UPDATE MDMDB.H_XCDIDENTIFIERSUBTP
		SET h_end_dt = new_last_update_dt
		WHERE h_lang_tp_cd=:NEW.lang_tp_cd AND
			h_identifier_sub_tp_cd=:NEW.identifier_sub_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
			
	INSERT INTO MDMDB.H_XCDIDENTIFIERSUBTP
	( 
	h_lang_tp_cd
	, 
	h_identifier_sub_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, identifier_sub_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.identifier_sub_tp_cd
	, 'U'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.identifier_sub_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/

CREATE OR REPLACE TRIGGER MDMDB.i_XCDMSOTP AFTER INSERT ON MDMDB.XCDMSOTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW BEGIN
	INSERT INTO MDMDB.H_XCDMSOTP
	( 
	h_lang_tp_cd
	, 
	  h_mso_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, mso_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.mso_tp_cd
	, 'I'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.mso_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/
	
CREATE OR REPLACE TRIGGER MDMDB.u_XCDMSOTP AFTER UPDATE ON MDMDB.XCDMSOTP
	REFERENCING NEW AS NEW OLD AS OLD
	FOR EACH ROW
	DECLARE new_last_update_dt timestamp;
	BEGIN
	
	select :NEW.last_update_dt - interval '00:00.000001' minute to second into new_last_update_dt from dual;                                                                                                                                        
	
	UPDATE MDMDB.H_XCDMSOTP
		SET h_end_dt = new_last_update_dt
		WHERE h_lang_tp_cd=:NEW.lang_tp_cd AND
			h_mso_tp_cd=:NEW.mso_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
			
	INSERT INTO MDMDB.H_XCDMSOTP
	( 
	h_lang_tp_cd
	, 
	h_mso_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, mso_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	:NEW.lang_tp_cd
	, 
	:NEW.mso_tp_cd
	, 'U'
	, user
	, :NEW.last_update_dt
	, NULL
	, :NEW.lang_tp_cd
	, :NEW.mso_tp_cd
	, :NEW.name
	, :NEW.description
	, :NEW.expiry_dt
	, :NEW.last_update_dt
	, :NEW.last_update_user
	);
	END;
/


