/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[a33663fb35475ddb51cfcc1be1b30d64]
 */

package com.metcash.db.custom.constant;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * Defines the component IDs used in this module.
 *
 * @generated
 */
public class MTTDBCustomComponentID {

  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for MTTDBCustomComponent.
     *
     * @generated
     */
    public final static String MTTDBCUSTOM_COMPONENT = "1000007";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for MTTDBCustomController.
     *
     * @generated
     */
    public final static String MTTDBCUSTOM_CONTROLLER = "1000008";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for MTTIdentifierBObj.
     *
     * @generated
     */
    public final static String MTTIDENTIFIER_BOBJ = "1000010";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCDIDENTIFIERSUBTypeBObj.
     *
     * @generated
     */
    public final static String XCDIDENTIFIERSUBTYPE_BOBJ = "1000126";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for MTTStoreBObj.
     *
     * @generated
     */
    public final static String MTTSTORE_BOBJ = "1000252";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCDMSOTPTypeBObj.
     *
     * @generated
     */
    public final static String XCDMSOTPTYPE_BOBJ = "1000347";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for MTTActReportingBObj.
     *
     * @generated
     */
    public final static String MTTACT_REPORTING_BOBJ = "1000472";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCDCHANNELGRPTypeBObj.
     *
     * @generated
     */
    public final static String XCDCHANNELGRPTYPE_BOBJ = "1000567";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCDAGENTNUMTypeBObj.
     *
     * @generated
     */
    public final static String XCDAGENTNUMTYPE_BOBJ = "1000632";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCDUSERLOCALITYTypeBObj.
     *
     * @generated
     */
    public final static String XCDUSERLOCALITYTYPE_BOBJ = "1000685";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCDCUSCLASSTypeBObj.
     *
     * @generated
     */
    public final static String XCDCUSCLASSTYPE_BOBJ = "1000738";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCDINVTERMSTypeBObj.
     *
     * @generated
     */
    public final static String XCDINVTERMSTYPE_BOBJ = "1001005";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCDCUSGRPTypeBObj.
     *
     * @generated
     */
    public final static String XCDCUSGRPTYPE_BOBJ = "1001058";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for MTTActCreditTaxBObj.
     *
     * @generated
     */
    public final static String MTTACT_CREDIT_TAX_BOBJ = "1001111";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for MTTActOrderInvoiceBObj.
     *
     * @generated
     */
    public final static String MTTACT_ORDER_INVOICE_BOBJ = "1001460";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCDINVSEQTypeBObj.
     *
     * @generated
     */
    public final static String XCDINVSEQTYPE_BOBJ = "1001555";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCDINVMODETypeBObj.
     *
     * @generated
     */
    public final static String XCDINVMODETYPE_BOBJ = "1001608";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCDORDERGUIDETypeBObj.
     *
     * @generated
     */
    public final static String XCDORDERGUIDETYPE_BOBJ = "1001661";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCDPRNCATINVBRKTypeBObj.
     *
     * @generated
     */
    public final static String XCDPRNCATINVBRKTYPE_BOBJ = "1001714";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCDINVRECAPSUMMARYTypeBObj.
     *
     * @generated
     */
    public final static String XCDINVRECAPSUMMARYTYPE_BOBJ = "1001767";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCDPICKUPDELIVERTypeBObj.
     *
     * @generated
     */
    public final static String XCDPICKUPDELIVERTYPE_BOBJ = "1001820";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCDUNITCASECOSTPRNTypeBObj.
     *
     * @generated
     */
    public final static String XCDUNITCASECOSTPRNTYPE_BOBJ = "1001873";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCDINVFORMATTypeBObj.
     *
     * @generated
     */
    public final static String XCDINVFORMATTYPE_BOBJ = "1001926";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCDDELPICKPACKINVTypeBObj.
     *
     * @generated
     */
    public final static String XCDDELPICKPACKINVTYPE_BOBJ = "1001979";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCDTOTESTypeBObj.
     *
     * @generated
     */
    public final static String XCDTOTESTYPE_BOBJ = "1002190";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCDINVTypeBObj.
     *
     * @generated
     */
    public final static String XCDINVTYPE_BOBJ = "1002243";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for MTTActCostChargesBObj.
     *
     * @generated
     */
    public final static String MTTACT_COST_CHARGES_BOBJ = "1002444";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCDCOSTBASETypeBObj.
     *
     * @generated
     */
    public final static String XCDCOSTBASETYPE_BOBJ = "1002539";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCDSRPCOMPLIANCETypeBObj.
     *
     * @generated
     */
    public final static String XCDSRPCOMPLIANCETYPE_BOBJ = "1002592";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCDBRKNCASECALCTypeBObj.
     *
     * @generated
     */
    public final static String XCDBRKNCASECALCTYPE_BOBJ = "1002645";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCDPSRPTypeBObj.
     *
     * @generated
     */
    public final static String XCDPSRPTYPE_BOBJ = "1002814";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for MTTActFinancialBObj.
     *
     * @generated
     */
    public final static String MTTACT_FINANCIAL_BOBJ = "1002891";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCDSTATEMENTMODETypeBObj.
     *
     * @generated
     */
    public final static String XCDSTATEMENTMODETYPE_BOBJ = "1002986";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCDGRACEDAYSTypeBObj.
     *
     * @generated
     */
    public final static String XCDGRACEDAYSTYPE_BOBJ = "1003039";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCDCOLLECTORTypeBObj.
     *
     * @generated
     */
    public final static String XCDCOLLECTORTYPE_BOBJ = "1003092";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCDPAYMENTMETHODTypeBObj.
     *
     * @generated
     */
    public final static String XCDPAYMENTMETHODTYPE_BOBJ = "1003145";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCDBANKTypeBObj.
     *
     * @generated
     */
    public final static String XCDBANKTYPE_BOBJ = "1003245";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCDBANKACCOUNTTypeBObj.
     *
     * @generated
     */
    public final static String XCDBANKACCOUNTTYPE_BOBJ = "1003348";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCDSALESREPTypeBObj.
     *
     * @generated
     */
    public final static String XCDSALESREPTYPE_BOBJ = "1003472";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for XCDGRACEDAYSCATTypeBObj.
     *
     * @generated
     */
    public final static String XCDGRACEDAYSCATTYPE_BOBJ = "1003613";

}


