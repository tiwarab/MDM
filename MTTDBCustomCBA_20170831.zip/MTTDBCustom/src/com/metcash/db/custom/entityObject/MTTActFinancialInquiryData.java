/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[e54e077ea5f8e01e2bc3156c752be54e]
 */

package com.metcash.db.custom.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface MTTActFinancialInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "MTT_ACCOUNT_FINANCIAL => com.metcash.db.custom.entityObject.EObjMTTActFinancial, " +
                                            "H_MTT_ACCOUNT_FINANCIAL => com.metcash.db.custom.entityObject.EObjMTTActFinancial" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getMTTActFinancialSql = "SELECT r.MTT_ACT_FINANCIAL_ID MTT_ACT_FINANCIAL_ID, r.CONTRACT_ID CONTRACT_ID, r.STATEMENT_MODE_TP_CD STATEMENT_MODE_TP_CD, r.DUE_GRACE_DAYS_TP_CD DUE_GRACE_DAYS_TP_CD, r.TOBACCO_GRACE_DAYS_TP_CD TOBACCO_GRACE_DAYS_TP_CD, r.BANK_TP_CD BANK_TP_CD, r.BPAY_IND BPAY_IND, r.STATEMENT_PRN_HOLD_IND STATEMENT_PRN_HOLD_IND, r.BPAY_CUS_REF_NUM BPAY_CUS_REF_NUM, r.COLLECTOR_TP_CD COLLECTOR_TP_CD, r.BANK_ACCOUNT_TP_CD BANK_ACCOUNT_TP_CD, r.EXT_TERMS_BY_SHIPDATE_IND EXT_TERMS_BY_SHIPDATE_IND, r.SETTLEMENT_DISC_IND SETTLEMENT_DISC_IND, r.ACCOUNT_DETAILS ACCOUNT_DETAILS, r.DISC_GRACE_DAYS_TP_CD DISC_GRACE_DAYS_TP_CD, r.PAYMENT_METHOD_TP_CD PAYMENT_METHOD_TP_CD, r.LMAA_NUM LMAA_NUM, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM MTT_ACCOUNT_FINANCIAL r WHERE r.MTT_ACT_FINANCIAL_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getMTTActFinancialParameters =
    "EObjMTTActFinancial.MTTActFinancialIdPk";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getMTTActFinancialResults =
    "EObjMTTActFinancial.MTTActFinancialIdPk," +
    "EObjMTTActFinancial.ContractId," +
    "EObjMTTActFinancial.StatementMode," +
    "EObjMTTActFinancial.DueGraceDays," +
    "EObjMTTActFinancial.TobaccoGraceDays," +
    "EObjMTTActFinancial.Bank," +
    "EObjMTTActFinancial.BPAYInd," +
    "EObjMTTActFinancial.StatementPrintHoldInd," +
    "EObjMTTActFinancial.BPAYCustomerRefNumber," +
    "EObjMTTActFinancial.Collector," +
    "EObjMTTActFinancial.BankAccount," +
    "EObjMTTActFinancial.ExtTermsByShipDateInd," +
    "EObjMTTActFinancial.SettlementDiscountInd," +
    "EObjMTTActFinancial.AccountDetails," +
    "EObjMTTActFinancial.DiscountGraceDays," +
    "EObjMTTActFinancial.PaymentMethod," +
    "EObjMTTActFinancial.LMAANumber," +
    "EObjMTTActFinancial.lastUpdateDt," +
    "EObjMTTActFinancial.lastUpdateUser," +
    "EObjMTTActFinancial.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getMTTActFinancialHistorySql = "SELECT r.H_MTT_ACT_FINANCIAL_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.MTT_ACT_FINANCIAL_ID MTT_ACT_FINANCIAL_ID, r.CONTRACT_ID CONTRACT_ID, r.STATEMENT_MODE_TP_CD STATEMENT_MODE_TP_CD, r.DUE_GRACE_DAYS_TP_CD DUE_GRACE_DAYS_TP_CD, r.TOBACCO_GRACE_DAYS_TP_CD TOBACCO_GRACE_DAYS_TP_CD, r.BANK_TP_CD BANK_TP_CD, r.BPAY_IND BPAY_IND, r.STATEMENT_PRN_HOLD_IND STATEMENT_PRN_HOLD_IND, r.BPAY_CUS_REF_NUM BPAY_CUS_REF_NUM, r.COLLECTOR_TP_CD COLLECTOR_TP_CD, r.BANK_ACCOUNT_TP_CD BANK_ACCOUNT_TP_CD, r.EXT_TERMS_BY_SHIPDATE_IND EXT_TERMS_BY_SHIPDATE_IND, r.SETTLEMENT_DISC_IND SETTLEMENT_DISC_IND, r.ACCOUNT_DETAILS ACCOUNT_DETAILS, r.DISC_GRACE_DAYS_TP_CD DISC_GRACE_DAYS_TP_CD, r.PAYMENT_METHOD_TP_CD PAYMENT_METHOD_TP_CD, r.LMAA_NUM LMAA_NUM, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_MTT_ACCOUNT_FINANCIAL r WHERE r.H_MTT_ACT_FINANCIAL_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getMTTActFinancialHistoryParameters =
    "EObjMTTActFinancial.MTTActFinancialIdPk," +
    "EObjMTTActFinancial.lastUpdateDt," +
    "EObjMTTActFinancial.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getMTTActFinancialHistoryResults =
    "EObjMTTActFinancial.historyIdPK," +
    "EObjMTTActFinancial.histActionCode," +
    "EObjMTTActFinancial.histCreatedBy," +
    "EObjMTTActFinancial.histCreateDt," +
    "EObjMTTActFinancial.histEndDt," +
    "EObjMTTActFinancial.MTTActFinancialIdPk," +
    "EObjMTTActFinancial.ContractId," +
    "EObjMTTActFinancial.StatementMode," +
    "EObjMTTActFinancial.DueGraceDays," +
    "EObjMTTActFinancial.TobaccoGraceDays," +
    "EObjMTTActFinancial.Bank," +
    "EObjMTTActFinancial.BPAYInd," +
    "EObjMTTActFinancial.StatementPrintHoldInd," +
    "EObjMTTActFinancial.BPAYCustomerRefNumber," +
    "EObjMTTActFinancial.Collector," +
    "EObjMTTActFinancial.BankAccount," +
    "EObjMTTActFinancial.ExtTermsByShipDateInd," +
    "EObjMTTActFinancial.SettlementDiscountInd," +
    "EObjMTTActFinancial.AccountDetails," +
    "EObjMTTActFinancial.DiscountGraceDays," +
    "EObjMTTActFinancial.PaymentMethod," +
    "EObjMTTActFinancial.LMAANumber," +
    "EObjMTTActFinancial.lastUpdateDt," +
    "EObjMTTActFinancial.lastUpdateUser," +
    "EObjMTTActFinancial.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllMTTActFinancialbyIDSql = "SELECT r.MTT_ACT_FINANCIAL_ID MTT_ACT_FINANCIAL_ID, r.CONTRACT_ID CONTRACT_ID, r.STATEMENT_MODE_TP_CD STATEMENT_MODE_TP_CD, r.DUE_GRACE_DAYS_TP_CD DUE_GRACE_DAYS_TP_CD, r.TOBACCO_GRACE_DAYS_TP_CD TOBACCO_GRACE_DAYS_TP_CD, r.BANK_TP_CD BANK_TP_CD, r.BPAY_IND BPAY_IND, r.STATEMENT_PRN_HOLD_IND STATEMENT_PRN_HOLD_IND, r.BPAY_CUS_REF_NUM BPAY_CUS_REF_NUM, r.COLLECTOR_TP_CD COLLECTOR_TP_CD, r.BANK_ACCOUNT_TP_CD BANK_ACCOUNT_TP_CD, r.EXT_TERMS_BY_SHIPDATE_IND EXT_TERMS_BY_SHIPDATE_IND, r.SETTLEMENT_DISC_IND SETTLEMENT_DISC_IND, r.ACCOUNT_DETAILS ACCOUNT_DETAILS, r.DISC_GRACE_DAYS_TP_CD DISC_GRACE_DAYS_TP_CD, r.PAYMENT_METHOD_TP_CD PAYMENT_METHOD_TP_CD, r.LMAA_NUM LMAA_NUM, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM MTT_ACCOUNT_FINANCIAL r WHERE r.CONTRACT_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllMTTActFinancialbyIDParameters =
    "EObjMTTActFinancial.ContractId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllMTTActFinancialbyIDResults =
    "EObjMTTActFinancial.MTTActFinancialIdPk," +
    "EObjMTTActFinancial.ContractId," +
    "EObjMTTActFinancial.StatementMode," +
    "EObjMTTActFinancial.DueGraceDays," +
    "EObjMTTActFinancial.TobaccoGraceDays," +
    "EObjMTTActFinancial.Bank," +
    "EObjMTTActFinancial.BPAYInd," +
    "EObjMTTActFinancial.StatementPrintHoldInd," +
    "EObjMTTActFinancial.BPAYCustomerRefNumber," +
    "EObjMTTActFinancial.Collector," +
    "EObjMTTActFinancial.BankAccount," +
    "EObjMTTActFinancial.ExtTermsByShipDateInd," +
    "EObjMTTActFinancial.SettlementDiscountInd," +
    "EObjMTTActFinancial.AccountDetails," +
    "EObjMTTActFinancial.DiscountGraceDays," +
    "EObjMTTActFinancial.PaymentMethod," +
    "EObjMTTActFinancial.LMAANumber," +
    "EObjMTTActFinancial.lastUpdateDt," +
    "EObjMTTActFinancial.lastUpdateUser," +
    "EObjMTTActFinancial.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllMTTActFinancialbyIDHistorySql = "SELECT r.H_MTT_ACT_FINANCIAL_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.MTT_ACT_FINANCIAL_ID MTT_ACT_FINANCIAL_ID, r.CONTRACT_ID CONTRACT_ID, r.STATEMENT_MODE_TP_CD STATEMENT_MODE_TP_CD, r.DUE_GRACE_DAYS_TP_CD DUE_GRACE_DAYS_TP_CD, r.TOBACCO_GRACE_DAYS_TP_CD TOBACCO_GRACE_DAYS_TP_CD, r.BANK_TP_CD BANK_TP_CD, r.BPAY_IND BPAY_IND, r.STATEMENT_PRN_HOLD_IND STATEMENT_PRN_HOLD_IND, r.BPAY_CUS_REF_NUM BPAY_CUS_REF_NUM, r.COLLECTOR_TP_CD COLLECTOR_TP_CD, r.BANK_ACCOUNT_TP_CD BANK_ACCOUNT_TP_CD, r.EXT_TERMS_BY_SHIPDATE_IND EXT_TERMS_BY_SHIPDATE_IND, r.SETTLEMENT_DISC_IND SETTLEMENT_DISC_IND, r.ACCOUNT_DETAILS ACCOUNT_DETAILS, r.DISC_GRACE_DAYS_TP_CD DISC_GRACE_DAYS_TP_CD, r.PAYMENT_METHOD_TP_CD PAYMENT_METHOD_TP_CD, r.LMAA_NUM LMAA_NUM, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_MTT_ACCOUNT_FINANCIAL r WHERE r.CONTRACT_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllMTTActFinancialbyIDHistoryParameters =
    "EObjMTTActFinancial.ContractId," +
    "EObjMTTActFinancial.lastUpdateDt," +
    "EObjMTTActFinancial.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllMTTActFinancialbyIDHistoryResults =
    "EObjMTTActFinancial.historyIdPK," +
    "EObjMTTActFinancial.histActionCode," +
    "EObjMTTActFinancial.histCreatedBy," +
    "EObjMTTActFinancial.histCreateDt," +
    "EObjMTTActFinancial.histEndDt," +
    "EObjMTTActFinancial.MTTActFinancialIdPk," +
    "EObjMTTActFinancial.ContractId," +
    "EObjMTTActFinancial.StatementMode," +
    "EObjMTTActFinancial.DueGraceDays," +
    "EObjMTTActFinancial.TobaccoGraceDays," +
    "EObjMTTActFinancial.Bank," +
    "EObjMTTActFinancial.BPAYInd," +
    "EObjMTTActFinancial.StatementPrintHoldInd," +
    "EObjMTTActFinancial.BPAYCustomerRefNumber," +
    "EObjMTTActFinancial.Collector," +
    "EObjMTTActFinancial.BankAccount," +
    "EObjMTTActFinancial.ExtTermsByShipDateInd," +
    "EObjMTTActFinancial.SettlementDiscountInd," +
    "EObjMTTActFinancial.AccountDetails," +
    "EObjMTTActFinancial.DiscountGraceDays," +
    "EObjMTTActFinancial.PaymentMethod," +
    "EObjMTTActFinancial.LMAANumber," +
    "EObjMTTActFinancial.lastUpdateDt," +
    "EObjMTTActFinancial.lastUpdateUser," +
    "EObjMTTActFinancial.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getMTTActFinancialSql, pattern=tableAliasString)
  @EntityMapping(parameters=getMTTActFinancialParameters, results=getMTTActFinancialResults)
  Iterator<ResultQueue1<EObjMTTActFinancial>> getMTTActFinancial(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getMTTActFinancialHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getMTTActFinancialHistoryParameters, results=getMTTActFinancialHistoryResults)
  Iterator<ResultQueue1<EObjMTTActFinancial>> getMTTActFinancialHistory(Object[] parameters);


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllMTTActFinancialbyIDSql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllMTTActFinancialbyIDParameters, results=getAllMTTActFinancialbyIDResults)
  Iterator<ResultQueue1<EObjMTTActFinancial>> getAllMTTActFinancialbyID(Object[] parameters);


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllMTTActFinancialbyIDHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllMTTActFinancialbyIDHistoryParameters, results=getAllMTTActFinancialbyIDHistoryResults)
  Iterator<ResultQueue1<EObjMTTActFinancial>> getAllMTTActFinancialbyIDHistory(Object[] parameters);  


}


