/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[924123c2bc5ff51d7f0e2e30f0f952ef]
 */


package com.metcash.db.custom.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.metcash.db.custom.entityObject.EObjMTTActFinancial;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjMTTActFinancialData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjMTTActFinancialSql = "select MTT_ACT_FINANCIAL_ID, CONTRACT_ID, STATEMENT_MODE_TP_CD, DUE_GRACE_DAYS_TP_CD, TOBACCO_GRACE_DAYS_TP_CD, BANK_TP_CD, BPAY_IND, STATEMENT_PRN_HOLD_IND, BPAY_CUS_REF_NUM, COLLECTOR_TP_CD, BANK_ACCOUNT_TP_CD, EXT_TERMS_BY_SHIPDATE_IND, SETTLEMENT_DISC_IND, ACCOUNT_DETAILS, DISC_GRACE_DAYS_TP_CD, PAYMENT_METHOD_TP_CD, LMAA_NUM,  LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from MTT_ACCOUNT_FINANCIAL where MTT_ACT_FINANCIAL_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjMTTActFinancialSql = "insert into MTT_ACCOUNT_FINANCIAL (MTT_ACT_FINANCIAL_ID, CONTRACT_ID, STATEMENT_MODE_TP_CD, DUE_GRACE_DAYS_TP_CD, TOBACCO_GRACE_DAYS_TP_CD, BANK_TP_CD, BPAY_IND, STATEMENT_PRN_HOLD_IND, BPAY_CUS_REF_NUM, COLLECTOR_TP_CD, BANK_ACCOUNT_TP_CD, EXT_TERMS_BY_SHIPDATE_IND, SETTLEMENT_DISC_IND, ACCOUNT_DETAILS, DISC_GRACE_DAYS_TP_CD, PAYMENT_METHOD_TP_CD, LMAA_NUM, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :mTTActFinancialIdPk, :contractId, :statementMode, :dueGraceDays, :tobaccoGraceDays, :bank, :bPAYInd, :statementPrintHoldInd, :bPAYCustomerRefNumber, :collector, :bankAccount, :extTermsByShipDateInd, :settlementDiscountInd, :accountDetails, :discountGraceDays, :paymentMethod, :lMAANumber, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjMTTActFinancialSql = "update MTT_ACCOUNT_FINANCIAL set CONTRACT_ID = :contractId, STATEMENT_MODE_TP_CD = :statementMode, DUE_GRACE_DAYS_TP_CD = :dueGraceDays, TOBACCO_GRACE_DAYS_TP_CD = :tobaccoGraceDays, BANK_TP_CD = :bank, BPAY_IND = :bPAYInd, STATEMENT_PRN_HOLD_IND = :statementPrintHoldInd, BPAY_CUS_REF_NUM = :bPAYCustomerRefNumber, COLLECTOR_TP_CD = :collector, BANK_ACCOUNT_TP_CD = :bankAccount, EXT_TERMS_BY_SHIPDATE_IND = :extTermsByShipDateInd, SETTLEMENT_DISC_IND = :settlementDiscountInd, ACCOUNT_DETAILS = :accountDetails, DISC_GRACE_DAYS_TP_CD = :discountGraceDays, PAYMENT_METHOD_TP_CD = :paymentMethod, LMAA_NUM = :lMAANumber, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where MTT_ACT_FINANCIAL_ID = :mTTActFinancialIdPk and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjMTTActFinancialSql = "delete from MTT_ACCOUNT_FINANCIAL where MTT_ACT_FINANCIAL_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjMTTActFinancialKeyField = "EObjMTTActFinancial.mTTActFinancialIdPk";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjMTTActFinancialGetFields =
    "EObjMTTActFinancial.mTTActFinancialIdPk," +
    "EObjMTTActFinancial.contractId," +
    "EObjMTTActFinancial.statementMode," +
    "EObjMTTActFinancial.dueGraceDays," +
    "EObjMTTActFinancial.tobaccoGraceDays," +
    "EObjMTTActFinancial.bank," +
    "EObjMTTActFinancial.bPAYInd," +
    "EObjMTTActFinancial.statementPrintHoldInd," +
    "EObjMTTActFinancial.bPAYCustomerRefNumber," +
    "EObjMTTActFinancial.collector," +
    "EObjMTTActFinancial.bankAccount," +
    "EObjMTTActFinancial.extTermsByShipDateInd," +
    "EObjMTTActFinancial.settlementDiscountInd," +
    "EObjMTTActFinancial.accountDetails," +
    "EObjMTTActFinancial.discountGraceDays," +
    "EObjMTTActFinancial.paymentMethod," +
    "EObjMTTActFinancial.lMAANumber," +
    "EObjMTTActFinancial.lastUpdateDt," +
    "EObjMTTActFinancial.lastUpdateUser," +
    "EObjMTTActFinancial.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjMTTActFinancialAllFields =
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.mTTActFinancialIdPk," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.contractId," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.statementMode," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.dueGraceDays," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.tobaccoGraceDays," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.bank," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.bPAYInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.statementPrintHoldInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.bPAYCustomerRefNumber," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.collector," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.bankAccount," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.extTermsByShipDateInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.settlementDiscountInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.accountDetails," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.discountGraceDays," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.paymentMethod," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.lMAANumber," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.lastUpdateDt," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.lastUpdateUser," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjMTTActFinancialUpdateFields =
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.contractId," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.statementMode," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.dueGraceDays," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.tobaccoGraceDays," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.bank," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.bPAYInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.statementPrintHoldInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.bPAYCustomerRefNumber," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.collector," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.bankAccount," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.extTermsByShipDateInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.settlementDiscountInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.accountDetails," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.discountGraceDays," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.paymentMethod," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.lMAANumber," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.lastUpdateDt," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.lastUpdateUser," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.lastUpdateTxId," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.mTTActFinancialIdPk," +
    "com.metcash.db.custom.entityObject.EObjMTTActFinancial.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select MTTActFinancial by parameters.
   * @generated
   */
  @Select(sql=getEObjMTTActFinancialSql)
  @EntityMapping(parameters=EObjMTTActFinancialKeyField, results=EObjMTTActFinancialGetFields)
  Iterator<EObjMTTActFinancial> getEObjMTTActFinancial(Long mTTActFinancialIdPk);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create MTTActFinancial by EObjMTTActFinancial Object.
   * @generated
   */
  @Update(sql=createEObjMTTActFinancialSql)
  @EntityMapping(parameters=EObjMTTActFinancialAllFields)
    int createEObjMTTActFinancial(EObjMTTActFinancial e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one MTTActFinancial by EObjMTTActFinancial object.
   * @generated
   */
  @Update(sql=updateEObjMTTActFinancialSql)
  @EntityMapping(parameters=EObjMTTActFinancialUpdateFields)
    int updateEObjMTTActFinancial(EObjMTTActFinancial e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete MTTActFinancial by parameters.
   * @generated
   */
  @Update(sql=deleteEObjMTTActFinancialSql)
  @EntityMapping(parameters=EObjMTTActFinancialKeyField)
  int deleteEObjMTTActFinancial(Long mTTActFinancialIdPk);

}

