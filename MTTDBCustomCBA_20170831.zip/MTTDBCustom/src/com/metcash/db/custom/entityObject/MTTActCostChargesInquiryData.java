/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[8eca9ab792d6c75279588b9501248c29]
 */

package com.metcash.db.custom.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface MTTActCostChargesInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "MTT_ACCOUNT_COST_CHARGES => com.metcash.db.custom.entityObject.EObjMTTActCostCharges, " +
                                            "H_MTT_ACCOUNT_COST_CHARGES => com.metcash.db.custom.entityObject.EObjMTTActCostCharges" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getMTTActCostChargesSql = "SELECT r.MTT_ACT_COST_CHARGES_ID MTT_ACT_COST_CHARGES_ID, r.CONTRACT_ID CONTRACT_ID, r.COST_BASE_TP_CD COST_BASE_TP_CD, r.DIRECT_SHIP_APPROVED_IND DIRECT_SHIP_APPROVED_IND, r.DO_NOT_APPLY_DIRECT_DISC_IND DO_NOT_APPLY_DIRECT_DISC_IND, r.SRP_COMPLIANCE_TP_CD SRP_COMPLIANCE_TP_CD, r.PRICE_MATCH_GAP_FEE_IND PRICE_MATCH_GAP_FEE_IND, r.BRKN_CASE_UPCHARGE_PCT BRKN_CASE_UPCHARGE_PCT, r.BRKN_CASE_UPCHARGE_CAP BRKN_CASE_UPCHARGE_CAP, r.BRKN_CASE_UPCHARGE_IND BRKN_CASE_UPCHARGE_IND, r.BRKN_CASE_CALC_TP_CD BRKN_CASE_CALC_TP_CD, r.SHELF_LABEL_PRICED_IND SHELF_LABEL_PRICED_IND, r.PSRP_TP_CD PSRP_TP_CD, r.ADD_FRT_RECOVERY_SRP_IND ADD_FRT_RECOVERY_SRP_IND, r.SRP_FRT_RECOVERY_VAL SRP_FRT_RECOVERY_VAL, r.SRP_FRT_RECOVERY_DIR_VAL SRP_FRT_RECOVERY_DIR_VAL, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM MTT_ACCOUNT_COST_CHARGES r WHERE r.MTT_ACT_COST_CHARGES_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getMTTActCostChargesParameters =
    "EObjMTTActCostCharges.MTTActCostChargesIdPk";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getMTTActCostChargesResults =
    "EObjMTTActCostCharges.MTTActCostChargesIdPk," +
    "EObjMTTActCostCharges.ContractId," +
    "EObjMTTActCostCharges.CostBase," +
    "EObjMTTActCostCharges.DirectShipApprovedInd," +
    "EObjMTTActCostCharges.DoNotApplyDirectDiscountInd," +
    "EObjMTTActCostCharges.SRPComplicance," +
    "EObjMTTActCostCharges.PriceMatchGapFeeInd," +
    "EObjMTTActCostCharges.BrokenCaseUpchargePercentage," +
    "EObjMTTActCostCharges.BrokenCaseUpchargeCap," +
    "EObjMTTActCostCharges.BrokenCaseUpchargeInd," +
    "EObjMTTActCostCharges.BrokenCaseCal," +
    "EObjMTTActCostCharges.ShelfLabelPricedInd," +
    "EObjMTTActCostCharges.PSRP," +
    "EObjMTTActCostCharges.AddFRTRecoverySRPInd," +
    "EObjMTTActCostCharges.SRPFRTRecoveryValue," +
    "EObjMTTActCostCharges.SRPFRTRecoveryDirectValue," +
    "EObjMTTActCostCharges.lastUpdateDt," +
    "EObjMTTActCostCharges.lastUpdateUser," +
    "EObjMTTActCostCharges.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getMTTActCostChargesHistorySql = "SELECT r.H_MTT_ACT_COST_CHARGES_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.MTT_ACT_COST_CHARGES_ID MTT_ACT_COST_CHARGES_ID, r.CONTRACT_ID CONTRACT_ID, r.COST_BASE_TP_CD COST_BASE_TP_CD, r.DIRECT_SHIP_APPROVED_IND DIRECT_SHIP_APPROVED_IND, r.DO_NOT_APPLY_DIRECT_DISC_IND DO_NOT_APPLY_DIRECT_DISC_IND, r.SRP_COMPLIANCE_TP_CD SRP_COMPLIANCE_TP_CD, r.PRICE_MATCH_GAP_FEE_IND PRICE_MATCH_GAP_FEE_IND, r.BRKN_CASE_UPCHARGE_PCT BRKN_CASE_UPCHARGE_PCT, r.BRKN_CASE_UPCHARGE_CAP BRKN_CASE_UPCHARGE_CAP, r.BRKN_CASE_UPCHARGE_IND BRKN_CASE_UPCHARGE_IND, r.BRKN_CASE_CALC_TP_CD BRKN_CASE_CALC_TP_CD, r.SHELF_LABEL_PRICED_IND SHELF_LABEL_PRICED_IND, r.PSRP_TP_CD PSRP_TP_CD, r.ADD_FRT_RECOVERY_SRP_IND ADD_FRT_RECOVERY_SRP_IND, r.SRP_FRT_RECOVERY_VAL SRP_FRT_RECOVERY_VAL, r.SRP_FRT_RECOVERY_DIR_VAL SRP_FRT_RECOVERY_DIR_VAL, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_MTT_ACCOUNT_COST_CHARGES r WHERE r.H_MTT_ACT_COST_CHARGES_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getMTTActCostChargesHistoryParameters =
    "EObjMTTActCostCharges.MTTActCostChargesIdPk," +
    "EObjMTTActCostCharges.lastUpdateDt," +
    "EObjMTTActCostCharges.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getMTTActCostChargesHistoryResults =
    "EObjMTTActCostCharges.historyIdPK," +
    "EObjMTTActCostCharges.histActionCode," +
    "EObjMTTActCostCharges.histCreatedBy," +
    "EObjMTTActCostCharges.histCreateDt," +
    "EObjMTTActCostCharges.histEndDt," +
    "EObjMTTActCostCharges.MTTActCostChargesIdPk," +
    "EObjMTTActCostCharges.ContractId," +
    "EObjMTTActCostCharges.CostBase," +
    "EObjMTTActCostCharges.DirectShipApprovedInd," +
    "EObjMTTActCostCharges.DoNotApplyDirectDiscountInd," +
    "EObjMTTActCostCharges.SRPComplicance," +
    "EObjMTTActCostCharges.PriceMatchGapFeeInd," +
    "EObjMTTActCostCharges.BrokenCaseUpchargePercentage," +
    "EObjMTTActCostCharges.BrokenCaseUpchargeCap," +
    "EObjMTTActCostCharges.BrokenCaseUpchargeInd," +
    "EObjMTTActCostCharges.BrokenCaseCal," +
    "EObjMTTActCostCharges.ShelfLabelPricedInd," +
    "EObjMTTActCostCharges.PSRP," +
    "EObjMTTActCostCharges.AddFRTRecoverySRPInd," +
    "EObjMTTActCostCharges.SRPFRTRecoveryValue," +
    "EObjMTTActCostCharges.SRPFRTRecoveryDirectValue," +
    "EObjMTTActCostCharges.lastUpdateDt," +
    "EObjMTTActCostCharges.lastUpdateUser," +
    "EObjMTTActCostCharges.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllMTTActCostChargesByIDSql = "SELECT r.MTT_ACT_COST_CHARGES_ID MTT_ACT_COST_CHARGES_ID, r.CONTRACT_ID CONTRACT_ID, r.COST_BASE_TP_CD COST_BASE_TP_CD, r.DIRECT_SHIP_APPROVED_IND DIRECT_SHIP_APPROVED_IND, r.DO_NOT_APPLY_DIRECT_DISC_IND DO_NOT_APPLY_DIRECT_DISC_IND, r.SRP_COMPLIANCE_TP_CD SRP_COMPLIANCE_TP_CD, r.PRICE_MATCH_GAP_FEE_IND PRICE_MATCH_GAP_FEE_IND, r.BRKN_CASE_UPCHARGE_PCT BRKN_CASE_UPCHARGE_PCT, r.BRKN_CASE_UPCHARGE_CAP BRKN_CASE_UPCHARGE_CAP, r.BRKN_CASE_UPCHARGE_IND BRKN_CASE_UPCHARGE_IND, r.BRKN_CASE_CALC_TP_CD BRKN_CASE_CALC_TP_CD, r.SHELF_LABEL_PRICED_IND SHELF_LABEL_PRICED_IND, r.PSRP_TP_CD PSRP_TP_CD, r.ADD_FRT_RECOVERY_SRP_IND ADD_FRT_RECOVERY_SRP_IND, r.SRP_FRT_RECOVERY_VAL SRP_FRT_RECOVERY_VAL, r.SRP_FRT_RECOVERY_DIR_VAL SRP_FRT_RECOVERY_DIR_VAL, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM MTT_ACCOUNT_COST_CHARGES r WHERE r.CONTRACT_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllMTTActCostChargesByIDParameters =
    "EObjMTTActCostCharges.ContractId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllMTTActCostChargesByIDResults =
    "EObjMTTActCostCharges.MTTActCostChargesIdPk," +
    "EObjMTTActCostCharges.ContractId," +
    "EObjMTTActCostCharges.CostBase," +
    "EObjMTTActCostCharges.DirectShipApprovedInd," +
    "EObjMTTActCostCharges.DoNotApplyDirectDiscountInd," +
    "EObjMTTActCostCharges.SRPComplicance," +
    "EObjMTTActCostCharges.PriceMatchGapFeeInd," +
    "EObjMTTActCostCharges.BrokenCaseUpchargePercentage," +
    "EObjMTTActCostCharges.BrokenCaseUpchargeCap," +
    "EObjMTTActCostCharges.BrokenCaseUpchargeInd," +
    "EObjMTTActCostCharges.BrokenCaseCal," +
    "EObjMTTActCostCharges.ShelfLabelPricedInd," +
    "EObjMTTActCostCharges.PSRP," +
    "EObjMTTActCostCharges.AddFRTRecoverySRPInd," +
    "EObjMTTActCostCharges.SRPFRTRecoveryValue," +
    "EObjMTTActCostCharges.SRPFRTRecoveryDirectValue," +
    "EObjMTTActCostCharges.lastUpdateDt," +
    "EObjMTTActCostCharges.lastUpdateUser," +
    "EObjMTTActCostCharges.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllMTTActCostChargesByIDHistorySql = "SELECT r.H_MTT_ACT_COST_CHARGES_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.MTT_ACT_COST_CHARGES_ID MTT_ACT_COST_CHARGES_ID, r.CONTRACT_ID CONTRACT_ID, r.COST_BASE_TP_CD COST_BASE_TP_CD, r.DIRECT_SHIP_APPROVED_IND DIRECT_SHIP_APPROVED_IND, r.DO_NOT_APPLY_DIRECT_DISC_IND DO_NOT_APPLY_DIRECT_DISC_IND, r.SRP_COMPLIANCE_TP_CD SRP_COMPLIANCE_TP_CD, r.PRICE_MATCH_GAP_FEE_IND PRICE_MATCH_GAP_FEE_IND, r.BRKN_CASE_UPCHARGE_PCT BRKN_CASE_UPCHARGE_PCT, r.BRKN_CASE_UPCHARGE_CAP BRKN_CASE_UPCHARGE_CAP, r.BRKN_CASE_UPCHARGE_IND BRKN_CASE_UPCHARGE_IND, r.BRKN_CASE_CALC_TP_CD BRKN_CASE_CALC_TP_CD, r.SHELF_LABEL_PRICED_IND SHELF_LABEL_PRICED_IND, r.PSRP_TP_CD PSRP_TP_CD, r.ADD_FRT_RECOVERY_SRP_IND ADD_FRT_RECOVERY_SRP_IND, r.SRP_FRT_RECOVERY_VAL SRP_FRT_RECOVERY_VAL, r.SRP_FRT_RECOVERY_DIR_VAL SRP_FRT_RECOVERY_DIR_VAL, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_MTT_ACCOUNT_COST_CHARGES r WHERE r.CONTRACT_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllMTTActCostChargesByIDHistoryParameters =
    "EObjMTTActCostCharges.ContractId," +
    "EObjMTTActCostCharges.lastUpdateDt," +
    "EObjMTTActCostCharges.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllMTTActCostChargesByIDHistoryResults =
    "EObjMTTActCostCharges.historyIdPK," +
    "EObjMTTActCostCharges.histActionCode," +
    "EObjMTTActCostCharges.histCreatedBy," +
    "EObjMTTActCostCharges.histCreateDt," +
    "EObjMTTActCostCharges.histEndDt," +
    "EObjMTTActCostCharges.MTTActCostChargesIdPk," +
    "EObjMTTActCostCharges.ContractId," +
    "EObjMTTActCostCharges.CostBase," +
    "EObjMTTActCostCharges.DirectShipApprovedInd," +
    "EObjMTTActCostCharges.DoNotApplyDirectDiscountInd," +
    "EObjMTTActCostCharges.SRPComplicance," +
    "EObjMTTActCostCharges.PriceMatchGapFeeInd," +
    "EObjMTTActCostCharges.BrokenCaseUpchargePercentage," +
    "EObjMTTActCostCharges.BrokenCaseUpchargeCap," +
    "EObjMTTActCostCharges.BrokenCaseUpchargeInd," +
    "EObjMTTActCostCharges.BrokenCaseCal," +
    "EObjMTTActCostCharges.ShelfLabelPricedInd," +
    "EObjMTTActCostCharges.PSRP," +
    "EObjMTTActCostCharges.AddFRTRecoverySRPInd," +
    "EObjMTTActCostCharges.SRPFRTRecoveryValue," +
    "EObjMTTActCostCharges.SRPFRTRecoveryDirectValue," +
    "EObjMTTActCostCharges.lastUpdateDt," +
    "EObjMTTActCostCharges.lastUpdateUser," +
    "EObjMTTActCostCharges.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getMTTActCostChargesSql, pattern=tableAliasString)
  @EntityMapping(parameters=getMTTActCostChargesParameters, results=getMTTActCostChargesResults)
  Iterator<ResultQueue1<EObjMTTActCostCharges>> getMTTActCostCharges(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getMTTActCostChargesHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getMTTActCostChargesHistoryParameters, results=getMTTActCostChargesHistoryResults)
  Iterator<ResultQueue1<EObjMTTActCostCharges>> getMTTActCostChargesHistory(Object[] parameters);


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllMTTActCostChargesByIDSql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllMTTActCostChargesByIDParameters, results=getAllMTTActCostChargesByIDResults)
  Iterator<ResultQueue1<EObjMTTActCostCharges>> getAllMTTActCostChargesByID(Object[] parameters);


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllMTTActCostChargesByIDHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllMTTActCostChargesByIDHistoryParameters, results=getAllMTTActCostChargesByIDHistoryResults)
  Iterator<ResultQueue1<EObjMTTActCostCharges>> getAllMTTActCostChargesByIDHistory(Object[] parameters);  


}


