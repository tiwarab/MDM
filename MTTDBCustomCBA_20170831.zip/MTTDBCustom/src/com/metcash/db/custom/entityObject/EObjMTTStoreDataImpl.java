package com.metcash.db.custom.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.metcash.db.custom.entityObject.EObjMTTStore;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjMTTStoreDataImpl  extends BaseData implements EObjMTTStoreData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjMTTStoreData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000015daaa4edadL;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjMTTStoreDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select MTT_STORE_ID, CONT_ID, MSO_TP_CD, STORE_OPEN_DT, STORE_CLOSE_DT,  LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from MTT_STORE where MTT_STORE_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjMTTStore> getEObjMTTStore (Long mTTStoreIdPk)
  {
    return queryIterator (getEObjMTTStoreStatementDescriptor, mTTStoreIdPk);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjMTTStoreStatementDescriptor = createStatementDescriptor (
    "getEObjMTTStore(Long)",
    "select MTT_STORE_ID, CONT_ID, MSO_TP_CD, STORE_OPEN_DT, STORE_CLOSE_DT,  LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from MTT_STORE where MTT_STORE_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"mtt_store_id", "cont_id", "mso_tp_cd", "store_open_dt", "store_close_dt", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjMTTStoreParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjMTTStoreRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 0, 0, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjMTTStoreParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjMTTStoreRowHandler extends BaseRowHandler<EObjMTTStore>
  {
    /**
     * @generated
     */
    public EObjMTTStore handle (java.sql.ResultSet rs, EObjMTTStore returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjMTTStore ();
      returnObject.setMTTStoreIdPk(getLongObject (rs, 1)); 
      returnObject.setPartyId(getLongObject (rs, 2)); 
      returnObject.setMSO(getLongObject (rs, 3)); 
      returnObject.setStoreOpenDate(getTimestamp (rs, 4)); 
      returnObject.setStoreCloseDate(getTimestamp (rs, 5)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 6)); 
      returnObject.setLastUpdateUser(getString (rs, 7)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 8)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into MTT_STORE (MTT_STORE_ID, CONT_ID, MSO_TP_CD, STORE_OPEN_DT, STORE_CLOSE_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :mTTStoreIdPk, :partyId, :mSO, :storeOpenDate, :storeCloseDate, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjMTTStore (EObjMTTStore e)
  {
    return update (createEObjMTTStoreStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjMTTStoreStatementDescriptor = createStatementDescriptor (
    "createEObjMTTStore(com.metcash.db.custom.entityObject.EObjMTTStore)",
    "insert into MTT_STORE (MTT_STORE_ID, CONT_ID, MSO_TP_CD, STORE_OPEN_DT, STORE_CLOSE_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjMTTStoreParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 0, 0, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjMTTStoreParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjMTTStore bean0 = (EObjMTTStore) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getMTTStoreIdPk());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getPartyId());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getMSO());
      setTimestamp (stmt, 4, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStoreOpenDate());
      setTimestamp (stmt, 5, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStoreCloseDate());
      setTimestamp (stmt, 6, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 8, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update MTT_STORE set CONT_ID = :partyId, MSO_TP_CD = :mSO, STORE_OPEN_DT = :storeOpenDate, STORE_CLOSE_DT = :storeCloseDate, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where MTT_STORE_ID = :mTTStoreIdPk and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjMTTStore (EObjMTTStore e)
  {
    return update (updateEObjMTTStoreStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjMTTStoreStatementDescriptor = createStatementDescriptor (
    "updateEObjMTTStore(com.metcash.db.custom.entityObject.EObjMTTStore)",
    "update MTT_STORE set CONT_ID =  ? , MSO_TP_CD =  ? , STORE_OPEN_DT =  ? , STORE_CLOSE_DT =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where MTT_STORE_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjMTTStoreParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 19, 0, 0, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjMTTStoreParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjMTTStore bean0 = (EObjMTTStore) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getPartyId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getMSO());
      setTimestamp (stmt, 3, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStoreOpenDate());
      setTimestamp (stmt, 4, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStoreCloseDate());
      setTimestamp (stmt, 5, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 7, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 8, Types.BIGINT, (Long)bean0.getMTTStoreIdPk());
      setTimestamp (stmt, 9, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from MTT_STORE where MTT_STORE_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjMTTStore (Long mTTStoreIdPk)
  {
    return update (deleteEObjMTTStoreStatementDescriptor, mTTStoreIdPk);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjMTTStoreStatementDescriptor = createStatementDescriptor (
    "deleteEObjMTTStore(Long)",
    "delete from MTT_STORE where MTT_STORE_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjMTTStoreParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjMTTStoreParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
