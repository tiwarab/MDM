
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[5ae06c935fe0519a31cf0ff2badaaf12]
 */

package com.metcash.db.custom.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;

import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;

import com.metcash.db.custom.constant.MTTDBCustomComponentID;
import com.metcash.db.custom.constant.MTTDBCustomErrorReasonCode;
import com.metcash.db.custom.constant.MTTDBCustomPropertyKeys;

import com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice;

import com.metcash.db.custom.interfaces.MTTDBCustom;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>MTTActOrderInvoiceBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class MTTActOrderInvoiceBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjMTTActOrderInvoice eObjMTTActOrderInvoice;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(MTTActOrderInvoiceBObj.class);
		
 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String invoiceSequenceValue;
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String invoiceModeValue;
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String orderGuideValue;
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String printCatInvoiceBreakValue;
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String invoiceRecapSummaryValue;
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String pickupDeiverValue;
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String totesValue;
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String unitCaseCostPrintValue;
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String invoiceFormatValue;
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String invoiceValue;
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String delPickPackInvoiceValue;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public MTTActOrderInvoiceBObj() {
        super();
        init();
        eObjMTTActOrderInvoice = new EObjMTTActOrderInvoice();
        setComponentID(MTTDBCustomComponentID.MTTACT_ORDER_INVOICE_BOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("MTTActOrderInvoiceIdPk", null);
        metaDataMap.put("ContractId", null);
        metaDataMap.put("PrintRetailInd", null);
        metaDataMap.put("PrintPriceMatchSummaryInd", null);
        metaDataMap.put("SubstituteItemInd", null);
        metaDataMap.put("InvoiceSequenceType", null);
        metaDataMap.put("InvoiceSequenceValue", null);
        metaDataMap.put("InvoiceCopiesNumber", null);
        metaDataMap.put("InvoiceModeType", null);
        metaDataMap.put("InvoiceModeValue", null);
        metaDataMap.put("OrderGuideType", null);
        metaDataMap.put("OrderGuideValue", null);
        metaDataMap.put("SepOrderItemReserveInd", null);
        metaDataMap.put("Specialinstructions", null);
        metaDataMap.put("PrintCatInvoiceBreakType", null);
        metaDataMap.put("PrintCatInvoiceBreakValue", null);
        metaDataMap.put("InvoiceRecapSummaryType", null);
        metaDataMap.put("InvoiceRecapSummaryValue", null);
        metaDataMap.put("PONumberRequiredInd", null);
        metaDataMap.put("PickupDeiverType", null);
        metaDataMap.put("PickupDeiverValue", null);
        metaDataMap.put("PrintAlternateTobaccoLicenceInd", null);
        metaDataMap.put("TotesInd", null);
        metaDataMap.put("TotesType", null);
        metaDataMap.put("TotesValue", null);
        metaDataMap.put("UnitCaseCostPrintType", null);
        metaDataMap.put("UnitCaseCostPrintValue", null);
        metaDataMap.put("InvoiceFormatType", null);
        metaDataMap.put("InvoiceFormatValue", null);
        metaDataMap.put("PickEachesInd", null);
        metaDataMap.put("InvoiceType", null);
        metaDataMap.put("InvoiceValue", null);
        metaDataMap.put("InvoiceStopMessage", null);
        metaDataMap.put("DelPickPackInvoiceType", null);
        metaDataMap.put("DelPickPackInvoiceValue", null);
        metaDataMap.put("PrintHOInvoiceInd", null);
        metaDataMap.put("PrintWholesaleOnInvoiceInd", null);
        metaDataMap.put("SepInvoicePerCustomerPOInd", null);
        metaDataMap.put("ASNRequiredInd", null);
        metaDataMap.put("EASNMailbox", null);
        metaDataMap.put("MTTActOrderInvoiceHistActionCode", null);
        metaDataMap.put("MTTActOrderInvoiceHistCreateDate", null);
        metaDataMap.put("MTTActOrderInvoiceHistCreatedBy", null);
        metaDataMap.put("MTTActOrderInvoiceHistEndDate", null);
        metaDataMap.put("MTTActOrderInvoiceHistoryIdPK", null);
        metaDataMap.put("MTTActOrderInvoiceLastUpdateDate", null);
        metaDataMap.put("MTTActOrderInvoiceLastUpdateTxId", null);
        metaDataMap.put("MTTActOrderInvoiceLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("MTTActOrderInvoiceIdPk", getMTTActOrderInvoiceIdPk());
            metaDataMap.put("ContractId", getContractId());
            metaDataMap.put("PrintRetailInd", getPrintRetailInd());
            metaDataMap.put("PrintPriceMatchSummaryInd", getPrintPriceMatchSummaryInd());
            metaDataMap.put("SubstituteItemInd", getSubstituteItemInd());
            metaDataMap.put("InvoiceSequenceType", getInvoiceSequenceType());
            metaDataMap.put("InvoiceSequenceValue", getInvoiceSequenceValue());
            metaDataMap.put("InvoiceCopiesNumber", getInvoiceCopiesNumber());
            metaDataMap.put("InvoiceModeType", getInvoiceModeType());
            metaDataMap.put("InvoiceModeValue", getInvoiceModeValue());
            metaDataMap.put("OrderGuideType", getOrderGuideType());
            metaDataMap.put("OrderGuideValue", getOrderGuideValue());
            metaDataMap.put("SepOrderItemReserveInd", getSepOrderItemReserveInd());
            metaDataMap.put("Specialinstructions", getSpecialinstructions());
            metaDataMap.put("PrintCatInvoiceBreakType", getPrintCatInvoiceBreakType());
            metaDataMap.put("PrintCatInvoiceBreakValue", getPrintCatInvoiceBreakValue());
            metaDataMap.put("InvoiceRecapSummaryType", getInvoiceRecapSummaryType());
            metaDataMap.put("InvoiceRecapSummaryValue", getInvoiceRecapSummaryValue());
            metaDataMap.put("PONumberRequiredInd", getPONumberRequiredInd());
            metaDataMap.put("PickupDeiverType", getPickupDeiverType());
            metaDataMap.put("PickupDeiverValue", getPickupDeiverValue());
            metaDataMap.put("PrintAlternateTobaccoLicenceInd", getPrintAlternateTobaccoLicenceInd());
            metaDataMap.put("TotesInd", getTotesInd());
            metaDataMap.put("TotesType", getTotesType());
            metaDataMap.put("TotesValue", getTotesValue());
            metaDataMap.put("UnitCaseCostPrintType", getUnitCaseCostPrintType());
            metaDataMap.put("UnitCaseCostPrintValue", getUnitCaseCostPrintValue());
            metaDataMap.put("InvoiceFormatType", getInvoiceFormatType());
            metaDataMap.put("InvoiceFormatValue", getInvoiceFormatValue());
            metaDataMap.put("PickEachesInd", getPickEachesInd());
            metaDataMap.put("InvoiceType", getInvoiceType());
            metaDataMap.put("InvoiceValue", getInvoiceValue());
            metaDataMap.put("InvoiceStopMessage", getInvoiceStopMessage());
            metaDataMap.put("DelPickPackInvoiceType", getDelPickPackInvoiceType());
            metaDataMap.put("DelPickPackInvoiceValue", getDelPickPackInvoiceValue());
            metaDataMap.put("PrintHOInvoiceInd", getPrintHOInvoiceInd());
            metaDataMap.put("PrintWholesaleOnInvoiceInd", getPrintWholesaleOnInvoiceInd());
            metaDataMap.put("SepInvoicePerCustomerPOInd", getSepInvoicePerCustomerPOInd());
            metaDataMap.put("ASNRequiredInd", getASNRequiredInd());
            metaDataMap.put("EASNMailbox", getEASNMailbox());
            metaDataMap.put("MTTActOrderInvoiceHistActionCode", getMTTActOrderInvoiceHistActionCode());
            metaDataMap.put("MTTActOrderInvoiceHistCreateDate", getMTTActOrderInvoiceHistCreateDate());
            metaDataMap.put("MTTActOrderInvoiceHistCreatedBy", getMTTActOrderInvoiceHistCreatedBy());
            metaDataMap.put("MTTActOrderInvoiceHistEndDate", getMTTActOrderInvoiceHistEndDate());
            metaDataMap.put("MTTActOrderInvoiceHistoryIdPK", getMTTActOrderInvoiceHistoryIdPK());
            metaDataMap.put("MTTActOrderInvoiceLastUpdateDate", getMTTActOrderInvoiceLastUpdateDate());
            metaDataMap.put("MTTActOrderInvoiceLastUpdateTxId", getMTTActOrderInvoiceLastUpdateTxId());
            metaDataMap.put("MTTActOrderInvoiceLastUpdateUser", getMTTActOrderInvoiceLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjMTTActOrderInvoice != null) {
            eObjMTTActOrderInvoice.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjMTTActOrderInvoice getEObjMTTActOrderInvoice() {
        bRequireMapRefresh = true;
        return eObjMTTActOrderInvoice;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjMTTActOrderInvoice
     *            The eObjMTTActOrderInvoice to set.
     * @generated
     */
    public void setEObjMTTActOrderInvoice(EObjMTTActOrderInvoice eObjMTTActOrderInvoice) {
        bRequireMapRefresh = true;
        this.eObjMTTActOrderInvoice = eObjMTTActOrderInvoice;
        if (this.eObjMTTActOrderInvoice != null && this.eObjMTTActOrderInvoice.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjMTTActOrderInvoice.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the mTTActOrderInvoiceIdPk attribute.
     * 
     * @generated
     */
    public String getMTTActOrderInvoiceIdPk (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActOrderInvoice.getMTTActOrderInvoiceIdPk());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the mTTActOrderInvoiceIdPk attribute.
     * 
     * @param newMTTActOrderInvoiceIdPk
     *     The new value of mTTActOrderInvoiceIdPk.
     * @generated
     */
    public void setMTTActOrderInvoiceIdPk( String newMTTActOrderInvoiceIdPk ) throws Exception {
        metaDataMap.put("MTTActOrderInvoiceIdPk", newMTTActOrderInvoiceIdPk);

        if (newMTTActOrderInvoiceIdPk == null || newMTTActOrderInvoiceIdPk.equals("")) {
            newMTTActOrderInvoiceIdPk = null;


        }
        eObjMTTActOrderInvoice.setMTTActOrderInvoiceIdPk( DWLFunctionUtils.getLongFromString(newMTTActOrderInvoiceIdPk) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contractId attribute.
     * 
     * @generated
     */
    public String getContractId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActOrderInvoice.getContractId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contractId attribute.
     * 
     * @param newContractId
     *     The new value of contractId.
     * @generated
     */
    public void setContractId( String newContractId ) throws Exception {
        metaDataMap.put("ContractId", newContractId);

        if (newContractId == null || newContractId.equals("")) {
            newContractId = null;


        }
        eObjMTTActOrderInvoice.setContractId( DWLFunctionUtils.getLongFromString(newContractId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the printRetailInd attribute.
     * 
     * @generated
     */
    public String getPrintRetailInd (){
   
        return eObjMTTActOrderInvoice.getPrintRetailInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the printRetailInd attribute.
     * 
     * @param newPrintRetailInd
     *     The new value of printRetailInd.
     * @generated
     */
    public void setPrintRetailInd( String newPrintRetailInd ) throws Exception {
        metaDataMap.put("PrintRetailInd", newPrintRetailInd);

        if (newPrintRetailInd == null || newPrintRetailInd.equals("")) {
            newPrintRetailInd = null;


        }
        eObjMTTActOrderInvoice.setPrintRetailInd( newPrintRetailInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the printPriceMatchSummaryInd attribute.
     * 
     * @generated
     */
    public String getPrintPriceMatchSummaryInd (){
   
        return eObjMTTActOrderInvoice.getPrintPriceMatchSummaryInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the printPriceMatchSummaryInd attribute.
     * 
     * @param newPrintPriceMatchSummaryInd
     *     The new value of printPriceMatchSummaryInd.
     * @generated
     */
    public void setPrintPriceMatchSummaryInd( String newPrintPriceMatchSummaryInd ) throws Exception {
        metaDataMap.put("PrintPriceMatchSummaryInd", newPrintPriceMatchSummaryInd);

        if (newPrintPriceMatchSummaryInd == null || newPrintPriceMatchSummaryInd.equals("")) {
            newPrintPriceMatchSummaryInd = null;


        }
        eObjMTTActOrderInvoice.setPrintPriceMatchSummaryInd( newPrintPriceMatchSummaryInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the substituteItemInd attribute.
     * 
     * @generated
     */
    public String getSubstituteItemInd (){
   
        return eObjMTTActOrderInvoice.getSubstituteItemInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the substituteItemInd attribute.
     * 
     * @param newSubstituteItemInd
     *     The new value of substituteItemInd.
     * @generated
     */
    public void setSubstituteItemInd( String newSubstituteItemInd ) throws Exception {
        metaDataMap.put("SubstituteItemInd", newSubstituteItemInd);

        if (newSubstituteItemInd == null || newSubstituteItemInd.equals("")) {
            newSubstituteItemInd = null;


        }
        eObjMTTActOrderInvoice.setSubstituteItemInd( newSubstituteItemInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the invoiceSequenceType attribute.
     * 
     * @generated
     */
    public String getInvoiceSequenceType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActOrderInvoice.getInvoiceSequence());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the invoiceSequenceType attribute.
     * 
     * @param newInvoiceSequenceType
     *     The new value of invoiceSequenceType.
     * @generated
     */
    public void setInvoiceSequenceType( String newInvoiceSequenceType ) throws Exception {
        metaDataMap.put("InvoiceSequenceType", newInvoiceSequenceType);

        if (newInvoiceSequenceType == null || newInvoiceSequenceType.equals("")) {
            newInvoiceSequenceType = null;


        }
        eObjMTTActOrderInvoice.setInvoiceSequence( DWLFunctionUtils.getLongFromString(newInvoiceSequenceType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the invoiceSequenceValue attribute.
     * 
     * @generated
     */
    public String getInvoiceSequenceValue (){
      return invoiceSequenceValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the invoiceSequenceValue attribute.
     * 
     * @param newInvoiceSequenceValue
     *     The new value of invoiceSequenceValue.
     * @generated
     */
    public void setInvoiceSequenceValue( String newInvoiceSequenceValue ) throws Exception {
        metaDataMap.put("InvoiceSequenceValue", newInvoiceSequenceValue);

        if (newInvoiceSequenceValue == null || newInvoiceSequenceValue.equals("")) {
            newInvoiceSequenceValue = null;


        }
        invoiceSequenceValue = newInvoiceSequenceValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the invoiceCopiesNumber attribute.
     * 
     * @generated
     */
    public String getInvoiceCopiesNumber (){
   
        return DWLFunctionUtils.getStringFromInteger(eObjMTTActOrderInvoice.getInvoiceCopiesNumber());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the invoiceCopiesNumber attribute.
     * 
     * @param newInvoiceCopiesNumber
     *     The new value of invoiceCopiesNumber.
     * @generated
     */
    public void setInvoiceCopiesNumber( String newInvoiceCopiesNumber ) throws Exception {
        metaDataMap.put("InvoiceCopiesNumber", newInvoiceCopiesNumber);

        if (newInvoiceCopiesNumber == null || newInvoiceCopiesNumber.equals("")) {
            newInvoiceCopiesNumber = null;


        }
        eObjMTTActOrderInvoice.setInvoiceCopiesNumber( DWLFunctionUtils.getIntegerFromString(newInvoiceCopiesNumber) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the invoiceModeType attribute.
     * 
     * @generated
     */
    public String getInvoiceModeType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActOrderInvoice.getInvoiceMode());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the invoiceModeType attribute.
     * 
     * @param newInvoiceModeType
     *     The new value of invoiceModeType.
     * @generated
     */
    public void setInvoiceModeType( String newInvoiceModeType ) throws Exception {
        metaDataMap.put("InvoiceModeType", newInvoiceModeType);

        if (newInvoiceModeType == null || newInvoiceModeType.equals("")) {
            newInvoiceModeType = null;


        }
        eObjMTTActOrderInvoice.setInvoiceMode( DWLFunctionUtils.getLongFromString(newInvoiceModeType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the invoiceModeValue attribute.
     * 
     * @generated
     */
    public String getInvoiceModeValue (){
      return invoiceModeValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the invoiceModeValue attribute.
     * 
     * @param newInvoiceModeValue
     *     The new value of invoiceModeValue.
     * @generated
     */
    public void setInvoiceModeValue( String newInvoiceModeValue ) throws Exception {
        metaDataMap.put("InvoiceModeValue", newInvoiceModeValue);

        if (newInvoiceModeValue == null || newInvoiceModeValue.equals("")) {
            newInvoiceModeValue = null;


        }
        invoiceModeValue = newInvoiceModeValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the orderGuideType attribute.
     * 
     * @generated
     */
    public String getOrderGuideType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActOrderInvoice.getOrderGuide());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the orderGuideType attribute.
     * 
     * @param newOrderGuideType
     *     The new value of orderGuideType.
     * @generated
     */
    public void setOrderGuideType( String newOrderGuideType ) throws Exception {
        metaDataMap.put("OrderGuideType", newOrderGuideType);

        if (newOrderGuideType == null || newOrderGuideType.equals("")) {
            newOrderGuideType = null;


        }
        eObjMTTActOrderInvoice.setOrderGuide( DWLFunctionUtils.getLongFromString(newOrderGuideType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the orderGuideValue attribute.
     * 
     * @generated
     */
    public String getOrderGuideValue (){
      return orderGuideValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the orderGuideValue attribute.
     * 
     * @param newOrderGuideValue
     *     The new value of orderGuideValue.
     * @generated
     */
    public void setOrderGuideValue( String newOrderGuideValue ) throws Exception {
        metaDataMap.put("OrderGuideValue", newOrderGuideValue);

        if (newOrderGuideValue == null || newOrderGuideValue.equals("")) {
            newOrderGuideValue = null;


        }
        orderGuideValue = newOrderGuideValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sepOrderItemReserveInd attribute.
     * 
     * @generated
     */
    public String getSepOrderItemReserveInd (){
   
        return eObjMTTActOrderInvoice.getSepOrderItemReserveInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sepOrderItemReserveInd attribute.
     * 
     * @param newSepOrderItemReserveInd
     *     The new value of sepOrderItemReserveInd.
     * @generated
     */
    public void setSepOrderItemReserveInd( String newSepOrderItemReserveInd ) throws Exception {
        metaDataMap.put("SepOrderItemReserveInd", newSepOrderItemReserveInd);

        if (newSepOrderItemReserveInd == null || newSepOrderItemReserveInd.equals("")) {
            newSepOrderItemReserveInd = null;


        }
        eObjMTTActOrderInvoice.setSepOrderItemReserveInd( newSepOrderItemReserveInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the specialinstructions attribute.
     * 
     * @generated
     */
    public String getSpecialinstructions (){
   
        return eObjMTTActOrderInvoice.getSpecialinstructions();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the specialinstructions attribute.
     * 
     * @param newSpecialinstructions
     *     The new value of specialinstructions.
     * @generated
     */
    public void setSpecialinstructions( String newSpecialinstructions ) throws Exception {
        metaDataMap.put("Specialinstructions", newSpecialinstructions);

        if (newSpecialinstructions == null || newSpecialinstructions.equals("")) {
            newSpecialinstructions = null;


        }
        eObjMTTActOrderInvoice.setSpecialinstructions( newSpecialinstructions );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the printCatInvoiceBreakType attribute.
     * 
     * @generated
     */
    public String getPrintCatInvoiceBreakType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActOrderInvoice.getPrintCatInvoiceBreak());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the printCatInvoiceBreakType attribute.
     * 
     * @param newPrintCatInvoiceBreakType
     *     The new value of printCatInvoiceBreakType.
     * @generated
     */
    public void setPrintCatInvoiceBreakType( String newPrintCatInvoiceBreakType ) throws Exception {
        metaDataMap.put("PrintCatInvoiceBreakType", newPrintCatInvoiceBreakType);

        if (newPrintCatInvoiceBreakType == null || newPrintCatInvoiceBreakType.equals("")) {
            newPrintCatInvoiceBreakType = null;


        }
        eObjMTTActOrderInvoice.setPrintCatInvoiceBreak( DWLFunctionUtils.getLongFromString(newPrintCatInvoiceBreakType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the printCatInvoiceBreakValue attribute.
     * 
     * @generated
     */
    public String getPrintCatInvoiceBreakValue (){
      return printCatInvoiceBreakValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the printCatInvoiceBreakValue attribute.
     * 
     * @param newPrintCatInvoiceBreakValue
     *     The new value of printCatInvoiceBreakValue.
     * @generated
     */
    public void setPrintCatInvoiceBreakValue( String newPrintCatInvoiceBreakValue ) throws Exception {
        metaDataMap.put("PrintCatInvoiceBreakValue", newPrintCatInvoiceBreakValue);

        if (newPrintCatInvoiceBreakValue == null || newPrintCatInvoiceBreakValue.equals("")) {
            newPrintCatInvoiceBreakValue = null;


        }
        printCatInvoiceBreakValue = newPrintCatInvoiceBreakValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the invoiceRecapSummaryType attribute.
     * 
     * @generated
     */
    public String getInvoiceRecapSummaryType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActOrderInvoice.getInvoiceRecapSummary());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the invoiceRecapSummaryType attribute.
     * 
     * @param newInvoiceRecapSummaryType
     *     The new value of invoiceRecapSummaryType.
     * @generated
     */
    public void setInvoiceRecapSummaryType( String newInvoiceRecapSummaryType ) throws Exception {
        metaDataMap.put("InvoiceRecapSummaryType", newInvoiceRecapSummaryType);

        if (newInvoiceRecapSummaryType == null || newInvoiceRecapSummaryType.equals("")) {
            newInvoiceRecapSummaryType = null;


        }
        eObjMTTActOrderInvoice.setInvoiceRecapSummary( DWLFunctionUtils.getLongFromString(newInvoiceRecapSummaryType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the invoiceRecapSummaryValue attribute.
     * 
     * @generated
     */
    public String getInvoiceRecapSummaryValue (){
      return invoiceRecapSummaryValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the invoiceRecapSummaryValue attribute.
     * 
     * @param newInvoiceRecapSummaryValue
     *     The new value of invoiceRecapSummaryValue.
     * @generated
     */
    public void setInvoiceRecapSummaryValue( String newInvoiceRecapSummaryValue ) throws Exception {
        metaDataMap.put("InvoiceRecapSummaryValue", newInvoiceRecapSummaryValue);

        if (newInvoiceRecapSummaryValue == null || newInvoiceRecapSummaryValue.equals("")) {
            newInvoiceRecapSummaryValue = null;


        }
        invoiceRecapSummaryValue = newInvoiceRecapSummaryValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the pONumberRequiredInd attribute.
     * 
     * @generated
     */
    public String getPONumberRequiredInd (){
   
        return eObjMTTActOrderInvoice.getPONumberRequiredInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the pONumberRequiredInd attribute.
     * 
     * @param newPONumberRequiredInd
     *     The new value of pONumberRequiredInd.
     * @generated
     */
    public void setPONumberRequiredInd( String newPONumberRequiredInd ) throws Exception {
        metaDataMap.put("PONumberRequiredInd", newPONumberRequiredInd);

        if (newPONumberRequiredInd == null || newPONumberRequiredInd.equals("")) {
            newPONumberRequiredInd = null;


        }
        eObjMTTActOrderInvoice.setPONumberRequiredInd( newPONumberRequiredInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the pickupDeiverType attribute.
     * 
     * @generated
     */
    public String getPickupDeiverType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActOrderInvoice.getPickupDeiver());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the pickupDeiverType attribute.
     * 
     * @param newPickupDeiverType
     *     The new value of pickupDeiverType.
     * @generated
     */
    public void setPickupDeiverType( String newPickupDeiverType ) throws Exception {
        metaDataMap.put("PickupDeiverType", newPickupDeiverType);

        if (newPickupDeiverType == null || newPickupDeiverType.equals("")) {
            newPickupDeiverType = null;


        }
        eObjMTTActOrderInvoice.setPickupDeiver( DWLFunctionUtils.getLongFromString(newPickupDeiverType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the pickupDeiverValue attribute.
     * 
     * @generated
     */
    public String getPickupDeiverValue (){
      return pickupDeiverValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the pickupDeiverValue attribute.
     * 
     * @param newPickupDeiverValue
     *     The new value of pickupDeiverValue.
     * @generated
     */
    public void setPickupDeiverValue( String newPickupDeiverValue ) throws Exception {
        metaDataMap.put("PickupDeiverValue", newPickupDeiverValue);

        if (newPickupDeiverValue == null || newPickupDeiverValue.equals("")) {
            newPickupDeiverValue = null;


        }
        pickupDeiverValue = newPickupDeiverValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the printAlternateTobaccoLicenceInd attribute.
     * 
     * @generated
     */
    public String getPrintAlternateTobaccoLicenceInd (){
   
        return eObjMTTActOrderInvoice.getPrintAlternateTobaccoLicenceInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the printAlternateTobaccoLicenceInd attribute.
     * 
     * @param newPrintAlternateTobaccoLicenceInd
     *     The new value of printAlternateTobaccoLicenceInd.
     * @generated
     */
    public void setPrintAlternateTobaccoLicenceInd( String newPrintAlternateTobaccoLicenceInd ) throws Exception {
        metaDataMap.put("PrintAlternateTobaccoLicenceInd", newPrintAlternateTobaccoLicenceInd);

        if (newPrintAlternateTobaccoLicenceInd == null || newPrintAlternateTobaccoLicenceInd.equals("")) {
            newPrintAlternateTobaccoLicenceInd = null;


        }
        eObjMTTActOrderInvoice.setPrintAlternateTobaccoLicenceInd( newPrintAlternateTobaccoLicenceInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the totesInd attribute.
     * 
     * @generated
     */
    public String getTotesInd (){
   
        return eObjMTTActOrderInvoice.getTotesInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the totesInd attribute.
     * 
     * @param newTotesInd
     *     The new value of totesInd.
     * @generated
     */
    public void setTotesInd( String newTotesInd ) throws Exception {
        metaDataMap.put("TotesInd", newTotesInd);

        if (newTotesInd == null || newTotesInd.equals("")) {
            newTotesInd = null;


        }
        eObjMTTActOrderInvoice.setTotesInd( newTotesInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the totesType attribute.
     * 
     * @generated
     */
    public String getTotesType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActOrderInvoice.getTotes());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the totesType attribute.
     * 
     * @param newTotesType
     *     The new value of totesType.
     * @generated
     */
    public void setTotesType( String newTotesType ) throws Exception {
        metaDataMap.put("TotesType", newTotesType);

        if (newTotesType == null || newTotesType.equals("")) {
            newTotesType = null;


        }
        eObjMTTActOrderInvoice.setTotes( DWLFunctionUtils.getLongFromString(newTotesType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the totesValue attribute.
     * 
     * @generated
     */
    public String getTotesValue (){
      return totesValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the totesValue attribute.
     * 
     * @param newTotesValue
     *     The new value of totesValue.
     * @generated
     */
    public void setTotesValue( String newTotesValue ) throws Exception {
        metaDataMap.put("TotesValue", newTotesValue);

        if (newTotesValue == null || newTotesValue.equals("")) {
            newTotesValue = null;


        }
        totesValue = newTotesValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the unitCaseCostPrintType attribute.
     * 
     * @generated
     */
    public String getUnitCaseCostPrintType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActOrderInvoice.getUnitCaseCostPrint());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the unitCaseCostPrintType attribute.
     * 
     * @param newUnitCaseCostPrintType
     *     The new value of unitCaseCostPrintType.
     * @generated
     */
    public void setUnitCaseCostPrintType( String newUnitCaseCostPrintType ) throws Exception {
        metaDataMap.put("UnitCaseCostPrintType", newUnitCaseCostPrintType);

        if (newUnitCaseCostPrintType == null || newUnitCaseCostPrintType.equals("")) {
            newUnitCaseCostPrintType = null;


        }
        eObjMTTActOrderInvoice.setUnitCaseCostPrint( DWLFunctionUtils.getLongFromString(newUnitCaseCostPrintType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the unitCaseCostPrintValue attribute.
     * 
     * @generated
     */
    public String getUnitCaseCostPrintValue (){
      return unitCaseCostPrintValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the unitCaseCostPrintValue attribute.
     * 
     * @param newUnitCaseCostPrintValue
     *     The new value of unitCaseCostPrintValue.
     * @generated
     */
    public void setUnitCaseCostPrintValue( String newUnitCaseCostPrintValue ) throws Exception {
        metaDataMap.put("UnitCaseCostPrintValue", newUnitCaseCostPrintValue);

        if (newUnitCaseCostPrintValue == null || newUnitCaseCostPrintValue.equals("")) {
            newUnitCaseCostPrintValue = null;


        }
        unitCaseCostPrintValue = newUnitCaseCostPrintValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the invoiceFormatType attribute.
     * 
     * @generated
     */
    public String getInvoiceFormatType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActOrderInvoice.getInvoiceFormat());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the invoiceFormatType attribute.
     * 
     * @param newInvoiceFormatType
     *     The new value of invoiceFormatType.
     * @generated
     */
    public void setInvoiceFormatType( String newInvoiceFormatType ) throws Exception {
        metaDataMap.put("InvoiceFormatType", newInvoiceFormatType);

        if (newInvoiceFormatType == null || newInvoiceFormatType.equals("")) {
            newInvoiceFormatType = null;


        }
        eObjMTTActOrderInvoice.setInvoiceFormat( DWLFunctionUtils.getLongFromString(newInvoiceFormatType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the invoiceFormatValue attribute.
     * 
     * @generated
     */
    public String getInvoiceFormatValue (){
      return invoiceFormatValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the invoiceFormatValue attribute.
     * 
     * @param newInvoiceFormatValue
     *     The new value of invoiceFormatValue.
     * @generated
     */
    public void setInvoiceFormatValue( String newInvoiceFormatValue ) throws Exception {
        metaDataMap.put("InvoiceFormatValue", newInvoiceFormatValue);

        if (newInvoiceFormatValue == null || newInvoiceFormatValue.equals("")) {
            newInvoiceFormatValue = null;


        }
        invoiceFormatValue = newInvoiceFormatValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the pickEachesInd attribute.
     * 
     * @generated
     */
    public String getPickEachesInd (){
   
        return eObjMTTActOrderInvoice.getPickEachesInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the pickEachesInd attribute.
     * 
     * @param newPickEachesInd
     *     The new value of pickEachesInd.
     * @generated
     */
    public void setPickEachesInd( String newPickEachesInd ) throws Exception {
        metaDataMap.put("PickEachesInd", newPickEachesInd);

        if (newPickEachesInd == null || newPickEachesInd.equals("")) {
            newPickEachesInd = null;


        }
        eObjMTTActOrderInvoice.setPickEachesInd( newPickEachesInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the invoiceType attribute.
     * 
     * @generated
     */
    public String getInvoiceType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActOrderInvoice.getInvoice());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the invoiceType attribute.
     * 
     * @param newInvoiceType
     *     The new value of invoiceType.
     * @generated
     */
    public void setInvoiceType( String newInvoiceType ) throws Exception {
        metaDataMap.put("InvoiceType", newInvoiceType);

        if (newInvoiceType == null || newInvoiceType.equals("")) {
            newInvoiceType = null;


        }
        eObjMTTActOrderInvoice.setInvoice( DWLFunctionUtils.getLongFromString(newInvoiceType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the invoiceValue attribute.
     * 
     * @generated
     */
    public String getInvoiceValue (){
      return invoiceValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the invoiceValue attribute.
     * 
     * @param newInvoiceValue
     *     The new value of invoiceValue.
     * @generated
     */
    public void setInvoiceValue( String newInvoiceValue ) throws Exception {
        metaDataMap.put("InvoiceValue", newInvoiceValue);

        if (newInvoiceValue == null || newInvoiceValue.equals("")) {
            newInvoiceValue = null;


        }
        invoiceValue = newInvoiceValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the invoiceStopMessage attribute.
     * 
     * @generated
     */
    public String getInvoiceStopMessage (){
   
        return eObjMTTActOrderInvoice.getInvoiceStopMessage();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the invoiceStopMessage attribute.
     * 
     * @param newInvoiceStopMessage
     *     The new value of invoiceStopMessage.
     * @generated
     */
    public void setInvoiceStopMessage( String newInvoiceStopMessage ) throws Exception {
        metaDataMap.put("InvoiceStopMessage", newInvoiceStopMessage);

        if (newInvoiceStopMessage == null || newInvoiceStopMessage.equals("")) {
            newInvoiceStopMessage = null;


        }
        eObjMTTActOrderInvoice.setInvoiceStopMessage( newInvoiceStopMessage );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the delPickPackInvoiceType attribute.
     * 
     * @generated
     */
    public String getDelPickPackInvoiceType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActOrderInvoice.getDelPickPackInvoice());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the delPickPackInvoiceType attribute.
     * 
     * @param newDelPickPackInvoiceType
     *     The new value of delPickPackInvoiceType.
     * @generated
     */
    public void setDelPickPackInvoiceType( String newDelPickPackInvoiceType ) throws Exception {
        metaDataMap.put("DelPickPackInvoiceType", newDelPickPackInvoiceType);

        if (newDelPickPackInvoiceType == null || newDelPickPackInvoiceType.equals("")) {
            newDelPickPackInvoiceType = null;


        }
        eObjMTTActOrderInvoice.setDelPickPackInvoice( DWLFunctionUtils.getLongFromString(newDelPickPackInvoiceType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the delPickPackInvoiceValue attribute.
     * 
     * @generated
     */
    public String getDelPickPackInvoiceValue (){
      return delPickPackInvoiceValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the delPickPackInvoiceValue attribute.
     * 
     * @param newDelPickPackInvoiceValue
     *     The new value of delPickPackInvoiceValue.
     * @generated
     */
    public void setDelPickPackInvoiceValue( String newDelPickPackInvoiceValue ) throws Exception {
        metaDataMap.put("DelPickPackInvoiceValue", newDelPickPackInvoiceValue);

        if (newDelPickPackInvoiceValue == null || newDelPickPackInvoiceValue.equals("")) {
            newDelPickPackInvoiceValue = null;


        }
        delPickPackInvoiceValue = newDelPickPackInvoiceValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the printHOInvoiceInd attribute.
     * 
     * @generated
     */
    public String getPrintHOInvoiceInd (){
   
        return eObjMTTActOrderInvoice.getPrintHOInvoiceInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the printHOInvoiceInd attribute.
     * 
     * @param newPrintHOInvoiceInd
     *     The new value of printHOInvoiceInd.
     * @generated
     */
    public void setPrintHOInvoiceInd( String newPrintHOInvoiceInd ) throws Exception {
        metaDataMap.put("PrintHOInvoiceInd", newPrintHOInvoiceInd);

        if (newPrintHOInvoiceInd == null || newPrintHOInvoiceInd.equals("")) {
            newPrintHOInvoiceInd = null;


        }
        eObjMTTActOrderInvoice.setPrintHOInvoiceInd( newPrintHOInvoiceInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the printWholesaleOnInvoiceInd attribute.
     * 
     * @generated
     */
    public String getPrintWholesaleOnInvoiceInd (){
   
        return eObjMTTActOrderInvoice.getPrintWholesaleOnInvoiceInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the printWholesaleOnInvoiceInd attribute.
     * 
     * @param newPrintWholesaleOnInvoiceInd
     *     The new value of printWholesaleOnInvoiceInd.
     * @generated
     */
    public void setPrintWholesaleOnInvoiceInd( String newPrintWholesaleOnInvoiceInd ) throws Exception {
        metaDataMap.put("PrintWholesaleOnInvoiceInd", newPrintWholesaleOnInvoiceInd);

        if (newPrintWholesaleOnInvoiceInd == null || newPrintWholesaleOnInvoiceInd.equals("")) {
            newPrintWholesaleOnInvoiceInd = null;


        }
        eObjMTTActOrderInvoice.setPrintWholesaleOnInvoiceInd( newPrintWholesaleOnInvoiceInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sepInvoicePerCustomerPOInd attribute.
     * 
     * @generated
     */
    public String getSepInvoicePerCustomerPOInd (){
   
        return eObjMTTActOrderInvoice.getSepInvoicePerCustomerPOInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sepInvoicePerCustomerPOInd attribute.
     * 
     * @param newSepInvoicePerCustomerPOInd
     *     The new value of sepInvoicePerCustomerPOInd.
     * @generated
     */
    public void setSepInvoicePerCustomerPOInd( String newSepInvoicePerCustomerPOInd ) throws Exception {
        metaDataMap.put("SepInvoicePerCustomerPOInd", newSepInvoicePerCustomerPOInd);

        if (newSepInvoicePerCustomerPOInd == null || newSepInvoicePerCustomerPOInd.equals("")) {
            newSepInvoicePerCustomerPOInd = null;


        }
        eObjMTTActOrderInvoice.setSepInvoicePerCustomerPOInd( newSepInvoicePerCustomerPOInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the aSNRequiredInd attribute.
     * 
     * @generated
     */
    public String getASNRequiredInd (){
   
        return eObjMTTActOrderInvoice.getASNRequiredInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the aSNRequiredInd attribute.
     * 
     * @param newASNRequiredInd
     *     The new value of aSNRequiredInd.
     * @generated
     */
    public void setASNRequiredInd( String newASNRequiredInd ) throws Exception {
        metaDataMap.put("ASNRequiredInd", newASNRequiredInd);

        if (newASNRequiredInd == null || newASNRequiredInd.equals("")) {
            newASNRequiredInd = null;


        }
        eObjMTTActOrderInvoice.setASNRequiredInd( newASNRequiredInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the eASNMailbox attribute.
     * 
     * @generated
     */
    public String getEASNMailbox (){
   
        return eObjMTTActOrderInvoice.getEASNMailbox();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the eASNMailbox attribute.
     * 
     * @param newEASNMailbox
     *     The new value of eASNMailbox.
     * @generated
     */
    public void setEASNMailbox( String newEASNMailbox ) throws Exception {
        metaDataMap.put("EASNMailbox", newEASNMailbox);

        if (newEASNMailbox == null || newEASNMailbox.equals("")) {
            newEASNMailbox = null;


        }
        eObjMTTActOrderInvoice.setEASNMailbox( newEASNMailbox );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getMTTActOrderInvoiceLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjMTTActOrderInvoice.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getMTTActOrderInvoiceLastUpdateUser() {
        return eObjMTTActOrderInvoice.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getMTTActOrderInvoiceLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjMTTActOrderInvoice.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setMTTActOrderInvoiceLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("MTTActOrderInvoiceLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjMTTActOrderInvoice.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setMTTActOrderInvoiceLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("MTTActOrderInvoiceLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjMTTActOrderInvoice.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setMTTActOrderInvoiceLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("MTTActOrderInvoiceLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjMTTActOrderInvoice.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTActOrderInvoiceHistActionCode history attribute.
     *
     * @generated
     */
    public String getMTTActOrderInvoiceHistActionCode() {
        return eObjMTTActOrderInvoice.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTActOrderInvoiceHistActionCode history attribute.
     *
     * @param aMTTActOrderInvoiceHistActionCode
     *     The new value of MTTActOrderInvoiceHistActionCode.
     * @generated
     */
    public void setMTTActOrderInvoiceHistActionCode(String aMTTActOrderInvoiceHistActionCode) {
        metaDataMap.put("MTTActOrderInvoiceHistActionCode", aMTTActOrderInvoiceHistActionCode);

        if ((aMTTActOrderInvoiceHistActionCode == null) || aMTTActOrderInvoiceHistActionCode.equals("")) {
            aMTTActOrderInvoiceHistActionCode = null;
        }
        eObjMTTActOrderInvoice.setHistActionCode(aMTTActOrderInvoiceHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTActOrderInvoiceHistCreateDate history attribute.
     *
     * @generated
     */
    public String getMTTActOrderInvoiceHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjMTTActOrderInvoice.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTActOrderInvoiceHistCreateDate history attribute.
     *
     * @param aMTTActOrderInvoiceHistCreateDate
     *     The new value of MTTActOrderInvoiceHistCreateDate.
     * @generated
     */
    public void setMTTActOrderInvoiceHistCreateDate(String aMTTActOrderInvoiceHistCreateDate) throws Exception{
        metaDataMap.put("MTTActOrderInvoiceHistCreateDate", aMTTActOrderInvoiceHistCreateDate);

        if ((aMTTActOrderInvoiceHistCreateDate == null) || aMTTActOrderInvoiceHistCreateDate.equals("")) {
            aMTTActOrderInvoiceHistCreateDate = null;
        }

        eObjMTTActOrderInvoice.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aMTTActOrderInvoiceHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTActOrderInvoiceHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getMTTActOrderInvoiceHistCreatedBy() {
        return eObjMTTActOrderInvoice.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTActOrderInvoiceHistCreatedBy history attribute.
     *
     * @param aMTTActOrderInvoiceHistCreatedBy
     *     The new value of MTTActOrderInvoiceHistCreatedBy.
     * @generated
     */
    public void setMTTActOrderInvoiceHistCreatedBy(String aMTTActOrderInvoiceHistCreatedBy) {
        metaDataMap.put("MTTActOrderInvoiceHistCreatedBy", aMTTActOrderInvoiceHistCreatedBy);

        if ((aMTTActOrderInvoiceHistCreatedBy == null) || aMTTActOrderInvoiceHistCreatedBy.equals("")) {
            aMTTActOrderInvoiceHistCreatedBy = null;
        }

        eObjMTTActOrderInvoice.setHistCreatedBy(aMTTActOrderInvoiceHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTActOrderInvoiceHistEndDate history attribute.
     *
     * @generated
     */
    public String getMTTActOrderInvoiceHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjMTTActOrderInvoice.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTActOrderInvoiceHistEndDate history attribute.
     *
     * @param aMTTActOrderInvoiceHistEndDate
     *     The new value of MTTActOrderInvoiceHistEndDate.
     * @generated
     */
    public void setMTTActOrderInvoiceHistEndDate(String aMTTActOrderInvoiceHistEndDate) throws Exception{
        metaDataMap.put("MTTActOrderInvoiceHistEndDate", aMTTActOrderInvoiceHistEndDate);

        if ((aMTTActOrderInvoiceHistEndDate == null) || aMTTActOrderInvoiceHistEndDate.equals("")) {
            aMTTActOrderInvoiceHistEndDate = null;
        }
        eObjMTTActOrderInvoice.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aMTTActOrderInvoiceHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTActOrderInvoiceHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getMTTActOrderInvoiceHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjMTTActOrderInvoice.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTActOrderInvoiceHistoryIdPK history attribute.
     *
     * @param aMTTActOrderInvoiceHistoryIdPK
     *     The new value of MTTActOrderInvoiceHistoryIdPK.
     * @generated
     */
    public void setMTTActOrderInvoiceHistoryIdPK(String aMTTActOrderInvoiceHistoryIdPK) {
        metaDataMap.put("MTTActOrderInvoiceHistoryIdPK", aMTTActOrderInvoiceHistoryIdPK);

        if ((aMTTActOrderInvoiceHistoryIdPK == null) || aMTTActOrderInvoiceHistoryIdPK.equals("")) {
            aMTTActOrderInvoiceHistoryIdPK = null;
        }
        eObjMTTActOrderInvoice.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aMTTActOrderInvoiceHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjMTTActOrderInvoice.getMTTActOrderInvoiceIdPk() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_ORDER_INVOICE_BOBJ).longValue());
                err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.MTTACTORDERINVOICE_MTTACTORDERINVOICEIDPK_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity MTTActOrderInvoice, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjMTTActOrderInvoice.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_ORDER_INVOICE_BOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity MTTActOrderInvoice, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        MTTDBCustom comp = null;
        try {
        
      comp = (MTTDBCustom)TCRMClassFactory.getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  MTTDBCustomComponentID.MTTACT_ORDER_INVOICE_BOBJ, 
                                  "DIERR",
                                  MTTDBCustomErrorReasonCode.MTTACTORDERINVOICE_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
        }
        
        comp.loadBeforeImage(this);
    logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_ContractId(status);
    		controllerValidation_InvoiceSequence(status);
    		controllerValidation_InvoiceMode(status);
    		controllerValidation_OrderGuide(status);
    		controllerValidation_PrintCatInvoiceBreak(status);
    		controllerValidation_InvoiceRecapSummary(status);
    		controllerValidation_PickupDeiver(status);
    		controllerValidation_Totes(status);
    		controllerValidation_UnitCaseCostPrint(status);
    		controllerValidation_InvoiceFormat(status);
    		controllerValidation_Invoice(status);
    		controllerValidation_DelPickPackInvoice(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_ContractId(status);
    		componentValidation_InvoiceSequence(status);
    		componentValidation_InvoiceMode(status);
    		componentValidation_OrderGuide(status);
    		componentValidation_PrintCatInvoiceBreak(status);
    		componentValidation_InvoiceRecapSummary(status);
    		componentValidation_PickupDeiver(status);
    		componentValidation_Totes(status);
    		componentValidation_UnitCaseCostPrint(status);
    		componentValidation_InvoiceFormat(status);
    		componentValidation_Invoice(status);
    		componentValidation_DelPickPackInvoice(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "ContractId"
     *
     * @generated
     */
	private void componentValidation_ContractId(DWLStatus status) {
  
            boolean isContractIdNull = (eObjMTTActOrderInvoice.getContractId() == null);
            if (isContractIdNull) {
                DWLError err = createDWLError("MTTActOrderInvoice", "ContractId", MTTDBCustomErrorReasonCode.MTTACTORDERINVOICE_CONTRACTID_NULL);
                status.addError(err); 
            }
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "InvoiceSequence"
     *
     * @generated
     */
  private void componentValidation_InvoiceSequence(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "InvoiceMode"
     *
     * @generated
     */
  private void componentValidation_InvoiceMode(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "OrderGuide"
     *
     * @generated
     */
  private void componentValidation_OrderGuide(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "PrintCatInvoiceBreak"
     *
     * @generated
     */
  private void componentValidation_PrintCatInvoiceBreak(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "InvoiceRecapSummary"
     *
     * @generated
     */
  private void componentValidation_InvoiceRecapSummary(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "PickupDeiver"
     *
     * @generated
     */
  private void componentValidation_PickupDeiver(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "Totes"
     *
     * @generated
     */
  private void componentValidation_Totes(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "UnitCaseCostPrint"
     *
     * @generated
     */
  private void componentValidation_UnitCaseCostPrint(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "InvoiceFormat"
     *
     * @generated
     */
  private void componentValidation_InvoiceFormat(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "Invoice"
     *
     * @generated
     */
  private void componentValidation_Invoice(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "DelPickPackInvoice"
     *
     * @generated
     */
  private void componentValidation_DelPickPackInvoice(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "ContractId"
     *
     * @generated
     */
	private void controllerValidation_ContractId(DWLStatus status) throws Exception {
  
            boolean isContractIdNull = (eObjMTTActOrderInvoice.getContractId() == null);
            if (isContractIdNull) {
                DWLError err = createDWLError("MTTActOrderInvoice", "ContractId", MTTDBCustomErrorReasonCode.MTTACTORDERINVOICE_CONTRACTID_NULL);
                status.addError(err); 
            }
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "InvoiceSequence"
     *
     * @generated
     */
  private void controllerValidation_InvoiceSequence(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isInvoiceSequenceNull = false;
            if ((eObjMTTActOrderInvoice.getInvoiceSequence() == null) &&
               ((getInvoiceSequenceValue() == null) || 
                 getInvoiceSequenceValue().trim().equals(""))) {
                isInvoiceSequenceNull = true;
            }
            if (!isInvoiceSequenceNull) {
                if (checkForInvalidMttactorderinvoiceInvoicesequence()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_ORDER_INVOICE_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTORDERINVOICE_INVOICESEQUENCE).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTActOrderInvoice, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_InvoiceSequence " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "InvoiceMode"
     *
     * @generated
     */
  private void controllerValidation_InvoiceMode(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isInvoiceModeNull = false;
            if ((eObjMTTActOrderInvoice.getInvoiceMode() == null) &&
               ((getInvoiceModeValue() == null) || 
                 getInvoiceModeValue().trim().equals(""))) {
                isInvoiceModeNull = true;
            }
            if (!isInvoiceModeNull) {
                if (checkForInvalidMttactorderinvoiceInvoicemode()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_ORDER_INVOICE_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTORDERINVOICE_INVOICEMODE).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTActOrderInvoice, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_InvoiceMode " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "OrderGuide"
     *
     * @generated
     */
  private void controllerValidation_OrderGuide(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isOrderGuideNull = false;
            if ((eObjMTTActOrderInvoice.getOrderGuide() == null) &&
               ((getOrderGuideValue() == null) || 
                 getOrderGuideValue().trim().equals(""))) {
                isOrderGuideNull = true;
            }
            if (!isOrderGuideNull) {
                if (checkForInvalidMttactorderinvoiceOrderguide()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_ORDER_INVOICE_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTORDERINVOICE_ORDERGUIDE).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTActOrderInvoice, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_OrderGuide " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "PrintCatInvoiceBreak"
     *
     * @generated
     */
  private void controllerValidation_PrintCatInvoiceBreak(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isPrintCatInvoiceBreakNull = false;
            if ((eObjMTTActOrderInvoice.getPrintCatInvoiceBreak() == null) &&
               ((getPrintCatInvoiceBreakValue() == null) || 
                 getPrintCatInvoiceBreakValue().trim().equals(""))) {
                isPrintCatInvoiceBreakNull = true;
            }
            if (!isPrintCatInvoiceBreakNull) {
                if (checkForInvalidMttactorderinvoicePrintcatinvoicebreak()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_ORDER_INVOICE_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTORDERINVOICE_PRINTCATINVOICEBREAK).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTActOrderInvoice, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_PrintCatInvoiceBreak " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "InvoiceRecapSummary"
     *
     * @generated
     */
  private void controllerValidation_InvoiceRecapSummary(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isInvoiceRecapSummaryNull = false;
            if ((eObjMTTActOrderInvoice.getInvoiceRecapSummary() == null) &&
               ((getInvoiceRecapSummaryValue() == null) || 
                 getInvoiceRecapSummaryValue().trim().equals(""))) {
                isInvoiceRecapSummaryNull = true;
            }
            if (!isInvoiceRecapSummaryNull) {
                if (checkForInvalidMttactorderinvoiceInvoicerecapsummary()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_ORDER_INVOICE_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTORDERINVOICE_INVOICERECAPSUMMARY).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTActOrderInvoice, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_InvoiceRecapSummary " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "PickupDeiver"
     *
     * @generated
     */
  private void controllerValidation_PickupDeiver(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isPickupDeiverNull = false;
            if ((eObjMTTActOrderInvoice.getPickupDeiver() == null) &&
               ((getPickupDeiverValue() == null) || 
                 getPickupDeiverValue().trim().equals(""))) {
                isPickupDeiverNull = true;
            }
            if (!isPickupDeiverNull) {
                if (checkForInvalidMttactorderinvoicePickupdeiver()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_ORDER_INVOICE_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTORDERINVOICE_PICKUPDEIVER).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTActOrderInvoice, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_PickupDeiver " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "Totes"
     *
     * @generated
     */
  private void controllerValidation_Totes(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isTotesNull = false;
            if ((eObjMTTActOrderInvoice.getTotes() == null) &&
               ((getTotesValue() == null) || 
                 getTotesValue().trim().equals(""))) {
                isTotesNull = true;
            }
            if (!isTotesNull) {
                if (checkForInvalidMttactorderinvoiceTotes()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_ORDER_INVOICE_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTORDERINVOICE_TOTES).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTActOrderInvoice, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_Totes " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "UnitCaseCostPrint"
     *
     * @generated
     */
  private void controllerValidation_UnitCaseCostPrint(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isUnitCaseCostPrintNull = false;
            if ((eObjMTTActOrderInvoice.getUnitCaseCostPrint() == null) &&
               ((getUnitCaseCostPrintValue() == null) || 
                 getUnitCaseCostPrintValue().trim().equals(""))) {
                isUnitCaseCostPrintNull = true;
            }
            if (!isUnitCaseCostPrintNull) {
                if (checkForInvalidMttactorderinvoiceUnitcasecostprint()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_ORDER_INVOICE_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTORDERINVOICE_UNITCASECOSTPRINT).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTActOrderInvoice, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_UnitCaseCostPrint " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "InvoiceFormat"
     *
     * @generated
     */
  private void controllerValidation_InvoiceFormat(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isInvoiceFormatNull = false;
            if ((eObjMTTActOrderInvoice.getInvoiceFormat() == null) &&
               ((getInvoiceFormatValue() == null) || 
                 getInvoiceFormatValue().trim().equals(""))) {
                isInvoiceFormatNull = true;
            }
            if (!isInvoiceFormatNull) {
                if (checkForInvalidMttactorderinvoiceInvoiceformat()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_ORDER_INVOICE_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTORDERINVOICE_INVOICEFORMAT).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTActOrderInvoice, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_InvoiceFormat " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "Invoice"
     *
     * @generated
     */
  private void controllerValidation_Invoice(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isInvoiceNull = false;
            if ((eObjMTTActOrderInvoice.getInvoice() == null) &&
               ((getInvoiceValue() == null) || 
                 getInvoiceValue().trim().equals(""))) {
                isInvoiceNull = true;
            }
            if (!isInvoiceNull) {
                if (checkForInvalidMttactorderinvoiceInvoice()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_ORDER_INVOICE_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTORDERINVOICE_INVOICE).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTActOrderInvoice, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_Invoice " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "DelPickPackInvoice"
     *
     * @generated
     */
  private void controllerValidation_DelPickPackInvoice(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isDelPickPackInvoiceNull = false;
            if ((eObjMTTActOrderInvoice.getDelPickPackInvoice() == null) &&
               ((getDelPickPackInvoiceValue() == null) || 
                 getDelPickPackInvoiceValue().trim().equals(""))) {
                isDelPickPackInvoiceNull = true;
            }
            if (!isDelPickPackInvoiceNull) {
                if (checkForInvalidMttactorderinvoiceDelpickpackinvoice()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_ORDER_INVOICE_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTORDERINVOICE_DELPICKPACKINVOICE).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTActOrderInvoice, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_DelPickPackInvoice " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_ORDER_INVOICE_BOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field InvoiceSequence and return true if the error
     * reason INVALID_MTTACTORDERINVOICE_INVOICESEQUENCE should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttactorderinvoiceInvoicesequence() throws Exception {
    logger.finest("ENTER checkForInvalidMttactorderinvoiceInvoicesequence()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getInvoiceSequenceType() );
    String codeValue = getInvoiceSequenceValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdinvseqtp", langId, getInvoiceSequenceType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdinvseqtp", langId, getInvoiceSequenceType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setInvoiceSequenceValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttactorderinvoiceInvoicesequence() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdinvseqtp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setInvoiceSequenceType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttactorderinvoiceInvoicesequence() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdinvseqtp", langId, getInvoiceSequenceType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttactorderinvoiceInvoicesequence() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttactorderinvoiceInvoicesequence() " + returnValue);
    }
    return notValid;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field InvoiceMode and return true if the error
     * reason INVALID_MTTACTORDERINVOICE_INVOICEMODE should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttactorderinvoiceInvoicemode() throws Exception {
    logger.finest("ENTER checkForInvalidMttactorderinvoiceInvoicemode()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getInvoiceModeType() );
    String codeValue = getInvoiceModeValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdinvmodetp", langId, getInvoiceModeType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdinvmodetp", langId, getInvoiceModeType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setInvoiceModeValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttactorderinvoiceInvoicemode() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdinvmodetp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setInvoiceModeType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttactorderinvoiceInvoicemode() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdinvmodetp", langId, getInvoiceModeType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttactorderinvoiceInvoicemode() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttactorderinvoiceInvoicemode() " + returnValue);
    }
    return notValid;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field OrderGuide and return true if the error
     * reason INVALID_MTTACTORDERINVOICE_ORDERGUIDE should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttactorderinvoiceOrderguide() throws Exception {
    logger.finest("ENTER checkForInvalidMttactorderinvoiceOrderguide()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getOrderGuideType() );
    String codeValue = getOrderGuideValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdorderguidetp", langId, getOrderGuideType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdorderguidetp", langId, getOrderGuideType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setOrderGuideValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttactorderinvoiceOrderguide() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdorderguidetp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setOrderGuideType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttactorderinvoiceOrderguide() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdorderguidetp", langId, getOrderGuideType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttactorderinvoiceOrderguide() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttactorderinvoiceOrderguide() " + returnValue);
    }
    return notValid;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field PrintCatInvoiceBreak and return true if the
     * error reason INVALID_MTTACTORDERINVOICE_PRINTCATINVOICEBREAK should be
     * returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttactorderinvoicePrintcatinvoicebreak() throws Exception {
    logger.finest("ENTER checkForInvalidMttactorderinvoicePrintcatinvoicebreak()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getPrintCatInvoiceBreakType() );
    String codeValue = getPrintCatInvoiceBreakValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdprncatinvbrktp", langId, getPrintCatInvoiceBreakType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdprncatinvbrktp", langId, getPrintCatInvoiceBreakType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setPrintCatInvoiceBreakValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttactorderinvoicePrintcatinvoicebreak() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdprncatinvbrktp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setPrintCatInvoiceBreakType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttactorderinvoicePrintcatinvoicebreak() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdprncatinvbrktp", langId, getPrintCatInvoiceBreakType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttactorderinvoicePrintcatinvoicebreak() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttactorderinvoicePrintcatinvoicebreak() " + returnValue);
    }
    return notValid;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field InvoiceRecapSummary and return true if the
     * error reason INVALID_MTTACTORDERINVOICE_INVOICERECAPSUMMARY should be
     * returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttactorderinvoiceInvoicerecapsummary() throws Exception {
    logger.finest("ENTER checkForInvalidMttactorderinvoiceInvoicerecapsummary()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getInvoiceRecapSummaryType() );
    String codeValue = getInvoiceRecapSummaryValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdinvrecapsummarytp", langId, getInvoiceRecapSummaryType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdinvrecapsummarytp", langId, getInvoiceRecapSummaryType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setInvoiceRecapSummaryValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttactorderinvoiceInvoicerecapsummary() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdinvrecapsummarytp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setInvoiceRecapSummaryType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttactorderinvoiceInvoicerecapsummary() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdinvrecapsummarytp", langId, getInvoiceRecapSummaryType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttactorderinvoiceInvoicerecapsummary() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttactorderinvoiceInvoicerecapsummary() " + returnValue);
    }
    return notValid;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field PickupDeiver and return true if the error
     * reason INVALID_MTTACTORDERINVOICE_PICKUPDEIVER should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttactorderinvoicePickupdeiver() throws Exception {
    logger.finest("ENTER checkForInvalidMttactorderinvoicePickupdeiver()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getPickupDeiverType() );
    String codeValue = getPickupDeiverValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdpickupdelivertp", langId, getPickupDeiverType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdpickupdelivertp", langId, getPickupDeiverType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setPickupDeiverValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttactorderinvoicePickupdeiver() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdpickupdelivertp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setPickupDeiverType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttactorderinvoicePickupdeiver() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdpickupdelivertp", langId, getPickupDeiverType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttactorderinvoicePickupdeiver() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttactorderinvoicePickupdeiver() " + returnValue);
    }
    return notValid;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field Totes and return true if the error reason
     * INVALID_MTTACTORDERINVOICE_TOTES should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttactorderinvoiceTotes() throws Exception {
    logger.finest("ENTER checkForInvalidMttactorderinvoiceTotes()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getTotesType() );
    String codeValue = getTotesValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdtotestp", langId, getTotesType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdtotestp", langId, getTotesType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setTotesValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttactorderinvoiceTotes() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdtotestp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setTotesType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttactorderinvoiceTotes() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdtotestp", langId, getTotesType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttactorderinvoiceTotes() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttactorderinvoiceTotes() " + returnValue);
    }
    return notValid;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field UnitCaseCostPrint and return true if the
     * error reason INVALID_MTTACTORDERINVOICE_UNITCASECOSTPRINT should be
     * returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttactorderinvoiceUnitcasecostprint() throws Exception {
    logger.finest("ENTER checkForInvalidMttactorderinvoiceUnitcasecostprint()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getUnitCaseCostPrintType() );
    String codeValue = getUnitCaseCostPrintValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdunitcasecostprntp", langId, getUnitCaseCostPrintType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdunitcasecostprntp", langId, getUnitCaseCostPrintType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setUnitCaseCostPrintValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttactorderinvoiceUnitcasecostprint() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdunitcasecostprntp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setUnitCaseCostPrintType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttactorderinvoiceUnitcasecostprint() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdunitcasecostprntp", langId, getUnitCaseCostPrintType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttactorderinvoiceUnitcasecostprint() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttactorderinvoiceUnitcasecostprint() " + returnValue);
    }
    return notValid;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field InvoiceFormat and return true if the error
     * reason INVALID_MTTACTORDERINVOICE_INVOICEFORMAT should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttactorderinvoiceInvoiceformat() throws Exception {
    logger.finest("ENTER checkForInvalidMttactorderinvoiceInvoiceformat()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getInvoiceFormatType() );
    String codeValue = getInvoiceFormatValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdinvformattp", langId, getInvoiceFormatType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdinvformattp", langId, getInvoiceFormatType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setInvoiceFormatValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttactorderinvoiceInvoiceformat() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdinvformattp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setInvoiceFormatType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttactorderinvoiceInvoiceformat() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdinvformattp", langId, getInvoiceFormatType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttactorderinvoiceInvoiceformat() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttactorderinvoiceInvoiceformat() " + returnValue);
    }
    return notValid;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field Invoice and return true if the error reason
     * INVALID_MTTACTORDERINVOICE_INVOICE should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttactorderinvoiceInvoice() throws Exception {
    logger.finest("ENTER checkForInvalidMttactorderinvoiceInvoice()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getInvoiceType() );
    String codeValue = getInvoiceValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdinvtp", langId, getInvoiceType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdinvtp", langId, getInvoiceType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setInvoiceValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttactorderinvoiceInvoice() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdinvtp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setInvoiceType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttactorderinvoiceInvoice() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdinvtp", langId, getInvoiceType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttactorderinvoiceInvoice() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttactorderinvoiceInvoice() " + returnValue);
    }
    return notValid;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field DelPickPackInvoice and return true if the
     * error reason INVALID_MTTACTORDERINVOICE_DELPICKPACKINVOICE should be
     * returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttactorderinvoiceDelpickpackinvoice() throws Exception {
    logger.finest("ENTER checkForInvalidMttactorderinvoiceDelpickpackinvoice()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getDelPickPackInvoiceType() );
    String codeValue = getDelPickPackInvoiceValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcddelpickpackinvtp", langId, getDelPickPackInvoiceType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcddelpickpackinvtp", langId, getDelPickPackInvoiceType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setDelPickPackInvoiceValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttactorderinvoiceDelpickpackinvoice() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcddelpickpackinvtp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setDelPickPackInvoiceType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttactorderinvoiceDelpickpackinvoice() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcddelpickpackinvtp", langId, getDelPickPackInvoiceType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttactorderinvoiceDelpickpackinvoice() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttactorderinvoiceDelpickpackinvoice() " + returnValue);
    }
    return notValid;
     } 
				 



}

