/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[31c1a1d43027e12306f2533de4220054]
 */

package com.metcash.db.custom.bobj.query;
 
import com.dwl.base.DWLCommon;
import com.dwl.bobj.query.Persistence;
/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * Interface through which instances of concrete implementation of
 * <code>Persistence</code> can be created for MTTDBCustom module.
 *
 * @generated
 */
public interface MTTDBCustomModuleBObjPersistenceFactory {

    /** 
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
	public final static String BOBJ_PERSISTENCE_FACTORY = "MTTDBCustom.BObjPersistenceFactory";

    
     /** 
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * This method returns an object of type <code>Persistence</code>
      * corresponding to <code>MTTActReportingBObj</code> business object.
      *
      * @param persistenceStrategyName
     * The persistence strategy name.  This parameter indicates the type of
     * database action to be taken such as addition, update or deletion of
     * records.
      * @param objectToPersist
     * The business object to be persisted.
    *
      * @return 
      * An instance of <code>MTTActReportingBObjQuery</code>, which is a
      * concrete implementation of <code>Persistence</code> interface.      
      *
      * @generated
      */
      public Persistence createMTTActReportingBObjPersistence(String persistenceStrategyName, DWLCommon objectToPersist);


    /** 
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * This method returns an object of type <code>Persistence</code>
      * corresponding to <code>MTTIdentifierBObj</code> business object.
      *
      * @param persistenceStrategyName
     * The persistence strategy name.  This parameter indicates the type of
     * database action to be taken such as addition, update or deletion of
     * records.
      * @param objectToPersist
     * The business object to be persisted.
    *
      * @return 
      * An instance of <code>MTTIdentifierBObjQuery</code>, which is a concrete
      * implementation of <code>Persistence</code> interface.      
      *
      * @generated
      */
      public Persistence createMTTIdentifierBObjPersistence(String persistenceStrategyName, DWLCommon objectToPersist);


    /** 
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * This method returns an object of type <code>Persistence</code>
      * corresponding to <code>MTTStoreBObj</code> business object.
      *
      * @param persistenceStrategyName
     * The persistence strategy name.  This parameter indicates the type of
     * database action to be taken such as addition, update or deletion of
     * records.
      * @param objectToPersist
     * The business object to be persisted.
    *
      * @return 
      * An instance of <code>MTTStoreBObjQuery</code>, which is a concrete
      * implementation of <code>Persistence</code> interface.      
      *
      * @generated
      */
      public Persistence createMTTStoreBObjPersistence(String persistenceStrategyName, DWLCommon objectToPersist);


    /** 
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * This method returns an object of type <code>Persistence</code>
      * corresponding to <code>MTTActCreditTaxBObj</code> business object.
      *
      * @param persistenceStrategyName
     * The persistence strategy name.  This parameter indicates the type of
     * database action to be taken such as addition, update or deletion of
     * records.
      * @param objectToPersist
     * The business object to be persisted.
    *
      * @return 
      * An instance of <code>MTTActCreditTaxBObjQuery</code>, which is a
      * concrete implementation of <code>Persistence</code> interface.      
      *
      * @generated
      */
      public Persistence createMTTActCreditTaxBObjPersistence(String persistenceStrategyName, DWLCommon objectToPersist);


    /** 
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * This method returns an object of type <code>Persistence</code>
      * corresponding to <code>MTTActOrderInvoiceBObj</code> business object.
      *
      * @param persistenceStrategyName
     * The persistence strategy name.  This parameter indicates the type of
     * database action to be taken such as addition, update or deletion of
     * records.
      * @param objectToPersist
     * The business object to be persisted.
    *
      * @return 
      * An instance of <code>MTTActOrderInvoiceBObjQuery</code>, which is a
      * concrete implementation of <code>Persistence</code> interface.      
      *
      * @generated
      */
      public Persistence createMTTActOrderInvoiceBObjPersistence(String persistenceStrategyName, DWLCommon objectToPersist);


    /** 
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * This method returns an object of type <code>Persistence</code>
      * corresponding to <code>MTTActCostChargesBObj</code> business object.
      *
      * @param persistenceStrategyName
     * The persistence strategy name.  This parameter indicates the type of
     * database action to be taken such as addition, update or deletion of
     * records.
      * @param objectToPersist
     * The business object to be persisted.
    *
      * @return 
      * An instance of <code>MTTActCostChargesBObjQuery</code>, which is a
      * concrete implementation of <code>Persistence</code> interface.      
      *
      * @generated
      */
      public Persistence createMTTActCostChargesBObjPersistence(String persistenceStrategyName, DWLCommon objectToPersist);


    /** 
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * This method returns an object of type <code>Persistence</code>
      * corresponding to <code>MTTActFinancialBObj</code> business object.
      *
      * @param persistenceStrategyName
     * The persistence strategy name.  This parameter indicates the type of
     * database action to be taken such as addition, update or deletion of
     * records.
      * @param objectToPersist
     * The business object to be persisted.
    *
      * @return 
      * An instance of <code>MTTActFinancialBObjQuery</code>, which is a
      * concrete implementation of <code>Persistence</code> interface.      
      *
      * @generated
      */
      public Persistence createMTTActFinancialBObjPersistence(String persistenceStrategyName, DWLCommon objectToPersist);

}

