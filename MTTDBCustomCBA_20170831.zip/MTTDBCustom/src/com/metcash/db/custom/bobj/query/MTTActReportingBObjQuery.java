
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[16b2dda5a1483c76f4e5e711ade0928d]
 */
package com.metcash.db.custom.bobj.query;




import com.dwl.base.DWLControl;
import com.dwl.bobj.query.BObjQueryException;
import com.dwl.base.DWLCommon;

import com.dwl.base.db.DataAccessFactory;


import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLDuplicateKeyException;

import com.dwl.base.interfaces.IGenericResultSetProcessor;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;

import com.metcash.db.custom.component.MTTActReportingBObj;
import com.metcash.db.custom.component.MTTActReportingResultSetProcessor;

import com.metcash.db.custom.constant.MTTDBCustomComponentID;
import com.metcash.db.custom.constant.MTTDBCustomErrorReasonCode;

import com.metcash.db.custom.entityObject.EObjMTTActReportingData;
import com.metcash.db.custom.entityObject.MTTActReportingInquiryData;


/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides query information for the business object
 * <code>MTTActReportingBObj</code>.
 *
 * @generated
 */
public class MTTActReportingBObjQuery  extends com.dwl.bobj.query.GenericBObjQuery {

     /**
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * @generated
      */
     public static final String MTTACT_REPORTING_QUERY = "getMTTActReporting(Object[])";

     /**
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * @generated
      */
     public static final String MTTACT_REPORTING_HISTORY_QUERY = "getMTTActReportingHistory(Object[])";

     /**
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * @generated
      */
     public static final String ALL_MTTREPORT_BY_ID_QUERY = "getAllMTTReportByID(Object[])";

    /**
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * @generated
      */
     public static final String ALL_MTTREPORT_BY_ID_HISTORY_QUERY = "getAllMTTReportByIDHistory(Object[])";

    /**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(MTTActReportingBObjQuery.class);
     /**
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * @generated
      */
     public static final String MTTACT_REPORTING_ADD = "MTTACT_REPORTING_ADD";

     /**
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * @generated
      */
     public static final String MTTACT_REPORTING_DELETE = "MTTACT_REPORTING_DELETE";

     /**
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * @generated
      */
     public static final String MTTACT_REPORTING_UPDATE = "MTTACT_REPORTING_UPDATE";


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Default constructor.
     *
     * @param queryName
     * The name of the query.
     * @param control
     * The control object.
     *
     * @generated
     */
    public MTTActReportingBObjQuery(String queryName, DWLControl control) {
        super(queryName, control);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Default constructor.
     *
     * @param persistenceStrategyName
     * The persistence strategy name.  This parameter indicates the type of
     * database action to be taken such as addition, update or deletion of
     * records.
     * @param objectToPersist
     * The business object to be persisted.
     *
     * @generated
     */
    public MTTActReportingBObjQuery(String persistenceStrategyName, DWLCommon objectToPersist) {
        super(persistenceStrategyName, objectToPersist);
    }

	 
 	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
	protected void persist() throws Exception{
    logger.finest("ENTER persist()");
    if (logger.isFinestEnabled()) {
   		String infoForLogging="Persistence strategy is " + persistenceStrategyName;
      logger.finest("persist() " + infoForLogging);
        }
    if (persistenceStrategyName.equals(MTTACT_REPORTING_ADD)) {
      addMTTActReporting();
    }else if(persistenceStrategyName.equals(MTTACT_REPORTING_UPDATE)) {
      updateMTTActReporting();
    }else if(persistenceStrategyName.equals(MTTACT_REPORTING_DELETE)) {
      deleteMTTActReporting();
    }
    logger.finest("RETURN persist()");
  }
  
 	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
      * Inserts mttactreporting data by calling
      * <code>EObjMTTActReportingData.createEObjMTTActReporting</code>
     *
     * @throws Exception
     *
     * @generated
     */
	protected void addMTTActReporting() throws Exception{
    logger.finest("ENTER addMTTActReporting()");
    
    EObjMTTActReportingData theEObjMTTActReportingData = (EObjMTTActReportingData) DataAccessFactory
      .getQuery(EObjMTTActReportingData.class, connection);
    theEObjMTTActReportingData.createEObjMTTActReporting(((MTTActReportingBObj) objectToPersist).getEObjMTTActReporting());
    logger.finest("RETURN addMTTActReporting()");
  }

 	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
      * Updates mttactreporting data by calling
      * <code>EObjMTTActReportingData.updateEObjMTTActReporting</code>
     *
     * @throws Exception
     *
     * @generated
     */
	protected void updateMTTActReporting() throws Exception{
    logger.finest("ENTER updateMTTActReporting()");
    EObjMTTActReportingData theEObjMTTActReportingData = (EObjMTTActReportingData) DataAccessFactory
      .getQuery(EObjMTTActReportingData.class, connection);
    theEObjMTTActReportingData.updateEObjMTTActReporting(((MTTActReportingBObj) objectToPersist).getEObjMTTActReporting());
    logger.finest("RETURN updateMTTActReporting()");
  }

 	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
      * Deletes {0} data by calling <{1}>{2}.{3}{4}</{1}>
   *
     * @throws Exception
     *
     * @generated
     */
	protected void deleteMTTActReporting() throws Exception{
    logger.finest("ENTER deleteMTTActReporting()");
         // MDM_TODO: CDKWB0018I Write customized business logic for the extension here.
    logger.finest("RETURN deleteMTTActReporting()");
  } 
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
      * This method is overridden to construct
      * <code>DWLDuplicateKeyException</code> based on MTTActReporting component
      * specific values.
     * 
     * @param errParams
     * The values to be substituted in the error message.
   *
     * @throws Exception
     *
     * @generated
     */
    protected void throwDuplicateKeyException(String[] errParams) throws Exception {
    if (logger.isFinestEnabled()) {
      	StringBuilder errParamsStringBuilder = new StringBuilder("Error: Duplicate key Exception parameters are ");
      	for(int i=0;i<errParams.length;i++) {
      		errParamsStringBuilder .append(errParams[i]);
      		if (i!=errParams.length-1) {
      			errParamsStringBuilder .append(" , ");
      		}
      	}
          String infoForLogging="Error: Duplicate key Exception parameters are " + errParamsStringBuilder;
      logger.finest("Unknown method " + infoForLogging);
    }
    	DWLExceptionUtils.throwDWLDuplicateKeyException(
    		new DWLDuplicateKeyException(buildDupThrowableMessage(errParams)),
    		objectToPersist.getStatus(), 
    		DWLStatus.FATAL,
    		MTTDBCustomComponentID.MTTDBCUSTOM_COMPONENT,
    		DWLErrorCode.DUPLICATE_KEY_ERROR, 
    		MTTDBCustomErrorReasonCode.DUPLICATE_PRIMARY_KEY_MTTACTREPORTING,
    		objectToPersist.getControl(), 
    		DWLClassFactory.getErrorHandler()
    		);
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Provides the result set processor that is used to populate the business
     * object.
     *
     * @return
     * An instance of <code>MTTActReportingResultSetProcessor</code>.
     *
     * @see com.dwl.bobj.query.AbstractBObjQuery#provideResultSetProcessor()
     * @see com.metcash.db.custom.component.MTTActReportingResultSetProcessor
     *
     * @generated
     */
    protected IGenericResultSetProcessor provideResultSetProcessor()
            throws BObjQueryException {

        return new MTTActReportingResultSetProcessor();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    @Override
    protected Class<MTTActReportingInquiryData> provideQueryInterfaceClass() throws BObjQueryException {
        return MTTActReportingInquiryData.class;
    }

}


