package com.metcash.services.custom.compositeTxn;

import java.util.Vector;

import com.dwl.base.DWLControl;
import com.dwl.base.DWLResponse;
import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLStatus;
import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.requestHandler.DWLTransactionInquiry;
import com.dwl.base.requestHandler.DWLTransactionPersistent;
import com.dwl.base.requestHandler.DWLTxnBP;
import com.dwl.base.util.DWLDateTimeUtilities;
import com.dwl.base.util.DWLFunctionUtils;
import com.dwl.tcrm.coreParty.component.TCRMPartyIdentificationBObj;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.dwl.unifi.tx.exception.BusinessProxyException;
import com.metcash.db.custom.component.MTTIdentifierBObj;
import com.metcash.services.custom.component.MetcashIdentifierBObj;
import com.metcash.services.custom.constant.MTTServicesComponentID;
import com.metcash.services.custom.constant.MTTServicesErrorReasonCode;

public class MaintainMetcashIdentifier extends DWLTxnBP {
	
	private IDWLErrorMessage errHandler;
	
	private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(MaintainMetcashIdentifier.class);
	
	public MaintainMetcashIdentifier() {
        super();
        errHandler = TCRMClassFactory.getErrorHandler();
    }
	
	public Object processMetcashIdentifier(Vector vecInpMetcashIdentifier, String partyId, DWLControl control) throws BusinessProxyException {
		
		logger.finest("ENTER Object processMetcashIdentifier");
	
	// Handle Metcash Identification BObj
		
		// Check existing Identifiers for the given Party ID
		Vector vecExistingIdentifier = getAllExistingIdentifier (partyId, control);
		
		if (vecExistingIdentifier.size() > 0 && vecExistingIdentifier != null) {
			resolveIdentity (vecInpMetcashIdentifier, vecExistingIdentifier, control);
		}
		
		Vector vecMetcashIdentifierResponse = new Vector();
		Vector vecInpMTTIdentifier = new Vector();
		
		MetcashIdentifierBObj inputMetcashIden = new MetcashIdentifierBObj();
    	TCRMPartyIdentificationBObj inputPartyIden = new TCRMPartyIdentificationBObj();
    	MetcashIdentifierBObj outputMetcashIden = new MetcashIdentifierBObj();
		outputMetcashIden.setControl(control);
		
    	for (int i=0; i < vecInpMetcashIdentifier.size(); i++) {
    		inputMetcashIden = (MetcashIdentifierBObj) vecInpMetcashIdentifier.elementAt(i);
    		vecInpMTTIdentifier = inputMetcashIden.getItemsMTTIdentifierBObj();
            
    		inputPartyIden = (TCRMPartyIdentificationBObj) inputMetcashIden.getTCRMPartyIdentificationBObj();
    		inputPartyIden.setControl(control);
    		inputPartyIden.setPartyId(partyId);
    		
    		if (inputPartyIden.getIdentificationIdPK() == null) {
    			// ADD   			
    			handlePartyIdentifierAdd (inputPartyIden, vecInpMTTIdentifier, outputMetcashIden, control);
    		} else {
    			handlePartyIdentifierUpdate (inputPartyIden, vecInpMTTIdentifier, outputMetcashIden, control);
    			
    		}
            	vecMetcashIdentifierResponse.add(outputMetcashIden);
    		}
    			return vecMetcashIdentifierResponse;
		}

	private void handlePartyIdentifierUpdate(
			TCRMPartyIdentificationBObj inputPartyIden,
			Vector vecInpMTTIdentifier,
			MetcashIdentifierBObj outputMetcashIden, DWLControl control) throws BusinessProxyException {
		
		DWLTransactionPersistent updatePartyIdenRequest = new DWLTransactionPersistent();
		updatePartyIdenRequest.setTxnControl(control);
		updatePartyIdenRequest.setTxnType("updatePartyIdentification");
		updatePartyIdenRequest.setTxnTopLevelObject(inputPartyIden);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse updatePartyIdenResponse = null;
        
        // Invoke the "updatePartyIdentification" transaction.
        try {
        	updatePartyIdenResponse = (DWLResponse) super.execute(updatePartyIdenRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTLEGAL_ENTITY_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTLEGALENTITY_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }
        
        if (updatePartyIdenResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTLEGAL_ENTITY_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTLEGALENTITY_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (updatePartyIdenResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	DWLStatus dwlStatus = updatePartyIdenResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }
		
	}

	private void resolveIdentity(Vector vecInpMetcashIdentifier,
			Vector vecExistingIdentifier, DWLControl control) throws BusinessProxyException {
		
		MetcashIdentifierBObj inputMetcashIden = new MetcashIdentifierBObj();
    	TCRMPartyIdentificationBObj inputPartyIden = new TCRMPartyIdentificationBObj();
    	TCRMPartyIdentificationBObj foundPartyIden = new TCRMPartyIdentificationBObj();
    	
		for (int a=0; a < vecInpMetcashIdentifier.size(); a++) {
			inputMetcashIden = (MetcashIdentifierBObj) vecInpMetcashIdentifier.elementAt(a);
			inputPartyIden = (TCRMPartyIdentificationBObj) inputMetcashIden.getTCRMPartyIdentificationBObj();
			for (int b=0; b < vecExistingIdentifier.size(); b++) {
				foundPartyIden = (TCRMPartyIdentificationBObj) vecExistingIdentifier.elementAt(b);				
				try {
					if (inputPartyIden.isBusinessKeySame(foundPartyIden)) {
						inputPartyIden.setIdentificationIdPK(foundPartyIden.getIdentificationIdPK());
						inputPartyIden.setPartyIdentificationLastUpdateDate(foundPartyIden.getPartyIdentificationLastUpdateDate());
						Vector vecInputMTTIdentifier = inputMetcashIden.getItemsMTTIdentifierBObj();
						if (vecInputMTTIdentifier.size() > 0 && vecInputMTTIdentifier != null) {
							resolveMTTIdentifier (vecInputMTTIdentifier, foundPartyIden, control);
						}						
					}
				} catch (DWLBaseException e) {					
					throw new BusinessProxyException(e.getMessage());
				} catch (Exception e) {					
					throw new BusinessProxyException(e.getMessage());
				}
			}
		}
	}

	private void resolveMTTIdentifier(Vector vecInputMTTIdentifier,
			TCRMPartyIdentificationBObj foundPartyIden, DWLControl control) throws BusinessProxyException {
		
		Vector vecExistingMTTIdentifier = getAllExistingMTTIdentifier (foundPartyIden.getIdentificationIdPK(), control);
		MTTIdentifierBObj inputMTTIdentifier = new MTTIdentifierBObj();
		
		if (vecExistingMTTIdentifier.size() > 0 && vecExistingMTTIdentifier != null) {
			for (int t=0; t < vecInputMTTIdentifier.size(); t++) {
				inputMTTIdentifier = (MTTIdentifierBObj) vecInputMTTIdentifier.elementAt(t);
				for (int v=0; v < vecExistingMTTIdentifier.size(); v++) {
					MTTIdentifierBObj existingMTTIdentifier = (MTTIdentifierBObj) vecExistingMTTIdentifier.elementAt(v);
					try {
						if (inputMTTIdentifier.isBusinessKeySame(existingMTTIdentifier)) {
							inputMTTIdentifier.setMTTIdentifierIdPk(existingMTTIdentifier.getMTTIdentifierIdPk());
							inputMTTIdentifier.setMTTIdentifierLastUpdateDate(existingMTTIdentifier.getMTTIdentifierLastUpdateDate());
							if (inputMTTIdentifier.getStartDate() == null) {
								inputMTTIdentifier.setStartDate(DWLDateTimeUtilities.getCurrentSystemTime());
							}
						}
					} catch (DWLBaseException e) {
						throw new BusinessProxyException(e.getMessage());
					} catch (Exception e) {
						throw new BusinessProxyException(e.getMessage());
					}
				}				
			}
		}
	}

	private Vector getAllExistingMTTIdentifier(String identificationIdPK, DWLControl control) throws BusinessProxyException {		
		
		Vector<Object> getMTTIdentifierInput = new Vector<Object>();
		getMTTIdentifierInput.add(0, identificationIdPK);
		getMTTIdentifierInput.add(1, MTTServicesComponentID.FILTER_FOR_GET);

		// Prepare a new DWLTransactionInquiry instance.
		DWLTransactionInquiry getMTTIdentifierRequest = new DWLTransactionInquiry();
		getMTTIdentifierRequest.setTxnControl(control);
		getMTTIdentifierRequest.setTxnType("getAllMTTIdentifierByID");
		getMTTIdentifierRequest.setStringParameters(getMTTIdentifierInput);

		// Prepare a reference to hold the response for this transaction.
		DWLResponse getMTTIdentifierResponse = null;

		// Invoke the transaction.
		try {
			getMTTIdentifierResponse = (DWLResponse) super
					.execute(getMTTIdentifierRequest);
		} catch (BusinessProxyException e) {
			DWLError error = errHandler.getErrorMessage(
					MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
					"READERR", MTTServicesErrorReasonCode.MAINTAINMTTLEGALENTITY_FAILED,
					control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage(), e);
		} if (getMTTIdentifierResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	DWLStatus dwlStatus = getMTTIdentifierResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
		}
		Vector vecExistingIdentifier = (Vector) getMTTIdentifierResponse.getData();
		
		return vecExistingIdentifier;
	}

	private Vector getAllExistingIdentifier(String partyId, DWLControl control) throws BusinessProxyException {
		
		Vector<Object> getPartyIdentifierInput = new Vector<Object>();
		getPartyIdentifierInput.add(0, partyId);
		getPartyIdentifierInput.add(1, MTTServicesComponentID.FILTER_FOR_GET);

		// Prepare a new DWLTransactionInquiry instance.
		DWLTransactionInquiry getPartyIdentifierRequest = new DWLTransactionInquiry();
		getPartyIdentifierRequest.setTxnControl(control);
		getPartyIdentifierRequest.setTxnType("getAllPartyIdentifications");
		getPartyIdentifierRequest.setStringParameters(getPartyIdentifierInput);

		// Prepare a reference to hold the response for this transaction.
		DWLResponse getPartyIdentifierResponse = null;

		// Invoke the transaction.
		try {
			getPartyIdentifierResponse = (DWLResponse) super
					.execute(getPartyIdentifierRequest);
		} catch (BusinessProxyException e) {
			DWLError error = errHandler.getErrorMessage(
					MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
					"READERR", MTTServicesErrorReasonCode.MAINTAINMTTLEGALENTITY_FAILED,
					control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage(), e);
		} if (getPartyIdentifierResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	DWLStatus dwlStatus = getPartyIdentifierResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	if (dwlError.getReasonCode() != DWLFunctionUtils.getLongFromString(MTTServicesErrorReasonCode.NO_PARTY_IDENTIFIER_EXISTS)) {
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        	}
		}
		Vector vecExistingIdentifier = new Vector();
		if (getPartyIdentifierResponse.getData() != null) {
		vecExistingIdentifier = (Vector) getPartyIdentifierResponse.getData();
		}
		return vecExistingIdentifier;		
	}

	private void handlePartyIdentifierAdd(
			TCRMPartyIdentificationBObj inputPartyIden, Vector vecInpMTTIdentifier, MetcashIdentifierBObj outputMetcashIden, DWLControl control) throws BusinessProxyException {
		
		DWLTransactionPersistent addPartyIdenRequest = new DWLTransactionPersistent();
		addPartyIdenRequest.setTxnControl(control);
		addPartyIdenRequest.setTxnType("addPartyIdentification");
		addPartyIdenRequest.setTxnTopLevelObject(inputPartyIden);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse addPartyIdenResponse = null;
        
        // Invoke the "addPartyIdentification" transaction.
        try {
        	addPartyIdenResponse = (DWLResponse) super.execute(addPartyIdenRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTLEGAL_ENTITY_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTLEGALENTITY_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }
        
        if (addPartyIdenResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTLEGAL_ENTITY_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTLEGALENTITY_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (addPartyIdenResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	DWLStatus dwlStatus = addPartyIdenResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }
        
        TCRMPartyIdentificationBObj addPartyIdenOutput = (TCRMPartyIdentificationBObj) addPartyIdenResponse.getData();       
        outputMetcashIden.setTCRMPartyIdentificationBObj(addPartyIdenOutput);
        
        if (vecInpMTTIdentifier.size() > 0 && vecInpMTTIdentifier != null) {
        	processMTTIdentifier(vecInpMTTIdentifier, addPartyIdenOutput.getIdentificationIdPK(), outputMetcashIden, control);
        	}        	
		}

	private void processMTTIdentifier(Vector vecInpMTTIdentifier,
			String identifierId, MetcashIdentifierBObj outputMetcashIden, DWLControl control) throws BusinessProxyException {
		
		MTTIdentifierBObj inputMTTIden = new MTTIdentifierBObj();
    	
    	for (int j=0; j < vecInpMTTIdentifier.size() ; j++) {
    		inputMTTIden = (MTTIdentifierBObj) vecInpMTTIdentifier.elementAt(j);        		
    		inputMTTIden.setControl(control);
    		try {
				inputMTTIden.setIdentifierId(identifierId);
			} catch (Exception e) {
				throw new BusinessProxyException (e.getMessage()); 
			}
    		
    		if (inputMTTIden.getMTTIdentifierIdPk() == null) {
    			//ADD
    			if (inputMTTIden.getStartDate() == null) {
    				try {
						inputMTTIden.setStartDate(DWLDateTimeUtilities.getCurrentSystemTime());
					} catch (Exception e) {
						throw new BusinessProxyException(e.getMessage());
					}
    			}
    			handleMTTIdentifierAdd (inputMTTIden, outputMetcashIden, control);    			
    		} else {
    			handleMTTIdentifierUpdate (inputMTTIden, outputMetcashIden, control);
    		}
    	}
	}

	private void handleMTTIdentifierUpdate(MTTIdentifierBObj inputMTTIden,
			MetcashIdentifierBObj outputMetcashIden, DWLControl control) throws BusinessProxyException {
		
		DWLTransactionPersistent updateMTTIdentifierRequest = new DWLTransactionPersistent();
		updateMTTIdentifierRequest.setTxnControl(control);
		updateMTTIdentifierRequest.setTxnType("updateMTTIdentifier");
		updateMTTIdentifierRequest.setTxnTopLevelObject(inputMTTIden);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse updateMTTIdentifierResponse = null;
        
        // Invoke the "updateMTTIdentifier" transaction.
        try {
        	updateMTTIdentifierResponse = (DWLResponse) super.execute(updateMTTIdentifierRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTLEGAL_ENTITY_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTLEGALENTITY_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }
        
        if (updateMTTIdentifierResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTLEGAL_ENTITY_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTLEGALENTITY_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (updateMTTIdentifierResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	DWLStatus dwlStatus = updateMTTIdentifierResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }
        outputMetcashIden.setMTTIdentifierBObj((MTTIdentifierBObj) updateMTTIdentifierResponse.getData());
		
	}

	private void handleMTTIdentifierAdd(MTTIdentifierBObj inputMTTIden,
			MetcashIdentifierBObj outputMetcashIden, DWLControl control) throws BusinessProxyException {
		
		// Handle transaction "addMTTIdentifier"
        // Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent addMTTIdentifierRequest = new DWLTransactionPersistent();
        addMTTIdentifierRequest.setTxnControl(control);
        addMTTIdentifierRequest.setTxnType("addMTTIdentifier");
        addMTTIdentifierRequest.setTxnTopLevelObject(inputMTTIden);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse addMTTIdentifierResponse = null;
        
        // Invoke the "addMTTIdentifier" transaction.
        try {
            addMTTIdentifierResponse = (DWLResponse) super.execute(addMTTIdentifierRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTLEGAL_ENTITY_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTLEGALENTITY_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }
        
        if (addMTTIdentifierResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTLEGAL_ENTITY_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTLEGALENTITY_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (addMTTIdentifierResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	DWLStatus dwlStatus = addMTTIdentifierResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }
        outputMetcashIden.setMTTIdentifierBObj((MTTIdentifierBObj) addMTTIdentifierResponse.getData());
		}
		
	}