/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[8823816dcdc242dcb5e1baea914d6a44]
 */

package com.metcash.services.custom.compositeTxn;

import java.util.Vector;

import com.dwl.base.DWLCommon;
import com.dwl.base.DWLControl;
import com.dwl.base.DWLResponse;
import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.admin.services.em.obj.ProcessActionBObj;
import com.dwl.base.admin.services.em.obj.ProcessControlBObj;
import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLStatus;
import com.dwl.base.requestHandler.DWLTransactionInquiry;
import com.dwl.base.requestHandler.DWLTransactionPersistent;
import com.dwl.base.requestHandler.DWLTxnBP;
import com.dwl.base.util.DWLFunctionUtils;
import com.dwl.commoncomponents.eventmanager.ProcessActionObj;
import com.dwl.commoncomponents.eventmanager.ProcessControlObj;
import com.dwl.tcrm.common.TCRMResponse;
import com.dwl.tcrm.coreParty.component.TCRMAdminContEquivBObj;
import com.dwl.tcrm.coreParty.component.TCRMOrganizationBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyAddressBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyContactMethodBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyIdentificationBObj;
import com.dwl.tcrm.financial.component.TCRMAdminNativeKeyBObj;
import com.dwl.tcrm.financial.component.TCRMContractBObj;
import com.dwl.tcrm.financial.component.TCRMContractComponentBObj;
import com.dwl.tcrm.financial.component.TCRMContractPartyRoleBObj;
import com.dwl.tcrm.financial.component.TCRMContractPartyRoleIdentifierBObj;
import com.dwl.tcrm.financial.component.TCRMContractRoleLocationBObj;
import com.dwl.tcrm.financial.component.TCRMContractRoleLocationPurposeBObj;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.dwl.unifi.tx.exception.BusinessProxyException;
import com.metcash.db.custom.component.MTTActCostChargesBObj;
import com.metcash.db.custom.component.MTTActCreditTaxBObj;
import com.metcash.db.custom.component.MTTActFinancialBObj;
import com.metcash.db.custom.component.MTTActOrderInvoiceBObj;
import com.metcash.db.custom.component.MTTActReportingBObj;
import com.metcash.services.custom.component.MetcashAccountBObj;
import com.metcash.services.custom.component.MetcashAccountRoleBObj;
import com.metcash.services.custom.component.MetcashIdentifierBObj;
import com.metcash.services.custom.constant.MTTEMConstant;
import com.metcash.services.custom.constant.MTTServicesComponentID;
import com.metcash.services.custom.constant.MTTServicesErrorReasonCode;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * 
 * @generated
 */
public class MaintainMTTAccountCompositeTxnBP  extends DWLTxnBP {

	/**
	 * @generated
	 **/
	private IDWLErrorMessage errHandler;
	
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(MaintainMTTAccountCompositeTxnBP.class);
	/**
	 * @generated
	 **/
    public MaintainMTTAccountCompositeTxnBP() {
        super();
        errHandler = TCRMClassFactory.getErrorHandler();
    }
	/**
	 * @generated NOT
	 **/
    public Object execute(Object inputObj) throws BusinessProxyException {
    logger.finest("ENTER Object execute(Object inputObj)");

        TCRMResponse outputTxnObj = null;
        DWLTransactionPersistent inputTxnObj = (DWLTransactionPersistent) inputObj;
        DWLControl control = inputTxnObj.getTxnControl();
        DWLCommon topLevelObject = (DWLCommon) inputTxnObj.getTxnTopLevelObject();
        if (!(topLevelObject instanceof MetcashAccountBObj)) {
            // MDM_TODO0: CDKWB0014I optionally use a more appropriate error code than
            // "MAINTAINMTTACCOUNT_FAILED".
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        
        MetcashAccountBObj mainInput = (MetcashAccountBObj) topLevelObject;
        MetcashAccountBObj mainOutput = new MetcashAccountBObj();
        mainOutput.setControl(control);
        
        boolean isUpdateContract = false;
        boolean isContractExists = false;
        
        isContractExists = searchContractBasic(mainInput, control);
        
        if (isContractExists) {
        	TCRMContractBObj foundContract = getExistingContract(mainInput, control);
        	resolveIdentity(mainInput, foundContract, control);        	
        	handleUpdateContract (mainInput, mainOutput, control);        	
            isUpdateContract = true;        	
        } else {
        	handleAddContract (mainInput, mainOutput, control);        	
        }
        if (mainInput.getMTTActCreditTaxBObj() != null) {
        	if (!isUpdateContract) {
                handleCreditTaxAdd (mainInput, mainOutput, control);
                } if (isUpdateContract) {
                	handleCreditTaxUpdate (mainInput, mainOutput, control);
             }
        }
        
        handleOrderInvoice (mainInput, mainOutput, control);
        
        handleFinancial (mainInput, mainOutput, control);
        
        handleCostCharge (mainInput, mainOutput, control);
        
        handleReporting (mainInput, mainOutput, control);
        
        triggerEventForContract (mainOutput.getTCRMContractBObj().getContractIdPK(), control);
        
        // MDM_TODO: CDKWB0013I build the response Bobj.        
        
        // Construct the response object.
        DWLStatus outputStatus = new DWLStatus();
        outputStatus.setStatus(DWLStatus.SUCCESS);
        outputTxnObj = new TCRMResponse();
        outputTxnObj.setStatus(outputStatus);
        outputTxnObj.setData(mainOutput);
        logger.finest("RETURN Object execute(Object inputObj)");
        return outputTxnObj;
    }
    private boolean searchContractBasic(MetcashAccountBObj mainInput,
			DWLControl control) throws BusinessProxyException {
		
    	TCRMContractBObj contractBObj = mainInput.getTCRMContractBObj();
    	Vector vecAdminNativeKey = contractBObj.getItemsTCRMAdminNativeKeyBObj();

		TCRMAdminNativeKeyBObj inputAdminNativekey = new TCRMAdminNativeKeyBObj();
		inputAdminNativekey = (TCRMAdminNativeKeyBObj) vecAdminNativeKey.firstElement();
		
		String adminSysTp = inputAdminNativekey.getAdminSystemType();
		String adminContractId = inputAdminNativekey.getAdminContractId();		
		
		Vector<Object> getAdminNativeKeyInput = new Vector<Object>();

		getAdminNativeKeyInput.add(0, adminSysTp);
		getAdminNativeKeyInput.add(1, adminContractId);		

		// Prepare a new DWLTransactionInquiry instance.
		DWLTransactionInquiry getAdminNativeKeyRequest = new DWLTransactionInquiry();
		getAdminNativeKeyRequest.setTxnControl(control);
		getAdminNativeKeyRequest.setTxnType("getContractByAdminSysKey");
		getAdminNativeKeyRequest.setStringParameters(getAdminNativeKeyInput);

		// Prepare a reference to hold the response for this transaction.
		DWLResponse getAdminNativeKeyResponse = null;

		// Invoke the "getContract" transaction.
		try {
			getAdminNativeKeyResponse = (DWLResponse) super
					.execute(getAdminNativeKeyRequest);
		} catch (BusinessProxyException e) {
			DWLError error = errHandler.getErrorMessage(
					MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
					"READERR", MTTServicesErrorReasonCode.GETCONTRACTBYADMINSYSKEY_FAILED,
					control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage(), e);
		} if (getAdminNativeKeyResponse == null) {
			DWLError error = errHandler.getErrorMessage(
					MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
					"READERR", MTTServicesErrorReasonCode.GETCONTRACTBYADMINSYSKEY_FAILED,
					control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage());
		}
		if (getAdminNativeKeyResponse.getData() != null) {
			resolveContract(mainInput, getAdminNativeKeyResponse);
			return true;
		} else {
			return false;
		}
	}
	private void resolveContract(MetcashAccountBObj mainInput,
			DWLResponse getAdminNativeKeyResponse) throws BusinessProxyException {
		
		TCRMContractBObj existingContract = (TCRMContractBObj) getAdminNativeKeyResponse.getData();
		mainInput.getTCRMContractBObj().setContractIdPK(existingContract.getContractIdPK());
		try {
			mainInput.getTCRMContractBObj().setContractLastUpdateDate(existingContract.getContractLastUpdateDate());
		} catch (Exception e1) {
			throw new BusinessProxyException(e1.getMessage());
		}
		
	}
	private void handleCreditTaxUpdate(MetcashAccountBObj mainInput,
			MetcashAccountBObj mainOutput, DWLControl control) throws BusinessProxyException {
    	
    	String contractId = mainOutput.getTCRMContractBObj().getContractIdPK();
    	MTTActCreditTaxBObj foundCreditTax = new  MTTActCreditTaxBObj();
    	foundCreditTax = getExistingCreditTax(contractId, control);
    	
		if (foundCreditTax == null) {
			handleCreditTaxAdd(mainInput, mainOutput, control);
		}
		if (foundCreditTax != null) {
    	MTTActCreditTaxBObj updateMTTActCreditTaxInput = new MTTActCreditTaxBObj();
    	updateMTTActCreditTaxInput.setControl(control);
        
    	updateMTTActCreditTaxInput = (MTTActCreditTaxBObj) mainInput.getMTTActCreditTaxBObj();
        
        if (updateMTTActCreditTaxInput != null) {
        try {
        	updateMTTActCreditTaxInput.setMTTActCreditTaxIdPk(foundCreditTax.getMTTActCreditTaxIdPk());
        	updateMTTActCreditTaxInput.setMTTActCreditTaxLastUpdateDate(foundCreditTax.getMTTActCreditTaxLastUpdateDate());
        	updateMTTActCreditTaxInput.setMTTActCreditTaxLastUpdateTxId(mainOutput.getTCRMContractBObj().getContractLastUpdateTxId());
        	updateMTTActCreditTaxInput.setMTTActCreditTaxLastUpdateUser(mainOutput.getTCRMContractBObj().getContractLastUpdateUser());
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                    "INSERR",
                    MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                    control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage(), e2);
		}

        // Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent updateMTTActCreditTaxRequest = new DWLTransactionPersistent();
        updateMTTActCreditTaxRequest.setTxnControl(control);
        updateMTTActCreditTaxRequest.setTxnType("updateMTTActCreditTax");
        updateMTTActCreditTaxRequest.setTxnTopLevelObject(updateMTTActCreditTaxInput);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse updateMTTActCreditTaxResponse = null;
        
        // Invoke the "updateMTTActCreditTax" transaction.
        try {
        	updateMTTActCreditTaxResponse = (DWLResponse) super.execute(updateMTTActCreditTaxRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }
        
        if (updateMTTActCreditTaxResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (updateMTTActCreditTaxResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	
        	DWLStatus dwlStatus = updateMTTActCreditTaxResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }
        
        // Extract the returned business object from the response.
        MTTActCreditTaxBObj addMTTActCreditTaxOutput = (MTTActCreditTaxBObj) updateMTTActCreditTaxResponse.getData();        
        mainOutput.setMTTActCreditTaxBObj(addMTTActCreditTaxOutput);
        	}
		}
	}
	private MTTActCreditTaxBObj getExistingCreditTax(String contractId,
			DWLControl control) throws BusinessProxyException {
		
		Vector<Object> getCreditTaxInput = new Vector<Object>();
    	getCreditTaxInput.add(0, contractId);

		// Prepare a new DWLTransactionInquiry instance.
		DWLTransactionInquiry getCreditTaxRequest = new DWLTransactionInquiry();
		getCreditTaxRequest.setTxnControl(control);
		getCreditTaxRequest.setTxnType("getAllMTTCreditTaxByID");
		getCreditTaxRequest.setStringParameters(getCreditTaxInput);

		// Prepare a reference to hold the response for this transaction.
		DWLResponse getCreditTaxResponse = null;

		// Invoke the transaction.
		try {
			getCreditTaxResponse = (DWLResponse) super
					.execute(getCreditTaxRequest);
		} catch (BusinessProxyException e) {
			DWLError error = errHandler.getErrorMessage(
					MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
					"READERR", MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
					control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage(), e);
		}    		
		MTTActCreditTaxBObj foundCreditTax = (MTTActCreditTaxBObj) getCreditTaxResponse.getData();
		if (foundCreditTax != null) {
		return foundCreditTax;
		} else {
			return null;
		}
	}
	private void handleMetcashRoleForUpdate(
			MetcashAccountBObj mainInput,
			TCRMContractBObj foundContract,
			DWLControl control) throws BusinessProxyException {
    	
    	Vector<Object> vecInputMetcashActRole = new Vector<>();
    	vecInputMetcashActRole = (Vector) mainInput.getItemsMetcashAccountRoleBObj();    	
		
    	if (vecInputMetcashActRole.size() > 0 && vecInputMetcashActRole != null) {
    		MetcashAccountRoleBObj inputMetcashContrRole = new MetcashAccountRoleBObj();
			TCRMContractPartyRoleBObj inputLegalEntityRole = new TCRMContractPartyRoleBObj();
			TCRMContractPartyRoleBObj foundLegalEntityRole = new TCRMContractPartyRoleBObj();
    		for (int k=0; k < vecInputMetcashActRole.size(); k++) {    			
    			inputMetcashContrRole = (MetcashAccountRoleBObj) vecInputMetcashActRole.elementAt(k);
    			Vector vecInpMetcashIdentifier = inputMetcashContrRole.getItemsMetcashIdentifierBObj();
    			if (inputMetcashContrRole.getTCRMContractPartyRoleBObj().
    					getRoleType().equalsIgnoreCase(MTTServicesComponentID.LEGAL_ENTITY_ROLE_TYPE)) {
    			inputLegalEntityRole = inputMetcashContrRole.getTCRMContractPartyRoleBObj();
    		
    			Vector vecFoundContrRole = new Vector();
    			TCRMContractComponentBObj foundContrComp = (TCRMContractComponentBObj) foundContract.getItemsTCRMContractComponentBObj().firstElement(); 
    			vecFoundContrRole = (Vector) foundContrComp.getItemsTCRMContractPartyRoleBObj();
    			for (int p=0; p < vecFoundContrRole.size(); p++) {								
    				foundLegalEntityRole = (TCRMContractPartyRoleBObj) vecFoundContrRole.elementAt(p);
    				if(foundLegalEntityRole.getRoleType().equalsIgnoreCase(inputLegalEntityRole.getRoleType())) {
    					resolveIdentityForLegalEntityRole (inputLegalEntityRole, foundLegalEntityRole, vecInpMetcashIdentifier, control);
    					break;
    					}
    				}
    			TCRMContractComponentBObj inputContrCom = (TCRMContractComponentBObj) mainInput.getTCRMContractBObj().getItemsTCRMContractComponentBObj().firstElement();
    			inputContrCom.setTCRMContractPartyRoleBObj(inputLegalEntityRole);    				
    			}
    		}  			
    	}
	}
	private void handleAddContract(MetcashAccountBObj mainInput, 
			MetcashAccountBObj mainOutput, DWLControl control) throws BusinessProxyException {
    	
		MetcashAccountRoleBObj outputMetcashLegalEntityRole = new MetcashAccountRoleBObj();
		handleMetcashRoleForAdd (mainInput, outputMetcashLegalEntityRole, control);
    	
    	TCRMContractBObj addContractInput = mainInput.getTCRMContractBObj();
    	addContractInput.setControl(control);
    	
    	// Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent addContractRequest = new DWLTransactionPersistent();
        addContractRequest.setTxnControl(control);
        addContractRequest.setTxnType("addContract");
        addContractRequest.setTxnTopLevelObject(addContractInput);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse addContractResponse = null;
        
        // Invoke the "addContract" transaction.
        try {
            addContractResponse = (DWLResponse) super.execute(addContractRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }
        
        if (addContractResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (addContractResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	DWLStatus dwlStatus = addContractResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }
        if(addContractResponse.getData() != null) {        	
        	TCRMContractBObj outputContract = new TCRMContractBObj();
        	TCRMContractComponentBObj outputContrComp = new TCRMContractComponentBObj();        	
        	Vector vecContractRole = new Vector();
        	        	
        	outputContract = (TCRMContractBObj) addContractResponse.getData();
        	outputContrComp = (TCRMContractComponentBObj) outputContract.getItemsTCRMContractComponentBObj().firstElement();        	
        	vecContractRole = outputContrComp.getItemsTCRMContractPartyRoleBObj();
        	MetcashAccountRoleBObj outputMetcashRole = new MetcashAccountRoleBObj();
        	
        	for (int i=0; i < vecContractRole.size(); i++) {
        		TCRMContractPartyRoleBObj outputConrRole = (TCRMContractPartyRoleBObj) vecContractRole.elementAt(i);        		
        		if (outputConrRole.getRoleType().equalsIgnoreCase(MTTServicesComponentID.LEGAL_ENTITY_ROLE_TYPE)) {
        			outputMetcashLegalEntityRole.setTCRMContractPartyRoleBObj(outputConrRole);
        			mainOutput.setMetcashAccountRoleBObj(outputMetcashLegalEntityRole);
        		} else {
        			outputMetcashRole.setTCRMContractPartyRoleBObj((TCRMContractPartyRoleBObj) vecContractRole.elementAt(i));
        			mainOutput.setMetcashAccountRoleBObj(outputMetcashRole);
        		}        		
        	}        	
        	outputContrComp.getItemsTCRMContractPartyRoleBObj().removeAllElements();
        	mainOutput.setTCRMContractBObj(outputContract);
        }
	}
    
	private void handleMetcashRoleForAdd(MetcashAccountBObj mainInput, 
			MetcashAccountRoleBObj outputMetcashRole, DWLControl control) throws BusinessProxyException {
		
		// Clear TCRMContractPartyRole from TCRMContractBObj
    	TCRMContractComponentBObj inputContrComp = (TCRMContractComponentBObj) mainInput.getTCRMContractBObj().getItemsTCRMContractComponentBObj().firstElement();
    	inputContrComp.getItemsTCRMContractPartyRoleBObj().removeAllElements();
    	
    	
		Vector<Object> vecInputMetcashActRole = new Vector<>();
    	vecInputMetcashActRole = (Vector) mainInput.getItemsMetcashAccountRoleBObj();
    	
    	if (vecInputMetcashActRole.size() > 0 && vecInputMetcashActRole != null) {
    		for (int m=0; m < vecInputMetcashActRole.size(); m++) {
    			MetcashAccountRoleBObj inputMetcashContrRole = new MetcashAccountRoleBObj();
    			TCRMContractPartyRoleBObj addContrRole = new TCRMContractPartyRoleBObj();
    			inputMetcashContrRole = (MetcashAccountRoleBObj) vecInputMetcashActRole.elementAt(m);
    			
    			TCRMContractPartyRoleBObj inputContrRole = inputMetcashContrRole.getTCRMContractPartyRoleBObj();
    			Vector vecInpMetcashIdentifier = inputMetcashContrRole.getItemsMetcashIdentifierBObj();
    				if (inputContrRole.getRoleType().equalsIgnoreCase(MTTServicesComponentID.LOCATION_ROLE_TYPE)) {
    					if (inputContrRole.getPartyId() == null) {	
    					resolveIDForRole (inputContrRole, control);
    					}
    						addContrRole = inputContrRole;
    				}
    				if (inputContrRole.getRoleType().equalsIgnoreCase(MTTServicesComponentID.LEGAL_ENTITY_ROLE_TYPE)) {
    					handleLegalEntityRole (inputContrRole, vecInpMetcashIdentifier, outputMetcashRole, control);
    					addContrRole = inputContrRole;
    				}
    				inputContrComp.setTCRMContractPartyRoleBObj(addContrRole);
    				}
    			}
		}
	private void resolveIdentityForLegalEntityRole(TCRMContractPartyRoleBObj inputLegalEntityRole,
			TCRMContractPartyRoleBObj foundLegalEntityRole, Vector vecInpMetcashIdentifier, DWLControl control) throws BusinessProxyException {
		
		inputLegalEntityRole.setContractRoleIdPK(foundLegalEntityRole.getContractRoleIdPK());
			try {
				inputLegalEntityRole.setContractPartyRoleLastUpdateDate(foundLegalEntityRole.getContractPartyRoleLastUpdateDate());
					} catch (Exception e) {
						DWLError error = errHandler.getErrorMessage(
		    					MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
		    					"READERR", MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
		    					control, new String[0]);
		    			throw new BusinessProxyException(error.getErrorMessage(), e);
					}
			resolveIdentityForRoleChild (inputLegalEntityRole, foundLegalEntityRole, vecInpMetcashIdentifier, control);
		}
	private void resolveIdentityForRoleChild(
			TCRMContractPartyRoleBObj inputLegalEntityRole,
			TCRMContractPartyRoleBObj foundLegalEntityRole, Vector vecInpMetcashIdentifier, DWLControl control) throws BusinessProxyException {
		
		Vector vecInputRoleLoc = inputLegalEntityRole.getItemsTCRMContractRoleLocationBObj();
		Vector vecFoundRoleLoc = foundLegalEntityRole.getItemsTCRMContractRoleLocationBObj();		
		Vector vecFoundRoleIden = foundLegalEntityRole.getItemsTCRMContractPartyRoleIdentifierBObj();
		
		if (vecInputRoleLoc.size() > 0 && vecInputRoleLoc != null) {
			resolveRoleLocation (inputLegalEntityRole, vecInputRoleLoc, vecFoundRoleLoc, control);
		}
		if (vecInpMetcashIdentifier.size() > 0 && vecInpMetcashIdentifier != null) {
			resolveRoleIdentifier (inputLegalEntityRole, vecInpMetcashIdentifier, vecFoundRoleIden, control);
		}
		
	}
	private void resolveRoleIdentifier(TCRMContractPartyRoleBObj inputLegalEntityRole, Vector vecInpMetcashIdentifier,
			Vector vecFoundRoleIden, DWLControl control) throws BusinessProxyException {
		
		MaintainMetcashIdentifier metcashIdentifier = new MaintainMetcashIdentifier();
		Vector metcashIdentfierResponse = (Vector) metcashIdentifier.processMetcashIdentifier(vecInpMetcashIdentifier, inputLegalEntityRole.getPartyId(), control);
		MetcashIdentifierBObj inputMetcashIden = new MetcashIdentifierBObj();
		TCRMPartyIdentificationBObj inputPartyIden = new TCRMPartyIdentificationBObj();		
		TCRMContractPartyRoleIdentifierBObj foundRoleIden = new TCRMContractPartyRoleIdentifierBObj();
		TCRMContractPartyRoleIdentifierBObj inputRoleIden = new TCRMContractPartyRoleIdentifierBObj();
		boolean isResolved = false;
		
		for (int u=0; u < metcashIdentfierResponse.size(); u++) {
			inputMetcashIden = (MetcashIdentifierBObj) metcashIdentfierResponse.elementAt(u);
			inputPartyIden = inputMetcashIden.getTCRMPartyIdentificationBObj();			
			if (vecFoundRoleIden.size() > 0 && vecFoundRoleIden != null) {
			for (int v=0; v < vecFoundRoleIden.size(); v++) {
				foundRoleIden = (TCRMContractPartyRoleIdentifierBObj) vecFoundRoleIden.elementAt(v);
				if (inputPartyIden.getIdentificationType().equalsIgnoreCase(foundRoleIden.getDescription())) {
					inputRoleIden.setControl(control);
					inputRoleIden.setContractPartyRoleIdentifierIdPK(foundRoleIden.getContractPartyRoleIdentifierIdPK());
					try {
						inputRoleIden.setContractPartyRoleIdentifierLastUpdateDate(foundRoleIden.getContractPartyRoleIdentifierLastUpdateDate());
					} catch (Exception e) {
						throw new BusinessProxyException(e.getMessage());
					}
					inputRoleIden.setIdentifierId(inputPartyIden.getIdentificationIdPK());
					inputRoleIden.setDescription(inputPartyIden.getIdentificationType());
					inputLegalEntityRole.setTCRMContractPartyRoleIdentifierBObj(inputRoleIden);
					isResolved = true;
					break;
					} 
				}
			} if (!isResolved) {
			inputRoleIden.setControl(control);
			inputRoleIden.setIdentifierId(inputPartyIden.getIdentificationIdPK());
			inputRoleIden.setDescription(inputPartyIden.getIdentificationType());
			inputLegalEntityRole.setTCRMContractPartyRoleIdentifierBObj(inputRoleIden);
			}
		}
	}
	private void resolveRoleLocation(TCRMContractPartyRoleBObj inputLegalEntityRole, Vector vecInputRoleLoc,
			Vector vecFoundRoleLoc, DWLControl control) throws BusinessProxyException {
		
		String partyId = inputLegalEntityRole.getPartyId();
		
		for (int h=0; h < vecInputRoleLoc.size(); h++) {
			
			boolean isInpRoleLocationAddr = false;
			boolean isInpRoleLocationCM = false;			
			boolean isResolved = false;
			
			TCRMContractRoleLocationBObj inputRoleLoc = (TCRMContractRoleLocationBObj) vecInputRoleLoc.elementAt(h);
			TCRMContractRoleLocationPurposeBObj inputRoleLocPurpose = (TCRMContractRoleLocationPurposeBObj) inputRoleLoc.getItemsTCRMContractRoleLocationPurposeBObj().firstElement();
			if (inputRoleLoc.getTCRMPartyAddressBObj() != null) {
				isInpRoleLocationAddr = true;
			}
			if (inputRoleLoc.getTCRMPartyContactMethodBObj() != null) {
				isInpRoleLocationCM = true;
			}
			if (vecFoundRoleLoc.size() > 0 && vecFoundRoleLoc != null) {
			for (int j=0; j < vecFoundRoleLoc.size(); j++) {
				
				boolean isFoundRoleLocAddr = false;
				boolean isFoundRoleLocCM = false;
				
				TCRMContractRoleLocationBObj foundRoleLoc = (TCRMContractRoleLocationBObj) vecFoundRoleLoc.elementAt(j);
				TCRMContractRoleLocationPurposeBObj foundRoleLocPurpose = (TCRMContractRoleLocationPurposeBObj) foundRoleLoc.getItemsTCRMContractRoleLocationPurposeBObj().firstElement();
				
				if (foundRoleLoc.getTCRMPartyAddressBObj() != null) {
					isFoundRoleLocAddr = true;
				}
				if (foundRoleLoc.getTCRMPartyContactMethodBObj() != null) {
					isFoundRoleLocCM = true;
				}
				
				try {
				if (isInpRoleLocationAddr && isFoundRoleLocAddr && 
						inputRoleLocPurpose.isBusinessKeySame(foundRoleLocPurpose)) {					
						handlePartyAddressUpdate (inputRoleLoc.getTCRMPartyAddressBObj(), foundRoleLoc.getTCRMPartyAddressBObj(), partyId, control);						
						inputRoleLoc.setContractRoleLocationIdPK(foundRoleLoc.getContractRoleLocationIdPK());
						inputRoleLoc.setContractRoleLocationLastUpdateDate(foundRoleLoc.getContractRoleLocationLastUpdateDate());
						inputRoleLocPurpose.setContractRoleLocationPurposeIdPK(foundRoleLocPurpose.getContractRoleLocationPurposeIdPK());
						inputRoleLocPurpose.setContractRoleLocationPurposeLastUpdateDate(foundRoleLocPurpose.getContractRoleLocationPurposeLastUpdateDate());
						isResolved = true;
						break;
					} 
				if (isInpRoleLocationCM && isFoundRoleLocCM && 
						inputRoleLocPurpose.isBusinessKeySame(foundRoleLocPurpose)) {					
						handlePartyContMethUpdate (inputRoleLoc.getTCRMPartyContactMethodBObj(), foundRoleLoc.getTCRMPartyContactMethodBObj(), partyId, control);
						inputRoleLoc.setContractRoleLocationIdPK(foundRoleLoc.getContractRoleLocationIdPK());
						inputRoleLoc.setContractRoleLocationLastUpdateDate(foundRoleLoc.getContractRoleLocationLastUpdateDate());
						inputRoleLocPurpose.setContractRoleLocationPurposeIdPK(foundRoleLocPurpose.getContractRoleLocationPurposeIdPK());
						inputRoleLocPurpose.setContractRoleLocationPurposeLastUpdateDate(foundRoleLocPurpose.getContractRoleLocationPurposeLastUpdateDate());
						isResolved = true;
						break;
					} 
				} catch (Exception e) {
						DWLError error = errHandler.getErrorMessage(
								MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
								"READERR", MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
								control, new String[0]);
						throw new BusinessProxyException(error.getErrorMessage(), e);
						}						
					}
			}
				if (isInpRoleLocationAddr || isInpRoleLocationCM) {
					if (!isResolved) {
					Vector vecRoleLoc = new Vector();
					vecRoleLoc.add(inputRoleLoc);
					handleRoleLocation (vecRoleLoc, inputLegalEntityRole.getPartyId(), control);					
					}
				}
			}
		}
	private void handlePartyContMethUpdate(
			TCRMPartyContactMethodBObj inputPartyContactMethodBObj,
			TCRMPartyContactMethodBObj foundPartyContactMethodBObj, String partyId, DWLControl control) throws BusinessProxyException {
		
		boolean isPhone = false;
		
		if (inputPartyContactMethodBObj.getTCRMContactMethodBObj().getTCRMPhoneNumberBObj() != null) {
			isPhone = true;
		}
		
		inputPartyContactMethodBObj.setControl(control);
		inputPartyContactMethodBObj.setPartyId(foundPartyContactMethodBObj.getPartyId());
		inputPartyContactMethodBObj.setPartyContactMethodIdPK(foundPartyContactMethodBObj.getPartyContactMethodIdPK());		
		inputPartyContactMethodBObj.setContactMethodId(foundPartyContactMethodBObj.getContactMethodId());
		inputPartyContactMethodBObj.getTCRMContactMethodBObj().setContactMethodIdPK(foundPartyContactMethodBObj.getTCRMContactMethodBObj().getContactMethodIdPK());
		if (isPhone) {
		inputPartyContactMethodBObj.getTCRMContactMethodBObj().getTCRMPhoneNumberBObj().setPhoneNumberId(foundPartyContactMethodBObj.getTCRMContactMethodBObj().getTCRMPhoneNumberBObj().getPhoneNumberId());
		}
		try {
			inputPartyContactMethodBObj.setLocationGroupLastUpdateDate(foundPartyContactMethodBObj.getLocationGroupLastUpdateDate());
			inputPartyContactMethodBObj.setContactMethodGroupLastUpdateDate(foundPartyContactMethodBObj.getContactMethodGroupLastUpdateDate());
			inputPartyContactMethodBObj.getTCRMContactMethodBObj().setContactMethodLastUpdateDate(foundPartyContactMethodBObj.getTCRMContactMethodBObj().getContactMethodLastUpdateDate());
			if (isPhone) {
			inputPartyContactMethodBObj.getTCRMContactMethodBObj().getTCRMPhoneNumberBObj().setPhoneLastUpdateDate(foundPartyContactMethodBObj.getTCRMContactMethodBObj().getTCRMPhoneNumberBObj().getPhoneLastUpdateDate());
			}
		} catch (Exception e1) {
			DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                    "INSERR",
                    MTTServicesErrorReasonCode.CONTACTMETHOD_FAILED,
                    control, new String[0]);
					throw new BusinessProxyException(error.getErrorMessage(), e1);
		}
		// Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent updatePartyCMRequest = new DWLTransactionPersistent();
        updatePartyCMRequest.setTxnControl(control);
        updatePartyCMRequest.setTxnType("updatePartyContactMethod");
        updatePartyCMRequest.setTxnTopLevelObject(inputPartyContactMethodBObj);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse updatePartyCMResponse = null;
        
        try {
        	updatePartyCMResponse = (DWLResponse) super.execute(updatePartyCMRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.CONTACTMETHOD_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }
        
        if (updatePartyCMResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.CONTACTMETHOD_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (updatePartyCMResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	DWLStatus dwlStatus = updatePartyCMResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }		
	}
	private void handlePartyAddressUpdate(
			TCRMPartyAddressBObj inputPartyAddress, TCRMPartyAddressBObj foundPartyAddress, String partyId, DWLControl control) throws BusinessProxyException {
		
		inputPartyAddress.setControl(control);
		inputPartyAddress.setPartyId(partyId);
		inputPartyAddress.setPartyAddressIdPK(foundPartyAddress.getPartyAddressIdPK());
		inputPartyAddress.setAddressId(foundPartyAddress.getAddressId());
		inputPartyAddress.getTCRMAddressBObj().setAddressIdPK(foundPartyAddress.getTCRMAddressBObj().getAddressIdPK());
		try {
			inputPartyAddress.setLocationGroupLastUpdateDate(foundPartyAddress.getLocationGroupLastUpdateDate());
			inputPartyAddress.setAddressGroupLastUpdateDate(foundPartyAddress.getAddressGroupLastUpdateDate());		
			inputPartyAddress.getTCRMAddressBObj().setAddressLastUpdateDate(foundPartyAddress.getTCRMAddressBObj().getAddressLastUpdateDate());
		} catch (Exception e1) {
			DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                    "INSERR",
                    MTTServicesErrorReasonCode.ADDRESS_FAILED,
                    control, new String[0]);
					throw new BusinessProxyException(error.getErrorMessage(), e1);
		}
		// Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent updatePartyAddrRequest = new DWLTransactionPersistent();
        updatePartyAddrRequest.setTxnControl(control);
        updatePartyAddrRequest.setTxnType("updatePartyAddress");
        updatePartyAddrRequest.setTxnTopLevelObject(inputPartyAddress);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse updatePartyAddrResponse = null;
        
        try {
        	updatePartyAddrResponse = (DWLResponse) super.execute(updatePartyAddrRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.ADDRESS_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }
        
        if (updatePartyAddrResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.ADDRESS_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (updatePartyAddrResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	DWLStatus dwlStatus = updatePartyAddrResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }		
	}	
	private void handleLegalEntityRole(TCRMContractPartyRoleBObj inputContrRole, 
			Vector vecInpMetcashIdentifier, MetcashAccountRoleBObj outputMetcashRole, DWLControl control) throws BusinessProxyException {
		
		if (inputContrRole.getPartyId() == null) {
			resolveIDForRole(inputContrRole, control);			
		}		
		
		String partyId = inputContrRole.getPartyId();
		
		if (partyId == null) {
			DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                    "INSERR",
                    MTTServicesErrorReasonCode.CONTRACTROLE_FAILED,
                    control, new String[0]);
				throw new BusinessProxyException(error.getErrorMessage());
		}
		
		Vector vecRoleLocation = (Vector) inputContrRole.getItemsTCRMContractRoleLocationBObj();
		
		if(vecRoleLocation.size() > 0 && vecRoleLocation != null) {			
			handleRoleLocation (vecRoleLocation, partyId, control);			
			}
		if (vecInpMetcashIdentifier.size() > 0 && vecInpMetcashIdentifier != null) {
			handleRoleIdentifier (inputContrRole, vecInpMetcashIdentifier, partyId, outputMetcashRole, control);
		}
	}
	private void handleRoleIdentifier(TCRMContractPartyRoleBObj inputContrRole, Vector vecInpMetcashIdentifier, String partyId,
			MetcashAccountRoleBObj outputMetcashRole, DWLControl control) throws BusinessProxyException {
		MaintainMetcashIdentifier metcashIdentifier = new MaintainMetcashIdentifier();
		Vector metcashIdentfierResponse = (Vector) metcashIdentifier.processMetcashIdentifier(vecInpMetcashIdentifier, partyId, control);
		MetcashIdentifierBObj metcashReponse = new MetcashIdentifierBObj();
		TCRMContractPartyRoleIdentifierBObj inputRoleIdentifier = new TCRMContractPartyRoleIdentifierBObj();
		inputRoleIdentifier.setControl(control);
		
		if (metcashIdentfierResponse.size() > 0 && metcashIdentfierResponse != null) {
			for (int k=0; k < metcashIdentfierResponse.size(); k++) {
				metcashReponse = (MetcashIdentifierBObj) metcashIdentfierResponse.elementAt(k);
				outputMetcashRole.setMetcashIdentifierBObj(metcashReponse);
				inputRoleIdentifier.setIdentifierId(metcashReponse.getTCRMPartyIdentificationBObj().getIdentificationIdPK());
				inputRoleIdentifier.setDescription(metcashReponse.getTCRMPartyIdentificationBObj().getIdentificationType());
				inputContrRole.setTCRMContractPartyRoleIdentifierBObj(inputRoleIdentifier);				
			}
		}
		
	}
	private void handleRoleLocation(Vector vecRoleLocation,
			String partyId, DWLControl control) throws BusinessProxyException {
		
		DWLResponse roleLocationResponse = null;		

		for (int a=0; a < vecRoleLocation.size(); a++) {
			TCRMContractRoleLocationBObj inputRoleLoc = (TCRMContractRoleLocationBObj) vecRoleLocation.elementAt(a);
			
			if (inputRoleLoc.getItemsTCRMContractRoleLocationPurposeBObj().size() == 0) {
				DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
	                    "INSERR",
	                    MTTServicesErrorReasonCode.ROLELOCPURPOSE_FAILED,
	                    control, new String[0]);
					throw new BusinessProxyException(error.getErrorMessage());
			}
			
			if (inputRoleLoc.getLocationGroupId() == null) {
				TCRMPartyAddressBObj inputPartyAddr = inputRoleLoc.getTCRMPartyAddressBObj();
				TCRMPartyContactMethodBObj inputPartyContMeth = inputRoleLoc.getTCRMPartyContactMethodBObj();	
		
				if (inputPartyAddr != null) {
					inputPartyAddr.setPartyId(partyId);
					roleLocationResponse = handlePartyAddress (inputPartyAddr, control);
					TCRMPartyAddressBObj partyAddrResponse = (TCRMPartyAddressBObj) roleLocationResponse.getData();
					inputRoleLoc.setLocationGroupId(partyAddrResponse.getPartyAddressIdPK());
				}
				if (inputPartyContMeth != null) {
					inputPartyContMeth.setPartyId(partyId);
					roleLocationResponse = handlePartyContactMethod (inputPartyContMeth, control);
					TCRMPartyContactMethodBObj partyContMethResponse = (TCRMPartyContactMethodBObj) roleLocationResponse.getData();
					inputRoleLoc.setLocationGroupId(partyContMethResponse.getPartyContactMethodIdPK());
				}
			}
		}
	}
	private DWLResponse handlePartyContactMethod(
			TCRMPartyContactMethodBObj inputPartyContMeth, DWLControl control) throws BusinessProxyException {
		
		// Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent addPartyCMRequest = new DWLTransactionPersistent();
        addPartyCMRequest.setTxnControl(control);
        addPartyCMRequest.setTxnType("addPartyContactMethod");
        addPartyCMRequest.setTxnTopLevelObject(inputPartyContMeth);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse addPartyContMethResponse = null;
        
        try {
        	addPartyContMethResponse = (DWLResponse) super.execute(addPartyCMRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.CONTACTMETHOD_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }
        
        if (addPartyContMethResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.CONTACTMETHOD_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (addPartyContMethResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	DWLStatus dwlStatus = addPartyContMethResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }
        
        return addPartyContMethResponse;
	}
	private DWLResponse handlePartyAddress(TCRMPartyAddressBObj inputPartyAddr,
			DWLControl control) throws BusinessProxyException {
		
		// Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent addPartyAddrRequest = new DWLTransactionPersistent();
        addPartyAddrRequest.setTxnControl(control);
        addPartyAddrRequest.setTxnType("addPartyAddress");
        addPartyAddrRequest.setTxnTopLevelObject(inputPartyAddr);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse addPartyAddrResponse = null;
        
        try {
        	addPartyAddrResponse = (DWLResponse) super.execute(addPartyAddrRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.ADDRESS_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }
        
        if (addPartyAddrResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.ADDRESS_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (addPartyAddrResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	DWLStatus dwlStatus = addPartyAddrResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }
        
        return addPartyAddrResponse;
		
	}
	private void resolveIDForRole(TCRMContractPartyRoleBObj inputContrRole,
			DWLControl control) throws BusinessProxyException {
		
		TCRMPartyBObj inputParty = new TCRMPartyBObj();
		inputParty = (TCRMPartyBObj) inputContrRole.getTCRMPartyBObj();
		
		Vector vecAdminContequiv = new Vector<>();
		vecAdminContequiv = (Vector) inputParty.getItemsTCRMAdminContEquivBObj();
		
		if (vecAdminContequiv.size() > 0 && vecAdminContequiv != null) {
			for (int k=0; k < vecAdminContequiv.size(); k++) {
				TCRMAdminContEquivBObj inputAdminContequiv = new TCRMAdminContEquivBObj();
				inputAdminContequiv = (TCRMAdminContEquivBObj) vecAdminContequiv.elementAt(k);
				
				String locationId = inputAdminContequiv.getAdminPartyId();
				String locationSysTp = inputAdminContequiv.getAdminSystemType();
				
				Vector<Object> getAdminContequivInput = new Vector<Object>();

				getAdminContequivInput.add(0, locationSysTp);
				getAdminContequivInput.add(1, locationId);
				getAdminContequivInput.add(2, MTTServicesComponentID.LOCATION_INQ_LVL);

				// Prepare a new DWLTransactionInquiry instance.
				DWLTransactionInquiry getAdminContequivRequest = new DWLTransactionInquiry();
				getAdminContequivRequest.setTxnControl(control);
				getAdminContequivRequest.setTxnType("getPartyByAdminSysKey");
				getAdminContequivRequest.setStringParameters(getAdminContequivInput);

				// Prepare a reference to hold the response for this transaction.
				DWLResponse getAdminContequivResponse = null;

				// Invoke the "getPartyByAdminSysKey" transaction.
				try {
					getAdminContequivResponse = (DWLResponse) super
							.execute(getAdminContequivRequest);
				} catch (BusinessProxyException e) {
					DWLError error = errHandler.getErrorMessage(
							MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
							"READERR", MTTServicesErrorReasonCode.GETPARTYBYADMINSYSKEY_FAILED,
							control, new String[0]);
					throw new BusinessProxyException(error.getErrorMessage(), e);
				}

				if (getAdminContequivResponse == null) {
					DWLError error = errHandler.getErrorMessage(
							MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
							"READERR", MTTServicesErrorReasonCode.GETPARTYBYADMINSYSKEY_FAILED,
							control, new String[0]);
					throw new BusinessProxyException(error.getErrorMessage());
				}
				TCRMOrganizationBObj existingParty = (TCRMOrganizationBObj) getAdminContequivResponse.getData();
				if (existingParty != null) {
				inputContrRole.setPartyId(existingParty.getPartyId());
				// Clear Party BObj for Location
				inputContrRole.setTCRMPartyBObj(null);
				} else {
					DWLError error = errHandler.getErrorMessage(
							MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
							"READERR", MTTServicesErrorReasonCode.GETPARTYBYADMINSYSKEY_FAILED,
							control, new String[0]);
					throw new BusinessProxyException(error.getErrorMessage());
				}
					
			}
		}		
	}
	private void handleUpdateContract(MetcashAccountBObj mainInput, 
			MetcashAccountBObj mainOutput, DWLControl control) throws BusinessProxyException {
		
		TCRMContractBObj updateContractInput = mainInput.getTCRMContractBObj();
		updateContractInput.setControl(control);
		// Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent updateContractRequest = new DWLTransactionPersistent();
        updateContractRequest.setTxnControl(control);
        updateContractRequest.setTxnType("updateContract");
        updateContractRequest.setTxnTopLevelObject(updateContractInput);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse updateContractResponse = null;
        
        // Invoke the "updateContract" transaction.
        try {
            updateContractResponse = (DWLResponse) super.execute(updateContractRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }
        
        if (updateContractResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (updateContractResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	DWLStatus dwlStatus = updateContractResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }
        if(updateContractResponse.getData() != null) {        	
        	TCRMContractBObj outputContract = new TCRMContractBObj();
        	TCRMContractComponentBObj outputContrComp = new TCRMContractComponentBObj();
        	MetcashAccountRoleBObj outputMetcashRole = new MetcashAccountRoleBObj();
        	Vector vecContractRole = new Vector();
        	        	
        	outputContract = (TCRMContractBObj) updateContractResponse.getData();
        	outputContrComp = (TCRMContractComponentBObj) outputContract.getItemsTCRMContractComponentBObj().firstElement();        	
        	vecContractRole = outputContrComp.getItemsTCRMContractPartyRoleBObj();
        	
        	for (int i=0; i < vecContractRole.size(); i++) {
        		outputMetcashRole.setTCRMContractPartyRoleBObj((TCRMContractPartyRoleBObj)vecContractRole.elementAt(i));
        		mainOutput.setMetcashAccountRoleBObj(outputMetcashRole);
        	}        	
        	outputContrComp.getItemsTCRMContractPartyRoleBObj().removeAllElements();
        	mainOutput.setTCRMContractBObj(outputContract);
        }
	}
	private void handleReporting(MetcashAccountBObj mainInput,
			MetcashAccountBObj mainOutput, DWLControl control) throws BusinessProxyException {
    	// STEP #6
        // START :: Handle ADD REPORTING transaction

        // MDM_TODO: CDKWB0016I Populate the mandatory fields of
        // "addMTTActReportingInput".
        MTTActReportingBObj addMTTActReportingInput = new MTTActReportingBObj();
        addMTTActReportingInput.setControl(control);
        
        addMTTActReportingInput = (MTTActReportingBObj) mainInput.getMTTActReportingBObj();
        if (addMTTActReportingInput != null) {
        
        try {
			addMTTActReportingInput.setContractId(mainOutput.getTCRMContractBObj().getContractIdPK());
			addMTTActReportingInput.setMTTActReportingLastUpdateTxId(mainOutput.getTCRMContractBObj().getContractLastUpdateTxId());
			addMTTActReportingInput.setMTTActReportingLastUpdateUser(mainOutput.getTCRMContractBObj().getContractLastUpdateUser());
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                    "INSERR",
                    MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                    control, new String[0]);
				throw new BusinessProxyException(error.getErrorMessage(), e1);
		}

        // Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent addMTTActReportingRequest = new DWLTransactionPersistent();
        addMTTActReportingRequest.setTxnControl(control);
        addMTTActReportingRequest.setTxnType("addMTTActReporting");
        addMTTActReportingRequest.setTxnTopLevelObject(addMTTActReportingInput);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse addMTTActReportingResponse = null;
        
        // Invoke the "addMTTActReporting" transaction.
        try {
            addMTTActReportingResponse = (DWLResponse) super.execute(addMTTActReportingRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }
        
        if (addMTTActReportingResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (addMTTActReportingResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	DWLStatus dwlStatus = addMTTActReportingResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }
        
        // Extract the returned business object from the response.
        MTTActReportingBObj addMTTActReportingOutput = (MTTActReportingBObj) addMTTActReportingResponse.getData();
        
        mainOutput.setMTTActReportingBObj(addMTTActReportingOutput);
        }
        
        // END :: Handle ADD REPORTING transaction
		
	}
	private void handleCostCharge(MetcashAccountBObj mainInput,
			MetcashAccountBObj mainOutput, DWLControl control) throws BusinessProxyException {
    	// STEP #5
        // START :: Handle ADD COST CHARGE transaction

        // MDM_TODO: CDKWB0016I Populate the mandatory fields of
        // "addMTTActCostChargesInput".
        MTTActCostChargesBObj addMTTActCostChargesInput = new MTTActCostChargesBObj();
        addMTTActCostChargesInput.setControl(control);
        
        addMTTActCostChargesInput = (MTTActCostChargesBObj) mainInput.getMTTActCostChargesBObj();
        
        if (addMTTActCostChargesInput != null) {
        try {
			addMTTActCostChargesInput.setContractId(mainOutput.getTCRMContractBObj().getContractIdPK());
			addMTTActCostChargesInput.setMTTActCostChargesLastUpdateTxId(mainOutput.getTCRMContractBObj().getContractLastUpdateTxId());
			addMTTActCostChargesInput.setMTTActCostChargesLastUpdateUser(mainOutput.getTCRMContractBObj().getContractLastUpdateUser());
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                    "INSERR",
                    MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                    control, new String[0]);
				throw new BusinessProxyException(error.getErrorMessage(), e1);
		}

        // Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent addMTTActCostChargesRequest = new DWLTransactionPersistent();
        addMTTActCostChargesRequest.setTxnControl(control);
        addMTTActCostChargesRequest.setTxnType("addMTTActCostCharges");
        addMTTActCostChargesRequest.setTxnTopLevelObject(addMTTActCostChargesInput);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse addMTTActCostChargesResponse = null;
        
        // Invoke the "addMTTActCostCharges" transaction.
        try {
            addMTTActCostChargesResponse = (DWLResponse) super.execute(addMTTActCostChargesRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }
        
        if (addMTTActCostChargesResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (addMTTActCostChargesResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	DWLStatus dwlStatus = addMTTActCostChargesResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }
        
        // Extract the returned business object from the response.
        MTTActCostChargesBObj addMTTActCostChargesOutput = (MTTActCostChargesBObj) addMTTActCostChargesResponse.getData();
        
        mainOutput.setMTTActCostChargesBObj(addMTTActCostChargesOutput);
        }
        
        // END :: Handle ADD COST CHARGE transaction
		
	}
	private void handleFinancial(MetcashAccountBObj mainInput,
			MetcashAccountBObj mainOutput, DWLControl control) throws BusinessProxyException {
    	// STEP #4
        // START :: Handle ADD FINANCIAL transaction

        // MDM_TODO: CDKWB0016I Populate the mandatory fields of
        // "addMTTActFinancialInput".
        MTTActFinancialBObj addMTTActFinancialInput = new MTTActFinancialBObj();
        addMTTActFinancialInput.setControl(control);
        
        addMTTActFinancialInput = (MTTActFinancialBObj) mainInput.getMTTActFinancialBObj();
        
        if (addMTTActFinancialInput != null) {
        try {
			addMTTActFinancialInput.setContractId(mainOutput.getTCRMContractBObj().getContractIdPK());
			addMTTActFinancialInput.setMTTActFinancialLastUpdateTxId(mainOutput.getTCRMContractBObj().getContractLastUpdateTxId());
			addMTTActFinancialInput.setMTTActFinancialLastUpdateUser(mainOutput.getTCRMContractBObj().getContractLastUpdateUser());
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                    "INSERR",
                    MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                    control, new String[0]);
				throw new BusinessProxyException(error.getErrorMessage(), e1);
		}

        // Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent addMTTActFinancialRequest = new DWLTransactionPersistent();
        addMTTActFinancialRequest.setTxnControl(control);
        addMTTActFinancialRequest.setTxnType("addMTTActFinancial");
        addMTTActFinancialRequest.setTxnTopLevelObject(addMTTActFinancialInput);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse addMTTActFinancialResponse = null;
        
        // Invoke the "addMTTActFinancial" transaction.
        try {
            addMTTActFinancialResponse = (DWLResponse) super.execute(addMTTActFinancialRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }
        
        if (addMTTActFinancialResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (addMTTActFinancialResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	DWLStatus dwlStatus = addMTTActFinancialResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }
        
        // Extract the returned business object from the response.
        MTTActFinancialBObj addMTTActFinancialOutput = (MTTActFinancialBObj) addMTTActFinancialResponse.getData();
        
        mainOutput.setMTTActFinancialBObj(addMTTActFinancialOutput);
        }
        
        // END :: Handle ADD FINANCIAL transaction
		
	}
	private void handleOrderInvoice(MetcashAccountBObj mainInput,
			MetcashAccountBObj mainOutput, DWLControl control) throws BusinessProxyException {
		
    	// STEP #3
        // START :: Handle ADD ORDER INVOICE transaction 

        // MDM_TODO: CDKWB0016I Populate the mandatory fields of
        // "addMTTActOrderInvoiceInput".
        MTTActOrderInvoiceBObj addMTTActOrderInvoiceInput = new MTTActOrderInvoiceBObj();
        addMTTActOrderInvoiceInput.setControl(control);
        
        addMTTActOrderInvoiceInput = (MTTActOrderInvoiceBObj) mainInput.getMTTActOrderInvoiceBObj();
        
        if (addMTTActOrderInvoiceInput != null) {
        try {
			addMTTActOrderInvoiceInput.setContractId(mainOutput.getTCRMContractBObj().getContractIdPK());
			addMTTActOrderInvoiceInput.setMTTActOrderInvoiceLastUpdateTxId(mainOutput.getTCRMContractBObj().getContractLastUpdateTxId());
			addMTTActOrderInvoiceInput.setMTTActOrderInvoiceLastUpdateUser(mainOutput.getTCRMContractBObj().getContractLastUpdateUser());
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                    "INSERR",
                    MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                    control, new String[0]);
				throw new BusinessProxyException(error.getErrorMessage(), e1);
		}

        // Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent addMTTActOrderInvoiceRequest = new DWLTransactionPersistent();
        addMTTActOrderInvoiceRequest.setTxnControl(control);
        addMTTActOrderInvoiceRequest.setTxnType("addMTTActOrderInvoice");
        addMTTActOrderInvoiceRequest.setTxnTopLevelObject(addMTTActOrderInvoiceInput);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse addMTTActOrderInvoiceResponse = null;
        
        // Invoke the "addMTTActOrderInvoice" transaction.
        try {
            addMTTActOrderInvoiceResponse = (DWLResponse) super.execute(addMTTActOrderInvoiceRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }
        
        if (addMTTActOrderInvoiceResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (addMTTActOrderInvoiceResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	DWLStatus dwlStatus = addMTTActOrderInvoiceResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }
        
        // Extract the returned business object from the response.
        MTTActOrderInvoiceBObj addMTTActOrderInvoiceOutput = (MTTActOrderInvoiceBObj) addMTTActOrderInvoiceResponse.getData();
        
        mainOutput.setMTTActOrderInvoiceBObj(addMTTActOrderInvoiceOutput);
        }
        
        // END :: Handle ADD ORDER INVOICE transaction 
		
	}
	private void handleCreditTaxAdd(MetcashAccountBObj mainInput,
			MetcashAccountBObj mainOutput, DWLControl control) throws BusinessProxyException {
    	// STEP #2
        // START :: Handle ADD CREDIT TAX transaction

        // MDM_TODO: CDKWB0016I Populate the mandatory fields of
        // "addMTTActCreditTaxInput".
        MTTActCreditTaxBObj addMTTActCreditTaxInput = new MTTActCreditTaxBObj();
        addMTTActCreditTaxInput.setControl(control);
        
        addMTTActCreditTaxInput = (MTTActCreditTaxBObj) mainInput.getMTTActCreditTaxBObj();
        
        if (addMTTActCreditTaxInput != null) {
        try {
			addMTTActCreditTaxInput.setContractId(mainOutput.getTCRMContractBObj().getContractIdPK());
			addMTTActCreditTaxInput.setMTTActCreditTaxLastUpdateTxId(mainOutput.getTCRMContractBObj().getContractLastUpdateTxId());
			addMTTActCreditTaxInput.setMTTActCreditTaxLastUpdateUser(mainOutput.getTCRMContractBObj().getContractLastUpdateUser());
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                    "INSERR",
                    MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                    control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage(), e2);
		}

        // Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent addMTTActCreditTaxRequest = new DWLTransactionPersistent();
        addMTTActCreditTaxRequest.setTxnControl(control);
        addMTTActCreditTaxRequest.setTxnType("addMTTActCreditTax");
        addMTTActCreditTaxRequest.setTxnTopLevelObject(addMTTActCreditTaxInput);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse addMTTActCreditTaxResponse = null;
        
        // Invoke the "addMTTActCreditTax" transaction.
        try {
            addMTTActCreditTaxResponse = (DWLResponse) super.execute(addMTTActCreditTaxRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }
        
        if (addMTTActCreditTaxResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (addMTTActCreditTaxResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	
        	DWLStatus dwlStatus = addMTTActCreditTaxResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }
        
        // Extract the returned business object from the response.
        MTTActCreditTaxBObj addMTTActCreditTaxOutput = (MTTActCreditTaxBObj) addMTTActCreditTaxResponse.getData();        
        mainOutput.setMTTActCreditTaxBObj(addMTTActCreditTaxOutput);
        }
        
        // END :: Handle ADD CREDIT TAX transaction
		
	}
	private void resolveIdentity(MetcashAccountBObj mainInput,
			TCRMContractBObj foundContract, DWLControl control) throws BusinessProxyException {
		
		if (mainInput.getTCRMContractBObj().getItemsTCRMContractComponentBObj().size() > 0 && mainInput.getTCRMContractBObj().getItemsTCRMContractComponentBObj() != null) {	
		TCRMContractComponentBObj inputContrComp = (TCRMContractComponentBObj) mainInput.getTCRMContractBObj().getItemsTCRMContractComponentBObj().firstElement();    		    		
    		if (foundContract.getItemsTCRMContractComponentBObj().size() > 0 && foundContract.getItemsTCRMContractComponentBObj() != null) {
    			TCRMContractComponentBObj foundContrComp = (TCRMContractComponentBObj) foundContract.getItemsTCRMContractComponentBObj().firstElement();
    			inputContrComp.setContractComponentIdPK(foundContrComp.getContractComponentIdPK());
					try {
						inputContrComp.setContractComponentLastUpdateDate(foundContrComp.getContractComponentLastUpdateDate());
					} catch (Exception e) {
						DWLError error = errHandler.getErrorMessage(
		    					MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
		    					"READERR", MTTServicesErrorReasonCode.GETCONTRACTBYADMINSYSKEY_FAILED,
		    					control, new String[0]);
		    			throw new BusinessProxyException(error.getErrorMessage(), e);
					}
    		}
		    		// Clear TCRMContractPartyRole from TCRMContractBObj		        	
		        	inputContrComp.getItemsTCRMContractPartyRoleBObj().removeAllElements();					
    			}
		handleMetcashRoleForUpdate(mainInput, foundContract, control);
		
    	}
	public TCRMContractBObj getExistingContract(MetcashAccountBObj mainInput, 
				DWLControl control) throws BusinessProxyException {
			
			TCRMContractBObj updateContractInput = mainInput.getTCRMContractBObj();
			updateContractInput.setControl(control);
		
			Vector<Object> getContractInput = new Vector<Object>();
			getContractInput.add(0, updateContractInput.getContractIdPK());  
			getContractInput.add(1, MTTServicesComponentID.CONTRACT_INQ_LVL);
			getContractInput.add(2, MTTServicesComponentID.CONTRACT_PARTY_INQ_LVL);

    		// Prepare a new DWLTransactionInquiry instance.
    		DWLTransactionInquiry getContractRequest = new DWLTransactionInquiry();
    		getContractRequest.setTxnControl(control);
    		getContractRequest.setTxnType("getContract");
    		getContractRequest.setStringParameters(getContractInput);

    		// Prepare a reference to hold the response for this transaction.
    		DWLResponse getContractResponse = null;

    		// Invoke the transaction.
    		try {
    			getContractResponse = (DWLResponse) super
    					.execute(getContractRequest);
    		} catch (BusinessProxyException e) {
    			DWLError error = errHandler.getErrorMessage(
    					MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
    					"READERR", MTTServicesErrorReasonCode.GETCONTRACTBYADMINSYSKEY_FAILED,
    					control, new String[0]);
    			throw new BusinessProxyException(error.getErrorMessage(), e);
    		} if (getContractResponse.getStatus().getStatus() == DWLStatus.FATAL) {
            	DWLStatus dwlStatus = getContractResponse.getStatus();
            	Vector vecError = dwlStatus.getDwlErrorGroup();
            	DWLError dwlError = (DWLError) vecError.get(0);
            	
            	throw new BusinessProxyException(dwlError.getErrorMessage());
    		}
    		TCRMContractBObj foundContract = (TCRMContractBObj) getContractResponse.getData();
    		return foundContract;
    		}
	
			private void triggerEventForContract(String contractIdPK, DWLControl control) throws BusinessProxyException {
	
			ProcessControlBObj inpProcessControl = new ProcessControlBObj();
			ProcessActionBObj inpProcessAction = new ProcessActionBObj();
	
			inpProcessAction.setControl(control);
			inpProcessAction.setEventStatus(MTTEMConstant.EM_STATUS);
			inpProcessAction.setEntityEventCatId(MTTEMConstant.EM_EVENTCAT);
			inpProcessAction.setEntityName(MTTEMConstant.EM_ENTITY_CONTRACT);
			inpProcessAction.setInstancePK(contractIdPK);
	
			inpProcessControl.setControl(control);
			inpProcessControl.setEntityName(MTTEMConstant.EM_ENTITY_CONTRACT);
			inpProcessControl.setInstancePK(contractIdPK);
			inpProcessControl.setProdEntityId(MTTEMConstant.EM_PRODENTITY_ID);
			inpProcessControl.setProcessActionBObj(inpProcessAction);
			
			DWLTransactionPersistent addEMRequest = new DWLTransactionPersistent();
			addEMRequest.setTxnControl(control);
			addEMRequest.setTxnType("addProcessControl");
			addEMRequest.setTxnTopLevelObject(inpProcessControl);
	        
	        // Prepare a reference to hold the response for this transaction.
	        DWLResponse addEMResponse = null;
	        
	        // Invoke the "addMTTActCreditTax" transaction.
	        try {
	        	addEMResponse = (DWLResponse) super.execute(addEMRequest);
	        }
	        catch (BusinessProxyException e) {
	            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
	                                                        "INSERR",
	                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
	                                                        control, new String[0]);
	            throw new BusinessProxyException(error.getErrorMessage(), e);
	        }
	        
	        if (addEMResponse == null)  {
	            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
	                                                        "INSERR",
	                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
	                                                        control, new String[0]);
	            throw new BusinessProxyException(error.getErrorMessage());
	        }
	        else if (addEMResponse.getStatus().getStatus() == DWLStatus.FATAL) {
	        	
	        	DWLStatus dwlStatus = addEMResponse.getStatus();
	        	Vector vecError = dwlStatus.getDwlErrorGroup();
	        	DWLError dwlError = (DWLError) vecError.get(0);
	        	
	        	throw new BusinessProxyException(dwlError.getErrorMessage());
	        }
	
		}
	
	
	}