/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[8dc67bd04bed4f5a426e0fa6d2666c8c]
 */

package com.metcash.services.custom.compositeTxn;

import com.dwl.base.DWLCommon;
import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLStatus;
import com.dwl.base.requestHandler.DWLTransactionPersistent;
import com.dwl.base.requestHandler.DWLTxnBP;
import com.dwl.tcrm.common.TCRMResponse;
import com.dwl.tcrm.coreParty.component.TCRMPartyIdentificationBObj;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.dwl.unifi.tx.exception.BusinessProxyException;
import com.dwl.base.DWLControl;
import com.dwl.base.DWLResponse;
import com.dwl.base.requestHandler.DWLTransactionInquiry;
import com.dwl.base.util.DWLDateTimeUtilities;
import com.dwl.tcrm.financial.component.TCRMContractBObj;
import com.dwl.tcrm.financial.component.TCRMContractComponentBObj;
import com.dwl.tcrm.financial.component.TCRMContractPartyRoleBObj;
import com.dwl.tcrm.financial.component.TCRMContractRoleLocationBObj;
import com.metcash.db.custom.component.MTTActCostChargesBObj;
import com.metcash.db.custom.component.MTTActCreditTaxBObj;
import com.metcash.db.custom.component.MTTActFinancialBObj;
import com.metcash.db.custom.component.MTTActOrderInvoiceBObj;
import com.metcash.db.custom.component.MTTActReportingBObj;
import com.metcash.db.custom.component.MTTIdentifierBObj;
import com.metcash.services.custom.component.MetcashAccountBObj;
import com.metcash.services.custom.component.MetcashAccountRoleBObj;
import com.metcash.services.custom.constant.MTTServicesComponentID;
import com.metcash.services.custom.constant.MTTServicesErrorReasonCode;

import java.util.Vector;

/**
 * <!-- begin-user-doc --> <!-- end-user-doc -->
 *
 * 
 * @generated
 */
public class GetMTTAccountCompositeTxnBP extends DWLTxnBP {

	/**
	 * @generated
	 **/
	private IDWLErrorMessage errHandler;

	/**
    * <!-- begin-user-doc --> <!-- end-user-doc -->
    * @generated 
    */
	private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(GetMTTAccountCompositeTxnBP.class);

	/**
	 * @generated
	 **/
	public GetMTTAccountCompositeTxnBP() {
        super();
        errHandler = TCRMClassFactory.getErrorHandler();
    }

	/**
	 * @generated NOT
	 **/
	public Object execute(Object inputObj) throws BusinessProxyException {
		logger.finest("ENTER Object execute(Object inputObj)");

		TCRMResponse outputTxnObj = null;
		DWLTransactionInquiry inputTxnObj = (DWLTransactionInquiry) inputObj;
		DWLControl control = inputTxnObj.getTxnControl();

		// Extract the request parameters. These will appear in the order
		// supplied.
		Vector parameters = inputTxnObj.getStringParameters();

		// Ensure that the correct number of parameters are present.
		if (parameters == null || parameters.size() != 3) {
			DWLError error = errHandler.getErrorMessage(
					MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
					"READERR", MTTServicesErrorReasonCode.GETMTTACCOUNT_FAILED,
					control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage());
		}

		// Handle transaction "getContract"

		// MDM_TODO: CDKWB0017I Populate this vector with the parameters to
		// "getContract".
		Vector<Object> getContractInput = new Vector<Object>();

		getContractInput.add(0, parameters.get(0));
		getContractInput.add(1, parameters.get(1));
		getContractInput.add(2, parameters.get(2));

		// Prepare a new DWLTransactionInquiry instance.
		DWLTransactionInquiry getContractRequest = new DWLTransactionInquiry();
		getContractRequest.setTxnControl(control);
		getContractRequest.setTxnType("getContract");
		getContractRequest.setStringParameters(getContractInput);

		// Prepare a reference to hold the response for this transaction.
		DWLResponse getContractResponse = null;

		// Invoke the "getContract" transaction.
		try {
			getContractResponse = (DWLResponse) super
					.execute(getContractRequest);
		} catch (BusinessProxyException e) {
			DWLError error = errHandler.getErrorMessage(
					MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
					"READERR", MTTServicesErrorReasonCode.GETMTTACCOUNT_FAILED,
					control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage(), e);
		}

		if (getContractResponse == null) {
			DWLError error = errHandler.getErrorMessage(
					MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
					"READERR", MTTServicesErrorReasonCode.GETMTTACCOUNT_FAILED,
					control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage());
		} else if (getContractResponse.getStatus().getStatus() == DWLStatus.FATAL) {
			DWLStatus status = getContractResponse.getStatus();
			TCRMResponse errResponse = new TCRMResponse();
			errResponse.setStatus(status);
			return errResponse;
		}
		// Extract the returned business object from the response.
		TCRMContractBObj getContractOutput = (TCRMContractBObj) getContractResponse
				.getData();

		// MDM_TODO: CDKWB0013I build the response Bobj.
		MetcashAccountBObj mainOutput = new MetcashAccountBObj();
		mainOutput.setControl(control);

		Vector<Object> vecContractComp = new Vector<Object>();
		Vector<Object> vecContractRole = new Vector<Object>();
		TCRMContractComponentBObj outputContrComp = new TCRMContractComponentBObj();

		if (getContractOutput != null) {
			vecContractComp = getContractOutput
					.getItemsTCRMContractComponentBObj();

			if (vecContractComp.size() > 0 && vecContractComp != null) {
				outputContrComp = (TCRMContractComponentBObj) vecContractComp.firstElement();
				vecContractRole = outputContrComp.getItemsTCRMContractPartyRoleBObj();
			}
		}

		if (vecContractRole.size() > 0 && vecContractRole != null) {
			for (int i = 0; i < vecContractRole.size(); i++) {
				MetcashAccountRoleBObj outputMetcashActRole = new MetcashAccountRoleBObj();
				TCRMContractPartyRoleBObj outputContrRole = new TCRMContractPartyRoleBObj();
				outputContrRole = (TCRMContractPartyRoleBObj) vecContractRole.elementAt(i);
				handleRoleLocation (outputContrRole);
				
				Vector vecPartyIdent = new Vector();
				TCRMPartyIdentificationBObj partyIden = new TCRMPartyIdentificationBObj();

				vecPartyIdent = outputContrRole.getTCRMPartyBObj().getItemsTCRMPartyIdentificationBObj();

				if (vecPartyIdent.size() > 0 && vecPartyIdent != null) {
					for (int j = 0; j < vecPartyIdent.size(); j++) {
						partyIden = (TCRMPartyIdentificationBObj) vecPartyIdent
								.get(j);
						String identifierID = partyIden.getIdentificationIdPK();

						Vector<Object> getMTTIdentifier = new Vector<Object>();

						getMTTIdentifier.add(0, identifierID);
						getMTTIdentifier.add(1, MTTServicesComponentID.FILTER_FOR_GET);

						// Prepare a new DWLTransactionInquiry instance.
						DWLTransactionInquiry getMTTIdentifierRequest = new DWLTransactionInquiry();
						getMTTIdentifierRequest.setTxnControl(control);
						getMTTIdentifierRequest
								.setTxnType("getAllMTTIdentifierByID");
						getMTTIdentifierRequest
								.setStringParameters(getMTTIdentifier);

						// Prepare a reference to hold the response for this
						// transaction.
						DWLResponse getMTTIdentifierResponse = null;

						// Handle transaction "getMTTIdentifier"
						try {
							getMTTIdentifierResponse = (DWLResponse) super
									.execute(getMTTIdentifierRequest);
						} catch (BusinessProxyException e) {
							DWLError error = errHandler
									.getErrorMessage(
											MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
											"READERR",
											MTTServicesErrorReasonCode.GETMTTACCOUNT_FAILED,
											control, new String[0]);
							throw new BusinessProxyException(
									error.getErrorMessage(), e);
						}

						if (getMTTIdentifierResponse.getStatus().getStatus() == DWLStatus.FATAL) {
							DWLStatus status = getContractResponse.getStatus();
							TCRMResponse errResponse = new TCRMResponse();
							errResponse.setStatus(status);
							return errResponse;
						}
						// Extract the returned business object from the
						// response.

						if (getMTTIdentifierResponse.getData() != null) {
							Vector vecMTTIdentOutput = new Vector();
							vecMTTIdentOutput = (Vector) getMTTIdentifierResponse
									.getData();

							if (vecMTTIdentOutput.size() > 0
									&& vecMTTIdentOutput != null) {
								for (int k = 0; k < vecMTTIdentOutput.size(); k++) {
									/*outputMetcashActRole
											.setMTTIdentifierBObj((MTTIdentifierBObj) vecMTTIdentOutput
													.elementAt(k));*/
								}
							}

						}
					}
				}

				outputMetcashActRole
						.setTCRMContractPartyRoleBObj(outputContrRole);
				mainOutput.setMetcashAccountRoleBObj(outputMetcashActRole);
			}
		}

		outputContrComp.getItemsTCRMContractPartyRoleBObj().clear();
		mainOutput.setTCRMContractBObj(getContractOutput);

		// Handle transaction "getCreditTax"

		// MDM_TODO: CDKWB0017I Populate this vector with the parameters to
		// "getContract".
		Vector<Object> getCreditTaxInput = new Vector<Object>();

		getCreditTaxInput.add(0, getContractOutput.getContractIdPK());

		// Prepare a new DWLTransactionInquiry instance.
		DWLTransactionInquiry getCreditTaxRequest = new DWLTransactionInquiry();
		getCreditTaxRequest.setTxnControl(control);
		getCreditTaxRequest.setTxnType("getAllMTTCreditTaxByID");
		getCreditTaxRequest.setStringParameters(getCreditTaxInput);

		// Prepare a reference to hold the response for this transaction.
		DWLResponse getCreditTaxResponse = null;

		// Invoke the "getContract" transaction.
		try {
			getCreditTaxResponse = (DWLResponse) super
					.execute(getCreditTaxRequest);
		} catch (BusinessProxyException e) {
			DWLError error = errHandler.getErrorMessage(
					MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
					"READERR", MTTServicesErrorReasonCode.GETMTTACCOUNT_FAILED,
					control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage(), e);
		}

		if (getCreditTaxResponse.getStatus().getStatus() == DWLStatus.FATAL) {
			DWLStatus status = getContractResponse.getStatus();
			TCRMResponse errResponse = new TCRMResponse();
			errResponse.setStatus(status);
			return errResponse;
		}
		// Extract the returned business object from the response.
		MTTActCreditTaxBObj getCreditTaxOutput = (MTTActCreditTaxBObj) getCreditTaxResponse
				.getData();

		mainOutput.setMTTActCreditTaxBObj(getCreditTaxOutput);

		// Handle transaction "getOrderInvoice"

		// MDM_TODO: CDKWB0017I Populate this vector with the parameters to
		// "getContract".
		Vector<Object> getOrderInvoiceInput = new Vector<Object>();

		getOrderInvoiceInput.add(0, getContractOutput.getContractIdPK());

		// Prepare a new DWLTransactionInquiry instance.
		DWLTransactionInquiry getOrderInvoiceRequest = new DWLTransactionInquiry();
		getOrderInvoiceRequest.setTxnControl(control);
		getOrderInvoiceRequest.setTxnType("getAllMTTOrderInvoiceByID");
		getOrderInvoiceRequest.setStringParameters(getOrderInvoiceInput);

		// Prepare a reference to hold the response for this transaction.
		DWLResponse getOrderInvoiceResponse = null;

		// Invoke the "getContract" transaction.
		try {
			getOrderInvoiceResponse = (DWLResponse) super
					.execute(getOrderInvoiceRequest);
		} catch (BusinessProxyException e) {
			DWLError error = errHandler.getErrorMessage(
					MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
					"READERR", MTTServicesErrorReasonCode.GETMTTACCOUNT_FAILED,
					control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage(), e);
		}

		if (getOrderInvoiceResponse.getStatus().getStatus() == DWLStatus.FATAL) {
			DWLStatus status = getContractResponse.getStatus();
			TCRMResponse errResponse = new TCRMResponse();
			errResponse.setStatus(status);
			return errResponse;
		}
		// Extract the returned business object from the response.
		MTTActOrderInvoiceBObj getOrderInvoiceOutput = (MTTActOrderInvoiceBObj) getOrderInvoiceResponse
				.getData();

		mainOutput.setMTTActOrderInvoiceBObj(getOrderInvoiceOutput);

		// Handle transaction "getFinance"

		// MDM_TODO: CDKWB0017I Populate this vector with the parameters to
		// "getContract".
		Vector<Object> getFinanceInput = new Vector<Object>();

		getFinanceInput.add(0, getContractOutput.getContractIdPK());

		// Prepare a new DWLTransactionInquiry instance.
		DWLTransactionInquiry getFinanceRequest = new DWLTransactionInquiry();
		getFinanceRequest.setTxnControl(control);
		getFinanceRequest.setTxnType("getAllMTTActFinancialbyID");
		getFinanceRequest.setStringParameters(getFinanceInput);

		// Prepare a reference to hold the response for this transaction.
		DWLResponse getFinanceResponse = null;

		// Invoke the "getContract" transaction.
		try {
			getFinanceResponse = (DWLResponse) super.execute(getFinanceRequest);
		} catch (BusinessProxyException e) {
			DWLError error = errHandler.getErrorMessage(
					MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
					"READERR", MTTServicesErrorReasonCode.GETMTTACCOUNT_FAILED,
					control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage(), e);
		}

		if (getFinanceResponse.getStatus().getStatus() == DWLStatus.FATAL) {
			DWLStatus status = getContractResponse.getStatus();
			TCRMResponse errResponse = new TCRMResponse();
			errResponse.setStatus(status);
			return errResponse;
		}
		// Extract the returned business object from the response.
		MTTActFinancialBObj getFinanceOutput = (MTTActFinancialBObj) getFinanceResponse
				.getData();

		mainOutput.setMTTActFinancialBObj(getFinanceOutput);

		// Handle transaction "getCostCharge"

		// MDM_TODO: CDKWB0017I Populate this vector with the parameters to
		// "getContract".
		Vector<Object> getCostChargeInput = new Vector<Object>();

		getCostChargeInput.add(0, getContractOutput.getContractIdPK());

		// Prepare a new DWLTransactionInquiry instance.
		DWLTransactionInquiry getCostChargeRequest = new DWLTransactionInquiry();
		getCostChargeRequest.setTxnControl(control);
		getCostChargeRequest.setTxnType("getAllMTTActCostChargesByID");
		getCostChargeRequest.setStringParameters(getCostChargeInput);

		// Prepare a reference to hold the response for this transaction.
		DWLResponse getCostChargeResponse = null;

		// Invoke the "getContract" transaction.
		try {
			getCostChargeResponse = (DWLResponse) super
					.execute(getCostChargeRequest);
		} catch (BusinessProxyException e) {
			DWLError error = errHandler.getErrorMessage(
					MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
					"READERR", MTTServicesErrorReasonCode.GETMTTACCOUNT_FAILED,
					control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage(), e);
		}

		if (getCostChargeResponse.getStatus().getStatus() == DWLStatus.FATAL) {
			DWLStatus status = getContractResponse.getStatus();
			TCRMResponse errResponse = new TCRMResponse();
			errResponse.setStatus(status);
			return errResponse;
		}
		// Extract the returned business object from the response.
		MTTActCostChargesBObj getCostChargeOutput = (MTTActCostChargesBObj) getCostChargeResponse
				.getData();

		mainOutput.setMTTActCostChargesBObj(getCostChargeOutput);

		// Handle transaction "getCostCharge"

		// MDM_TODO: CDKWB0017I Populate this vector with the parameters to
		// "getContract".
		Vector<Object> getReportInput = new Vector<Object>();

		getReportInput.add(0, getContractOutput.getContractIdPK());

		// Prepare a new DWLTransactionInquiry instance.
		DWLTransactionInquiry getReportRequest = new DWLTransactionInquiry();
		getReportRequest.setTxnControl(control);
		getReportRequest.setTxnType("getAllMTTReportByID");
		getReportRequest.setStringParameters(getReportInput);

		// Prepare a reference to hold the response for this transaction.
		DWLResponse getReportResponse = null;

		// Invoke the "getContract" transaction.
		try {
			getReportResponse = (DWLResponse) super.execute(getReportRequest);
		} catch (BusinessProxyException e) {
			DWLError error = errHandler.getErrorMessage(
					MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
					"READERR", MTTServicesErrorReasonCode.GETMTTACCOUNT_FAILED,
					control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage(), e);
		}

		if (getReportResponse.getStatus().getStatus() == DWLStatus.FATAL) {
			DWLStatus status = getContractResponse.getStatus();
			TCRMResponse errResponse = new TCRMResponse();
			errResponse.setStatus(status);
			return errResponse;
		}
		// Extract the returned business object from the response.
		MTTActReportingBObj getReportOutput = (MTTActReportingBObj) getReportResponse
				.getData();

		mainOutput.setMTTActReportingBObj(getReportOutput);

		// Construct the response object.
		DWLStatus outputStatus = new DWLStatus();
		outputStatus.setStatus(DWLStatus.SUCCESS);
		outputTxnObj = new TCRMResponse();
		outputTxnObj.setStatus(outputStatus);
		outputTxnObj.setData(mainOutput);
		logger.finest("RETURN Object execute(Object inputObj)");
		return outputTxnObj;
	}

	private void handleRoleLocation(TCRMContractPartyRoleBObj outputContrRole) {
		
		TCRMContractRoleLocationBObj existingRoleLoc = new TCRMContractRoleLocationBObj();
		Vector vecContractRoleLoc = outputContrRole.getItemsTCRMContractRoleLocationBObj();
		
		if (vecContractRoleLoc.size() > 0 && vecContractRoleLoc != null) {
			for (int t=0; t < vecContractRoleLoc.size(); t++) {
				existingRoleLoc = (TCRMContractRoleLocationBObj) vecContractRoleLoc.elementAt(t);
				if (existingRoleLoc.getTCRMPartyAddressBObj() != null) {
					existingRoleLoc.setObjectReferenceId("A");
				} if (existingRoleLoc.getTCRMPartyContactMethodBObj() != null) {
					existingRoleLoc.setObjectReferenceId("C");
				}
			}
		}
	}
}
