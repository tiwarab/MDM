/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[0cbc8445b64ad1f1cc2ea713715b598c]
 */

package com.metcash.services.custom.constant;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * Defines the component IDs used in this module.
 *
 * @generated
 */
public class MTTServicesComponentID {

  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for MetcashAccountBObj.
     *
     * @generated
     */
    public final static String METCASH_ACCOUNT_BOBJ = "1010010";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for MaintainMTTAccountBusinessProxy.
     *
     * @generated
     */
    public final static String MAINTAIN_MTTACCOUNT_BUSINESS_PROXY = "1010042";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for GetMTTAccountBusinessProxy.
     *
     * @generated
     */
    public final static String GET_MTTACCOUNT_BUSINESS_PROXY = "1010083";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for MetcashIdentifierBObj.
     *
     * @generated
     */
    public final static String METCASH_IDENTIFIER_BOBJ = "1010090";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for MetcashLegalEntityBObj.
     *
     * @generated
     */
    public final static String METCASH_LEGAL_ENTITY_BOBJ = "1010118";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for MetcashAccountRoleBObj.
     *
     * @generated
     */
    public final static String METCASH_ACCOUNT_ROLE_BOBJ = "1010142";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for MetcashLocationBObj.
     *
     * @generated
     */
    public final static String METCASH_LOCATION_BOBJ = "1010166";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for MaintainMTTLocationBusinessProxy.
     *
     * @generated
     */
    public final static String MAINTAIN_MTTLOCATION_BUSINESS_PROXY = "1010204";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for MaintainMTTLegalEntityBusinessProxy.
     *
     * @generated
     */
    public final static String MAINTAIN_MTTLEGAL_ENTITY_BUSINESS_PROXY = "1010219";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for MetcashBusinessContactBObj.
     *
     * @generated
     */
    public final static String METCASH_BUSINESS_CONTACT_BOBJ = "1010227";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for MaintainMTTBusinessContactBusinessProxy.
     *
     * @generated
     */
    public final static String MAINTAIN_MTTBUSINESS_CONTACT_BUSINESS_PROXY = "1010253";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for MetcashStoreBObj.
     *
     * @generated
     */
    public final static String METCASH_STORE_BOBJ = "1010260";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for MaintianMTTStoreBusinessProxy.
     *
     * @generated
     */
    public final static String MAINTIAN_MTTSTORE_BUSINESS_PROXY = "1010292";    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for MaintianMTTStoreBusinessProxy.
     *
     * @generated NOT
     */
    public final static String LOCATION_ROLE_TYPE = "1000003";    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for MaintianMTTStoreBusinessProxy.
     *
     * @generated NOT
     */
    public final static String LEGAL_ENTITY_ROLE_TYPE = "1000001";    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for MaintianMTTStoreBusinessProxy.
     *
     * @generated NOT
     */
    public final static String LOCATION_INQ_LVL = "0";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for MaintianMTTStoreBusinessProxy.
     *
     * @generated NOT
     */
    public final static String CONTRACT_INQ_LVL = "2";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for MaintianMTTStoreBusinessProxy.
     *
     * @generated NOT
     */
    public final static String CONTRACT_PARTY_INQ_LVL = "0";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Component ID for MaintianMTTStoreBusinessProxy.
     *
     * @generated NOT
     */
    public final static String FILTER_FOR_GET = "ACTIVE";
    
}


