/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[183e437f46a6d553d88fd688d6201bed]
 */
package com.metcash.services.custom.constant;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * Defines the error message codes used in this module.
 *
 * @generated
 */
public class MTTServicesErrorReasonCode {

  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String METCASHACCOUNT_CONTRACT_REFERENCE_INVALID = "1010023";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String METCASHACCOUNT_CREDITTAX_REFERENCE_INVALID = "1010029";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String METCASHACCOUNT_ORDERINVOICE_REFERENCE_INVALID = "1010052";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String METCASHACCOUNT_FINANCIAL_REFERENCE_INVALID = "1010058";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String METCASHACCOUNT_COSTCHARGE_REFERENCE_INVALID = "1010064";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String METCASHACCOUNT_REPORTING_REFERENCE_INVALID = "1010070";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String METCASHACCOUNT_METCASHACCOUNTROLE_REFERENCE_INVALID = "1010191";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The transaction maintainMTTAccount failed.
     *
     * @generated
     */
    public final static String MAINTAINMTTACCOUNT_FAILED = "1010043";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The transaction getMTTAccount failed.
     *
     * @generated
     */
    public final static String GETMTTACCOUNT_FAILED = "1010084";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String METCASHIDENTIFIER_PARTYIDENTIFICATION_REFERENCE_INVALID = "1010103";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String METCASHIDENTIFIER_MTTIDENTIFICATION_REFERENCE_INVALID = "1010109";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String METCASHLEGALENTITY_ORGANIZATION_REFERENCE_INVALID = "1010131";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String METCASHLEGALENTITY_METCASHIDENTIFIER_REFERENCE_INVALID = "1010328";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String METCASHACCOUNTROLE_CONTRACTROLE_REFERENCE_INVALID = "1010155";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String METCASHACCOUNTROLE_MTTSTORE_REFERENCE_INVALID = "1010307";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String METCASHACCOUNTROLE_METCASHIDENTIFIER_REFERENCE_INVALID = "1010322";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String METCASHLOCATION_ORGANIZATION_REFERENCE_INVALID = "1010179";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The transaction maintainMTTLocation failed.
     *
     * @generated
     */
    public final static String MAINTAINMTTLOCATION_FAILED = "1010205";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The transaction maintainMTTLegalEntity failed.
     *
     * @generated
     */
    public final static String MAINTAINMTTLEGALENTITY_FAILED = "1010220";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String METCASHBUSINESSCONTACT_PERSON_REFERENCE_INVALID = "1010240";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The transaction maintainMTTBusinessContact failed.
     *
     * @generated
     */
    public final static String MAINTAINMTTBUSINESSCONTACT_FAILED = "1010254";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String METCASHSTORE_ORGANIZATION_REFERENCE_INVALID = "1010273";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.
     *
     * @generated
     */
    public final static String METCASHSTORE_MTTSTORE_REFERENCE_INVALID = "1010279";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The transaction maintianMTTStore failed.
     *
     * @generated
     */
    public final static String MAINTIANMTTSTORE_FAILED = "1010293";    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The transaction getPartyByAdminSysKey failed.
     *
     * @generated NOT
     */
    public final static String GETPARTYBYADMINSYSKEY_FAILED = "1020001";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The transaction getContractByAdminSysKey failed.
     *
     * @generated NOT
     */
    public final static String GETCONTRACTBYADMINSYSKEY_FAILED = "1020002";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The transaction maintainMTTAccount failed.
     *
     * @generated NOT
     */
    public final static String CONTRACTROLE_FAILED = "1020003";    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The transaction maintainMTTAccount failed.
     *
     * @generated NOT
     */
    public final static String ROLELOCPURPOSE_FAILED = "1020004";    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The transaction addPartyAddress failed.
     *
     * @generated NOT
     */
    public final static String ADDRESS_FAILED = "1020005";    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The transaction addPartyContactMethod failed.
     *
     * @generated NOT
     */
    public final static String CONTACTMETHOD_FAILED = "1020006";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The transaction addPartyContactMethod failed.
     *
     * @generated NOT
     */
    public final static String NO_PARTY_IDENTIFIER_EXISTS = "1892";

}


