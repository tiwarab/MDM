
-- @SqlSnippetPriority 350
-- @SqlModuleOrdering 5

-- The following source code ("Code") may only be used in accordance with the terms
-- and conditions of the license agreement you have with IBM Corporation. The Code 
-- is provided to you on an "AS IS" basis, without warranty of any kind.  
-- SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
-- WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
-- TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
-- PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
-- IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
-- CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
-- LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
-- ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
-- DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
-- INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
-- NOT APPLY TO YOU.



-- Notes
-- MDM_TODO: CDKWB0046I Statements are placed in the generated SQL file when user changes are required.
-- 1. Edit the following SQL files following any associated instructions.
-- 2. Connect to the database.
-- 3. Run each SQL file as shown below and in the same order.
-- 			sqlplus userid/password@host @MTTServices_SETUP_ORACLE.sql
-- 			sqlplus userid/password@host @MTTServices_TRIGGERS_ORACLE.sql
-- 			sqlplus userid/password@host @MTTServices_CONSTRAINTS_ORACLE.sql
--			sqlplus userid/password@host @MTTServices_ERRORS_100_ORACLE.sql
-- 			sqlplus userid/password@host @MTTServices_MetaData_ORACLE.sql
-- 			sqlplus userid/password@host CONFIG_XMLSERVICES_RESPONSE_ORACLE.sql
-- 			sqlplus userid/password@host @MTTServices_CODETABLES_ORACLE.sql

-- For locale: 100 / default
INSERT INTO MDMDB.CDERRMESSAGETP (LANG_TP_CD, ERR_MESSAGE_TP_CD, ERR_MESSAGE, COMMENTS, LAST_UPDATE_DT) 
   VALUES (100, 1010023, 'The following is incorrect: MetcashAccount has a child Contract but the reference in Contract is present and does not match the id from MetcashAccount', 'In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.', CURRENT_TIMESTAMP);
INSERT INTO MDMDB.CDERRMESSAGETP (LANG_TP_CD, ERR_MESSAGE_TP_CD, ERR_MESSAGE, COMMENTS, LAST_UPDATE_DT) 
   VALUES (100, 1010029, 'The following is incorrect: MetcashAccount has a child MTTActCreditTax but the reference in MTTActCreditTax is present and does not match the id from MetcashAccount', 'In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.', CURRENT_TIMESTAMP);
INSERT INTO MDMDB.CDERRMESSAGETP (LANG_TP_CD, ERR_MESSAGE_TP_CD, ERR_MESSAGE, COMMENTS, LAST_UPDATE_DT) 
   VALUES (100, 1010043, 'The following transaction failed: maintainMTTAccount.', 'The transaction maintainMTTAccount failed.', CURRENT_TIMESTAMP);
INSERT INTO MDMDB.CDERRMESSAGETP (LANG_TP_CD, ERR_MESSAGE_TP_CD, ERR_MESSAGE, COMMENTS, LAST_UPDATE_DT) 
   VALUES (100, 1010052, 'The following is incorrect: MetcashAccount has a child MTTActOrderInvoice but the reference in MTTActOrderInvoice is present and does not match the id from MetcashAccount', 'In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.', CURRENT_TIMESTAMP);
INSERT INTO MDMDB.CDERRMESSAGETP (LANG_TP_CD, ERR_MESSAGE_TP_CD, ERR_MESSAGE, COMMENTS, LAST_UPDATE_DT) 
   VALUES (100, 1010058, 'The following is incorrect: MetcashAccount has a child MTTActFinancial but the reference in MTTActFinancial is present and does not match the id from MetcashAccount', 'In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.', CURRENT_TIMESTAMP);
INSERT INTO MDMDB.CDERRMESSAGETP (LANG_TP_CD, ERR_MESSAGE_TP_CD, ERR_MESSAGE, COMMENTS, LAST_UPDATE_DT) 
   VALUES (100, 1010064, 'The following is incorrect: MetcashAccount has a child MTTActCostCharges but the reference in MTTActCostCharges is present and does not match the id from MetcashAccount', 'In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.', CURRENT_TIMESTAMP);
INSERT INTO MDMDB.CDERRMESSAGETP (LANG_TP_CD, ERR_MESSAGE_TP_CD, ERR_MESSAGE, COMMENTS, LAST_UPDATE_DT) 
   VALUES (100, 1010070, 'The following is incorrect: MetcashAccount has a child MTTActReporting but the reference in MTTActReporting is present and does not match the id from MetcashAccount', 'In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.', CURRENT_TIMESTAMP);
INSERT INTO MDMDB.CDERRMESSAGETP (LANG_TP_CD, ERR_MESSAGE_TP_CD, ERR_MESSAGE, COMMENTS, LAST_UPDATE_DT) 
   VALUES (100, 1010084, 'The following transaction failed: getMTTAccount.', 'The transaction getMTTAccount failed.', CURRENT_TIMESTAMP);
INSERT INTO MDMDB.CDERRMESSAGETP (LANG_TP_CD, ERR_MESSAGE_TP_CD, ERR_MESSAGE, COMMENTS, LAST_UPDATE_DT) 
   VALUES (100, 1010103, 'The following is incorrect: MetcashIdentifier has a child PartyIdentification but the reference in PartyIdentification is present and does not match the id from MetcashIdentifier', 'In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.', CURRENT_TIMESTAMP);
INSERT INTO MDMDB.CDERRMESSAGETP (LANG_TP_CD, ERR_MESSAGE_TP_CD, ERR_MESSAGE, COMMENTS, LAST_UPDATE_DT) 
   VALUES (100, 1010109, 'The following is incorrect: MetcashIdentifier has a child MTTIdentifier but the reference in MTTIdentifier is present and does not match the id from MetcashIdentifier', 'In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.', CURRENT_TIMESTAMP);
INSERT INTO MDMDB.CDERRMESSAGETP (LANG_TP_CD, ERR_MESSAGE_TP_CD, ERR_MESSAGE, COMMENTS, LAST_UPDATE_DT) 
   VALUES (100, 1010131, 'The following is incorrect: MetcashLegalEntity has a child Organization but the reference in Organization is present and does not match the id from MetcashLegalEntity', 'In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.', CURRENT_TIMESTAMP);
INSERT INTO MDMDB.CDERRMESSAGETP (LANG_TP_CD, ERR_MESSAGE_TP_CD, ERR_MESSAGE, COMMENTS, LAST_UPDATE_DT) 
   VALUES (100, 1010155, 'The following is incorrect: MetcashAccountRole has a child ContractPartyRole but the reference in ContractPartyRole is present and does not match the id from MetcashAccountRole', 'In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.', CURRENT_TIMESTAMP);
INSERT INTO MDMDB.CDERRMESSAGETP (LANG_TP_CD, ERR_MESSAGE_TP_CD, ERR_MESSAGE, COMMENTS, LAST_UPDATE_DT) 
   VALUES (100, 1010179, 'The following is incorrect: MetcashLocation has a child Organization but the reference in Organization is present and does not match the id from MetcashLocation', 'In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.', CURRENT_TIMESTAMP);
INSERT INTO MDMDB.CDERRMESSAGETP (LANG_TP_CD, ERR_MESSAGE_TP_CD, ERR_MESSAGE, COMMENTS, LAST_UPDATE_DT) 
   VALUES (100, 1010191, 'The following is incorrect: MetcashAccount has a child MetcashAccountRole but the reference in MetcashAccountRole is present and does not match the id from MetcashAccount', 'In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.', CURRENT_TIMESTAMP);
INSERT INTO MDMDB.CDERRMESSAGETP (LANG_TP_CD, ERR_MESSAGE_TP_CD, ERR_MESSAGE, COMMENTS, LAST_UPDATE_DT) 
   VALUES (100, 1010205, 'The following transaction failed: maintainMTTLocation.', 'The transaction maintainMTTLocation failed.', CURRENT_TIMESTAMP);
INSERT INTO MDMDB.CDERRMESSAGETP (LANG_TP_CD, ERR_MESSAGE_TP_CD, ERR_MESSAGE, COMMENTS, LAST_UPDATE_DT) 
   VALUES (100, 1010220, 'The following transaction failed: maintainMTTLegalEntity.', 'The transaction maintainMTTLegalEntity failed.', CURRENT_TIMESTAMP);
INSERT INTO MDMDB.CDERRMESSAGETP (LANG_TP_CD, ERR_MESSAGE_TP_CD, ERR_MESSAGE, COMMENTS, LAST_UPDATE_DT) 
   VALUES (100, 1010240, 'The following is incorrect: MetcashBusinessContact has a child Person but the reference in Person is present and does not match the id from MetcashBusinessContact', 'In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.', CURRENT_TIMESTAMP);
INSERT INTO MDMDB.CDERRMESSAGETP (LANG_TP_CD, ERR_MESSAGE_TP_CD, ERR_MESSAGE, COMMENTS, LAST_UPDATE_DT) 
   VALUES (100, 1010254, 'The following transaction failed: maintainMTTBusinessContact.', 'The transaction maintainMTTBusinessContact failed.', CURRENT_TIMESTAMP);
INSERT INTO MDMDB.CDERRMESSAGETP (LANG_TP_CD, ERR_MESSAGE_TP_CD, ERR_MESSAGE, COMMENTS, LAST_UPDATE_DT) 
   VALUES (100, 1010273, 'The following is incorrect: MetcashStore has a child Organization but the reference in Organization is present and does not match the id from MetcashStore', 'In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.', CURRENT_TIMESTAMP);
INSERT INTO MDMDB.CDERRMESSAGETP (LANG_TP_CD, ERR_MESSAGE_TP_CD, ERR_MESSAGE, COMMENTS, LAST_UPDATE_DT) 
   VALUES (100, 1010279, 'The following is incorrect: MetcashStore has a child MTTStore but the reference in MTTStore is present and does not match the id from MetcashStore', 'In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.', CURRENT_TIMESTAMP);
INSERT INTO MDMDB.CDERRMESSAGETP (LANG_TP_CD, ERR_MESSAGE_TP_CD, ERR_MESSAGE, COMMENTS, LAST_UPDATE_DT) 
   VALUES (100, 1010293, 'The following transaction failed: maintianMTTStore.', 'The transaction maintianMTTStore failed.', CURRENT_TIMESTAMP);
INSERT INTO MDMDB.CDERRMESSAGETP (LANG_TP_CD, ERR_MESSAGE_TP_CD, ERR_MESSAGE, COMMENTS, LAST_UPDATE_DT) 
   VALUES (100, 1010307, 'The following is incorrect: MetcashAccountRole has a child MTTStore but the reference in MTTStore is present and does not match the id from MetcashAccountRole', 'In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.', CURRENT_TIMESTAMP);
INSERT INTO MDMDB.CDERRMESSAGETP (LANG_TP_CD, ERR_MESSAGE_TP_CD, ERR_MESSAGE, COMMENTS, LAST_UPDATE_DT) 
   VALUES (100, 1010322, 'The following is incorrect: MetcashAccountRole has a child MetcashIdentifier but the reference in MetcashIdentifier is present and does not match the id from MetcashAccountRole', 'In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.', CURRENT_TIMESTAMP);
INSERT INTO MDMDB.CDERRMESSAGETP (LANG_TP_CD, ERR_MESSAGE_TP_CD, ERR_MESSAGE, COMMENTS, LAST_UPDATE_DT) 
   VALUES (100, 1010328, 'The following is incorrect: MetcashLegalEntity has a child MetcashIdentifier but the reference in MetcashIdentifier is present and does not match the id from MetcashLegalEntity', 'In a one-to-many containment, the reference in the child object has a value which does not match the parent object during an update transaction.', CURRENT_TIMESTAMP);
