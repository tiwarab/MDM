
-- @SqlSnippetPriority 200
-- @SqlModuleOrdering 4

-- The following source code ("Code") may only be used in accordance with the terms
-- and conditions of the license agreement you have with IBM Corporation. The Code 
-- is provided to you on an "AS IS" basis, without warranty of any kind.  
-- SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
-- WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
-- TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
-- PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
-- IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
-- CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
-- LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
-- ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
-- DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
-- INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
-- NOT APPLY TO YOU.

-- Notes
-- MDM_TODO: CDKWB0046I Statements are placed in the generated SQL file when user changes are required.
-- 1. Edit the following SQL files following any associated instructions.
-- 2. Connect to the database.
-- 3. Run each SQL file as shown below and in the same order.
-- 			db2 -vf MTTDBCustom_SETUP_DB2.sql
-- 			db2 -vf MTTDBCustom_TRIGGERS_DB2.sql
-- 			db2 -vf MTTDBCustom_CONSTRAINTS_DB2.sql
--			db2 -vf MTTDBCustom_ERRORS_100_DB2.sql
-- 			db2 -vf MTTDBCustom_MetaData_DB2.sql
-- 			db2 -vf CONFIG_XMLSERVICES_RESPONSE_DB2.sql
-- 			db2 -vf MTTDBCustom_CODETABLES_DB2.sql

--#SET TERMINATOR @


CREATE TRIGGER MDMDB.i_MTT_ACCO9249a62a AFTER INSERT ON MDMDB.MTT_ACCOUNT_REPORTING
  REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
  BEGIN ATOMIC
    INSERT INTO MDMDB.H_MTT_ACCOUNT_REPORTING
    ( H_MTT_ACT_REPORTING_ID
    , h_action_code
    , h_created_by
    , h_create_dt
    , h_end_dt
    , MTT_ACT_REPORTING_ID
    , CHANNEL_GRP_TP_CD
    , GOV_CONTRACT_IND
    , CAPRICORN_NUM
    , IGAD_PERISHABLE_IND
    , AGENT_NUM_TP_CD
    , USER_LOCALITY_TP_CD
    , CUS_CLASS_TP_CD
    , SHOW_PRICES_ON_WEB_IND
    , CONTRACT_ID
    , EXPORT_CUS_IND
    , last_update_dt
    , last_update_user
    , last_update_tx_id
    ) VALUES
    ( newrow.MTT_ACT_REPORTING_ID
    , 'I'
    , COALESCE(newrow.last_update_user,'')
    , newrow.last_update_dt
    , NULL
    , newrow.MTT_ACT_REPORTING_ID
    , newrow.CHANNEL_GRP_TP_CD
    , newrow.GOV_CONTRACT_IND
    , newrow.CAPRICORN_NUM
    , newrow.IGAD_PERISHABLE_IND
    , newrow.AGENT_NUM_TP_CD
    , newrow.USER_LOCALITY_TP_CD
    , newrow.CUS_CLASS_TP_CD
    , newrow.SHOW_PRICES_ON_WEB_IND
    , newrow.CONTRACT_ID
    , newrow.EXPORT_CUS_IND
    , newrow.last_update_dt
    , newrow.last_update_user
    , newrow.last_update_tx_id
    );
  END@

CREATE TRIGGER MDMDB.u_MTT_ACCO9249a62a AFTER UPDATE ON MDMDB.MTT_ACCOUNT_REPORTING
  REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
  BEGIN ATOMIC
    UPDATE MDMDB.H_MTT_ACCOUNT_REPORTING
        SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND WHERE 
            H_MTT_ACT_REPORTING_ID=newrow.MTT_ACT_REPORTING_ID AND 
            (h_action_code='U' or h_action_code='I') AND 
            h_end_dt IS NULL ;
    INSERT INTO MDMDB.H_MTT_ACCOUNT_REPORTING
    ( H_MTT_ACT_REPORTING_ID
    , h_action_code
    , h_created_by
    , h_create_dt
    , h_end_dt
    , MTT_ACT_REPORTING_ID
    , CHANNEL_GRP_TP_CD
    , GOV_CONTRACT_IND
    , CAPRICORN_NUM
    , IGAD_PERISHABLE_IND
    , AGENT_NUM_TP_CD
    , USER_LOCALITY_TP_CD
    , CUS_CLASS_TP_CD
    , SHOW_PRICES_ON_WEB_IND
    , CONTRACT_ID
    , EXPORT_CUS_IND
    , last_update_dt
    , last_update_user
    , last_update_tx_id
    ) VALUES
    ( newrow.MTT_ACT_REPORTING_ID
    , 'U'
    , COALESCE(newrow.last_update_user,'')
    , newrow.last_update_dt
    , NULL
    , newrow.MTT_ACT_REPORTING_ID
    , newrow.CHANNEL_GRP_TP_CD
    , newrow.GOV_CONTRACT_IND
    , newrow.CAPRICORN_NUM
    , newrow.IGAD_PERISHABLE_IND
    , newrow.AGENT_NUM_TP_CD
    , newrow.USER_LOCALITY_TP_CD
    , newrow.CUS_CLASS_TP_CD
    , newrow.SHOW_PRICES_ON_WEB_IND
    , newrow.CONTRACT_ID
    , newrow.EXPORT_CUS_IND
    , newrow.last_update_dt
    , newrow.last_update_user
    , newrow.last_update_tx_id
    );
  END@

CREATE TRIGGER MDMDB.i_MTT_IDENTIFIER AFTER INSERT ON MDMDB.MTT_IDENTIFIER
  REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
  BEGIN ATOMIC
    INSERT INTO MDMDB.H_MTT_IDENTIFIER
    ( H_MTT_IDENTIFIER_ID
    , h_action_code
    , h_created_by
    , h_create_dt
    , h_end_dt
    , MTT_IDENTIFIER_ID
    , IDENTIFIER_ID
    , IDENTIFIER_SUB_TP_CD
    , START_DT
    , END_DT
    , EXPIRY_DT
    , DESCRIPTION
    , last_update_dt
    , last_update_user
    , last_update_tx_id
    ) VALUES
    ( newrow.MTT_IDENTIFIER_ID
    , 'I'
    , COALESCE(newrow.last_update_user,'')
    , newrow.last_update_dt
    , NULL
    , newrow.MTT_IDENTIFIER_ID
    , newrow.IDENTIFIER_ID
    , newrow.IDENTIFIER_SUB_TP_CD
    , newrow.START_DT
    , newrow.END_DT
    , newrow.EXPIRY_DT
    , newrow.DESCRIPTION
    , newrow.last_update_dt
    , newrow.last_update_user
    , newrow.last_update_tx_id
    );
  END@

CREATE TRIGGER MDMDB.u_MTT_IDENTIFIER AFTER UPDATE ON MDMDB.MTT_IDENTIFIER
  REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
  BEGIN ATOMIC
    UPDATE MDMDB.H_MTT_IDENTIFIER
        SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND WHERE 
            H_MTT_IDENTIFIER_ID=newrow.MTT_IDENTIFIER_ID AND 
            (h_action_code='U' or h_action_code='I') AND 
            h_end_dt IS NULL ;
    INSERT INTO MDMDB.H_MTT_IDENTIFIER
    ( H_MTT_IDENTIFIER_ID
    , h_action_code
    , h_created_by
    , h_create_dt
    , h_end_dt
    , MTT_IDENTIFIER_ID
    , IDENTIFIER_ID
    , IDENTIFIER_SUB_TP_CD
    , START_DT
    , END_DT
    , EXPIRY_DT
    , DESCRIPTION
    , last_update_dt
    , last_update_user
    , last_update_tx_id
    ) VALUES
    ( newrow.MTT_IDENTIFIER_ID
    , 'U'
    , COALESCE(newrow.last_update_user,'')
    , newrow.last_update_dt
    , NULL
    , newrow.MTT_IDENTIFIER_ID
    , newrow.IDENTIFIER_ID
    , newrow.IDENTIFIER_SUB_TP_CD
    , newrow.START_DT
    , newrow.END_DT
    , newrow.EXPIRY_DT
    , newrow.DESCRIPTION
    , newrow.last_update_dt
    , newrow.last_update_user
    , newrow.last_update_tx_id
    );
  END@

CREATE TRIGGER MDMDB.i_MTT_STORE AFTER INSERT ON MDMDB.MTT_STORE
  REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
  BEGIN ATOMIC
    INSERT INTO MDMDB.H_MTT_STORE
    ( H_MTT_STORE_ID
    , h_action_code
    , h_created_by
    , h_create_dt
    , h_end_dt
    , MTT_STORE_ID
    , CONT_ID
    , MSO_TP_CD
    , STORE_OPEN_DT
    , STORE_CLOSE_DT
    , last_update_dt
    , last_update_user
    , last_update_tx_id
    ) VALUES
    ( newrow.MTT_STORE_ID
    , 'I'
    , COALESCE(newrow.last_update_user,'')
    , newrow.last_update_dt
    , NULL
    , newrow.MTT_STORE_ID
    , newrow.CONT_ID
    , newrow.MSO_TP_CD
    , newrow.STORE_OPEN_DT
    , newrow.STORE_CLOSE_DT
    , newrow.last_update_dt
    , newrow.last_update_user
    , newrow.last_update_tx_id
    );
  END@

CREATE TRIGGER MDMDB.u_MTT_STORE AFTER UPDATE ON MDMDB.MTT_STORE
  REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
  BEGIN ATOMIC
    UPDATE MDMDB.H_MTT_STORE
        SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND WHERE 
            H_MTT_STORE_ID=newrow.MTT_STORE_ID AND 
            (h_action_code='U' or h_action_code='I') AND 
            h_end_dt IS NULL ;
    INSERT INTO MDMDB.H_MTT_STORE
    ( H_MTT_STORE_ID
    , h_action_code
    , h_created_by
    , h_create_dt
    , h_end_dt
    , MTT_STORE_ID
    , CONT_ID
    , MSO_TP_CD
    , STORE_OPEN_DT
    , STORE_CLOSE_DT
    , last_update_dt
    , last_update_user
    , last_update_tx_id
    ) VALUES
    ( newrow.MTT_STORE_ID
    , 'U'
    , COALESCE(newrow.last_update_user,'')
    , newrow.last_update_dt
    , NULL
    , newrow.MTT_STORE_ID
    , newrow.CONT_ID
    , newrow.MSO_TP_CD
    , newrow.STORE_OPEN_DT
    , newrow.STORE_CLOSE_DT
    , newrow.last_update_dt
    , newrow.last_update_user
    , newrow.last_update_tx_id
    );
  END@

CREATE TRIGGER MDMDB.i_MTT_ACCO223420a9 AFTER INSERT ON MDMDB.MTT_ACCOUNT_CREDIT_TAX
  REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
  BEGIN ATOMIC
    INSERT INTO MDMDB.H_MTT_ACCOUNT_CREDIT_TAX
    ( H_MTT_ACT_CREDIT_TAX_ID
    , h_action_code
    , h_created_by
    , h_create_dt
    , h_end_dt
    , MTT_ACT_CREDIT_TAX_ID
    , CONTRACT_ID
    , INV_TERMS_TP_CD
    , GST_EXEMPT_IND
    , CUS_GRP_TP_CD
    , BANK_GUARANTEE_AMT
    , BANK_GUARANTEE_END_DT
    , CASH_DEPOSIT_AMT
    , CASH_DEPOSIT_RECV_DT
    , CASH_DEPOSIT_REL_DT
    , FIRST_MORTGAGE
    , SECOND_MORTGAGE
    , DEED_OF_PRIORITY
    , PPSR_DETAILS
    , PMSI_DETAILS
    , ALLPAP_DETAILS
    , ARREARS
    , CREDIT_HOLD
    , NATIONAL_HOLD
    , CREDIT_HOLD_DT
    , CREDIT_STATUS_OVERRIDE
    , CHEQUE_LIMIT_AMT
    , CHEQUE_LIMIT_CURRENCY_TP_CD
    , WET_EXEMPT_IND
    , DUTY_FREE_IND
    , CASH_ON_DELIVERY_IND
    , SALES_REP_TP_CD
    , last_update_dt
    , last_update_user
    , last_update_tx_id
    ) VALUES
    ( newrow.MTT_ACT_CREDIT_TAX_ID
    , 'I'
    , COALESCE(newrow.last_update_user,'')
    , newrow.last_update_dt
    , NULL
    , newrow.MTT_ACT_CREDIT_TAX_ID
    , newrow.CONTRACT_ID
    , newrow.INV_TERMS_TP_CD
    , newrow.GST_EXEMPT_IND
    , newrow.CUS_GRP_TP_CD
    , newrow.BANK_GUARANTEE_AMT
    , newrow.BANK_GUARANTEE_END_DT
    , newrow.CASH_DEPOSIT_AMT
    , newrow.CASH_DEPOSIT_RECV_DT
    , newrow.CASH_DEPOSIT_REL_DT
    , newrow.FIRST_MORTGAGE
    , newrow.SECOND_MORTGAGE
    , newrow.DEED_OF_PRIORITY
    , newrow.PPSR_DETAILS
    , newrow.PMSI_DETAILS
    , newrow.ALLPAP_DETAILS
    , newrow.ARREARS
    , newrow.CREDIT_HOLD
    , newrow.NATIONAL_HOLD
    , newrow.CREDIT_HOLD_DT
    , newrow.CREDIT_STATUS_OVERRIDE
    , newrow.CHEQUE_LIMIT_AMT
    , newrow.CHEQUE_LIMIT_CURRENCY_TP_CD
    , newrow.WET_EXEMPT_IND
    , newrow.DUTY_FREE_IND
    , newrow.CASH_ON_DELIVERY_IND
    , newrow.SALES_REP_TP_CD
    , newrow.last_update_dt
    , newrow.last_update_user
    , newrow.last_update_tx_id
    );
  END@

CREATE TRIGGER MDMDB.u_MTT_ACCO223420a9 AFTER UPDATE ON MDMDB.MTT_ACCOUNT_CREDIT_TAX
  REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
  BEGIN ATOMIC
    UPDATE MDMDB.H_MTT_ACCOUNT_CREDIT_TAX
        SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND WHERE 
            H_MTT_ACT_CREDIT_TAX_ID=newrow.MTT_ACT_CREDIT_TAX_ID AND 
            (h_action_code='U' or h_action_code='I') AND 
            h_end_dt IS NULL ;
    INSERT INTO MDMDB.H_MTT_ACCOUNT_CREDIT_TAX
    ( H_MTT_ACT_CREDIT_TAX_ID
    , h_action_code
    , h_created_by
    , h_create_dt
    , h_end_dt
    , MTT_ACT_CREDIT_TAX_ID
    , CONTRACT_ID
    , INV_TERMS_TP_CD
    , GST_EXEMPT_IND
    , CUS_GRP_TP_CD
    , BANK_GUARANTEE_AMT
    , BANK_GUARANTEE_END_DT
    , CASH_DEPOSIT_AMT
    , CASH_DEPOSIT_RECV_DT
    , CASH_DEPOSIT_REL_DT
    , FIRST_MORTGAGE
    , SECOND_MORTGAGE
    , DEED_OF_PRIORITY
    , PPSR_DETAILS
    , PMSI_DETAILS
    , ALLPAP_DETAILS
    , ARREARS
    , CREDIT_HOLD
    , NATIONAL_HOLD
    , CREDIT_HOLD_DT
    , CREDIT_STATUS_OVERRIDE
    , CHEQUE_LIMIT_AMT
    , CHEQUE_LIMIT_CURRENCY_TP_CD
    , WET_EXEMPT_IND
    , DUTY_FREE_IND
    , CASH_ON_DELIVERY_IND
    , SALES_REP_TP_CD
    , last_update_dt
    , last_update_user
    , last_update_tx_id
    ) VALUES
    ( newrow.MTT_ACT_CREDIT_TAX_ID
    , 'U'
    , COALESCE(newrow.last_update_user,'')
    , newrow.last_update_dt
    , NULL
    , newrow.MTT_ACT_CREDIT_TAX_ID
    , newrow.CONTRACT_ID
    , newrow.INV_TERMS_TP_CD
    , newrow.GST_EXEMPT_IND
    , newrow.CUS_GRP_TP_CD
    , newrow.BANK_GUARANTEE_AMT
    , newrow.BANK_GUARANTEE_END_DT
    , newrow.CASH_DEPOSIT_AMT
    , newrow.CASH_DEPOSIT_RECV_DT
    , newrow.CASH_DEPOSIT_REL_DT
    , newrow.FIRST_MORTGAGE
    , newrow.SECOND_MORTGAGE
    , newrow.DEED_OF_PRIORITY
    , newrow.PPSR_DETAILS
    , newrow.PMSI_DETAILS
    , newrow.ALLPAP_DETAILS
    , newrow.ARREARS
    , newrow.CREDIT_HOLD
    , newrow.NATIONAL_HOLD
    , newrow.CREDIT_HOLD_DT
    , newrow.CREDIT_STATUS_OVERRIDE
    , newrow.CHEQUE_LIMIT_AMT
    , newrow.CHEQUE_LIMIT_CURRENCY_TP_CD
    , newrow.WET_EXEMPT_IND
    , newrow.DUTY_FREE_IND
    , newrow.CASH_ON_DELIVERY_IND
    , newrow.SALES_REP_TP_CD
    , newrow.last_update_dt
    , newrow.last_update_user
    , newrow.last_update_tx_id
    );
  END@

CREATE TRIGGER MDMDB.i_MTT_ACCOf5e15918 AFTER INSERT ON MDMDB.MTT_ACCOUNT_ORDER_INVOICE
  REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
  BEGIN ATOMIC
    INSERT INTO MDMDB.H_MTT_ACCOUNT_ORDER_INVOICE
    ( H_MTT_ACT_ORDER_INV_ID
    , h_action_code
    , h_created_by
    , h_create_dt
    , h_end_dt
    , MTT_ACT_ORDER_INV_ID
    , CONTRACT_ID
    , PRN_RETAIL_IND
    , PRN_PRICE_MATCH_SUMMARY_IND
    , SUBSTITUTE_ITEM_IND
    , INV_SEQ_TP_CD
    , INV_COPIES_NUM
    , INV_MODE_TP_CD
    , ORDER_GUIDE_TP_CD
    , SEP_ORDER_ITEM_RESRV_IND
    , SPECIAL_INSTRUCTIONS
    , PRN_CAT_INV_BRK_TP_CD
    , INV_RECAP_SUMMARY_TP_CD
    , PO_NUM_REQ_IND
    , PICKUP_DELIVER_TP_CD
    , PRN_ALT_TOBACCO_LICENCE_IND
    , TOTES_IND
    , TOTES_TP_CD
    , UNIT_CASE_COST_PRN_TP_CD
    , INV_FORMAT_TP_CD
    , PICK_EACHES_IND
    , INV_TP_CD
    , INV_STOP_MSG
    , DEL_PICK_PACK_INV_TP_CD
    , PRN_HO_INV_IND
    , PRN_WHOLESALE_ON_INV_IND
    , SEP_INV_PER_CUS_PO_IND
    , ASN_REQ_IND
    , EASNMailbox
    , last_update_dt
    , last_update_user
    , last_update_tx_id
    ) VALUES
    ( newrow.MTT_ACT_ORDER_INV_ID
    , 'I'
    , COALESCE(newrow.last_update_user,'')
    , newrow.last_update_dt
    , NULL
    , newrow.MTT_ACT_ORDER_INV_ID
    , newrow.CONTRACT_ID
    , newrow.PRN_RETAIL_IND
    , newrow.PRN_PRICE_MATCH_SUMMARY_IND
    , newrow.SUBSTITUTE_ITEM_IND
    , newrow.INV_SEQ_TP_CD
    , newrow.INV_COPIES_NUM
    , newrow.INV_MODE_TP_CD
    , newrow.ORDER_GUIDE_TP_CD
    , newrow.SEP_ORDER_ITEM_RESRV_IND
    , newrow.SPECIAL_INSTRUCTIONS
    , newrow.PRN_CAT_INV_BRK_TP_CD
    , newrow.INV_RECAP_SUMMARY_TP_CD
    , newrow.PO_NUM_REQ_IND
    , newrow.PICKUP_DELIVER_TP_CD
    , newrow.PRN_ALT_TOBACCO_LICENCE_IND
    , newrow.TOTES_IND
    , newrow.TOTES_TP_CD
    , newrow.UNIT_CASE_COST_PRN_TP_CD
    , newrow.INV_FORMAT_TP_CD
    , newrow.PICK_EACHES_IND
    , newrow.INV_TP_CD
    , newrow.INV_STOP_MSG
    , newrow.DEL_PICK_PACK_INV_TP_CD
    , newrow.PRN_HO_INV_IND
    , newrow.PRN_WHOLESALE_ON_INV_IND
    , newrow.SEP_INV_PER_CUS_PO_IND
    , newrow.ASN_REQ_IND
    , newrow.EASNMailbox
    , newrow.last_update_dt
    , newrow.last_update_user
    , newrow.last_update_tx_id
    );
  END@

CREATE TRIGGER MDMDB.u_MTT_ACCOf5e15918 AFTER UPDATE ON MDMDB.MTT_ACCOUNT_ORDER_INVOICE
  REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
  BEGIN ATOMIC
    UPDATE MDMDB.H_MTT_ACCOUNT_ORDER_INVOICE
        SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND WHERE 
            H_MTT_ACT_ORDER_INV_ID=newrow.MTT_ACT_ORDER_INV_ID AND 
            (h_action_code='U' or h_action_code='I') AND 
            h_end_dt IS NULL ;
    INSERT INTO MDMDB.H_MTT_ACCOUNT_ORDER_INVOICE
    ( H_MTT_ACT_ORDER_INV_ID
    , h_action_code
    , h_created_by
    , h_create_dt
    , h_end_dt
    , MTT_ACT_ORDER_INV_ID
    , CONTRACT_ID
    , PRN_RETAIL_IND
    , PRN_PRICE_MATCH_SUMMARY_IND
    , SUBSTITUTE_ITEM_IND
    , INV_SEQ_TP_CD
    , INV_COPIES_NUM
    , INV_MODE_TP_CD
    , ORDER_GUIDE_TP_CD
    , SEP_ORDER_ITEM_RESRV_IND
    , SPECIAL_INSTRUCTIONS
    , PRN_CAT_INV_BRK_TP_CD
    , INV_RECAP_SUMMARY_TP_CD
    , PO_NUM_REQ_IND
    , PICKUP_DELIVER_TP_CD
    , PRN_ALT_TOBACCO_LICENCE_IND
    , TOTES_IND
    , TOTES_TP_CD
    , UNIT_CASE_COST_PRN_TP_CD
    , INV_FORMAT_TP_CD
    , PICK_EACHES_IND
    , INV_TP_CD
    , INV_STOP_MSG
    , DEL_PICK_PACK_INV_TP_CD
    , PRN_HO_INV_IND
    , PRN_WHOLESALE_ON_INV_IND
    , SEP_INV_PER_CUS_PO_IND
    , ASN_REQ_IND
    , EASNMailbox
    , last_update_dt
    , last_update_user
    , last_update_tx_id
    ) VALUES
    ( newrow.MTT_ACT_ORDER_INV_ID
    , 'U'
    , COALESCE(newrow.last_update_user,'')
    , newrow.last_update_dt
    , NULL
    , newrow.MTT_ACT_ORDER_INV_ID
    , newrow.CONTRACT_ID
    , newrow.PRN_RETAIL_IND
    , newrow.PRN_PRICE_MATCH_SUMMARY_IND
    , newrow.SUBSTITUTE_ITEM_IND
    , newrow.INV_SEQ_TP_CD
    , newrow.INV_COPIES_NUM
    , newrow.INV_MODE_TP_CD
    , newrow.ORDER_GUIDE_TP_CD
    , newrow.SEP_ORDER_ITEM_RESRV_IND
    , newrow.SPECIAL_INSTRUCTIONS
    , newrow.PRN_CAT_INV_BRK_TP_CD
    , newrow.INV_RECAP_SUMMARY_TP_CD
    , newrow.PO_NUM_REQ_IND
    , newrow.PICKUP_DELIVER_TP_CD
    , newrow.PRN_ALT_TOBACCO_LICENCE_IND
    , newrow.TOTES_IND
    , newrow.TOTES_TP_CD
    , newrow.UNIT_CASE_COST_PRN_TP_CD
    , newrow.INV_FORMAT_TP_CD
    , newrow.PICK_EACHES_IND
    , newrow.INV_TP_CD
    , newrow.INV_STOP_MSG
    , newrow.DEL_PICK_PACK_INV_TP_CD
    , newrow.PRN_HO_INV_IND
    , newrow.PRN_WHOLESALE_ON_INV_IND
    , newrow.SEP_INV_PER_CUS_PO_IND
    , newrow.ASN_REQ_IND
    , newrow.EASNMailbox
    , newrow.last_update_dt
    , newrow.last_update_user
    , newrow.last_update_tx_id
    );
  END@

CREATE TRIGGER MDMDB.i_MTT_ACCO8917dc11 AFTER INSERT ON MDMDB.MTT_ACCOUNT_COST_CHARGES
  REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
  BEGIN ATOMIC
    INSERT INTO MDMDB.H_MTT_ACCOUNT_COST_CHARGES
    ( H_MTT_ACT_COST_CHARGES_ID
    , h_action_code
    , h_created_by
    , h_create_dt
    , h_end_dt
    , MTT_ACT_COST_CHARGES_ID
    , CONTRACT_ID
    , COST_BASE_TP_CD
    , DIRECT_SHIP_APPROVED_IND
    , DO_NOT_APPLY_DIRECT_DISC_IND
    , SRP_COMPLIANCE_TP_CD
    , PRICE_MATCH_GAP_FEE_IND
    , BRKN_CASE_UPCHARGE_PCT
    , BRKN_CASE_UPCHARGE_CAP
    , BRKN_CASE_UPCHARGE_IND
    , BRKN_CASE_CALC_TP_CD
    , SHELF_LABEL_PRICED_IND
    , PSRP_TP_CD
    , ADD_FRT_RECOVERY_SRP_IND
    , SRP_FRT_RECOVERY_VAL
    , SRP_FRT_RECOVERY_DIR_VAL
    , last_update_dt
    , last_update_user
    , last_update_tx_id
    ) VALUES
    ( newrow.MTT_ACT_COST_CHARGES_ID
    , 'I'
    , COALESCE(newrow.last_update_user,'')
    , newrow.last_update_dt
    , NULL
    , newrow.MTT_ACT_COST_CHARGES_ID
    , newrow.CONTRACT_ID
    , newrow.COST_BASE_TP_CD
    , newrow.DIRECT_SHIP_APPROVED_IND
    , newrow.DO_NOT_APPLY_DIRECT_DISC_IND
    , newrow.SRP_COMPLIANCE_TP_CD
    , newrow.PRICE_MATCH_GAP_FEE_IND
    , newrow.BRKN_CASE_UPCHARGE_PCT
    , newrow.BRKN_CASE_UPCHARGE_CAP
    , newrow.BRKN_CASE_UPCHARGE_IND
    , newrow.BRKN_CASE_CALC_TP_CD
    , newrow.SHELF_LABEL_PRICED_IND
    , newrow.PSRP_TP_CD
    , newrow.ADD_FRT_RECOVERY_SRP_IND
    , newrow.SRP_FRT_RECOVERY_VAL
    , newrow.SRP_FRT_RECOVERY_DIR_VAL
    , newrow.last_update_dt
    , newrow.last_update_user
    , newrow.last_update_tx_id
    );
  END@

CREATE TRIGGER MDMDB.u_MTT_ACCO8917dc11 AFTER UPDATE ON MDMDB.MTT_ACCOUNT_COST_CHARGES
  REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
  BEGIN ATOMIC
    UPDATE MDMDB.H_MTT_ACCOUNT_COST_CHARGES
        SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND WHERE 
            H_MTT_ACT_COST_CHARGES_ID=newrow.MTT_ACT_COST_CHARGES_ID AND 
            (h_action_code='U' or h_action_code='I') AND 
            h_end_dt IS NULL ;
    INSERT INTO MDMDB.H_MTT_ACCOUNT_COST_CHARGES
    ( H_MTT_ACT_COST_CHARGES_ID
    , h_action_code
    , h_created_by
    , h_create_dt
    , h_end_dt
    , MTT_ACT_COST_CHARGES_ID
    , CONTRACT_ID
    , COST_BASE_TP_CD
    , DIRECT_SHIP_APPROVED_IND
    , DO_NOT_APPLY_DIRECT_DISC_IND
    , SRP_COMPLIANCE_TP_CD
    , PRICE_MATCH_GAP_FEE_IND
    , BRKN_CASE_UPCHARGE_PCT
    , BRKN_CASE_UPCHARGE_CAP
    , BRKN_CASE_UPCHARGE_IND
    , BRKN_CASE_CALC_TP_CD
    , SHELF_LABEL_PRICED_IND
    , PSRP_TP_CD
    , ADD_FRT_RECOVERY_SRP_IND
    , SRP_FRT_RECOVERY_VAL
    , SRP_FRT_RECOVERY_DIR_VAL
    , last_update_dt
    , last_update_user
    , last_update_tx_id
    ) VALUES
    ( newrow.MTT_ACT_COST_CHARGES_ID
    , 'U'
    , COALESCE(newrow.last_update_user,'')
    , newrow.last_update_dt
    , NULL
    , newrow.MTT_ACT_COST_CHARGES_ID
    , newrow.CONTRACT_ID
    , newrow.COST_BASE_TP_CD
    , newrow.DIRECT_SHIP_APPROVED_IND
    , newrow.DO_NOT_APPLY_DIRECT_DISC_IND
    , newrow.SRP_COMPLIANCE_TP_CD
    , newrow.PRICE_MATCH_GAP_FEE_IND
    , newrow.BRKN_CASE_UPCHARGE_PCT
    , newrow.BRKN_CASE_UPCHARGE_CAP
    , newrow.BRKN_CASE_UPCHARGE_IND
    , newrow.BRKN_CASE_CALC_TP_CD
    , newrow.SHELF_LABEL_PRICED_IND
    , newrow.PSRP_TP_CD
    , newrow.ADD_FRT_RECOVERY_SRP_IND
    , newrow.SRP_FRT_RECOVERY_VAL
    , newrow.SRP_FRT_RECOVERY_DIR_VAL
    , newrow.last_update_dt
    , newrow.last_update_user
    , newrow.last_update_tx_id
    );
  END@

CREATE TRIGGER MDMDB.i_MTT_ACCObca8bc85 AFTER INSERT ON MDMDB.MTT_ACCOUNT_FINANCIAL
  REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
  BEGIN ATOMIC
    INSERT INTO MDMDB.H_MTT_ACCOUNT_FINANCIAL
    ( H_MTT_ACT_FINANCIAL_ID
    , h_action_code
    , h_created_by
    , h_create_dt
    , h_end_dt
    , MTT_ACT_FINANCIAL_ID
    , CONTRACT_ID
    , STATEMENT_MODE_TP_CD
    , DUE_GRACE_DAYS_TP_CD
    , TOBACCO_GRACE_DAYS_TP_CD
    , BANK_TP_CD
    , BPAY_IND
    , STATEMENT_PRN_HOLD_IND
    , BPAY_CUS_REF_NUM
    , COLLECTOR_TP_CD
    , BANK_ACCOUNT_TP_CD
    , EXT_TERMS_BY_SHIPDATE_IND
    , SETTLEMENT_DISC_IND
    , ACCOUNT_DETAILS
    , DISC_GRACE_DAYS_TP_CD
    , PAYMENT_METHOD_TP_CD
    , LMAA_NUM
    , last_update_dt
    , last_update_user
    , last_update_tx_id
    ) VALUES
    ( newrow.MTT_ACT_FINANCIAL_ID
    , 'I'
    , COALESCE(newrow.last_update_user,'')
    , newrow.last_update_dt
    , NULL
    , newrow.MTT_ACT_FINANCIAL_ID
    , newrow.CONTRACT_ID
    , newrow.STATEMENT_MODE_TP_CD
    , newrow.DUE_GRACE_DAYS_TP_CD
    , newrow.TOBACCO_GRACE_DAYS_TP_CD
    , newrow.BANK_TP_CD
    , newrow.BPAY_IND
    , newrow.STATEMENT_PRN_HOLD_IND
    , newrow.BPAY_CUS_REF_NUM
    , newrow.COLLECTOR_TP_CD
    , newrow.BANK_ACCOUNT_TP_CD
    , newrow.EXT_TERMS_BY_SHIPDATE_IND
    , newrow.SETTLEMENT_DISC_IND
    , newrow.ACCOUNT_DETAILS
    , newrow.DISC_GRACE_DAYS_TP_CD
    , newrow.PAYMENT_METHOD_TP_CD
    , newrow.LMAA_NUM
    , newrow.last_update_dt
    , newrow.last_update_user
    , newrow.last_update_tx_id
    );
  END@

CREATE TRIGGER MDMDB.u_MTT_ACCObca8bc85 AFTER UPDATE ON MDMDB.MTT_ACCOUNT_FINANCIAL
  REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
  BEGIN ATOMIC
    UPDATE MDMDB.H_MTT_ACCOUNT_FINANCIAL
        SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND WHERE 
            H_MTT_ACT_FINANCIAL_ID=newrow.MTT_ACT_FINANCIAL_ID AND 
            (h_action_code='U' or h_action_code='I') AND 
            h_end_dt IS NULL ;
    INSERT INTO MDMDB.H_MTT_ACCOUNT_FINANCIAL
    ( H_MTT_ACT_FINANCIAL_ID
    , h_action_code
    , h_created_by
    , h_create_dt
    , h_end_dt
    , MTT_ACT_FINANCIAL_ID
    , CONTRACT_ID
    , STATEMENT_MODE_TP_CD
    , DUE_GRACE_DAYS_TP_CD
    , TOBACCO_GRACE_DAYS_TP_CD
    , BANK_TP_CD
    , BPAY_IND
    , STATEMENT_PRN_HOLD_IND
    , BPAY_CUS_REF_NUM
    , COLLECTOR_TP_CD
    , BANK_ACCOUNT_TP_CD
    , EXT_TERMS_BY_SHIPDATE_IND
    , SETTLEMENT_DISC_IND
    , ACCOUNT_DETAILS
    , DISC_GRACE_DAYS_TP_CD
    , PAYMENT_METHOD_TP_CD
    , LMAA_NUM
    , last_update_dt
    , last_update_user
    , last_update_tx_id
    ) VALUES
    ( newrow.MTT_ACT_FINANCIAL_ID
    , 'U'
    , COALESCE(newrow.last_update_user,'')
    , newrow.last_update_dt
    , NULL
    , newrow.MTT_ACT_FINANCIAL_ID
    , newrow.CONTRACT_ID
    , newrow.STATEMENT_MODE_TP_CD
    , newrow.DUE_GRACE_DAYS_TP_CD
    , newrow.TOBACCO_GRACE_DAYS_TP_CD
    , newrow.BANK_TP_CD
    , newrow.BPAY_IND
    , newrow.STATEMENT_PRN_HOLD_IND
    , newrow.BPAY_CUS_REF_NUM
    , newrow.COLLECTOR_TP_CD
    , newrow.BANK_ACCOUNT_TP_CD
    , newrow.EXT_TERMS_BY_SHIPDATE_IND
    , newrow.SETTLEMENT_DISC_IND
    , newrow.ACCOUNT_DETAILS
    , newrow.DISC_GRACE_DAYS_TP_CD
    , newrow.PAYMENT_METHOD_TP_CD
    , newrow.LMAA_NUM
    , newrow.last_update_dt
    , newrow.last_update_user
    , newrow.last_update_tx_id
    );
  END@

CREATE TRIGGER MDMDB.i_XCDCHANNELGRPTP AFTER INSERT ON MDMDB.XCDCHANNELGRPTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDCHANNELGRPTP
	( 
	h_lang_tp_cd
	, h_channel_grp_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, channel_grp_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.channel_grp_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.channel_grp_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDCHANNELGRPTP AFTER UPDATE ON MDMDB.XCDCHANNELGRPTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDCHANNELGRPTP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_channel_grp_tp_cd=newrow.channel_grp_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDCHANNELGRPTP
	( 
	h_lang_tp_cd
	, h_channel_grp_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, channel_grp_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.channel_grp_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.channel_grp_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDAGENTNUMTP AFTER INSERT ON MDMDB.XCDAGENTNUMTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDAGENTNUMTP
	( 
	h_lang_tp_cd
	, h_agent_num_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, agent_num_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.agent_num_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.agent_num_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDAGENTNUMTP AFTER UPDATE ON MDMDB.XCDAGENTNUMTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDAGENTNUMTP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_agent_num_tp_cd=newrow.agent_num_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDAGENTNUMTP
	( 
	h_lang_tp_cd
	, h_agent_num_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, agent_num_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.agent_num_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.agent_num_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDUSERL2447a823 AFTER INSERT ON MDMDB.XCDUSERLOCALITYTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDUSERLOCALITYTP
	( 
	h_lang_tp_cd
	, h_user_locality_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, user_locality_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.user_locality_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.user_locality_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDUSERL2447a823 AFTER UPDATE ON MDMDB.XCDUSERLOCALITYTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDUSERLOCALITYTP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_user_locality_tp_cd=newrow.user_locality_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDUSERLOCALITYTP
	( 
	h_lang_tp_cd
	, h_user_locality_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, user_locality_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.user_locality_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.user_locality_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDCUSCLASSTP AFTER INSERT ON MDMDB.XCDCUSCLASSTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDCUSCLASSTP
	( 
	h_lang_tp_cd
	, h_cus_class_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, cus_class_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.cus_class_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.cus_class_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDCUSCLASSTP AFTER UPDATE ON MDMDB.XCDCUSCLASSTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDCUSCLASSTP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_cus_class_tp_cd=newrow.cus_class_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDCUSCLASSTP
	( 
	h_lang_tp_cd
	, h_cus_class_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, cus_class_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.cus_class_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.cus_class_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDINVTERMSTP AFTER INSERT ON MDMDB.XCDINVTERMSTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDINVTERMSTP
	( 
	h_lang_tp_cd
	, h_inv_terms_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, inv_terms_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.inv_terms_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.inv_terms_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDINVTERMSTP AFTER UPDATE ON MDMDB.XCDINVTERMSTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDINVTERMSTP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_inv_terms_tp_cd=newrow.inv_terms_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDINVTERMSTP
	( 
	h_lang_tp_cd
	, h_inv_terms_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, inv_terms_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.inv_terms_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.inv_terms_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDCUSGRPTP AFTER INSERT ON MDMDB.XCDCUSGRPTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDCUSGRPTP
	( 
	h_lang_tp_cd
	, h_cus_grp_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, cus_grp_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.cus_grp_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.cus_grp_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDCUSGRPTP AFTER UPDATE ON MDMDB.XCDCUSGRPTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDCUSGRPTP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_cus_grp_tp_cd=newrow.cus_grp_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDCUSGRPTP
	( 
	h_lang_tp_cd
	, h_cus_grp_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, cus_grp_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.cus_grp_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.cus_grp_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDINVSEQTP AFTER INSERT ON MDMDB.XCDINVSEQTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDINVSEQTP
	( 
	h_lang_tp_cd
	, h_inv_seq_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, inv_seq_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.inv_seq_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.inv_seq_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDINVSEQTP AFTER UPDATE ON MDMDB.XCDINVSEQTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDINVSEQTP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_inv_seq_tp_cd=newrow.inv_seq_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDINVSEQTP
	( 
	h_lang_tp_cd
	, h_inv_seq_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, inv_seq_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.inv_seq_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.inv_seq_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDINVMODETP AFTER INSERT ON MDMDB.XCDINVMODETP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDINVMODETP
	( 
	h_lang_tp_cd
	, h_inv_mode_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, inv_mode_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.inv_mode_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.inv_mode_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDINVMODETP AFTER UPDATE ON MDMDB.XCDINVMODETP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDINVMODETP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_inv_mode_tp_cd=newrow.inv_mode_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDINVMODETP
	( 
	h_lang_tp_cd
	, h_inv_mode_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, inv_mode_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.inv_mode_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.inv_mode_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDORDERGUIDETP AFTER INSERT ON MDMDB.XCDORDERGUIDETP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDORDERGUIDETP
	( 
	h_lang_tp_cd
	, h_order_guide_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, order_guide_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.order_guide_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.order_guide_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDORDERGUIDETP AFTER UPDATE ON MDMDB.XCDORDERGUIDETP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDORDERGUIDETP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_order_guide_tp_cd=newrow.order_guide_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDORDERGUIDETP
	( 
	h_lang_tp_cd
	, h_order_guide_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, order_guide_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.order_guide_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.order_guide_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDPRNCAee1b1b29 AFTER INSERT ON MDMDB.XCDPRNCATINVBRKTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDPRNCATINVBRKTP
	( 
	h_lang_tp_cd
	, h_prn_cat_inv_brk_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, prn_cat_inv_brk_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.prn_cat_inv_brk_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.prn_cat_inv_brk_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDPRNCAee1b1b29 AFTER UPDATE ON MDMDB.XCDPRNCATINVBRKTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDPRNCATINVBRKTP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_prn_cat_inv_brk_tp_cd=newrow.prn_cat_inv_brk_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDPRNCATINVBRKTP
	( 
	h_lang_tp_cd
	, h_prn_cat_inv_brk_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, prn_cat_inv_brk_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.prn_cat_inv_brk_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.prn_cat_inv_brk_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDINVRE5fc2bf3b AFTER INSERT ON MDMDB.XCDINVRECAPSUMMARYTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDINVRECAPSUMMARYTP
	( 
	h_lang_tp_cd
	, h_inv_recap_summary_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, inv_recap_summary_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.inv_recap_summary_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.inv_recap_summary_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDINVRE5fc2bf3b AFTER UPDATE ON MDMDB.XCDINVRECAPSUMMARYTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDINVRECAPSUMMARYTP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_inv_recap_summary_tp_cd=newrow.inv_recap_summary_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDINVRECAPSUMMARYTP
	( 
	h_lang_tp_cd
	, h_inv_recap_summary_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, inv_recap_summary_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.inv_recap_summary_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.inv_recap_summary_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDPICKU2208c36c AFTER INSERT ON MDMDB.XCDPICKUPDELIVERTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDPICKUPDELIVERTP
	( 
	h_lang_tp_cd
	, h_pickup_deliver_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, pickup_deliver_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.pickup_deliver_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.pickup_deliver_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDPICKU2208c36c AFTER UPDATE ON MDMDB.XCDPICKUPDELIVERTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDPICKUPDELIVERTP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_pickup_deliver_tp_cd=newrow.pickup_deliver_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDPICKUPDELIVERTP
	( 
	h_lang_tp_cd
	, h_pickup_deliver_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, pickup_deliver_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.pickup_deliver_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.pickup_deliver_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDUNITCfe703c8e AFTER INSERT ON MDMDB.XCDUNITCASECOSTPRNTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDUNITCASECOSTPRNTP
	( 
	h_lang_tp_cd
	, h_unit_case_cost_prn_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, unit_case_cost_prn_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.unit_case_cost_prn_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.unit_case_cost_prn_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDUNITCfe703c8e AFTER UPDATE ON MDMDB.XCDUNITCASECOSTPRNTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDUNITCASECOSTPRNTP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_unit_case_cost_prn_tp_cd=newrow.unit_case_cost_prn_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDUNITCASECOSTPRNTP
	( 
	h_lang_tp_cd
	, h_unit_case_cost_prn_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, unit_case_cost_prn_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.unit_case_cost_prn_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.unit_case_cost_prn_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDINVFORMATTP AFTER INSERT ON MDMDB.XCDINVFORMATTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDINVFORMATTP
	( 
	h_lang_tp_cd
	, h_inv_format_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, inv_format_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.inv_format_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.inv_format_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDINVFORMATTP AFTER UPDATE ON MDMDB.XCDINVFORMATTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDINVFORMATTP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_inv_format_tp_cd=newrow.inv_format_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDINVFORMATTP
	( 
	h_lang_tp_cd
	, h_inv_format_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, inv_format_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.inv_format_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.inv_format_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDDELPI1887cf41 AFTER INSERT ON MDMDB.XCDDELPICKPACKINVTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDDELPICKPACKINVTP
	( 
	h_lang_tp_cd
	, h_del_pick_pack_inv_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, del_pick_pack_inv_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.del_pick_pack_inv_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.del_pick_pack_inv_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDDELPI1887cf41 AFTER UPDATE ON MDMDB.XCDDELPICKPACKINVTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDDELPICKPACKINVTP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_del_pick_pack_inv_tp_cd=newrow.del_pick_pack_inv_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDDELPICKPACKINVTP
	( 
	h_lang_tp_cd
	, h_del_pick_pack_inv_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, del_pick_pack_inv_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.del_pick_pack_inv_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.del_pick_pack_inv_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDTOTESTP AFTER INSERT ON MDMDB.XCDTOTESTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDTOTESTP
	( 
	h_lang_tp_cd
	, h_totes_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, totes_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.totes_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.totes_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDTOTESTP AFTER UPDATE ON MDMDB.XCDTOTESTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDTOTESTP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_totes_tp_cd=newrow.totes_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDTOTESTP
	( 
	h_lang_tp_cd
	, h_totes_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, totes_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.totes_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.totes_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDINVTP AFTER INSERT ON MDMDB.XCDINVTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDINVTP
	( 
	h_lang_tp_cd
	, h_inv_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, inv_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.inv_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.inv_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDINVTP AFTER UPDATE ON MDMDB.XCDINVTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDINVTP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_inv_tp_cd=newrow.inv_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDINVTP
	( 
	h_lang_tp_cd
	, h_inv_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, inv_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.inv_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.inv_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDCOSTBASETP AFTER INSERT ON MDMDB.XCDCOSTBASETP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDCOSTBASETP
	( 
	h_lang_tp_cd
	, h_cost_base_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, cost_base_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.cost_base_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.cost_base_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDCOSTBASETP AFTER UPDATE ON MDMDB.XCDCOSTBASETP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDCOSTBASETP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_cost_base_tp_cd=newrow.cost_base_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDCOSTBASETP
	( 
	h_lang_tp_cd
	, h_cost_base_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, cost_base_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.cost_base_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.cost_base_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDSRPCOc2dae04f AFTER INSERT ON MDMDB.XCDSRPCOMPLIANCETP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDSRPCOMPLIANCETP
	( 
	h_lang_tp_cd
	, h_srp_compliance_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, srp_compliance_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.srp_compliance_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.srp_compliance_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDSRPCOc2dae04f AFTER UPDATE ON MDMDB.XCDSRPCOMPLIANCETP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDSRPCOMPLIANCETP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_srp_compliance_tp_cd=newrow.srp_compliance_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDSRPCOMPLIANCETP
	( 
	h_lang_tp_cd
	, h_srp_compliance_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, srp_compliance_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.srp_compliance_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.srp_compliance_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDBRKNCdc6e1fad AFTER INSERT ON MDMDB.XCDBRKNCASECALCTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDBRKNCASECALCTP
	( 
	h_lang_tp_cd
	, h_brkn_case_calc_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, brkn_case_calc_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.brkn_case_calc_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.brkn_case_calc_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDBRKNCdc6e1fad AFTER UPDATE ON MDMDB.XCDBRKNCASECALCTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDBRKNCASECALCTP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_brkn_case_calc_tp_cd=newrow.brkn_case_calc_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDBRKNCASECALCTP
	( 
	h_lang_tp_cd
	, h_brkn_case_calc_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, brkn_case_calc_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.brkn_case_calc_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.brkn_case_calc_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDPSRPTP AFTER INSERT ON MDMDB.XCDPSRPTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDPSRPTP
	( 
	h_lang_tp_cd
	, h_psrp_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, psrp_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.psrp_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.psrp_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDPSRPTP AFTER UPDATE ON MDMDB.XCDPSRPTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDPSRPTP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_psrp_tp_cd=newrow.psrp_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDPSRPTP
	( 
	h_lang_tp_cd
	, h_psrp_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, psrp_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.psrp_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.psrp_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDSTATEMa04e595 AFTER INSERT ON MDMDB.XCDSTATEMENTMODETP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDSTATEMENTMODETP
	( 
	h_lang_tp_cd
	, h_statement_mode_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, statement_mode_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.statement_mode_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.statement_mode_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDSTATEMa04e595 AFTER UPDATE ON MDMDB.XCDSTATEMENTMODETP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDSTATEMENTMODETP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_statement_mode_tp_cd=newrow.statement_mode_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDSTATEMENTMODETP
	( 
	h_lang_tp_cd
	, h_statement_mode_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, statement_mode_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.statement_mode_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.statement_mode_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDGRACEDAYSTP AFTER INSERT ON MDMDB.XCDGRACEDAYSTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDGRACEDAYSTP
	( 
	h_lang_tp_cd
	, h_grace_days_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, grace_days_cat_cd
	, grace_days_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.grace_days_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.grace_days_cat_cd
	, newrow.grace_days_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDGRACEDAYSTP AFTER UPDATE ON MDMDB.XCDGRACEDAYSTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDGRACEDAYSTP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_grace_days_tp_cd=newrow.grace_days_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDGRACEDAYSTP
	( 
	h_lang_tp_cd
	, h_grace_days_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, grace_days_cat_cd
	, grace_days_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.grace_days_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.grace_days_cat_cd
	, newrow.grace_days_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDCOLLECTORTP AFTER INSERT ON MDMDB.XCDCOLLECTORTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDCOLLECTORTP
	( 
	h_lang_tp_cd
	, h_collector_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, collector_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.collector_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.collector_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDCOLLECTORTP AFTER UPDATE ON MDMDB.XCDCOLLECTORTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDCOLLECTORTP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_collector_tp_cd=newrow.collector_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDCOLLECTORTP
	( 
	h_lang_tp_cd
	, h_collector_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, collector_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.collector_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.collector_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDPAYME8deb572a AFTER INSERT ON MDMDB.XCDPAYMENTMETHODTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDPAYMENTMETHODTP
	( 
	h_lang_tp_cd
	, h_payment_method_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, payment_method_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.payment_method_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.payment_method_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDPAYME8deb572a AFTER UPDATE ON MDMDB.XCDPAYMENTMETHODTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDPAYMENTMETHODTP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_payment_method_tp_cd=newrow.payment_method_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDPAYMENTMETHODTP
	( 
	h_lang_tp_cd
	, h_payment_method_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, payment_method_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.payment_method_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.payment_method_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDBANKTP AFTER INSERT ON MDMDB.XCDBANKTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDBANKTP
	( 
	h_lang_tp_cd
	, h_bank_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, bank_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.bank_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.bank_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDBANKTP AFTER UPDATE ON MDMDB.XCDBANKTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDBANKTP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_bank_tp_cd=newrow.bank_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDBANKTP
	( 
	h_lang_tp_cd
	, h_bank_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, bank_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.bank_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.bank_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDBANKACCOUNTTP AFTER INSERT ON MDMDB.XCDBANKACCOUNTTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDBANKACCOUNTTP
	( 
	h_lang_tp_cd
	, h_bank_account_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, bank_account_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.bank_account_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.bank_account_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDBANKACCOUNTTP AFTER UPDATE ON MDMDB.XCDBANKACCOUNTTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDBANKACCOUNTTP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_bank_account_tp_cd=newrow.bank_account_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDBANKACCOUNTTP
	( 
	h_lang_tp_cd
	, h_bank_account_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, bank_account_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.bank_account_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.bank_account_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDSALESREPTP AFTER INSERT ON MDMDB.XCDSALESREPTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDSALESREPTP
	( 
	h_lang_tp_cd
	, h_sales_rep_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, sales_rep_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.sales_rep_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.sales_rep_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDSALESREPTP AFTER UPDATE ON MDMDB.XCDSALESREPTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDSALESREPTP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_sales_rep_tp_cd=newrow.sales_rep_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDSALESREPTP
	( 
	h_lang_tp_cd
	, h_sales_rep_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, sales_rep_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.sales_rep_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.sales_rep_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDGRACEDAYSCAT AFTER INSERT ON MDMDB.XCDGRACEDAYSCAT
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDGRACEDAYSCAT
	( 
	h_lang_tp_cd
	, h_grace_days_cat_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, grace_days_cat_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.grace_days_cat_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.grace_days_cat_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDGRACEDAYSCAT AFTER UPDATE ON MDMDB.XCDGRACEDAYSCAT
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDGRACEDAYSCAT
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_grace_days_cat_cd=newrow.grace_days_cat_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDGRACEDAYSCAT
	( 
	h_lang_tp_cd
	, h_grace_days_cat_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, grace_days_cat_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.grace_days_cat_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.grace_days_cat_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDDUEGRACEDAYSTP AFTER INSERT ON MDMDB.XCDDUEGRACEDAYSTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDDUEGRACEDAYSTP
	( 
	h_lang_tp_cd
	, h_due_grace_days_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, due_grace_days_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.due_grace_days_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.due_grace_days_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDDUEGRACEDAYSTP AFTER UPDATE ON MDMDB.XCDDUEGRACEDAYSTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDDUEGRACEDAYSTP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_due_grace_days_tp_cd=newrow.due_grace_days_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDDUEGRACEDAYSTP
	( 
	h_lang_tp_cd
	, h_due_grace_days_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, due_grace_days_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.due_grace_days_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.due_grace_days_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDTOBACCOGRACEDAYSTP AFTER INSERT ON MDMDB.XCDTOBACCOGRACEDAYSTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDTOBACCOGRACEDAYSTP
	( 
	h_lang_tp_cd
	, h_tobacco_grace_days_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, tobacco_grace_days_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.tobacco_grace_days_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.tobacco_grace_days_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDTOBACCOGRACEDAYSTP AFTER UPDATE ON MDMDB.XCDTOBACCOGRACEDAYSTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDTOBACCOGRACEDAYSTP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_tobacco_grace_days_tp_cd=newrow.tobacco_grace_days_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDTOBACCOGRACEDAYSTP
	( 
	h_lang_tp_cd
	, h_tobacco_grace_days_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, tobacco_grace_days_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.tobacco_grace_days_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.tobacco_grace_days_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDDISCOUNTGRACEDAYSTP AFTER INSERT ON MDMDB.XCDDISCOUNTGRACEDAYSTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDDISCOUNTGRACEDAYSTP
	( 
	h_lang_tp_cd
	, h_discount_grace_days_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, discount_grace_days_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.discount_grace_days_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.discount_grace_days_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDDISCOUNTGRACEDAYSTP AFTER UPDATE ON MDMDB.XCDDISCOUNTGRACEDAYSTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDDISCOUNTGRACEDAYSTP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_discount_grace_days_tp_cd=newrow.discount_grace_days_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDDISCOUNTGRACEDAYSTP
	( 
	h_lang_tp_cd
	, h_discount_grace_days_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, discount_grace_days_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.discount_grace_days_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.discount_grace_days_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDIDENT59e271ba AFTER INSERT ON MDMDB.XCDIDENTIFIERSUBTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDIDENTIFIERSUBTP
	( 
	h_lang_tp_cd
	, h_identifier_sub_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, identifier_sub_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.identifier_sub_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.identifier_sub_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDIDENT59e271ba AFTER UPDATE ON MDMDB.XCDIDENTIFIERSUBTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDIDENTIFIERSUBTP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_identifier_sub_tp_cd=newrow.identifier_sub_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDIDENTIFIERSUBTP
	( 
	h_lang_tp_cd
	, h_identifier_sub_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, identifier_sub_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.identifier_sub_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.identifier_sub_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@

CREATE TRIGGER MDMDB.i_XCDMSOTP AFTER INSERT ON MDMDB.XCDMSOTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	INSERT INTO MDMDB.H_XCDMSOTP
	( 
	h_lang_tp_cd
	, h_mso_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, mso_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	)VALUES
	( 
	newrow.lang_tp_cd
	, newrow.mso_tp_cd
	, 'I'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.mso_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@
	
CREATE TRIGGER MDMDB.u_XCDMSOTP AFTER UPDATE ON MDMDB.XCDMSOTP
	REFERENCING NEW AS newrow FOR EACH ROW MODE DB2SQL
	BEGIN ATOMIC
	UPDATE MDMDB.H_XCDMSOTP
		SET h_end_dt = newrow.last_update_dt - 1 MICROSECOND
		WHERE h_lang_tp_cd=newrow.lang_tp_cd AND
			h_mso_tp_cd=newrow.mso_tp_cd AND
			(h_action_code='U' or h_action_code='I') AND
			h_end_dt IS NULL;
	INSERT INTO MDMDB.H_XCDMSOTP
	( 
	h_lang_tp_cd
	, h_mso_tp_cd
	, h_action_code
	, h_created_by
	, h_create_dt
	, h_end_dt
	, lang_tp_cd
	, mso_tp_cd
	, name
	, description
	, expiry_dt
	, last_update_dt
	, last_update_user
	) VALUES
	( 
	newrow.lang_tp_cd
	, newrow.mso_tp_cd
	, 'U'
	, user
	, newrow.last_update_dt
	, NULL
	, newrow.lang_tp_cd
	, newrow.mso_tp_cd
	, newrow.name
	, newrow.description
	, newrow.expiry_dt
	, newrow.last_update_dt
	, newrow.last_update_user
	);
	END@


