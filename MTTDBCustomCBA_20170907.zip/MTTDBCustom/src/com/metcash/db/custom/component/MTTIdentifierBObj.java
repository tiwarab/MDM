
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[7b3d959d599ebe4dcc9625e394cb84a2]
 */

package com.metcash.db.custom.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.management.config.client.Configuration;
import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;
import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;
import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;
import com.metcash.db.custom.constant.MTTDBCustomComponentID;
import com.metcash.db.custom.constant.MTTDBCustomErrorReasonCode;
import com.metcash.db.custom.constant.MTTDBCustomPropertyKeys;

import com.metcash.db.custom.entityObject.EObjMTTIdentifier;

import com.metcash.db.custom.interfaces.MTTDBCustom;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>MTTIdentifierBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class MTTIdentifierBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjMTTIdentifier eObjMTTIdentifier;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(MTTIdentifierBObj.class);
		
 


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String identifierSubValue;
    protected boolean isValidStartDate = true;
  protected boolean isValidEndDate = true;
  protected boolean isValidExpiryDate = true;




    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public MTTIdentifierBObj() {
        super();
        init();
        eObjMTTIdentifier = new EObjMTTIdentifier();
        setComponentID(MTTDBCustomComponentID.MTTIDENTIFIER_BOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("MTTIdentifierIdPk", null);
        metaDataMap.put("IdentifierId", null);
        metaDataMap.put("IdentifierSubType", null);
        metaDataMap.put("IdentifierSubValue", null);
        metaDataMap.put("StartDate", null);
        metaDataMap.put("EndDate", null);
        metaDataMap.put("ExpiryDate", null);
        metaDataMap.put("Description", null);
        metaDataMap.put("MTTIdentifierHistActionCode", null);
        metaDataMap.put("MTTIdentifierHistCreateDate", null);
        metaDataMap.put("MTTIdentifierHistCreatedBy", null);
        metaDataMap.put("MTTIdentifierHistEndDate", null);
        metaDataMap.put("MTTIdentifierHistoryIdPK", null);
        metaDataMap.put("MTTIdentifierLastUpdateDate", null);
        metaDataMap.put("MTTIdentifierLastUpdateTxId", null);
        metaDataMap.put("MTTIdentifierLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("MTTIdentifierIdPk", getMTTIdentifierIdPk());
            metaDataMap.put("IdentifierId", getIdentifierId());
            metaDataMap.put("IdentifierSubType", getIdentifierSubType());
            metaDataMap.put("IdentifierSubValue", getIdentifierSubValue());
            metaDataMap.put("StartDate", getStartDate());
            metaDataMap.put("EndDate", getEndDate());
            metaDataMap.put("ExpiryDate", getExpiryDate());
            metaDataMap.put("Description", getDescription());
            metaDataMap.put("MTTIdentifierHistActionCode", getMTTIdentifierHistActionCode());
            metaDataMap.put("MTTIdentifierHistCreateDate", getMTTIdentifierHistCreateDate());
            metaDataMap.put("MTTIdentifierHistCreatedBy", getMTTIdentifierHistCreatedBy());
            metaDataMap.put("MTTIdentifierHistEndDate", getMTTIdentifierHistEndDate());
            metaDataMap.put("MTTIdentifierHistoryIdPK", getMTTIdentifierHistoryIdPK());
            metaDataMap.put("MTTIdentifierLastUpdateDate", getMTTIdentifierLastUpdateDate());
            metaDataMap.put("MTTIdentifierLastUpdateTxId", getMTTIdentifierLastUpdateTxId());
            metaDataMap.put("MTTIdentifierLastUpdateUser", getMTTIdentifierLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjMTTIdentifier != null) {
            eObjMTTIdentifier.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjMTTIdentifier getEObjMTTIdentifier() {
        bRequireMapRefresh = true;
        return eObjMTTIdentifier;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjMTTIdentifier
     *            The eObjMTTIdentifier to set.
     * @generated
     */
    public void setEObjMTTIdentifier(EObjMTTIdentifier eObjMTTIdentifier) {
        bRequireMapRefresh = true;
        this.eObjMTTIdentifier = eObjMTTIdentifier;
        if (this.eObjMTTIdentifier != null && this.eObjMTTIdentifier.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjMTTIdentifier.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the mTTIdentifierIdPk attribute.
     * 
     * @generated
     */
    public String getMTTIdentifierIdPk (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTIdentifier.getMTTIdentifierIdPk());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the mTTIdentifierIdPk attribute.
     * 
     * @param newMTTIdentifierIdPk
     *     The new value of mTTIdentifierIdPk.
     * @generated
     */
    public void setMTTIdentifierIdPk( String newMTTIdentifierIdPk ) throws Exception {
        metaDataMap.put("MTTIdentifierIdPk", newMTTIdentifierIdPk);

        if (newMTTIdentifierIdPk == null || newMTTIdentifierIdPk.equals("")) {
            newMTTIdentifierIdPk = null;


        }
        eObjMTTIdentifier.setMTTIdentifierIdPk( DWLFunctionUtils.getLongFromString(newMTTIdentifierIdPk) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the identifierId attribute.
     * 
     * @generated
     */
    public String getIdentifierId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTIdentifier.getIdentifierId());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the identifierId attribute.
     * 
     * @param newIdentifierId
     *     The new value of identifierId.
     * @generated
     */
    public void setIdentifierId( String newIdentifierId ) throws Exception {
        metaDataMap.put("IdentifierId", newIdentifierId);

        if (newIdentifierId == null || newIdentifierId.equals("")) {
            newIdentifierId = null;


        }
        eObjMTTIdentifier.setIdentifierId( DWLFunctionUtils.getLongFromString(newIdentifierId) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the identifierSubType attribute.
     * 
     * @generated
     */
    public String getIdentifierSubType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTIdentifier.getIdentifierSub());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the identifierSubType attribute.
     * 
     * @param newIdentifierSubType
     *     The new value of identifierSubType.
     * @generated
     */
    public void setIdentifierSubType( String newIdentifierSubType ) throws Exception {
        metaDataMap.put("IdentifierSubType", newIdentifierSubType);

        if (newIdentifierSubType == null || newIdentifierSubType.equals("")) {
            newIdentifierSubType = null;


        }
        eObjMTTIdentifier.setIdentifierSub( DWLFunctionUtils.getLongFromString(newIdentifierSubType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the identifierSubValue attribute.
     * 
     * @generated
     */
    public String getIdentifierSubValue (){
      return identifierSubValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the identifierSubValue attribute.
     * 
     * @param newIdentifierSubValue
     *     The new value of identifierSubValue.
     * @generated
     */
    public void setIdentifierSubValue( String newIdentifierSubValue ) throws Exception {
        metaDataMap.put("IdentifierSubValue", newIdentifierSubValue);

        if (newIdentifierSubValue == null || newIdentifierSubValue.equals("")) {
            newIdentifierSubValue = null;


        }
        identifierSubValue = newIdentifierSubValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the startDate attribute.
     * 
     * @generated
     */
    public String getStartDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjMTTIdentifier.getStartDate());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the startDate attribute.
     * 
     * @param newStartDate
     *     The new value of startDate.
     * @generated
     */
    public void setStartDate( String newStartDate ) throws Exception {
        metaDataMap.put("StartDate", newStartDate);
       	isValidStartDate = true;

        if (newStartDate == null || newStartDate.equals("")) {
            newStartDate = null;
            eObjMTTIdentifier.setStartDate(null);


        }
    else {
        	if (DateValidator.validates(newStartDate)) {
           		eObjMTTIdentifier.setStartDate(DateFormatter.getStartDateTimestamp(newStartDate));
            	metaDataMap.put("StartDate", getStartDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("StartDate") != null) {
                    	metaDataMap.put("StartDate", "");
                	}
                	isValidStartDate = false;
                	eObjMTTIdentifier.setStartDate(null);
            	}
        	}
        }
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the endDate attribute.
     * 
     * @generated
     */
    public String getEndDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjMTTIdentifier.getEndDate());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the endDate attribute.
     * 
     * @param newEndDate
     *     The new value of endDate.
     * @generated
     */
    public void setEndDate( String newEndDate ) throws Exception {
        metaDataMap.put("EndDate", newEndDate);
       	isValidEndDate = true;

        if (newEndDate == null || newEndDate.equals("")) {
            newEndDate = null;
            eObjMTTIdentifier.setEndDate(null);


        }
    else {
        	if (DateValidator.validates(newEndDate)) {
           		eObjMTTIdentifier.setEndDate(DateFormatter.getStartDateTimestamp(newEndDate));
            	metaDataMap.put("EndDate", getEndDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("EndDate") != null) {
                    	metaDataMap.put("EndDate", "");
                	}
                	isValidEndDate = false;
                	eObjMTTIdentifier.setEndDate(null);
            	}
        	}
        }
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the expiryDate attribute.
     * 
     * @generated
     */
    public String getExpiryDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjMTTIdentifier.getExpiryDate());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the expiryDate attribute.
     * 
     * @param newExpiryDate
     *     The new value of expiryDate.
     * @generated
     */
    public void setExpiryDate( String newExpiryDate ) throws Exception {
        metaDataMap.put("ExpiryDate", newExpiryDate);
       	isValidExpiryDate = true;

        if (newExpiryDate == null || newExpiryDate.equals("")) {
            newExpiryDate = null;
            eObjMTTIdentifier.setExpiryDate(null);


        }
    else {
        	if (DateValidator.validates(newExpiryDate)) {
           		eObjMTTIdentifier.setExpiryDate(DateFormatter.getStartDateTimestamp(newExpiryDate));
            	metaDataMap.put("ExpiryDate", getExpiryDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("ExpiryDate") != null) {
                    	metaDataMap.put("ExpiryDate", "");
                	}
                	isValidExpiryDate = false;
                	eObjMTTIdentifier.setExpiryDate(null);
            	}
        	}
        }
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the description attribute.
     * 
     * @generated
     */
    public String getDescription (){
   
        return eObjMTTIdentifier.getDescription();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the description attribute.
     * 
     * @param newDescription
     *     The new value of description.
     * @generated
     */
    public void setDescription( String newDescription ) throws Exception {
        metaDataMap.put("Description", newDescription);

        if (newDescription == null || newDescription.equals("")) {
            newDescription = null;


        }
        eObjMTTIdentifier.setDescription( newDescription );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getMTTIdentifierLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjMTTIdentifier.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getMTTIdentifierLastUpdateUser() {
        return eObjMTTIdentifier.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getMTTIdentifierLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjMTTIdentifier.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setMTTIdentifierLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("MTTIdentifierLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjMTTIdentifier.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setMTTIdentifierLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("MTTIdentifierLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjMTTIdentifier.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setMTTIdentifierLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("MTTIdentifierLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjMTTIdentifier.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTIdentifierHistActionCode history attribute.
     *
     * @generated
     */
    public String getMTTIdentifierHistActionCode() {
        return eObjMTTIdentifier.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTIdentifierHistActionCode history attribute.
     *
     * @param aMTTIdentifierHistActionCode
     *     The new value of MTTIdentifierHistActionCode.
     * @generated
     */
    public void setMTTIdentifierHistActionCode(String aMTTIdentifierHistActionCode) {
        metaDataMap.put("MTTIdentifierHistActionCode", aMTTIdentifierHistActionCode);

        if ((aMTTIdentifierHistActionCode == null) || aMTTIdentifierHistActionCode.equals("")) {
            aMTTIdentifierHistActionCode = null;
        }
        eObjMTTIdentifier.setHistActionCode(aMTTIdentifierHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTIdentifierHistCreateDate history attribute.
     *
     * @generated
     */
    public String getMTTIdentifierHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjMTTIdentifier.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTIdentifierHistCreateDate history attribute.
     *
     * @param aMTTIdentifierHistCreateDate
     *     The new value of MTTIdentifierHistCreateDate.
     * @generated
     */
    public void setMTTIdentifierHistCreateDate(String aMTTIdentifierHistCreateDate) throws Exception{
        metaDataMap.put("MTTIdentifierHistCreateDate", aMTTIdentifierHistCreateDate);

        if ((aMTTIdentifierHistCreateDate == null) || aMTTIdentifierHistCreateDate.equals("")) {
            aMTTIdentifierHistCreateDate = null;
        }

        eObjMTTIdentifier.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aMTTIdentifierHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTIdentifierHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getMTTIdentifierHistCreatedBy() {
        return eObjMTTIdentifier.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTIdentifierHistCreatedBy history attribute.
     *
     * @param aMTTIdentifierHistCreatedBy
     *     The new value of MTTIdentifierHistCreatedBy.
     * @generated
     */
    public void setMTTIdentifierHistCreatedBy(String aMTTIdentifierHistCreatedBy) {
        metaDataMap.put("MTTIdentifierHistCreatedBy", aMTTIdentifierHistCreatedBy);

        if ((aMTTIdentifierHistCreatedBy == null) || aMTTIdentifierHistCreatedBy.equals("")) {
            aMTTIdentifierHistCreatedBy = null;
        }

        eObjMTTIdentifier.setHistCreatedBy(aMTTIdentifierHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTIdentifierHistEndDate history attribute.
     *
     * @generated
     */
    public String getMTTIdentifierHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjMTTIdentifier.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTIdentifierHistEndDate history attribute.
     *
     * @param aMTTIdentifierHistEndDate
     *     The new value of MTTIdentifierHistEndDate.
     * @generated
     */
    public void setMTTIdentifierHistEndDate(String aMTTIdentifierHistEndDate) throws Exception{
        metaDataMap.put("MTTIdentifierHistEndDate", aMTTIdentifierHistEndDate);

        if ((aMTTIdentifierHistEndDate == null) || aMTTIdentifierHistEndDate.equals("")) {
            aMTTIdentifierHistEndDate = null;
        }
        eObjMTTIdentifier.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aMTTIdentifierHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTIdentifierHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getMTTIdentifierHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjMTTIdentifier.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTIdentifierHistoryIdPK history attribute.
     *
     * @param aMTTIdentifierHistoryIdPK
     *     The new value of MTTIdentifierHistoryIdPK.
     * @generated
     */
    public void setMTTIdentifierHistoryIdPK(String aMTTIdentifierHistoryIdPK) {
        metaDataMap.put("MTTIdentifierHistoryIdPK", aMTTIdentifierHistoryIdPK);

        if ((aMTTIdentifierHistoryIdPK == null) || aMTTIdentifierHistoryIdPK.equals("")) {
            aMTTIdentifierHistoryIdPK = null;
        }
        eObjMTTIdentifier.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aMTTIdentifierHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjMTTIdentifier.getMTTIdentifierIdPk() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(MTTDBCustomComponentID.MTTIDENTIFIER_BOBJ).longValue());
                err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.MTTIDENTIFIER_MTTIDENTIFIERIDPK_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity MTTIdentifier, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjMTTIdentifier.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(MTTDBCustomComponentID.MTTIDENTIFIER_BOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity MTTIdentifier, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        MTTDBCustom comp = null;
        try {
        
      comp = (MTTDBCustom)TCRMClassFactory.getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  MTTDBCustomComponentID.MTTIDENTIFIER_BOBJ, 
                                  "DIERR",
                                  MTTDBCustomErrorReasonCode.MTTIDENTIFIER_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
        }
        
        comp.loadBeforeImage(this);
    logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_IdentifierId(status);
    		controllerValidation_IdentifierSub(status);
    		controllerValidation_StartDate(status);
    		controllerValidation_EndDate(status);
    		controllerValidation_ExpiryDate(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_IdentifierId(status);
    		componentValidation_IdentifierSub(status);
    		componentValidation_StartDate(status);
    		componentValidation_EndDate(status);
    		componentValidation_ExpiryDate(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "IdentifierId"
     *
     * @generated
     */
  private void componentValidation_IdentifierId(DWLStatus status) {
  
            boolean isIdentifierIdNull = (eObjMTTIdentifier.getIdentifierId() == null);
            if (isIdentifierIdNull) {
                DWLError err = createDWLError("MTTIdentifier", "IdentifierId", MTTDBCustomErrorReasonCode.MTTIDENTIFIER_IDENTIFIERID_NULL);
                status.addError(err); 
            }
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "IdentifierSub"
     *
     * @generated
     */
  private void componentValidation_IdentifierSub(DWLStatus status) {
  
      //persistent code type
            boolean isIdentifierSubNull = false;
            if ((eObjMTTIdentifier.getIdentifierSub() == null) &&
               ((getIdentifierSubValue() == null) || 
                 getIdentifierSubValue().trim().equals(""))) {
                isIdentifierSubNull = true;
            }
            if (isIdentifierSubNull) {
                DWLError err = createDWLError("MTTIdentifier", "IdentifierSub", MTTDBCustomErrorReasonCode.MTTIDENTIFIER_IDENTIFIERSUB_NULL);
                status.addError(err); 
            }
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
  private void componentValidation_StartDate(DWLStatus status) {
  
            boolean isStartDateNull = (eObjMTTIdentifier.getStartDate() == null);
            if (isStartDateNull) {
                DWLError err = createDWLError("MTTIdentifier", "StartDate", MTTDBCustomErrorReasonCode.MTTIDENTIFIER_STARTDATE_NULL);
                status.addError(err); 
            }
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
  private void componentValidation_EndDate(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "ExpiryDate"
     *
     * @generated
     */
  private void componentValidation_ExpiryDate(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "IdentifierId"
     *
     * @generated
     */
  private void controllerValidation_IdentifierId(DWLStatus status) throws Exception {
  
            boolean isIdentifierIdNull = (eObjMTTIdentifier.getIdentifierId() == null);
            if (isIdentifierIdNull) {
                DWLError err = createDWLError("MTTIdentifier", "IdentifierId", MTTDBCustomErrorReasonCode.MTTIDENTIFIER_IDENTIFIERID_NULL);
                status.addError(err); 
            }
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "IdentifierSub"
     *
     * @generated
     */
  private void controllerValidation_IdentifierSub(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isIdentifierSubNull = false;
            if ((eObjMTTIdentifier.getIdentifierSub() == null) &&
               ((getIdentifierSubValue() == null) || 
                 getIdentifierSubValue().trim().equals(""))) {
                isIdentifierSubNull = true;
            }
            if (isIdentifierSubNull) {
                DWLError err = createDWLError("MTTIdentifier", "IdentifierSub", MTTDBCustomErrorReasonCode.MTTIDENTIFIER_IDENTIFIERSUB_NULL);
                status.addError(err); 
            }
            if (!isIdentifierSubNull) {
                if (checkForInvalidMttidentifierIdentifiersub()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTIDENTIFIER_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTIDENTIFIER_IDENTIFIERSUB).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTIdentifier, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_IdentifierSub " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "StartDate"
     *
     * @generated
     */
  private void controllerValidation_StartDate(DWLStatus status) throws Exception {
  
            boolean isStartDateNull = (eObjMTTIdentifier.getStartDate() == null);
            if (!isValidStartDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(MTTDBCustomComponentID.MTTIDENTIFIER_BOBJ).longValue());
               	err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTIDENTIFIER_STARTDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property StartDate in entity MTTIdentifier, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_StartDate " + infoForLogging);
               	status.addError(err);
            } 
            if (isStartDateNull) {
                DWLError err = createDWLError("MTTIdentifier", "StartDate", MTTDBCustomErrorReasonCode.MTTIDENTIFIER_STARTDATE_NULL);
                status.addError(err); 
            }
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "EndDate"
     *
     * @generated
     */
  private void controllerValidation_EndDate(DWLStatus status) throws Exception {
  
            boolean isEndDateNull = (eObjMTTIdentifier.getEndDate() == null);
            if (!isValidEndDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(MTTDBCustomComponentID.MTTIDENTIFIER_BOBJ).longValue());
               	err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTIDENTIFIER_ENDDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property EndDate in entity MTTIdentifier, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_EndDate " + infoForLogging);
               	status.addError(err);
            } 
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "ExpiryDate"
     *
     * @generated
     */
  private void controllerValidation_ExpiryDate(DWLStatus status) throws Exception {
  
            boolean isExpiryDateNull = (eObjMTTIdentifier.getExpiryDate() == null);
            if (!isValidExpiryDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(MTTDBCustomComponentID.MTTIDENTIFIER_BOBJ).longValue());
               	err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTIDENTIFIER_EXPIRYDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property ExpiryDate in entity MTTIdentifier, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_ExpiryDate " + infoForLogging);
               	status.addError(err);
            } 
    	}


    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(MTTDBCustomComponentID.MTTIDENTIFIER_BOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field IdentifierSub and return true if the error
     * reason INVALID_MTTIDENTIFIER_IDENTIFIERSUB should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttidentifierIdentifiersub() throws Exception {
    logger.finest("ENTER checkForInvalidMttidentifierIdentifiersub()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getIdentifierSubType() );
    String codeValue = getIdentifierSubValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdidentifiersubtp", langId, getIdentifierSubType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdidentifiersubtp", langId, getIdentifierSubType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setIdentifierSubValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttidentifierIdentifiersub() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdidentifiersubtp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setIdentifierSubType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttidentifierIdentifiersub() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdidentifiersubtp", langId, getIdentifierSubType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttidentifierIdentifiersub() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttidentifierIdentifiersub() " + returnValue);
    }
    return notValid;
     }
    



}

