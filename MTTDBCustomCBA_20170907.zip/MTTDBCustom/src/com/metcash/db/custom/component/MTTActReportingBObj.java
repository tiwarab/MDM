
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[92ec317ef74899771a2424aa56421a58]
 */

package com.metcash.db.custom.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;

import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;

import com.metcash.db.custom.constant.MTTDBCustomComponentID;
import com.metcash.db.custom.constant.MTTDBCustomErrorReasonCode;
import com.metcash.db.custom.constant.MTTDBCustomPropertyKeys;

import com.metcash.db.custom.entityObject.EObjMTTActReporting;

import com.metcash.db.custom.interfaces.MTTDBCustom;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>MTTActReportingBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class MTTActReportingBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjMTTActReporting eObjMTTActReporting;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(MTTActReportingBObj.class);
		
 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String channelGroupValue;
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String agentNumberValue;
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String userLocalityValue;
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String customerClassValue;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public MTTActReportingBObj() {
        super();
        init();
        eObjMTTActReporting = new EObjMTTActReporting();
        setComponentID(MTTDBCustomComponentID.MTTACT_REPORTING_BOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("MTTActReportingIdPk", null);
        metaDataMap.put("ChannelGroupType", null);
        metaDataMap.put("ChannelGroupValue", null);
        metaDataMap.put("GovtContractInd", null);
        metaDataMap.put("CapricornNumber", null);
        metaDataMap.put("IGADPerishableInd", null);
        metaDataMap.put("AgentNumberType", null);
        metaDataMap.put("AgentNumberValue", null);
        metaDataMap.put("UserLocalityType", null);
        metaDataMap.put("UserLocalityValue", null);
        metaDataMap.put("CustomerClassType", null);
        metaDataMap.put("CustomerClassValue", null);
        metaDataMap.put("ShowPricesOnWebInd", null);
        metaDataMap.put("ContractId", null);
        metaDataMap.put("ExportCustomerInd", null);
        metaDataMap.put("MTTActReportingHistActionCode", null);
        metaDataMap.put("MTTActReportingHistCreateDate", null);
        metaDataMap.put("MTTActReportingHistCreatedBy", null);
        metaDataMap.put("MTTActReportingHistEndDate", null);
        metaDataMap.put("MTTActReportingHistoryIdPK", null);
        metaDataMap.put("MTTActReportingLastUpdateDate", null);
        metaDataMap.put("MTTActReportingLastUpdateTxId", null);
        metaDataMap.put("MTTActReportingLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("MTTActReportingIdPk", getMTTActReportingIdPk());
            metaDataMap.put("ChannelGroupType", getChannelGroupType());
            metaDataMap.put("ChannelGroupValue", getChannelGroupValue());
            metaDataMap.put("GovtContractInd", getGovtContractInd());
            metaDataMap.put("CapricornNumber", getCapricornNumber());
            metaDataMap.put("IGADPerishableInd", getIGADPerishableInd());
            metaDataMap.put("AgentNumberType", getAgentNumberType());
            metaDataMap.put("AgentNumberValue", getAgentNumberValue());
            metaDataMap.put("UserLocalityType", getUserLocalityType());
            metaDataMap.put("UserLocalityValue", getUserLocalityValue());
            metaDataMap.put("CustomerClassType", getCustomerClassType());
            metaDataMap.put("CustomerClassValue", getCustomerClassValue());
            metaDataMap.put("ShowPricesOnWebInd", getShowPricesOnWebInd());
            metaDataMap.put("ContractId", getContractId());
            metaDataMap.put("ExportCustomerInd", getExportCustomerInd());
            metaDataMap.put("MTTActReportingHistActionCode", getMTTActReportingHistActionCode());
            metaDataMap.put("MTTActReportingHistCreateDate", getMTTActReportingHistCreateDate());
            metaDataMap.put("MTTActReportingHistCreatedBy", getMTTActReportingHistCreatedBy());
            metaDataMap.put("MTTActReportingHistEndDate", getMTTActReportingHistEndDate());
            metaDataMap.put("MTTActReportingHistoryIdPK", getMTTActReportingHistoryIdPK());
            metaDataMap.put("MTTActReportingLastUpdateDate", getMTTActReportingLastUpdateDate());
            metaDataMap.put("MTTActReportingLastUpdateTxId", getMTTActReportingLastUpdateTxId());
            metaDataMap.put("MTTActReportingLastUpdateUser", getMTTActReportingLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjMTTActReporting != null) {
            eObjMTTActReporting.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjMTTActReporting getEObjMTTActReporting() {
        bRequireMapRefresh = true;
        return eObjMTTActReporting;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjMTTActReporting
     *            The eObjMTTActReporting to set.
     * @generated
     */
    public void setEObjMTTActReporting(EObjMTTActReporting eObjMTTActReporting) {
        bRequireMapRefresh = true;
        this.eObjMTTActReporting = eObjMTTActReporting;
        if (this.eObjMTTActReporting != null && this.eObjMTTActReporting.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjMTTActReporting.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the mTTActReportingIdPk attribute.
     * 
     * @generated
     */
    public String getMTTActReportingIdPk (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActReporting.getMTTActReportingIdPk());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the mTTActReportingIdPk attribute.
     * 
     * @param newMTTActReportingIdPk
     *     The new value of mTTActReportingIdPk.
     * @generated
     */
    public void setMTTActReportingIdPk( String newMTTActReportingIdPk ) throws Exception {
        metaDataMap.put("MTTActReportingIdPk", newMTTActReportingIdPk);

        if (newMTTActReportingIdPk == null || newMTTActReportingIdPk.equals("")) {
            newMTTActReportingIdPk = null;


        }
        eObjMTTActReporting.setMTTActReportingIdPk( DWLFunctionUtils.getLongFromString(newMTTActReportingIdPk) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the channelGroupType attribute.
     * 
     * @generated
     */
    public String getChannelGroupType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActReporting.getChannelGroup());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the channelGroupType attribute.
     * 
     * @param newChannelGroupType
     *     The new value of channelGroupType.
     * @generated
     */
    public void setChannelGroupType( String newChannelGroupType ) throws Exception {
        metaDataMap.put("ChannelGroupType", newChannelGroupType);

        if (newChannelGroupType == null || newChannelGroupType.equals("")) {
            newChannelGroupType = null;


        }
        eObjMTTActReporting.setChannelGroup( DWLFunctionUtils.getLongFromString(newChannelGroupType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the channelGroupValue attribute.
     * 
     * @generated
     */
    public String getChannelGroupValue (){
      return channelGroupValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the channelGroupValue attribute.
     * 
     * @param newChannelGroupValue
     *     The new value of channelGroupValue.
     * @generated
     */
    public void setChannelGroupValue( String newChannelGroupValue ) throws Exception {
        metaDataMap.put("ChannelGroupValue", newChannelGroupValue);

        if (newChannelGroupValue == null || newChannelGroupValue.equals("")) {
            newChannelGroupValue = null;


        }
        channelGroupValue = newChannelGroupValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the govtContractInd attribute.
     * 
     * @generated
     */
    public String getGovtContractInd (){
   
        return eObjMTTActReporting.getGovtContractInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the govtContractInd attribute.
     * 
     * @param newGovtContractInd
     *     The new value of govtContractInd.
     * @generated
     */
    public void setGovtContractInd( String newGovtContractInd ) throws Exception {
        metaDataMap.put("GovtContractInd", newGovtContractInd);

        if (newGovtContractInd == null || newGovtContractInd.equals("")) {
            newGovtContractInd = null;


        }
        eObjMTTActReporting.setGovtContractInd( newGovtContractInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the capricornNumber attribute.
     * 
     * @generated
     */
    public String getCapricornNumber (){
   
        return DWLFunctionUtils.getStringFromInteger(eObjMTTActReporting.getCapricornNumber());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the capricornNumber attribute.
     * 
     * @param newCapricornNumber
     *     The new value of capricornNumber.
     * @generated
     */
    public void setCapricornNumber( String newCapricornNumber ) throws Exception {
        metaDataMap.put("CapricornNumber", newCapricornNumber);

        if (newCapricornNumber == null || newCapricornNumber.equals("")) {
            newCapricornNumber = null;


        }
        eObjMTTActReporting.setCapricornNumber( DWLFunctionUtils.getIntegerFromString(newCapricornNumber) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the iGADPerishableInd attribute.
     * 
     * @generated
     */
    public String getIGADPerishableInd (){
   
        return eObjMTTActReporting.getIGADPerishableInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the iGADPerishableInd attribute.
     * 
     * @param newIGADPerishableInd
     *     The new value of iGADPerishableInd.
     * @generated
     */
    public void setIGADPerishableInd( String newIGADPerishableInd ) throws Exception {
        metaDataMap.put("IGADPerishableInd", newIGADPerishableInd);

        if (newIGADPerishableInd == null || newIGADPerishableInd.equals("")) {
            newIGADPerishableInd = null;


        }
        eObjMTTActReporting.setIGADPerishableInd( newIGADPerishableInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the agentNumberType attribute.
     * 
     * @generated
     */
    public String getAgentNumberType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActReporting.getAgentNumber());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the agentNumberType attribute.
     * 
     * @param newAgentNumberType
     *     The new value of agentNumberType.
     * @generated
     */
    public void setAgentNumberType( String newAgentNumberType ) throws Exception {
        metaDataMap.put("AgentNumberType", newAgentNumberType);

        if (newAgentNumberType == null || newAgentNumberType.equals("")) {
            newAgentNumberType = null;


        }
        eObjMTTActReporting.setAgentNumber( DWLFunctionUtils.getLongFromString(newAgentNumberType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the agentNumberValue attribute.
     * 
     * @generated
     */
    public String getAgentNumberValue (){
      return agentNumberValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the agentNumberValue attribute.
     * 
     * @param newAgentNumberValue
     *     The new value of agentNumberValue.
     * @generated
     */
    public void setAgentNumberValue( String newAgentNumberValue ) throws Exception {
        metaDataMap.put("AgentNumberValue", newAgentNumberValue);

        if (newAgentNumberValue == null || newAgentNumberValue.equals("")) {
            newAgentNumberValue = null;


        }
        agentNumberValue = newAgentNumberValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the userLocalityType attribute.
     * 
     * @generated
     */
    public String getUserLocalityType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActReporting.getUserLocality());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the userLocalityType attribute.
     * 
     * @param newUserLocalityType
     *     The new value of userLocalityType.
     * @generated
     */
    public void setUserLocalityType( String newUserLocalityType ) throws Exception {
        metaDataMap.put("UserLocalityType", newUserLocalityType);

        if (newUserLocalityType == null || newUserLocalityType.equals("")) {
            newUserLocalityType = null;


        }
        eObjMTTActReporting.setUserLocality( DWLFunctionUtils.getLongFromString(newUserLocalityType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the userLocalityValue attribute.
     * 
     * @generated
     */
    public String getUserLocalityValue (){
      return userLocalityValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the userLocalityValue attribute.
     * 
     * @param newUserLocalityValue
     *     The new value of userLocalityValue.
     * @generated
     */
    public void setUserLocalityValue( String newUserLocalityValue ) throws Exception {
        metaDataMap.put("UserLocalityValue", newUserLocalityValue);

        if (newUserLocalityValue == null || newUserLocalityValue.equals("")) {
            newUserLocalityValue = null;


        }
        userLocalityValue = newUserLocalityValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the customerClassType attribute.
     * 
     * @generated
     */
    public String getCustomerClassType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActReporting.getCustomerClass());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the customerClassType attribute.
     * 
     * @param newCustomerClassType
     *     The new value of customerClassType.
     * @generated
     */
    public void setCustomerClassType( String newCustomerClassType ) throws Exception {
        metaDataMap.put("CustomerClassType", newCustomerClassType);

        if (newCustomerClassType == null || newCustomerClassType.equals("")) {
            newCustomerClassType = null;


        }
        eObjMTTActReporting.setCustomerClass( DWLFunctionUtils.getLongFromString(newCustomerClassType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the customerClassValue attribute.
     * 
     * @generated
     */
    public String getCustomerClassValue (){
      return customerClassValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the customerClassValue attribute.
     * 
     * @param newCustomerClassValue
     *     The new value of customerClassValue.
     * @generated
     */
    public void setCustomerClassValue( String newCustomerClassValue ) throws Exception {
        metaDataMap.put("CustomerClassValue", newCustomerClassValue);

        if (newCustomerClassValue == null || newCustomerClassValue.equals("")) {
            newCustomerClassValue = null;


        }
        customerClassValue = newCustomerClassValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the showPricesOnWebInd attribute.
     * 
     * @generated
     */
    public String getShowPricesOnWebInd (){
   
        return eObjMTTActReporting.getShowPricesOnWebInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the showPricesOnWebInd attribute.
     * 
     * @param newShowPricesOnWebInd
     *     The new value of showPricesOnWebInd.
     * @generated
     */
    public void setShowPricesOnWebInd( String newShowPricesOnWebInd ) throws Exception {
        metaDataMap.put("ShowPricesOnWebInd", newShowPricesOnWebInd);

        if (newShowPricesOnWebInd == null || newShowPricesOnWebInd.equals("")) {
            newShowPricesOnWebInd = null;


        }
        eObjMTTActReporting.setShowPricesOnWebInd( newShowPricesOnWebInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contractId attribute.
     * 
     * @generated
     */
    public String getContractId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActReporting.getContractId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contractId attribute.
     * 
     * @param newContractId
     *     The new value of contractId.
     * @generated
     */
    public void setContractId( String newContractId ) throws Exception {
        metaDataMap.put("ContractId", newContractId);

        if (newContractId == null || newContractId.equals("")) {
            newContractId = null;


        }
        eObjMTTActReporting.setContractId( DWLFunctionUtils.getLongFromString(newContractId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the exportCustomerInd attribute.
     * 
     * @generated
     */
    public String getExportCustomerInd (){
   
        return eObjMTTActReporting.getExportCustomerInd();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the exportCustomerInd attribute.
     * 
     * @param newExportCustomerInd
     *     The new value of exportCustomerInd.
     * @generated
     */
    public void setExportCustomerInd( String newExportCustomerInd ) throws Exception {
        metaDataMap.put("ExportCustomerInd", newExportCustomerInd);

        if (newExportCustomerInd == null || newExportCustomerInd.equals("")) {
            newExportCustomerInd = null;


        }
        eObjMTTActReporting.setExportCustomerInd( newExportCustomerInd );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getMTTActReportingLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjMTTActReporting.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getMTTActReportingLastUpdateUser() {
        return eObjMTTActReporting.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getMTTActReportingLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjMTTActReporting.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setMTTActReportingLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("MTTActReportingLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjMTTActReporting.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setMTTActReportingLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("MTTActReportingLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjMTTActReporting.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setMTTActReportingLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("MTTActReportingLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjMTTActReporting.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTActReportingHistActionCode history attribute.
     *
     * @generated
     */
    public String getMTTActReportingHistActionCode() {
        return eObjMTTActReporting.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTActReportingHistActionCode history attribute.
     *
     * @param aMTTActReportingHistActionCode
     *     The new value of MTTActReportingHistActionCode.
     * @generated
     */
    public void setMTTActReportingHistActionCode(String aMTTActReportingHistActionCode) {
        metaDataMap.put("MTTActReportingHistActionCode", aMTTActReportingHistActionCode);

        if ((aMTTActReportingHistActionCode == null) || aMTTActReportingHistActionCode.equals("")) {
            aMTTActReportingHistActionCode = null;
        }
        eObjMTTActReporting.setHistActionCode(aMTTActReportingHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTActReportingHistCreateDate history attribute.
     *
     * @generated
     */
    public String getMTTActReportingHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjMTTActReporting.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTActReportingHistCreateDate history attribute.
     *
     * @param aMTTActReportingHistCreateDate
     *     The new value of MTTActReportingHistCreateDate.
     * @generated
     */
    public void setMTTActReportingHistCreateDate(String aMTTActReportingHistCreateDate) throws Exception{
        metaDataMap.put("MTTActReportingHistCreateDate", aMTTActReportingHistCreateDate);

        if ((aMTTActReportingHistCreateDate == null) || aMTTActReportingHistCreateDate.equals("")) {
            aMTTActReportingHistCreateDate = null;
        }

        eObjMTTActReporting.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aMTTActReportingHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTActReportingHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getMTTActReportingHistCreatedBy() {
        return eObjMTTActReporting.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTActReportingHistCreatedBy history attribute.
     *
     * @param aMTTActReportingHistCreatedBy
     *     The new value of MTTActReportingHistCreatedBy.
     * @generated
     */
    public void setMTTActReportingHistCreatedBy(String aMTTActReportingHistCreatedBy) {
        metaDataMap.put("MTTActReportingHistCreatedBy", aMTTActReportingHistCreatedBy);

        if ((aMTTActReportingHistCreatedBy == null) || aMTTActReportingHistCreatedBy.equals("")) {
            aMTTActReportingHistCreatedBy = null;
        }

        eObjMTTActReporting.setHistCreatedBy(aMTTActReportingHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTActReportingHistEndDate history attribute.
     *
     * @generated
     */
    public String getMTTActReportingHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjMTTActReporting.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTActReportingHistEndDate history attribute.
     *
     * @param aMTTActReportingHistEndDate
     *     The new value of MTTActReportingHistEndDate.
     * @generated
     */
    public void setMTTActReportingHistEndDate(String aMTTActReportingHistEndDate) throws Exception{
        metaDataMap.put("MTTActReportingHistEndDate", aMTTActReportingHistEndDate);

        if ((aMTTActReportingHistEndDate == null) || aMTTActReportingHistEndDate.equals("")) {
            aMTTActReportingHistEndDate = null;
        }
        eObjMTTActReporting.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aMTTActReportingHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTActReportingHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getMTTActReportingHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjMTTActReporting.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTActReportingHistoryIdPK history attribute.
     *
     * @param aMTTActReportingHistoryIdPK
     *     The new value of MTTActReportingHistoryIdPK.
     * @generated
     */
    public void setMTTActReportingHistoryIdPK(String aMTTActReportingHistoryIdPK) {
        metaDataMap.put("MTTActReportingHistoryIdPK", aMTTActReportingHistoryIdPK);

        if ((aMTTActReportingHistoryIdPK == null) || aMTTActReportingHistoryIdPK.equals("")) {
            aMTTActReportingHistoryIdPK = null;
        }
        eObjMTTActReporting.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aMTTActReportingHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjMTTActReporting.getMTTActReportingIdPk() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_REPORTING_BOBJ).longValue());
                err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.MTTACTREPORTING_MTTACTREPORTINGIDPK_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity MTTActReporting, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjMTTActReporting.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_REPORTING_BOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity MTTActReporting, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        MTTDBCustom comp = null;
        try {
        
      comp = (MTTDBCustom)TCRMClassFactory.getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  MTTDBCustomComponentID.MTTACT_REPORTING_BOBJ, 
                                  "DIERR",
                                  MTTDBCustomErrorReasonCode.MTTACTREPORTING_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
        }
        
        comp.loadBeforeImage(this);
    logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_ChannelGroup(status);
    		controllerValidation_AgentNumber(status);
    		controllerValidation_UserLocality(status);
    		controllerValidation_CustomerClass(status);
    		controllerValidation_ContractId(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_ChannelGroup(status);
    		componentValidation_AgentNumber(status);
    		componentValidation_UserLocality(status);
    		componentValidation_CustomerClass(status);
    		componentValidation_ContractId(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "ChannelGroup"
     *
     * @generated
     */
  private void componentValidation_ChannelGroup(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "AgentNumber"
     *
     * @generated
     */
  private void componentValidation_AgentNumber(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "UserLocality"
     *
     * @generated
     */
  private void componentValidation_UserLocality(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "CustomerClass"
     *
     * @generated
     */
  private void componentValidation_CustomerClass(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "ContractId"
     *
     * @generated
     */
	private void componentValidation_ContractId(DWLStatus status) {
  
            boolean isContractIdNull = (eObjMTTActReporting.getContractId() == null);
            if (isContractIdNull) {
                DWLError err = createDWLError("MTTActReporting", "ContractId", MTTDBCustomErrorReasonCode.MTTACTREPORTING_CONTRACTID_NULL);
                status.addError(err); 
            }
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "ChannelGroup"
     *
     * @generated
     */
  private void controllerValidation_ChannelGroup(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isChannelGroupNull = false;
            if ((eObjMTTActReporting.getChannelGroup() == null) &&
               ((getChannelGroupValue() == null) || 
                 getChannelGroupValue().trim().equals(""))) {
                isChannelGroupNull = true;
            }
            if (!isChannelGroupNull) {
                if (checkForInvalidMttactreportingChannelgroup()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_REPORTING_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTREPORTING_CHANNELGROUP).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTActReporting, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_ChannelGroup " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "AgentNumber"
     *
     * @generated
     */
  private void controllerValidation_AgentNumber(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isAgentNumberNull = false;
            if ((eObjMTTActReporting.getAgentNumber() == null) &&
               ((getAgentNumberValue() == null) || 
                 getAgentNumberValue().trim().equals(""))) {
                isAgentNumberNull = true;
            }
            if (!isAgentNumberNull) {
                if (checkForInvalidMttactreportingAgentnumber()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_REPORTING_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTREPORTING_AGENTNUMBER).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTActReporting, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_AgentNumber " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "UserLocality"
     *
     * @generated
     */
  private void controllerValidation_UserLocality(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isUserLocalityNull = false;
            if ((eObjMTTActReporting.getUserLocality() == null) &&
               ((getUserLocalityValue() == null) || 
                 getUserLocalityValue().trim().equals(""))) {
                isUserLocalityNull = true;
            }
            if (!isUserLocalityNull) {
                if (checkForInvalidMttactreportingUserlocality()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_REPORTING_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTREPORTING_USERLOCALITY).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTActReporting, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_UserLocality " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "CustomerClass"
     *
     * @generated
     */
  private void controllerValidation_CustomerClass(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isCustomerClassNull = false;
            if ((eObjMTTActReporting.getCustomerClass() == null) &&
               ((getCustomerClassValue() == null) || 
                 getCustomerClassValue().trim().equals(""))) {
                isCustomerClassNull = true;
            }
            if (!isCustomerClassNull) {
                if (checkForInvalidMttactreportingCustomerclass()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_REPORTING_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTREPORTING_CUSTOMERCLASS).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTActReporting, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_CustomerClass " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "ContractId"
     *
     * @generated
     */
	private void controllerValidation_ContractId(DWLStatus status) throws Exception {
  
            boolean isContractIdNull = (eObjMTTActReporting.getContractId() == null);
            if (isContractIdNull) {
                DWLError err = createDWLError("MTTActReporting", "ContractId", MTTDBCustomErrorReasonCode.MTTACTREPORTING_CONTRACTID_NULL);
                status.addError(err); 
            }
    	}
    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_REPORTING_BOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field ChannelGroup and return true if the error
     * reason INVALID_MTTACTREPORTING_CHANNELGROUP should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttactreportingChannelgroup() throws Exception {
    logger.finest("ENTER checkForInvalidMttactreportingChannelgroup()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getChannelGroupType() );
    String codeValue = getChannelGroupValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdchannelgrptp", langId, getChannelGroupType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdchannelgrptp", langId, getChannelGroupType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setChannelGroupValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttactreportingChannelgroup() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdchannelgrptp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setChannelGroupType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttactreportingChannelgroup() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdchannelgrptp", langId, getChannelGroupType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttactreportingChannelgroup() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttactreportingChannelgroup() " + returnValue);
    }
    return notValid;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field AgentNumber and return true if the error
     * reason INVALID_MTTACTREPORTING_AGENTNUMBER should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttactreportingAgentnumber() throws Exception {
    logger.finest("ENTER checkForInvalidMttactreportingAgentnumber()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getAgentNumberType() );
    String codeValue = getAgentNumberValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdagentnumtp", langId, getAgentNumberType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdagentnumtp", langId, getAgentNumberType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setAgentNumberValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttactreportingAgentnumber() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdagentnumtp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setAgentNumberType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttactreportingAgentnumber() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdagentnumtp", langId, getAgentNumberType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttactreportingAgentnumber() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttactreportingAgentnumber() " + returnValue);
    }
    return notValid;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field UserLocality and return true if the error
     * reason INVALID_MTTACTREPORTING_USERLOCALITY should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttactreportingUserlocality() throws Exception {
    logger.finest("ENTER checkForInvalidMttactreportingUserlocality()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getUserLocalityType() );
    String codeValue = getUserLocalityValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcduserlocalitytp", langId, getUserLocalityType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcduserlocalitytp", langId, getUserLocalityType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setUserLocalityValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttactreportingUserlocality() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcduserlocalitytp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setUserLocalityType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttactreportingUserlocality() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcduserlocalitytp", langId, getUserLocalityType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttactreportingUserlocality() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttactreportingUserlocality() " + returnValue);
    }
    return notValid;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field CustomerClass and return true if the error
     * reason INVALID_MTTACTREPORTING_CUSTOMERCLASS should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttactreportingCustomerclass() throws Exception {
    logger.finest("ENTER checkForInvalidMttactreportingCustomerclass()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getCustomerClassType() );
    String codeValue = getCustomerClassValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdcusclasstp", langId, getCustomerClassType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdcusclasstp", langId, getCustomerClassType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setCustomerClassValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttactreportingCustomerclass() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdcusclasstp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setCustomerClassType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttactreportingCustomerclass() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdcusclasstp", langId, getCustomerClassType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttactreportingCustomerclass() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttactreportingCustomerclass() " + returnValue);
    }
    return notValid;
     } 
				 



}

