
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[410baa428c0e38ed326390fa4713fdcd]
 */

package com.metcash.db.custom.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;

import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;

import com.metcash.db.custom.constant.MTTDBCustomComponentID;
import com.metcash.db.custom.constant.MTTDBCustomErrorReasonCode;
import com.metcash.db.custom.constant.MTTDBCustomPropertyKeys;

import com.metcash.db.custom.entityObject.EObjMTTActCostCharges;

import com.metcash.db.custom.interfaces.MTTDBCustom;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>MTTActCostChargesBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class MTTActCostChargesBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjMTTActCostCharges eObjMTTActCostCharges;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(MTTActCostChargesBObj.class);
		
 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String costBaseValue;
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String sRPComplicanceValue;
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String brokenCaseCalValue;
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String pSRPValue;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public MTTActCostChargesBObj() {
        super();
        init();
        eObjMTTActCostCharges = new EObjMTTActCostCharges();
        setComponentID(MTTDBCustomComponentID.MTTACT_COST_CHARGES_BOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("MTTActCostChargesIdPk", null);
        metaDataMap.put("ContractId", null);
        metaDataMap.put("CostBaseType", null);
        metaDataMap.put("CostBaseValue", null);
        metaDataMap.put("DirectShipApprovedInd", null);
        metaDataMap.put("DoNotApplyDirectDiscountInd", null);
        metaDataMap.put("SRPComplicanceType", null);
        metaDataMap.put("SRPComplicanceValue", null);
        metaDataMap.put("PriceMatchGapFeeInd", null);
        metaDataMap.put("BrokenCaseUpchargePercentage", null);
        metaDataMap.put("BrokenCaseUpchargeCap", null);
        metaDataMap.put("BrokenCaseUpchargeInd", null);
        metaDataMap.put("BrokenCaseCalType", null);
        metaDataMap.put("BrokenCaseCalValue", null);
        metaDataMap.put("ShelfLabelPricedInd", null);
        metaDataMap.put("PSRPType", null);
        metaDataMap.put("PSRPValue", null);
        metaDataMap.put("AddFRTRecoverySRPInd", null);
        metaDataMap.put("SRPFRTRecoveryValue", null);
        metaDataMap.put("SRPFRTRecoveryDirectValue", null);
        metaDataMap.put("MTTActCostChargesHistActionCode", null);
        metaDataMap.put("MTTActCostChargesHistCreateDate", null);
        metaDataMap.put("MTTActCostChargesHistCreatedBy", null);
        metaDataMap.put("MTTActCostChargesHistEndDate", null);
        metaDataMap.put("MTTActCostChargesHistoryIdPK", null);
        metaDataMap.put("MTTActCostChargesLastUpdateDate", null);
        metaDataMap.put("MTTActCostChargesLastUpdateTxId", null);
        metaDataMap.put("MTTActCostChargesLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("MTTActCostChargesIdPk", getMTTActCostChargesIdPk());
            metaDataMap.put("ContractId", getContractId());
            metaDataMap.put("CostBaseType", getCostBaseType());
            metaDataMap.put("CostBaseValue", getCostBaseValue());
            metaDataMap.put("DirectShipApprovedInd", getDirectShipApprovedInd());
            metaDataMap.put("DoNotApplyDirectDiscountInd", getDoNotApplyDirectDiscountInd());
            metaDataMap.put("SRPComplicanceType", getSRPComplicanceType());
            metaDataMap.put("SRPComplicanceValue", getSRPComplicanceValue());
            metaDataMap.put("PriceMatchGapFeeInd", getPriceMatchGapFeeInd());
            metaDataMap.put("BrokenCaseUpchargePercentage", getBrokenCaseUpchargePercentage());
            metaDataMap.put("BrokenCaseUpchargeCap", getBrokenCaseUpchargeCap());
            metaDataMap.put("BrokenCaseUpchargeInd", getBrokenCaseUpchargeInd());
            metaDataMap.put("BrokenCaseCalType", getBrokenCaseCalType());
            metaDataMap.put("BrokenCaseCalValue", getBrokenCaseCalValue());
            metaDataMap.put("ShelfLabelPricedInd", getShelfLabelPricedInd());
            metaDataMap.put("PSRPType", getPSRPType());
            metaDataMap.put("PSRPValue", getPSRPValue());
            metaDataMap.put("AddFRTRecoverySRPInd", getAddFRTRecoverySRPInd());
            metaDataMap.put("SRPFRTRecoveryValue", getSRPFRTRecoveryValue());
            metaDataMap.put("SRPFRTRecoveryDirectValue", getSRPFRTRecoveryDirectValue());
            metaDataMap.put("MTTActCostChargesHistActionCode", getMTTActCostChargesHistActionCode());
            metaDataMap.put("MTTActCostChargesHistCreateDate", getMTTActCostChargesHistCreateDate());
            metaDataMap.put("MTTActCostChargesHistCreatedBy", getMTTActCostChargesHistCreatedBy());
            metaDataMap.put("MTTActCostChargesHistEndDate", getMTTActCostChargesHistEndDate());
            metaDataMap.put("MTTActCostChargesHistoryIdPK", getMTTActCostChargesHistoryIdPK());
            metaDataMap.put("MTTActCostChargesLastUpdateDate", getMTTActCostChargesLastUpdateDate());
            metaDataMap.put("MTTActCostChargesLastUpdateTxId", getMTTActCostChargesLastUpdateTxId());
            metaDataMap.put("MTTActCostChargesLastUpdateUser", getMTTActCostChargesLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjMTTActCostCharges != null) {
            eObjMTTActCostCharges.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjMTTActCostCharges getEObjMTTActCostCharges() {
        bRequireMapRefresh = true;
        return eObjMTTActCostCharges;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjMTTActCostCharges
     *            The eObjMTTActCostCharges to set.
     * @generated
     */
    public void setEObjMTTActCostCharges(EObjMTTActCostCharges eObjMTTActCostCharges) {
        bRequireMapRefresh = true;
        this.eObjMTTActCostCharges = eObjMTTActCostCharges;
        if (this.eObjMTTActCostCharges != null && this.eObjMTTActCostCharges.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjMTTActCostCharges.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the mTTActCostChargesIdPk attribute.
     * 
     * @generated
     */
    public String getMTTActCostChargesIdPk (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActCostCharges.getMTTActCostChargesIdPk());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the mTTActCostChargesIdPk attribute.
     * 
     * @param newMTTActCostChargesIdPk
     *     The new value of mTTActCostChargesIdPk.
     * @generated
     */
    public void setMTTActCostChargesIdPk( String newMTTActCostChargesIdPk ) throws Exception {
        metaDataMap.put("MTTActCostChargesIdPk", newMTTActCostChargesIdPk);

        if (newMTTActCostChargesIdPk == null || newMTTActCostChargesIdPk.equals("")) {
            newMTTActCostChargesIdPk = null;


        }
        eObjMTTActCostCharges.setMTTActCostChargesIdPk( DWLFunctionUtils.getLongFromString(newMTTActCostChargesIdPk) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contractId attribute.
     * 
     * @generated
     */
    public String getContractId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActCostCharges.getContractId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contractId attribute.
     * 
     * @param newContractId
     *     The new value of contractId.
     * @generated
     */
    public void setContractId( String newContractId ) throws Exception {
        metaDataMap.put("ContractId", newContractId);

        if (newContractId == null || newContractId.equals("")) {
            newContractId = null;


        }
        eObjMTTActCostCharges.setContractId( DWLFunctionUtils.getLongFromString(newContractId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the costBaseType attribute.
     * 
     * @generated
     */
    public String getCostBaseType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActCostCharges.getCostBase());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the costBaseType attribute.
     * 
     * @param newCostBaseType
     *     The new value of costBaseType.
     * @generated
     */
    public void setCostBaseType( String newCostBaseType ) throws Exception {
        metaDataMap.put("CostBaseType", newCostBaseType);

        if (newCostBaseType == null || newCostBaseType.equals("")) {
            newCostBaseType = null;


        }
        eObjMTTActCostCharges.setCostBase( DWLFunctionUtils.getLongFromString(newCostBaseType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the costBaseValue attribute.
     * 
     * @generated
     */
    public String getCostBaseValue (){
      return costBaseValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the costBaseValue attribute.
     * 
     * @param newCostBaseValue
     *     The new value of costBaseValue.
     * @generated
     */
    public void setCostBaseValue( String newCostBaseValue ) throws Exception {
        metaDataMap.put("CostBaseValue", newCostBaseValue);

        if (newCostBaseValue == null || newCostBaseValue.equals("")) {
            newCostBaseValue = null;


        }
        costBaseValue = newCostBaseValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the directShipApprovedInd attribute.
     * 
     * @generated
     */
    public String getDirectShipApprovedInd (){
   
        return eObjMTTActCostCharges.getDirectShipApprovedInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the directShipApprovedInd attribute.
     * 
     * @param newDirectShipApprovedInd
     *     The new value of directShipApprovedInd.
     * @generated
     */
    public void setDirectShipApprovedInd( String newDirectShipApprovedInd ) throws Exception {
        metaDataMap.put("DirectShipApprovedInd", newDirectShipApprovedInd);

        if (newDirectShipApprovedInd == null || newDirectShipApprovedInd.equals("")) {
            newDirectShipApprovedInd = null;


        }
        eObjMTTActCostCharges.setDirectShipApprovedInd( newDirectShipApprovedInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the doNotApplyDirectDiscountInd attribute.
     * 
     * @generated
     */
    public String getDoNotApplyDirectDiscountInd (){
   
        return eObjMTTActCostCharges.getDoNotApplyDirectDiscountInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the doNotApplyDirectDiscountInd attribute.
     * 
     * @param newDoNotApplyDirectDiscountInd
     *     The new value of doNotApplyDirectDiscountInd.
     * @generated
     */
    public void setDoNotApplyDirectDiscountInd( String newDoNotApplyDirectDiscountInd ) throws Exception {
        metaDataMap.put("DoNotApplyDirectDiscountInd", newDoNotApplyDirectDiscountInd);

        if (newDoNotApplyDirectDiscountInd == null || newDoNotApplyDirectDiscountInd.equals("")) {
            newDoNotApplyDirectDiscountInd = null;


        }
        eObjMTTActCostCharges.setDoNotApplyDirectDiscountInd( newDoNotApplyDirectDiscountInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sRPComplicanceType attribute.
     * 
     * @generated
     */
    public String getSRPComplicanceType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActCostCharges.getSRPComplicance());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sRPComplicanceType attribute.
     * 
     * @param newSRPComplicanceType
     *     The new value of sRPComplicanceType.
     * @generated
     */
    public void setSRPComplicanceType( String newSRPComplicanceType ) throws Exception {
        metaDataMap.put("SRPComplicanceType", newSRPComplicanceType);

        if (newSRPComplicanceType == null || newSRPComplicanceType.equals("")) {
            newSRPComplicanceType = null;


        }
        eObjMTTActCostCharges.setSRPComplicance( DWLFunctionUtils.getLongFromString(newSRPComplicanceType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sRPComplicanceValue attribute.
     * 
     * @generated
     */
    public String getSRPComplicanceValue (){
      return sRPComplicanceValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sRPComplicanceValue attribute.
     * 
     * @param newSRPComplicanceValue
     *     The new value of sRPComplicanceValue.
     * @generated
     */
    public void setSRPComplicanceValue( String newSRPComplicanceValue ) throws Exception {
        metaDataMap.put("SRPComplicanceValue", newSRPComplicanceValue);

        if (newSRPComplicanceValue == null || newSRPComplicanceValue.equals("")) {
            newSRPComplicanceValue = null;


        }
        sRPComplicanceValue = newSRPComplicanceValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the priceMatchGapFeeInd attribute.
     * 
     * @generated
     */
    public String getPriceMatchGapFeeInd (){
   
        return eObjMTTActCostCharges.getPriceMatchGapFeeInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the priceMatchGapFeeInd attribute.
     * 
     * @param newPriceMatchGapFeeInd
     *     The new value of priceMatchGapFeeInd.
     * @generated
     */
    public void setPriceMatchGapFeeInd( String newPriceMatchGapFeeInd ) throws Exception {
        metaDataMap.put("PriceMatchGapFeeInd", newPriceMatchGapFeeInd);

        if (newPriceMatchGapFeeInd == null || newPriceMatchGapFeeInd.equals("")) {
            newPriceMatchGapFeeInd = null;


        }
        eObjMTTActCostCharges.setPriceMatchGapFeeInd( newPriceMatchGapFeeInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the brokenCaseUpchargePercentage attribute.
     * 
     * @generated
     */
    public String getBrokenCaseUpchargePercentage (){
   
        return DWLFunctionUtils.getStringFromFloat(eObjMTTActCostCharges.getBrokenCaseUpchargePercentage());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the brokenCaseUpchargePercentage attribute.
     * 
     * @param newBrokenCaseUpchargePercentage
     *     The new value of brokenCaseUpchargePercentage.
     * @generated
     */
    public void setBrokenCaseUpchargePercentage( String newBrokenCaseUpchargePercentage ) throws Exception {
        metaDataMap.put("BrokenCaseUpchargePercentage", newBrokenCaseUpchargePercentage);

        if (newBrokenCaseUpchargePercentage == null || newBrokenCaseUpchargePercentage.equals("")) {
            newBrokenCaseUpchargePercentage = null;


        }
        eObjMTTActCostCharges.setBrokenCaseUpchargePercentage( DWLFunctionUtils.getFloatFromString(newBrokenCaseUpchargePercentage) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the brokenCaseUpchargeCap attribute.
     * 
     * @generated
     */
    public String getBrokenCaseUpchargeCap (){
   
        return DWLFunctionUtils.getStringFromFloat(eObjMTTActCostCharges.getBrokenCaseUpchargeCap());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the brokenCaseUpchargeCap attribute.
     * 
     * @param newBrokenCaseUpchargeCap
     *     The new value of brokenCaseUpchargeCap.
     * @generated
     */
    public void setBrokenCaseUpchargeCap( String newBrokenCaseUpchargeCap ) throws Exception {
        metaDataMap.put("BrokenCaseUpchargeCap", newBrokenCaseUpchargeCap);

        if (newBrokenCaseUpchargeCap == null || newBrokenCaseUpchargeCap.equals("")) {
            newBrokenCaseUpchargeCap = null;


        }
        eObjMTTActCostCharges.setBrokenCaseUpchargeCap( DWLFunctionUtils.getFloatFromString(newBrokenCaseUpchargeCap) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the brokenCaseUpchargeInd attribute.
     * 
     * @generated
     */
    public String getBrokenCaseUpchargeInd (){
   
        return eObjMTTActCostCharges.getBrokenCaseUpchargeInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the brokenCaseUpchargeInd attribute.
     * 
     * @param newBrokenCaseUpchargeInd
     *     The new value of brokenCaseUpchargeInd.
     * @generated
     */
    public void setBrokenCaseUpchargeInd( String newBrokenCaseUpchargeInd ) throws Exception {
        metaDataMap.put("BrokenCaseUpchargeInd", newBrokenCaseUpchargeInd);

        if (newBrokenCaseUpchargeInd == null || newBrokenCaseUpchargeInd.equals("")) {
            newBrokenCaseUpchargeInd = null;


        }
        eObjMTTActCostCharges.setBrokenCaseUpchargeInd( newBrokenCaseUpchargeInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the brokenCaseCalType attribute.
     * 
     * @generated
     */
    public String getBrokenCaseCalType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActCostCharges.getBrokenCaseCal());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the brokenCaseCalType attribute.
     * 
     * @param newBrokenCaseCalType
     *     The new value of brokenCaseCalType.
     * @generated
     */
    public void setBrokenCaseCalType( String newBrokenCaseCalType ) throws Exception {
        metaDataMap.put("BrokenCaseCalType", newBrokenCaseCalType);

        if (newBrokenCaseCalType == null || newBrokenCaseCalType.equals("")) {
            newBrokenCaseCalType = null;


        }
        eObjMTTActCostCharges.setBrokenCaseCal( DWLFunctionUtils.getLongFromString(newBrokenCaseCalType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the brokenCaseCalValue attribute.
     * 
     * @generated
     */
    public String getBrokenCaseCalValue (){
      return brokenCaseCalValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the brokenCaseCalValue attribute.
     * 
     * @param newBrokenCaseCalValue
     *     The new value of brokenCaseCalValue.
     * @generated
     */
    public void setBrokenCaseCalValue( String newBrokenCaseCalValue ) throws Exception {
        metaDataMap.put("BrokenCaseCalValue", newBrokenCaseCalValue);

        if (newBrokenCaseCalValue == null || newBrokenCaseCalValue.equals("")) {
            newBrokenCaseCalValue = null;


        }
        brokenCaseCalValue = newBrokenCaseCalValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the shelfLabelPricedInd attribute.
     * 
     * @generated
     */
    public String getShelfLabelPricedInd (){
   
        return eObjMTTActCostCharges.getShelfLabelPricedInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the shelfLabelPricedInd attribute.
     * 
     * @param newShelfLabelPricedInd
     *     The new value of shelfLabelPricedInd.
     * @generated
     */
    public void setShelfLabelPricedInd( String newShelfLabelPricedInd ) throws Exception {
        metaDataMap.put("ShelfLabelPricedInd", newShelfLabelPricedInd);

        if (newShelfLabelPricedInd == null || newShelfLabelPricedInd.equals("")) {
            newShelfLabelPricedInd = null;


        }
        eObjMTTActCostCharges.setShelfLabelPricedInd( newShelfLabelPricedInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the pSRPType attribute.
     * 
     * @generated
     */
    public String getPSRPType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActCostCharges.getPSRP());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the pSRPType attribute.
     * 
     * @param newPSRPType
     *     The new value of pSRPType.
     * @generated
     */
    public void setPSRPType( String newPSRPType ) throws Exception {
        metaDataMap.put("PSRPType", newPSRPType);

        if (newPSRPType == null || newPSRPType.equals("")) {
            newPSRPType = null;


        }
        eObjMTTActCostCharges.setPSRP( DWLFunctionUtils.getLongFromString(newPSRPType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the pSRPValue attribute.
     * 
     * @generated
     */
    public String getPSRPValue (){
      return pSRPValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the pSRPValue attribute.
     * 
     * @param newPSRPValue
     *     The new value of pSRPValue.
     * @generated
     */
    public void setPSRPValue( String newPSRPValue ) throws Exception {
        metaDataMap.put("PSRPValue", newPSRPValue);

        if (newPSRPValue == null || newPSRPValue.equals("")) {
            newPSRPValue = null;


        }
        pSRPValue = newPSRPValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the addFRTRecoverySRPInd attribute.
     * 
     * @generated
     */
    public String getAddFRTRecoverySRPInd (){
   
        return eObjMTTActCostCharges.getAddFRTRecoverySRPInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the addFRTRecoverySRPInd attribute.
     * 
     * @param newAddFRTRecoverySRPInd
     *     The new value of addFRTRecoverySRPInd.
     * @generated
     */
    public void setAddFRTRecoverySRPInd( String newAddFRTRecoverySRPInd ) throws Exception {
        metaDataMap.put("AddFRTRecoverySRPInd", newAddFRTRecoverySRPInd);

        if (newAddFRTRecoverySRPInd == null || newAddFRTRecoverySRPInd.equals("")) {
            newAddFRTRecoverySRPInd = null;


        }
        eObjMTTActCostCharges.setAddFRTRecoverySRPInd( newAddFRTRecoverySRPInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sRPFRTRecoveryValue attribute.
     * 
     * @generated
     */
    public String getSRPFRTRecoveryValue (){
   
        return DWLFunctionUtils.getStringFromFloat(eObjMTTActCostCharges.getSRPFRTRecoveryValue());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sRPFRTRecoveryValue attribute.
     * 
     * @param newSRPFRTRecoveryValue
     *     The new value of sRPFRTRecoveryValue.
     * @generated
     */
    public void setSRPFRTRecoveryValue( String newSRPFRTRecoveryValue ) throws Exception {
        metaDataMap.put("SRPFRTRecoveryValue", newSRPFRTRecoveryValue);

        if (newSRPFRTRecoveryValue == null || newSRPFRTRecoveryValue.equals("")) {
            newSRPFRTRecoveryValue = null;


        }
        eObjMTTActCostCharges.setSRPFRTRecoveryValue( DWLFunctionUtils.getFloatFromString(newSRPFRTRecoveryValue) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sRPFRTRecoveryDirectValue attribute.
     * 
     * @generated
     */
    public String getSRPFRTRecoveryDirectValue (){
   
        return DWLFunctionUtils.getStringFromFloat(eObjMTTActCostCharges.getSRPFRTRecoveryDirectValue());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sRPFRTRecoveryDirectValue attribute.
     * 
     * @param newSRPFRTRecoveryDirectValue
     *     The new value of sRPFRTRecoveryDirectValue.
     * @generated
     */
    public void setSRPFRTRecoveryDirectValue( String newSRPFRTRecoveryDirectValue ) throws Exception {
        metaDataMap.put("SRPFRTRecoveryDirectValue", newSRPFRTRecoveryDirectValue);

        if (newSRPFRTRecoveryDirectValue == null || newSRPFRTRecoveryDirectValue.equals("")) {
            newSRPFRTRecoveryDirectValue = null;


        }
        eObjMTTActCostCharges.setSRPFRTRecoveryDirectValue( DWLFunctionUtils.getFloatFromString(newSRPFRTRecoveryDirectValue) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getMTTActCostChargesLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjMTTActCostCharges.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getMTTActCostChargesLastUpdateUser() {
        return eObjMTTActCostCharges.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getMTTActCostChargesLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjMTTActCostCharges.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setMTTActCostChargesLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("MTTActCostChargesLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjMTTActCostCharges.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setMTTActCostChargesLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("MTTActCostChargesLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjMTTActCostCharges.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setMTTActCostChargesLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("MTTActCostChargesLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjMTTActCostCharges.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTActCostChargesHistActionCode history attribute.
     *
     * @generated
     */
    public String getMTTActCostChargesHistActionCode() {
        return eObjMTTActCostCharges.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTActCostChargesHistActionCode history attribute.
     *
     * @param aMTTActCostChargesHistActionCode
     *     The new value of MTTActCostChargesHistActionCode.
     * @generated
     */
    public void setMTTActCostChargesHistActionCode(String aMTTActCostChargesHistActionCode) {
        metaDataMap.put("MTTActCostChargesHistActionCode", aMTTActCostChargesHistActionCode);

        if ((aMTTActCostChargesHistActionCode == null) || aMTTActCostChargesHistActionCode.equals("")) {
            aMTTActCostChargesHistActionCode = null;
        }
        eObjMTTActCostCharges.setHistActionCode(aMTTActCostChargesHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTActCostChargesHistCreateDate history attribute.
     *
     * @generated
     */
    public String getMTTActCostChargesHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjMTTActCostCharges.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTActCostChargesHistCreateDate history attribute.
     *
     * @param aMTTActCostChargesHistCreateDate
     *     The new value of MTTActCostChargesHistCreateDate.
     * @generated
     */
    public void setMTTActCostChargesHistCreateDate(String aMTTActCostChargesHistCreateDate) throws Exception{
        metaDataMap.put("MTTActCostChargesHistCreateDate", aMTTActCostChargesHistCreateDate);

        if ((aMTTActCostChargesHistCreateDate == null) || aMTTActCostChargesHistCreateDate.equals("")) {
            aMTTActCostChargesHistCreateDate = null;
        }

        eObjMTTActCostCharges.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aMTTActCostChargesHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTActCostChargesHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getMTTActCostChargesHistCreatedBy() {
        return eObjMTTActCostCharges.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTActCostChargesHistCreatedBy history attribute.
     *
     * @param aMTTActCostChargesHistCreatedBy
     *     The new value of MTTActCostChargesHistCreatedBy.
     * @generated
     */
    public void setMTTActCostChargesHistCreatedBy(String aMTTActCostChargesHistCreatedBy) {
        metaDataMap.put("MTTActCostChargesHistCreatedBy", aMTTActCostChargesHistCreatedBy);

        if ((aMTTActCostChargesHistCreatedBy == null) || aMTTActCostChargesHistCreatedBy.equals("")) {
            aMTTActCostChargesHistCreatedBy = null;
        }

        eObjMTTActCostCharges.setHistCreatedBy(aMTTActCostChargesHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTActCostChargesHistEndDate history attribute.
     *
     * @generated
     */
    public String getMTTActCostChargesHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjMTTActCostCharges.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTActCostChargesHistEndDate history attribute.
     *
     * @param aMTTActCostChargesHistEndDate
     *     The new value of MTTActCostChargesHistEndDate.
     * @generated
     */
    public void setMTTActCostChargesHistEndDate(String aMTTActCostChargesHistEndDate) throws Exception{
        metaDataMap.put("MTTActCostChargesHistEndDate", aMTTActCostChargesHistEndDate);

        if ((aMTTActCostChargesHistEndDate == null) || aMTTActCostChargesHistEndDate.equals("")) {
            aMTTActCostChargesHistEndDate = null;
        }
        eObjMTTActCostCharges.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aMTTActCostChargesHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTActCostChargesHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getMTTActCostChargesHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjMTTActCostCharges.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTActCostChargesHistoryIdPK history attribute.
     *
     * @param aMTTActCostChargesHistoryIdPK
     *     The new value of MTTActCostChargesHistoryIdPK.
     * @generated
     */
    public void setMTTActCostChargesHistoryIdPK(String aMTTActCostChargesHistoryIdPK) {
        metaDataMap.put("MTTActCostChargesHistoryIdPK", aMTTActCostChargesHistoryIdPK);

        if ((aMTTActCostChargesHistoryIdPK == null) || aMTTActCostChargesHistoryIdPK.equals("")) {
            aMTTActCostChargesHistoryIdPK = null;
        }
        eObjMTTActCostCharges.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aMTTActCostChargesHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjMTTActCostCharges.getMTTActCostChargesIdPk() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_COST_CHARGES_BOBJ).longValue());
                err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.MTTACTCOSTCHARGES_MTTACTCOSTCHARGESIDPK_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity MTTActCostCharges, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjMTTActCostCharges.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_COST_CHARGES_BOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity MTTActCostCharges, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        MTTDBCustom comp = null;
        try {
        
      comp = (MTTDBCustom)TCRMClassFactory.getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  MTTDBCustomComponentID.MTTACT_COST_CHARGES_BOBJ, 
                                  "DIERR",
                                  MTTDBCustomErrorReasonCode.MTTACTCOSTCHARGES_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
        }
        
        comp.loadBeforeImage(this);
    logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_ContractId(status);
    		controllerValidation_CostBase(status);
    		controllerValidation_SRPComplicance(status);
    		controllerValidation_BrokenCaseCal(status);
    		controllerValidation_PSRP(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_ContractId(status);
    		componentValidation_CostBase(status);
    		componentValidation_SRPComplicance(status);
    		componentValidation_BrokenCaseCal(status);
    		componentValidation_PSRP(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "ContractId"
     *
     * @generated
     */
	private void componentValidation_ContractId(DWLStatus status) {
  
            boolean isContractIdNull = (eObjMTTActCostCharges.getContractId() == null);
            if (isContractIdNull) {
                DWLError err = createDWLError("MTTActCostCharges", "ContractId", MTTDBCustomErrorReasonCode.MTTACTCOSTCHARGES_CONTRACTID_NULL);
                status.addError(err); 
            }
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "CostBase"
     *
     * @generated
     */
  private void componentValidation_CostBase(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "SRPComplicance"
     *
     * @generated
     */
  private void componentValidation_SRPComplicance(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "BrokenCaseCal"
     *
     * @generated
     */
  private void componentValidation_BrokenCaseCal(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "PSRP"
     *
     * @generated
     */
  private void componentValidation_PSRP(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "ContractId"
     *
     * @generated
     */
	private void controllerValidation_ContractId(DWLStatus status) throws Exception {
  
            boolean isContractIdNull = (eObjMTTActCostCharges.getContractId() == null);
            if (isContractIdNull) {
                DWLError err = createDWLError("MTTActCostCharges", "ContractId", MTTDBCustomErrorReasonCode.MTTACTCOSTCHARGES_CONTRACTID_NULL);
                status.addError(err); 
            }
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "CostBase"
     *
     * @generated
     */
  private void controllerValidation_CostBase(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isCostBaseNull = false;
            if ((eObjMTTActCostCharges.getCostBase() == null) &&
               ((getCostBaseValue() == null) || 
                 getCostBaseValue().trim().equals(""))) {
                isCostBaseNull = true;
            }
            if (!isCostBaseNull) {
                if (checkForInvalidMttactcostchargesCostbase()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_COST_CHARGES_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTCOSTCHARGES_COSTBASE).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTActCostCharges, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_CostBase " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "SRPComplicance"
     *
     * @generated
     */
  private void controllerValidation_SRPComplicance(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isSRPComplicanceNull = false;
            if ((eObjMTTActCostCharges.getSRPComplicance() == null) &&
               ((getSRPComplicanceValue() == null) || 
                 getSRPComplicanceValue().trim().equals(""))) {
                isSRPComplicanceNull = true;
            }
            if (!isSRPComplicanceNull) {
                if (checkForInvalidMttactcostchargesSrpcomplicance()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_COST_CHARGES_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTCOSTCHARGES_SRPCOMPLICANCE).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTActCostCharges, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_SRPComplicance " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "BrokenCaseCal"
     *
     * @generated
     */
  private void controllerValidation_BrokenCaseCal(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isBrokenCaseCalNull = false;
            if ((eObjMTTActCostCharges.getBrokenCaseCal() == null) &&
               ((getBrokenCaseCalValue() == null) || 
                 getBrokenCaseCalValue().trim().equals(""))) {
                isBrokenCaseCalNull = true;
            }
            if (!isBrokenCaseCalNull) {
                if (checkForInvalidMttactcostchargesBrokencasecal()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_COST_CHARGES_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTCOSTCHARGES_BROKENCASECAL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTActCostCharges, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_BrokenCaseCal " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "PSRP"
     *
     * @generated
     */
  private void controllerValidation_PSRP(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isPSRPNull = false;
            if ((eObjMTTActCostCharges.getPSRP() == null) &&
               ((getPSRPValue() == null) || 
                 getPSRPValue().trim().equals(""))) {
                isPSRPNull = true;
            }
            if (!isPSRPNull) {
                if (checkForInvalidMttactcostchargesPsrp()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_COST_CHARGES_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTCOSTCHARGES_PSRP).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTActCostCharges, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_PSRP " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_COST_CHARGES_BOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field CostBase and return true if the error reason
     * INVALID_MTTACTCOSTCHARGES_COSTBASE should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttactcostchargesCostbase() throws Exception {
    logger.finest("ENTER checkForInvalidMttactcostchargesCostbase()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getCostBaseType() );
    String codeValue = getCostBaseValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdcostbasetp", langId, getCostBaseType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdcostbasetp", langId, getCostBaseType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setCostBaseValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttactcostchargesCostbase() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdcostbasetp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setCostBaseType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttactcostchargesCostbase() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdcostbasetp", langId, getCostBaseType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttactcostchargesCostbase() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttactcostchargesCostbase() " + returnValue);
    }
    return notValid;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field SRPComplicance and return true if the error
     * reason INVALID_MTTACTCOSTCHARGES_SRPCOMPLICANCE should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttactcostchargesSrpcomplicance() throws Exception {
    logger.finest("ENTER checkForInvalidMttactcostchargesSrpcomplicance()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getSRPComplicanceType() );
    String codeValue = getSRPComplicanceValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdsrpcompliancetp", langId, getSRPComplicanceType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdsrpcompliancetp", langId, getSRPComplicanceType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setSRPComplicanceValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttactcostchargesSrpcomplicance() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdsrpcompliancetp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setSRPComplicanceType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttactcostchargesSrpcomplicance() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdsrpcompliancetp", langId, getSRPComplicanceType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttactcostchargesSrpcomplicance() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttactcostchargesSrpcomplicance() " + returnValue);
    }
    return notValid;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field BrokenCaseCal and return true if the error
     * reason INVALID_MTTACTCOSTCHARGES_BROKENCASECAL should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttactcostchargesBrokencasecal() throws Exception {
    logger.finest("ENTER checkForInvalidMttactcostchargesBrokencasecal()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getBrokenCaseCalType() );
    String codeValue = getBrokenCaseCalValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdbrkncasecalctp", langId, getBrokenCaseCalType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdbrkncasecalctp", langId, getBrokenCaseCalType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setBrokenCaseCalValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttactcostchargesBrokencasecal() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdbrkncasecalctp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setBrokenCaseCalType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttactcostchargesBrokencasecal() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdbrkncasecalctp", langId, getBrokenCaseCalType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttactcostchargesBrokencasecal() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttactcostchargesBrokencasecal() " + returnValue);
    }
    return notValid;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field PSRP and return true if the error reason
     * INVALID_MTTACTCOSTCHARGES_PSRP should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttactcostchargesPsrp() throws Exception {
    logger.finest("ENTER checkForInvalidMttactcostchargesPsrp()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getPSRPType() );
    String codeValue = getPSRPValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdpsrptp", langId, getPSRPType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdpsrptp", langId, getPSRPType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setPSRPValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttactcostchargesPsrp() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdpsrptp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setPSRPType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttactcostchargesPsrp() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdpsrptp", langId, getPSRPType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttactcostchargesPsrp() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttactcostchargesPsrp() " + returnValue);
    }
    return notValid;
     } 
				 



}

