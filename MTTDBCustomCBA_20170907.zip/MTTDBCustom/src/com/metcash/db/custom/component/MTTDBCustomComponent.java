
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[5eaae8bc68165b1797336572219728a9]
 */

package com.metcash.db.custom.component;

import com.dwl.base.DWLControl;
import com.dwl.common.globalization.util.ResourceBundleHelper;
import com.dwl.base.DWLResponse;
import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.error.DWLStatus;
import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.requestHandler.DWLTransaction;
import com.dwl.base.util.DWLFunctionUtils;
import com.dwl.tcrm.common.TCRMErrorCode;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.ibm.mdm.annotations.Component;
import com.ibm.mdm.annotations.TxMetadata;


import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.exception.DWLUpdateException;
import com.dwl.base.requestHandler.DWLTransactionInquiry;
import com.dwl.base.requestHandler.DWLTransactionPersistent;
import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLDateTimeUtilities;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.PaginationUtils;
import com.dwl.bobj.query.BObjQuery;
import com.dwl.bobj.query.BObjQueryException;
import com.dwl.bobj.query.Persistence;
import com.dwl.tcrm.common.TCRMCommonComponent;
import com.dwl.tcrm.common.TCRMControlKeys;
import com.dwl.tcrm.exception.TCRMInsertException;
import com.dwl.tcrm.exception.TCRMReadException;
import com.dwl.tcrm.utilities.FunctionUtils;
import com.dwl.tcrm.utilities.StringUtils;
import com.dwl.tcrm.utilities.TCRMExceptionUtils;
import com.ibm.mdm.common.brokers.BObjPersistenceFactoryBroker;
import com.ibm.mdm.common.brokers.BObjQueryFactoryBroker;
import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;
import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;
import com.metcash.db.custom.bobj.query.MTTActCostChargesBObjQuery;
import com.metcash.db.custom.bobj.query.MTTActCreditTaxBObjQuery;
import com.metcash.db.custom.bobj.query.MTTActFinancialBObjQuery;
import com.metcash.db.custom.bobj.query.MTTActOrderInvoiceBObjQuery;
import com.metcash.db.custom.bobj.query.MTTActReportingBObjQuery;
import com.metcash.db.custom.bobj.query.MTTDBCustomModuleBObjPersistenceFactory;
import com.metcash.db.custom.bobj.query.MTTDBCustomModuleBObjQueryFactory;
import com.metcash.db.custom.bobj.query.MTTIdentifierBObjQuery;
import com.metcash.db.custom.bobj.query.MTTStoreBObjQuery;
import com.metcash.db.custom.component.MTTActCostChargesBObj;
import com.metcash.db.custom.component.MTTActCreditTaxBObj;
import com.metcash.db.custom.component.MTTActFinancialBObj;
import com.metcash.db.custom.component.MTTActOrderInvoiceBObj;
import com.metcash.db.custom.component.MTTActReportingBObj;
import com.metcash.db.custom.component.MTTIdentifierBObj;
import com.metcash.db.custom.component.MTTStoreBObj;
import com.metcash.db.custom.constant.MTTDBCustomComponentID;
import com.metcash.db.custom.constant.MTTDBCustomErrorReasonCode;
import com.metcash.db.custom.constant.ResourceBundleNames;
import com.metcash.db.custom.interfaces.MTTDBCustom;

import java.sql.Timestamp;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * Business component class for handling MTTDBCustom related transactions and
 * inquiries.
 * @generated
 */
 @Component(errorComponentID = MTTDBCustomComponentID.MTTDBCUSTOM_COMPONENT)
public class MTTDBCustomComponent extends TCRMCommonComponent implements MTTDBCustom {
	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
	private final static String EXCEPTION_DUPLICATE_KEY = "Exception_Shared_DuplicateKey";

	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(MTTDBCustomComponent.class);
			
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private IDWLErrorMessage errHandler;
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Default constructor.
     *
     * @generated
     */
    public MTTDBCustomComponent() {
        super();
        errHandler = TCRMClassFactory.getErrorHandler();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the BObjQuery factory class from the configuration.
     * @generated
     **/
    private MTTDBCustomModuleBObjQueryFactory getBObjQueryFactory() throws BObjQueryException{
        return (MTTDBCustomModuleBObjQueryFactory) BObjQueryFactoryBroker.getBObjQueryFactory(MTTDBCustomModuleBObjQueryFactory.class.getName());
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the BObjPersistenceFactory class from the configuration.
     * @generated
     **/
    private MTTDBCustomModuleBObjPersistenceFactory getBObjPersistenceFactory() throws BObjQueryException {
        return (MTTDBCustomModuleBObjPersistenceFactory) BObjPersistenceFactoryBroker.getBObjPersistenceFactory(MTTDBCustomModuleBObjPersistenceFactory.class.getName());
    }
    



	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getMTTActReporting.
     *
     * @param MTTActReportingIdPk
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetMTTActReporting
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.GETMTTACTREPORTING_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetMTTActReporting"
    )
     public DWLResponse getMTTActReporting(String MTTActReportingIdPk,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getMTTActReporting(String MTTActReportingIdPk,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(MTTActReportingIdPk);
        DWLTransaction txObj = new  DWLTransactionInquiry("getMTTActReporting", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getMTTActReporting.";
      logger.finest("getMTTActReporting(String MTTActReportingIdPk,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getMTTActReporting.";
      logger.finest("getMTTActReporting(String MTTActReportingIdPk,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getMTTActReporting(String MTTActReportingIdPk,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a MTTActReporting from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetMTTActReporting(String MTTActReportingIdPk,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, MTTDBCustomComponentID.MTTDBCUSTOM_COMPONENT,
                                                     MTTDBCustomErrorReasonCode.GETMTTACTREPORTING_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createMTTActReportingBObjQuery(MTTActReportingBObjQuery.MTTACT_REPORTING_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(MTTActReportingIdPk));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createMTTActReportingBObjQuery(MTTActReportingBObjQuery.MTTACT_REPORTING_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(MTTActReportingIdPk));
        }


        MTTActReportingBObj o = (MTTActReportingBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveMTTActReportingBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetMTTActReporting(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                MTTDBCustomComponentID.MTTACT_REPORTING_BOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                MTTDBCustomErrorReasonCode.MTTACTREPORTING_MTTACTREPORTINGIDPK_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllMTTReportByID.
     *
     * @param ContractId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllMTTReportByID
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.GETALLMTTREPORTBYID_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetAllMTTReportByID"
    )
     public DWLResponse getAllMTTReportByID(String ContractId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllMTTReportByID(String ContractId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContractId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getAllMTTReportByID", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getAllMTTReportByID.";
      logger.finest("getAllMTTReportByID(String ContractId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getAllMTTReportByID.";
      logger.finest("getAllMTTReportByID(String ContractId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllMTTReportByID(String ContractId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a MTTActReporting from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetAllMTTReportByID(String ContractId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, MTTDBCustomComponentID.MTTDBCUSTOM_COMPONENT,
                                                     MTTDBCustomErrorReasonCode.GETALLMTTREPORTBYID_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createMTTActReportingBObjQuery(MTTActReportingBObjQuery.ALL_MTTREPORT_BY_ID_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContractId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createMTTActReportingBObjQuery(MTTActReportingBObjQuery.ALL_MTTREPORT_BY_ID_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContractId));
        }


        MTTActReportingBObj o = (MTTActReportingBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveMTTActReportingBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetAllMTTReportByID(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addMTTActReporting.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddMTTActReporting
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.ADDMTTACTREPORTING_FAILED
    )
     public DWLResponse addMTTActReporting(MTTActReportingBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addMTTActReporting(MTTActReportingBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addMTTActReporting", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addMTTActReporting.";
      logger.finest("addMTTActReporting(MTTActReportingBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addMTTActReporting.";
      logger.finest("addMTTActReporting(MTTActReportingBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addMTTActReporting(MTTActReportingBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a MTTActReporting to the database.
     *
     * @param theMTTActReportingBObj
     *     The object that contains MTTActReporting attribute values.
     * @return
     *     DWLResponse containing a MTTActReportingBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddMTTActReporting(MTTActReportingBObj theMTTActReportingBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theMTTActReportingBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theMTTActReportingBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theMTTActReportingBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theMTTActReportingBObj.getEObjMTTActReporting().setMTTActReportingIdPk(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theMTTActReportingBObj.getEObjMTTActReporting().setMTTActReportingIdPk(null);
            }
         Persistence theMTTActReportingBObjPersistence = getBObjPersistenceFactory().createMTTActReportingBObjPersistence(MTTActReportingBObjQuery.MTTACT_REPORTING_ADD, theMTTActReportingBObj);
         theMTTActReportingBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theMTTActReportingBObj);
            response.setStatus(theMTTActReportingBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, MTTDBCustomComponentID.MTTDBCUSTOM_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    MTTDBCustomErrorReasonCode.ADDMTTACTREPORTING_FAILED, theMTTActReportingBObj.getControl(), errHandler);
        }
        
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateMTTActReporting.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateMTTActReporting
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.UPDATEMTTACTREPORTING_FAILED
    )
     public DWLResponse updateMTTActReporting(MTTActReportingBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateMTTActReporting(MTTActReportingBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateMTTActReporting", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateMTTActReporting.";
      logger.finest("updateMTTActReporting(MTTActReportingBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateMTTActReporting.";
      logger.finest("updateMTTActReporting(MTTActReportingBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateMTTActReporting(MTTActReportingBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified MTTActReporting with new attribute values.
     *
     * @param theMTTActReportingBObj
     *     The object that contains MTTActReporting attribute values to be
     *     updated
     * @return
     *     DWLResponse containing a MTTActReportingBObj of the updated object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateMTTActReporting(MTTActReportingBObj theMTTActReportingBObj) throws Exception {

        DWLStatus status = theMTTActReportingBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theMTTActReportingBObj.setStatus(status);
        }
        
            // set lastupdatetxid with txnid from dwlcontrol
            theMTTActReportingBObj.getEObjMTTActReporting().setLastUpdateTxId(new Long(theMTTActReportingBObj.getControl().getTxnId()));
         Persistence theMTTActReportingBObjPersistence = getBObjPersistenceFactory().createMTTActReportingBObjPersistence(MTTActReportingBObjQuery.MTTACT_REPORTING_UPDATE, theMTTActReportingBObj);
         theMTTActReportingBObjPersistence.persistUpdate();

        DWLResponse response = createDWLResponse();
        response.setData(theMTTActReportingBObj);
        response.setStatus(theMTTActReportingBObj.getStatus());

        return response;
    }

  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getMTTIdentifier.
     *
     * @param MTTIdentifierIdPk
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetMTTIdentifier
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.GETMTTIDENTIFIER_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetMTTIdentifier"
    )
     public DWLResponse getMTTIdentifier(String MTTIdentifierIdPk,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getMTTIdentifier(String MTTIdentifierIdPk,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(MTTIdentifierIdPk);
        DWLTransaction txObj = new  DWLTransactionInquiry("getMTTIdentifier", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getMTTIdentifier.";
      logger.finest("getMTTIdentifier(String MTTIdentifierIdPk,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getMTTIdentifier.";
      logger.finest("getMTTIdentifier(String MTTIdentifierIdPk,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getMTTIdentifier(String MTTIdentifierIdPk,  DWLControl control) " + returnValue);
    }
        return retObj;
    }
    
    
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a MTTIdentifier from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetMTTIdentifier(String MTTIdentifierIdPk,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, MTTDBCustomComponentID.MTTDBCUSTOM_COMPONENT,
                                                     MTTDBCustomErrorReasonCode.GETMTTIDENTIFIER_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createMTTIdentifierBObjQuery(MTTIdentifierBObjQuery.MTTIDENTIFIER_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(MTTIdentifierIdPk));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createMTTIdentifierBObjQuery(MTTIdentifierBObjQuery.MTTIDENTIFIER_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(MTTIdentifierIdPk));
        }


        MTTIdentifierBObj o = (MTTIdentifierBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveMTTIdentifierBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetMTTIdentifier(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                MTTDBCustomComponentID.MTTIDENTIFIER_BOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                MTTDBCustomErrorReasonCode.MTTIDENTIFIER_MTTIDENTIFIERIDPK_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllMTTIdentifierByID.
     *
     * @param IdentifierId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllMTTIdentifierByID
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.GETALLMTTIDENTIFIERBYID_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetAllMTTIdentifierByID"
    )
     public DWLResponse getAllMTTIdentifierByID(String IdentifierId,  String filter,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllMTTIdentifierByID(String IdentifierId,  String filter,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(IdentifierId);
        params.add(filter);
        DWLTransaction txObj = new  DWLTransactionInquiry("getAllMTTIdentifierByID", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getAllMTTIdentifierByID.";
      logger.finest("getAllMTTIdentifierByID(String IdentifierId,  String filter,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getAllMTTIdentifierByID.";
      logger.finest("getAllMTTIdentifierByID(String IdentifierId,  String filter,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllMTTIdentifierByID(String IdentifierId,  String filter,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a MTTIdentifier from the database.
     * 
     * @generated NOT
     */
    public DWLResponse handleGetAllMTTIdentifierByID(String IdentifierId,  String filter,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, MTTDBCustomComponentID.MTTDBCUSTOM_COMPONENT,
                                                     MTTDBCustomErrorReasonCode.GETALLMTTIDENTIFIERBYID_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createMTTIdentifierBObjQuery(MTTIdentifierBObjQuery.ALL_MTTIDENTIFIER_BY_ID_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(IdentifierId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createMTTIdentifierBObjQuery(MTTIdentifierBObjQuery.ALL_MTTIDENTIFIER_BY_ID_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(IdentifierId));
            bObjQuery.setParameter(1, DWLDateTimeUtilities.getCurrentSystemTime());
        }

        boolean considerForPagination = PaginationUtils
                            .considerForPagintion(MTTIdentifierBObj.class.getName(), control);
        control.setConsiderForPagintionFlag(considerForPagination);

        // set returned object
        List<?> list = bObjQuery.getResults();

        if (list.size() == 0) {
            return null;
        }
    Vector<MTTIdentifierBObj> vector = new Vector<MTTIdentifierBObj>();
        for (Iterator<?> it = list.iterator(); it.hasNext();) {
            MTTIdentifierBObj o = (MTTIdentifierBObj) it.next();
            postRetrieveMTTIdentifierBObj(o, "0", filter, control); 
            vector.add(o);
          
            if (o.getStatus()==null) {
                o.setStatus(status);
            }
            response.addStatus(o.getStatus());
        }
        response.setData(vector);

      return response;
    }

  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetAllMTTIdentifierByID(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addMTTIdentifier.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddMTTIdentifier
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.ADDMTTIDENTIFIER_FAILED
    )
     public DWLResponse addMTTIdentifier(MTTIdentifierBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addMTTIdentifier(MTTIdentifierBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addMTTIdentifier", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addMTTIdentifier.";
      logger.finest("addMTTIdentifier(MTTIdentifierBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addMTTIdentifier.";
      logger.finest("addMTTIdentifier(MTTIdentifierBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addMTTIdentifier(MTTIdentifierBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a MTTIdentifier to the database.
     *
     * @param theMTTIdentifierBObj
     *     The object that contains MTTIdentifier attribute values.
     * @return
     *     DWLResponse containing a MTTIdentifierBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddMTTIdentifier(MTTIdentifierBObj theMTTIdentifierBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theMTTIdentifierBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theMTTIdentifierBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theMTTIdentifierBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theMTTIdentifierBObj.getEObjMTTIdentifier().setMTTIdentifierIdPk(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theMTTIdentifierBObj.getEObjMTTIdentifier().setMTTIdentifierIdPk(null);
            }
         Persistence theMTTIdentifierBObjPersistence = getBObjPersistenceFactory().createMTTIdentifierBObjPersistence(MTTIdentifierBObjQuery.MTTIDENTIFIER_ADD, theMTTIdentifierBObj);
         theMTTIdentifierBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theMTTIdentifierBObj);
            response.setStatus(theMTTIdentifierBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, MTTDBCustomComponentID.MTTDBCUSTOM_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    MTTDBCustomErrorReasonCode.ADDMTTIDENTIFIER_FAILED, theMTTIdentifierBObj.getControl(), errHandler);
        }
        
        return response;
    }
    

	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateMTTIdentifier.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateMTTIdentifier
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.UPDATEMTTIDENTIFIER_FAILED
    )
     public DWLResponse updateMTTIdentifier(MTTIdentifierBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateMTTIdentifier(MTTIdentifierBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateMTTIdentifier", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateMTTIdentifier.";
      logger.finest("updateMTTIdentifier(MTTIdentifierBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateMTTIdentifier.";
      logger.finest("updateMTTIdentifier(MTTIdentifierBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateMTTIdentifier(MTTIdentifierBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified MTTIdentifier with new attribute values.
     *
     * @param theMTTIdentifierBObj
     *     The object that contains MTTIdentifier attribute values to be updated
     * @return
     *     DWLResponse containing a MTTIdentifierBObj of the updated object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateMTTIdentifier(MTTIdentifierBObj theMTTIdentifierBObj) throws Exception {

        DWLStatus status = theMTTIdentifierBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theMTTIdentifierBObj.setStatus(status);
        }
        
            // set lastupdatetxid with txnid from dwlcontrol
            theMTTIdentifierBObj.getEObjMTTIdentifier().setLastUpdateTxId(new Long(theMTTIdentifierBObj.getControl().getTxnId()));
         Persistence theMTTIdentifierBObjPersistence = getBObjPersistenceFactory().createMTTIdentifierBObjPersistence(MTTIdentifierBObjQuery.MTTIDENTIFIER_UPDATE, theMTTIdentifierBObj);
         theMTTIdentifierBObjPersistence.persistUpdate();

        DWLResponse response = createDWLResponse();
        response.setData(theMTTIdentifierBObj);
        response.setStatus(theMTTIdentifierBObj.getStatus());

        return response;
    }



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getMTTStore.
     *
     * @param MTTStoreIdPk
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetMTTStore
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.GETMTTSTORE_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetMTTStore"
    )
     public DWLResponse getMTTStore(String MTTStoreIdPk,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getMTTStore(String MTTStoreIdPk,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(MTTStoreIdPk);
        DWLTransaction txObj = new  DWLTransactionInquiry("getMTTStore", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getMTTStore.";
      logger.finest("getMTTStore(String MTTStoreIdPk,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getMTTStore.";
      logger.finest("getMTTStore(String MTTStoreIdPk,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getMTTStore(String MTTStoreIdPk,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a MTTStore from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetMTTStore(String MTTStoreIdPk,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, MTTDBCustomComponentID.MTTDBCUSTOM_COMPONENT,
                                                     MTTDBCustomErrorReasonCode.GETMTTSTORE_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createMTTStoreBObjQuery(MTTStoreBObjQuery.MTTSTORE_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(MTTStoreIdPk));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createMTTStoreBObjQuery(MTTStoreBObjQuery.MTTSTORE_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(MTTStoreIdPk));
        }


        MTTStoreBObj o = (MTTStoreBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveMTTStoreBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetMTTStore(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                MTTDBCustomComponentID.MTTSTORE_BOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                MTTDBCustomErrorReasonCode.MTTSTORE_MTTSTOREIDPK_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllStoreByID.
     *
     * @param PartyId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllStoreByID
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.GETALLSTOREBYID_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetAllStoreByID"
    )
     public DWLResponse getAllStoreByID(String PartyId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllStoreByID(String PartyId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(PartyId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getAllStoreByID", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getAllStoreByID.";
      logger.finest("getAllStoreByID(String PartyId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getAllStoreByID.";
      logger.finest("getAllStoreByID(String PartyId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllStoreByID(String PartyId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a MTTStore from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetAllStoreByID(String PartyId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, MTTDBCustomComponentID.MTTDBCUSTOM_COMPONENT,
                                                     MTTDBCustomErrorReasonCode.GETALLSTOREBYID_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createMTTStoreBObjQuery(MTTStoreBObjQuery.ALL_STORE_BY_ID_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(PartyId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createMTTStoreBObjQuery(MTTStoreBObjQuery.ALL_STORE_BY_ID_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(PartyId));
        }


        MTTStoreBObj o = (MTTStoreBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveMTTStoreBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetAllStoreByID(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addMTTStore.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddMTTStore
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.ADDMTTSTORE_FAILED
    )
     public DWLResponse addMTTStore(MTTStoreBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addMTTStore(MTTStoreBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addMTTStore", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addMTTStore.";
      logger.finest("addMTTStore(MTTStoreBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addMTTStore.";
      logger.finest("addMTTStore(MTTStoreBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addMTTStore(MTTStoreBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a MTTStore to the database.
     *
     * @param theMTTStoreBObj
     *     The object that contains MTTStore attribute values.
     * @return
     *     DWLResponse containing a MTTStoreBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddMTTStore(MTTStoreBObj theMTTStoreBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theMTTStoreBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theMTTStoreBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theMTTStoreBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theMTTStoreBObj.getEObjMTTStore().setMTTStoreIdPk(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theMTTStoreBObj.getEObjMTTStore().setMTTStoreIdPk(null);
            }
         Persistence theMTTStoreBObjPersistence = getBObjPersistenceFactory().createMTTStoreBObjPersistence(MTTStoreBObjQuery.MTTSTORE_ADD, theMTTStoreBObj);
         theMTTStoreBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theMTTStoreBObj);
            response.setStatus(theMTTStoreBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, MTTDBCustomComponentID.MTTDBCUSTOM_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    MTTDBCustomErrorReasonCode.ADDMTTSTORE_FAILED, theMTTStoreBObj.getControl(), errHandler);
        }
        
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateMTTStore.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateMTTStore
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.UPDATEMTTSTORE_FAILED
    )
     public DWLResponse updateMTTStore(MTTStoreBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateMTTStore(MTTStoreBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateMTTStore", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateMTTStore.";
      logger.finest("updateMTTStore(MTTStoreBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateMTTStore.";
      logger.finest("updateMTTStore(MTTStoreBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateMTTStore(MTTStoreBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified MTTStore with new attribute values.
     *
     * @param theMTTStoreBObj
     *     The object that contains MTTStore attribute values to be updated
     * @return
     *     DWLResponse containing a MTTStoreBObj of the updated object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateMTTStore(MTTStoreBObj theMTTStoreBObj) throws Exception {

        DWLStatus status = theMTTStoreBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theMTTStoreBObj.setStatus(status);
        }
        
            // set lastupdatetxid with txnid from dwlcontrol
            theMTTStoreBObj.getEObjMTTStore().setLastUpdateTxId(new Long(theMTTStoreBObj.getControl().getTxnId()));
         Persistence theMTTStoreBObjPersistence = getBObjPersistenceFactory().createMTTStoreBObjPersistence(MTTStoreBObjQuery.MTTSTORE_UPDATE, theMTTStoreBObj);
         theMTTStoreBObjPersistence.persistUpdate();

        DWLResponse response = createDWLResponse();
        response.setData(theMTTStoreBObj);
        response.setStatus(theMTTStoreBObj.getStatus());

        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getMTTActCreditTax.
     *
     * @param MTTActCreditTaxIdPk
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetMTTActCreditTax
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.GETMTTACTCREDITTAX_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetMTTActCreditTax"
    )
     public DWLResponse getMTTActCreditTax(String MTTActCreditTaxIdPk,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getMTTActCreditTax(String MTTActCreditTaxIdPk,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(MTTActCreditTaxIdPk);
        DWLTransaction txObj = new  DWLTransactionInquiry("getMTTActCreditTax", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getMTTActCreditTax.";
      logger.finest("getMTTActCreditTax(String MTTActCreditTaxIdPk,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getMTTActCreditTax.";
      logger.finest("getMTTActCreditTax(String MTTActCreditTaxIdPk,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getMTTActCreditTax(String MTTActCreditTaxIdPk,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a MTTActCreditTax from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetMTTActCreditTax(String MTTActCreditTaxIdPk,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, MTTDBCustomComponentID.MTTDBCUSTOM_COMPONENT,
                                                     MTTDBCustomErrorReasonCode.GETMTTACTCREDITTAX_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createMTTActCreditTaxBObjQuery(MTTActCreditTaxBObjQuery.MTTACT_CREDIT_TAX_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(MTTActCreditTaxIdPk));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createMTTActCreditTaxBObjQuery(MTTActCreditTaxBObjQuery.MTTACT_CREDIT_TAX_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(MTTActCreditTaxIdPk));
        }


        MTTActCreditTaxBObj o = (MTTActCreditTaxBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveMTTActCreditTaxBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetMTTActCreditTax(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                MTTDBCustomComponentID.MTTACT_CREDIT_TAX_BOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                MTTDBCustomErrorReasonCode.MTTACTCREDITTAX_MTTACTCREDITTAXIDPK_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllMTTCreditTaxByID.
     *
     * @param ContractId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllMTTCreditTaxByID
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.GETALLMTTCREDITTAXBYID_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetAllMTTCreditTaxByID"
    )
     public DWLResponse getAllMTTCreditTaxByID(String ContractId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllMTTCreditTaxByID(String ContractId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContractId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getAllMTTCreditTaxByID", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getAllMTTCreditTaxByID.";
      logger.finest("getAllMTTCreditTaxByID(String ContractId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getAllMTTCreditTaxByID.";
      logger.finest("getAllMTTCreditTaxByID(String ContractId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllMTTCreditTaxByID(String ContractId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a MTTActCreditTax from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetAllMTTCreditTaxByID(String ContractId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, MTTDBCustomComponentID.MTTDBCUSTOM_COMPONENT,
                                                     MTTDBCustomErrorReasonCode.GETALLMTTCREDITTAXBYID_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createMTTActCreditTaxBObjQuery(MTTActCreditTaxBObjQuery.ALL_MTTCREDIT_TAX_BY_ID_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContractId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createMTTActCreditTaxBObjQuery(MTTActCreditTaxBObjQuery.ALL_MTTCREDIT_TAX_BY_ID_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContractId));
        }


        MTTActCreditTaxBObj o = (MTTActCreditTaxBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveMTTActCreditTaxBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetAllMTTCreditTaxByID(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addMTTActCreditTax.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddMTTActCreditTax
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.ADDMTTACTCREDITTAX_FAILED
    )
     public DWLResponse addMTTActCreditTax(MTTActCreditTaxBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addMTTActCreditTax(MTTActCreditTaxBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addMTTActCreditTax", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addMTTActCreditTax.";
      logger.finest("addMTTActCreditTax(MTTActCreditTaxBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addMTTActCreditTax.";
      logger.finest("addMTTActCreditTax(MTTActCreditTaxBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addMTTActCreditTax(MTTActCreditTaxBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a MTTActCreditTax to the database.
     *
     * @param theMTTActCreditTaxBObj
     *     The object that contains MTTActCreditTax attribute values.
     * @return
     *     DWLResponse containing a MTTActCreditTaxBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddMTTActCreditTax(MTTActCreditTaxBObj theMTTActCreditTaxBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theMTTActCreditTaxBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theMTTActCreditTaxBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theMTTActCreditTaxBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theMTTActCreditTaxBObj.getEObjMTTActCreditTax().setMTTActCreditTaxIdPk(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theMTTActCreditTaxBObj.getEObjMTTActCreditTax().setMTTActCreditTaxIdPk(null);
            }
         Persistence theMTTActCreditTaxBObjPersistence = getBObjPersistenceFactory().createMTTActCreditTaxBObjPersistence(MTTActCreditTaxBObjQuery.MTTACT_CREDIT_TAX_ADD, theMTTActCreditTaxBObj);
         theMTTActCreditTaxBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theMTTActCreditTaxBObj);
            response.setStatus(theMTTActCreditTaxBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, MTTDBCustomComponentID.MTTDBCUSTOM_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    MTTDBCustomErrorReasonCode.ADDMTTACTCREDITTAX_FAILED, theMTTActCreditTaxBObj.getControl(), errHandler);
        }
        
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateMTTActCreditTax.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateMTTActCreditTax
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.UPDATEMTTACTCREDITTAX_FAILED
    )
     public DWLResponse updateMTTActCreditTax(MTTActCreditTaxBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateMTTActCreditTax(MTTActCreditTaxBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateMTTActCreditTax", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateMTTActCreditTax.";
      logger.finest("updateMTTActCreditTax(MTTActCreditTaxBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateMTTActCreditTax.";
      logger.finest("updateMTTActCreditTax(MTTActCreditTaxBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateMTTActCreditTax(MTTActCreditTaxBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified MTTActCreditTax with new attribute values.
     *
     * @param theMTTActCreditTaxBObj
     *     The object that contains MTTActCreditTax attribute values to be
     *     updated
     * @return
     *     DWLResponse containing a MTTActCreditTaxBObj of the updated object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateMTTActCreditTax(MTTActCreditTaxBObj theMTTActCreditTaxBObj) throws Exception {

        DWLStatus status = theMTTActCreditTaxBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theMTTActCreditTaxBObj.setStatus(status);
        }
        
            // set lastupdatetxid with txnid from dwlcontrol
            theMTTActCreditTaxBObj.getEObjMTTActCreditTax().setLastUpdateTxId(new Long(theMTTActCreditTaxBObj.getControl().getTxnId()));
         Persistence theMTTActCreditTaxBObjPersistence = getBObjPersistenceFactory().createMTTActCreditTaxBObjPersistence(MTTActCreditTaxBObjQuery.MTTACT_CREDIT_TAX_UPDATE, theMTTActCreditTaxBObj);
         theMTTActCreditTaxBObjPersistence.persistUpdate();

        DWLResponse response = createDWLResponse();
        response.setData(theMTTActCreditTaxBObj);
        response.setStatus(theMTTActCreditTaxBObj.getStatus());

        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getMTTActOrderInvoice.
     *
     * @param MTTActOrderInvoiceIdPk
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetMTTActOrderInvoice
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.GETMTTACTORDERINVOICE_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetMTTActOrderInvoice"
    )
     public DWLResponse getMTTActOrderInvoice(String MTTActOrderInvoiceIdPk,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getMTTActOrderInvoice(String MTTActOrderInvoiceIdPk,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(MTTActOrderInvoiceIdPk);
        DWLTransaction txObj = new  DWLTransactionInquiry("getMTTActOrderInvoice", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getMTTActOrderInvoice.";
      logger.finest("getMTTActOrderInvoice(String MTTActOrderInvoiceIdPk,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getMTTActOrderInvoice.";
      logger.finest("getMTTActOrderInvoice(String MTTActOrderInvoiceIdPk,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getMTTActOrderInvoice(String MTTActOrderInvoiceIdPk,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a MTTActOrderInvoice from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetMTTActOrderInvoice(String MTTActOrderInvoiceIdPk,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, MTTDBCustomComponentID.MTTDBCUSTOM_COMPONENT,
                                                     MTTDBCustomErrorReasonCode.GETMTTACTORDERINVOICE_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createMTTActOrderInvoiceBObjQuery(MTTActOrderInvoiceBObjQuery.MTTACT_ORDER_INVOICE_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(MTTActOrderInvoiceIdPk));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createMTTActOrderInvoiceBObjQuery(MTTActOrderInvoiceBObjQuery.MTTACT_ORDER_INVOICE_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(MTTActOrderInvoiceIdPk));
        }


        MTTActOrderInvoiceBObj o = (MTTActOrderInvoiceBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveMTTActOrderInvoiceBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetMTTActOrderInvoice(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                MTTDBCustomComponentID.MTTACT_ORDER_INVOICE_BOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                MTTDBCustomErrorReasonCode.MTTACTORDERINVOICE_MTTACTORDERINVOICEIDPK_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllMTTOrderInvoiceByID.
     *
     * @param ContractId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllMTTOrderInvoiceByID
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.GETALLMTTORDERINVOICEBYID_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetAllMTTOrderInvoiceByID"
    )
     public DWLResponse getAllMTTOrderInvoiceByID(String ContractId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllMTTOrderInvoiceByID(String ContractId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContractId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getAllMTTOrderInvoiceByID", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getAllMTTOrderInvoiceByID.";
      logger.finest("getAllMTTOrderInvoiceByID(String ContractId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getAllMTTOrderInvoiceByID.";
      logger.finest("getAllMTTOrderInvoiceByID(String ContractId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllMTTOrderInvoiceByID(String ContractId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a MTTActOrderInvoice from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetAllMTTOrderInvoiceByID(String ContractId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, MTTDBCustomComponentID.MTTDBCUSTOM_COMPONENT,
                                                     MTTDBCustomErrorReasonCode.GETALLMTTORDERINVOICEBYID_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createMTTActOrderInvoiceBObjQuery(MTTActOrderInvoiceBObjQuery.ALL_MTTORDER_INVOICE_BY_ID_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContractId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createMTTActOrderInvoiceBObjQuery(MTTActOrderInvoiceBObjQuery.ALL_MTTORDER_INVOICE_BY_ID_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContractId));
        }


        MTTActOrderInvoiceBObj o = (MTTActOrderInvoiceBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveMTTActOrderInvoiceBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetAllMTTOrderInvoiceByID(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addMTTActOrderInvoice.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddMTTActOrderInvoice
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.ADDMTTACTORDERINVOICE_FAILED
    )
     public DWLResponse addMTTActOrderInvoice(MTTActOrderInvoiceBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addMTTActOrderInvoice(MTTActOrderInvoiceBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addMTTActOrderInvoice", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addMTTActOrderInvoice.";
      logger.finest("addMTTActOrderInvoice(MTTActOrderInvoiceBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addMTTActOrderInvoice.";
      logger.finest("addMTTActOrderInvoice(MTTActOrderInvoiceBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addMTTActOrderInvoice(MTTActOrderInvoiceBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a MTTActOrderInvoice to the database.
     *
     * @param theMTTActOrderInvoiceBObj
     *     The object that contains MTTActOrderInvoice attribute values.
     * @return
     *     DWLResponse containing a MTTActOrderInvoiceBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddMTTActOrderInvoice(MTTActOrderInvoiceBObj theMTTActOrderInvoiceBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theMTTActOrderInvoiceBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theMTTActOrderInvoiceBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theMTTActOrderInvoiceBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theMTTActOrderInvoiceBObj.getEObjMTTActOrderInvoice().setMTTActOrderInvoiceIdPk(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theMTTActOrderInvoiceBObj.getEObjMTTActOrderInvoice().setMTTActOrderInvoiceIdPk(null);
            }
         Persistence theMTTActOrderInvoiceBObjPersistence = getBObjPersistenceFactory().createMTTActOrderInvoiceBObjPersistence(MTTActOrderInvoiceBObjQuery.MTTACT_ORDER_INVOICE_ADD, theMTTActOrderInvoiceBObj);
         theMTTActOrderInvoiceBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theMTTActOrderInvoiceBObj);
            response.setStatus(theMTTActOrderInvoiceBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, MTTDBCustomComponentID.MTTDBCUSTOM_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    MTTDBCustomErrorReasonCode.ADDMTTACTORDERINVOICE_FAILED, theMTTActOrderInvoiceBObj.getControl(), errHandler);
        }
        
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateMTTActOrderInvoice.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateMTTActOrderInvoice
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.UPDATEMTTACTORDERINVOICE_FAILED
    )
     public DWLResponse updateMTTActOrderInvoice(MTTActOrderInvoiceBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateMTTActOrderInvoice(MTTActOrderInvoiceBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateMTTActOrderInvoice", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateMTTActOrderInvoice.";
      logger.finest("updateMTTActOrderInvoice(MTTActOrderInvoiceBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateMTTActOrderInvoice.";
      logger.finest("updateMTTActOrderInvoice(MTTActOrderInvoiceBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateMTTActOrderInvoice(MTTActOrderInvoiceBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified MTTActOrderInvoice with new attribute values.
     *
     * @param theMTTActOrderInvoiceBObj
     *     The object that contains MTTActOrderInvoice attribute values to be
     *     updated
     * @return
     *     DWLResponse containing a MTTActOrderInvoiceBObj of the updated
     *     object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateMTTActOrderInvoice(MTTActOrderInvoiceBObj theMTTActOrderInvoiceBObj) throws Exception {

        DWLStatus status = theMTTActOrderInvoiceBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theMTTActOrderInvoiceBObj.setStatus(status);
        }
        
            // set lastupdatetxid with txnid from dwlcontrol
            theMTTActOrderInvoiceBObj.getEObjMTTActOrderInvoice().setLastUpdateTxId(new Long(theMTTActOrderInvoiceBObj.getControl().getTxnId()));
         Persistence theMTTActOrderInvoiceBObjPersistence = getBObjPersistenceFactory().createMTTActOrderInvoiceBObjPersistence(MTTActOrderInvoiceBObjQuery.MTTACT_ORDER_INVOICE_UPDATE, theMTTActOrderInvoiceBObj);
         theMTTActOrderInvoiceBObjPersistence.persistUpdate();

        DWLResponse response = createDWLResponse();
        response.setData(theMTTActOrderInvoiceBObj);
        response.setStatus(theMTTActOrderInvoiceBObj.getStatus());

        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getMTTActCostCharges.
     *
     * @param MTTActCostChargesIdPk
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetMTTActCostCharges
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.GETMTTACTCOSTCHARGES_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetMTTActCostCharges"
    )
     public DWLResponse getMTTActCostCharges(String MTTActCostChargesIdPk,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getMTTActCostCharges(String MTTActCostChargesIdPk,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(MTTActCostChargesIdPk);
        DWLTransaction txObj = new  DWLTransactionInquiry("getMTTActCostCharges", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getMTTActCostCharges.";
      logger.finest("getMTTActCostCharges(String MTTActCostChargesIdPk,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getMTTActCostCharges.";
      logger.finest("getMTTActCostCharges(String MTTActCostChargesIdPk,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getMTTActCostCharges(String MTTActCostChargesIdPk,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a MTTActCostCharges from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetMTTActCostCharges(String MTTActCostChargesIdPk,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, MTTDBCustomComponentID.MTTDBCUSTOM_COMPONENT,
                                                     MTTDBCustomErrorReasonCode.GETMTTACTCOSTCHARGES_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createMTTActCostChargesBObjQuery(MTTActCostChargesBObjQuery.MTTACT_COST_CHARGES_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(MTTActCostChargesIdPk));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createMTTActCostChargesBObjQuery(MTTActCostChargesBObjQuery.MTTACT_COST_CHARGES_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(MTTActCostChargesIdPk));
        }


        MTTActCostChargesBObj o = (MTTActCostChargesBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveMTTActCostChargesBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetMTTActCostCharges(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                MTTDBCustomComponentID.MTTACT_COST_CHARGES_BOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                MTTDBCustomErrorReasonCode.MTTACTCOSTCHARGES_MTTACTCOSTCHARGESIDPK_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllMTTActCostChargesByID.
     *
     * @param ContractId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllMTTActCostChargesByID
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.GETALLMTTACTCOSTCHARGESBYID_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetAllMTTActCostChargesByID"
    )
     public DWLResponse getAllMTTActCostChargesByID(String ContractId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllMTTActCostChargesByID(String ContractId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContractId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getAllMTTActCostChargesByID", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getAllMTTActCostChargesByID.";
      logger.finest("getAllMTTActCostChargesByID(String ContractId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getAllMTTActCostChargesByID.";
      logger.finest("getAllMTTActCostChargesByID(String ContractId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllMTTActCostChargesByID(String ContractId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a MTTActCostCharges from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetAllMTTActCostChargesByID(String ContractId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, MTTDBCustomComponentID.MTTDBCUSTOM_COMPONENT,
                                                     MTTDBCustomErrorReasonCode.GETALLMTTACTCOSTCHARGESBYID_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createMTTActCostChargesBObjQuery(MTTActCostChargesBObjQuery.ALL_MTTACT_COST_CHARGES_BY_ID_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContractId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createMTTActCostChargesBObjQuery(MTTActCostChargesBObjQuery.ALL_MTTACT_COST_CHARGES_BY_ID_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContractId));
        }


        MTTActCostChargesBObj o = (MTTActCostChargesBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveMTTActCostChargesBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetAllMTTActCostChargesByID(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addMTTActCostCharges.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddMTTActCostCharges
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.ADDMTTACTCOSTCHARGES_FAILED
    )
     public DWLResponse addMTTActCostCharges(MTTActCostChargesBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addMTTActCostCharges(MTTActCostChargesBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addMTTActCostCharges", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addMTTActCostCharges.";
      logger.finest("addMTTActCostCharges(MTTActCostChargesBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addMTTActCostCharges.";
      logger.finest("addMTTActCostCharges(MTTActCostChargesBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addMTTActCostCharges(MTTActCostChargesBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a MTTActCostCharges to the database.
     *
     * @param theMTTActCostChargesBObj
     *     The object that contains MTTActCostCharges attribute values.
     * @return
     *     DWLResponse containing a MTTActCostChargesBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddMTTActCostCharges(MTTActCostChargesBObj theMTTActCostChargesBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theMTTActCostChargesBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theMTTActCostChargesBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theMTTActCostChargesBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theMTTActCostChargesBObj.getEObjMTTActCostCharges().setMTTActCostChargesIdPk(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theMTTActCostChargesBObj.getEObjMTTActCostCharges().setMTTActCostChargesIdPk(null);
            }
         Persistence theMTTActCostChargesBObjPersistence = getBObjPersistenceFactory().createMTTActCostChargesBObjPersistence(MTTActCostChargesBObjQuery.MTTACT_COST_CHARGES_ADD, theMTTActCostChargesBObj);
         theMTTActCostChargesBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theMTTActCostChargesBObj);
            response.setStatus(theMTTActCostChargesBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, MTTDBCustomComponentID.MTTDBCUSTOM_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    MTTDBCustomErrorReasonCode.ADDMTTACTCOSTCHARGES_FAILED, theMTTActCostChargesBObj.getControl(), errHandler);
        }
        
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateMTTActCostCharges.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateMTTActCostCharges
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.UPDATEMTTACTCOSTCHARGES_FAILED
    )
     public DWLResponse updateMTTActCostCharges(MTTActCostChargesBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateMTTActCostCharges(MTTActCostChargesBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateMTTActCostCharges", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateMTTActCostCharges.";
      logger.finest("updateMTTActCostCharges(MTTActCostChargesBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateMTTActCostCharges.";
      logger.finest("updateMTTActCostCharges(MTTActCostChargesBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateMTTActCostCharges(MTTActCostChargesBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified MTTActCostCharges with new attribute values.
     *
     * @param theMTTActCostChargesBObj
     *     The object that contains MTTActCostCharges attribute values to be
     *     updated
     * @return
     *     DWLResponse containing a MTTActCostChargesBObj of the updated object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateMTTActCostCharges(MTTActCostChargesBObj theMTTActCostChargesBObj) throws Exception {

        DWLStatus status = theMTTActCostChargesBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theMTTActCostChargesBObj.setStatus(status);
        }
        
            // set lastupdatetxid with txnid from dwlcontrol
            theMTTActCostChargesBObj.getEObjMTTActCostCharges().setLastUpdateTxId(new Long(theMTTActCostChargesBObj.getControl().getTxnId()));
         Persistence theMTTActCostChargesBObjPersistence = getBObjPersistenceFactory().createMTTActCostChargesBObjPersistence(MTTActCostChargesBObjQuery.MTTACT_COST_CHARGES_UPDATE, theMTTActCostChargesBObj);
         theMTTActCostChargesBObjPersistence.persistUpdate();

        DWLResponse response = createDWLResponse();
        response.setData(theMTTActCostChargesBObj);
        response.setStatus(theMTTActCostChargesBObj.getStatus());

        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getMTTActFinancial.
     *
     * @param MTTActFinancialIdPk
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetMTTActFinancial
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.GETMTTACTFINANCIAL_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetMTTActFinancial"
    )
     public DWLResponse getMTTActFinancial(String MTTActFinancialIdPk,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getMTTActFinancial(String MTTActFinancialIdPk,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(MTTActFinancialIdPk);
        DWLTransaction txObj = new  DWLTransactionInquiry("getMTTActFinancial", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getMTTActFinancial.";
      logger.finest("getMTTActFinancial(String MTTActFinancialIdPk,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getMTTActFinancial.";
      logger.finest("getMTTActFinancial(String MTTActFinancialIdPk,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getMTTActFinancial(String MTTActFinancialIdPk,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a MTTActFinancial from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetMTTActFinancial(String MTTActFinancialIdPk,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, MTTDBCustomComponentID.MTTDBCUSTOM_COMPONENT,
                                                     MTTDBCustomErrorReasonCode.GETMTTACTFINANCIAL_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createMTTActFinancialBObjQuery(MTTActFinancialBObjQuery.MTTACT_FINANCIAL_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(MTTActFinancialIdPk));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createMTTActFinancialBObjQuery(MTTActFinancialBObjQuery.MTTACT_FINANCIAL_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(MTTActFinancialIdPk));
        }


        MTTActFinancialBObj o = (MTTActFinancialBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveMTTActFinancialBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetMTTActFinancial(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
        String pk = null;
        if (arguments!=null && arguments.length>0) {
            pk = (String)arguments[0];
        }
        // Check if the parameter passed in exists.
        if ((pk == null) || (pk.trim().length() == 0)) {
            TCRMExceptionUtils.throwTCRMException(null, new TCRMReadException(), transaction.getStatus(), DWLStatus.FATAL,
                MTTDBCustomComponentID.MTTACT_FINANCIAL_BOBJ,
                TCRMErrorCode.FIELD_VALIDATION_ERROR,
                MTTDBCustomErrorReasonCode.MTTACTFINANCIAL_MTTACTFINANCIALIDPK_NULL,
                transaction.getTxnControl(), errHandler);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllMTTActFinancialbyID.
     *
     * @param ContractId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllMTTActFinancialbyID
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.GETALLMTTACTFINANCIALBYID_FAILED,
       beforePreExecuteMethod = "beforePreExecuteGetAllMTTActFinancialbyID"
    )
     public DWLResponse getAllMTTActFinancialbyID(String ContractId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllMTTActFinancialbyID(String ContractId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContractId);
        DWLTransaction txObj = new  DWLTransactionInquiry("getAllMTTActFinancialbyID", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction getAllMTTActFinancialbyID.";
      logger.finest("getAllMTTActFinancialbyID(String ContractId,  DWLControl control) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction getAllMTTActFinancialbyID.";
      logger.finest("getAllMTTActFinancialbyID(String ContractId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllMTTActFinancialbyID(String ContractId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets a MTTActFinancial from the database.
     * 
     * @generated
     */
    public DWLResponse handleGetAllMTTActFinancialbyID(String ContractId,  DWLControl control) throws Exception {
        DWLStatus status = new DWLStatus();
        DWLResponse response = createDWLResponse();
        
        BObjQuery bObjQuery = null;
           
        String asOfDate = (String) control.get(DWLControl.INQUIRE_AS_OF_DATE);

        // History data inquiry: if inquireAsOfDate field has value in request xml 
        if (StringUtils.isNonBlank(asOfDate)) {
            Timestamp tsAsOfDate = getPITHistoryDate(asOfDate, MTTDBCustomComponentID.MTTDBCUSTOM_COMPONENT,
                                                     MTTDBCustomErrorReasonCode.GETALLMTTACTFINANCIALBYID_INVALID_INQUIRE_AS_OF_DATE_FORMAT,
                                                     status, control);

            bObjQuery = getBObjQueryFactory().createMTTActFinancialBObjQuery(MTTActFinancialBObjQuery.ALL_MTTACT_FINANCIALBY_ID_HISTORY_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContractId));
            bObjQuery.setParameter(1, tsAsOfDate);
            bObjQuery.setParameter(2, tsAsOfDate);
        } else {
            bObjQuery = getBObjQueryFactory().createMTTActFinancialBObjQuery(MTTActFinancialBObjQuery.ALL_MTTACT_FINANCIALBY_ID_QUERY,
                		control);
            bObjQuery.setParameter(0, DWLFunctionUtils.getLongFromString(ContractId));
        }


        MTTActFinancialBObj o = (MTTActFinancialBObj) bObjQuery.getSingleResult();
        if( o == null ){
        	return null;
        } 
        postRetrieveMTTActFinancialBObj(o, "0", "ALL", control); 
          
        if (o.getStatus()==null) {
            o.setStatus(status);
        }
        response.addStatus(o.getStatus());
        response.setData(o);

      return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void beforePreExecuteGetAllMTTActFinancialbyID(DWLTransaction transaction) throws DWLBaseException{
        // Check if the parameters are valid.
        Object[] arguments = getInquiryArgumentType((DWLTransactionInquiry)transaction);
    if (arguments!=null && arguments.length>0) {
            // MDM_TODO0: CDKWB0003I Add argument validation logic
    }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction addMTTActFinancial.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleAddMTTActFinancial
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.ADDMTTACTFINANCIAL_FAILED
    )
     public DWLResponse addMTTActFinancial(MTTActFinancialBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addMTTActFinancial(MTTActFinancialBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addMTTActFinancial", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction addMTTActFinancial.";
      logger.finest("addMTTActFinancial(MTTActFinancialBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction addMTTActFinancial.";
      logger.finest("addMTTActFinancial(MTTActFinancialBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addMTTActFinancial(MTTActFinancialBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Adds a MTTActFinancial to the database.
     *
     * @param theMTTActFinancialBObj
     *     The object that contains MTTActFinancial attribute values.
     * @return
     *     DWLResponse containing a MTTActFinancialBObj object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleAddMTTActFinancial(MTTActFinancialBObj theMTTActFinancialBObj) throws Exception {
        DWLResponse response = null;
        DWLStatus status = theMTTActFinancialBObj.getStatus();
        if (status == null) {
            status = new DWLStatus();
            theMTTActFinancialBObj.setStatus(status);
        }

        String strPluggableID = null;

        try {
            // Pluggable Key Structure implementation
            strPluggableID = getSuppliedIdPKFromBObj(theMTTActFinancialBObj);

            if ((strPluggableID != null) && (strPluggableID.length() > 0)) {
                theMTTActFinancialBObj.getEObjMTTActFinancial().setMTTActFinancialIdPk(FunctionUtils.getLongFromString(strPluggableID));
            } else {
                strPluggableID = null;
                theMTTActFinancialBObj.getEObjMTTActFinancial().setMTTActFinancialIdPk(null);
            }
         Persistence theMTTActFinancialBObjPersistence = getBObjPersistenceFactory().createMTTActFinancialBObjPersistence(MTTActFinancialBObjQuery.MTTACT_FINANCIAL_ADD, theMTTActFinancialBObj);
         theMTTActFinancialBObjPersistence.persistAdd();

            response = new DWLResponse();
            response.setData(theMTTActFinancialBObj);
            response.setStatus(theMTTActFinancialBObj.getStatus());
    } catch (Exception ex) {
 				TCRMExceptionUtils.throwTCRMException(ex, new TCRMInsertException(ex.getMessage()), status,
                    DWLStatus.FATAL, MTTDBCustomComponentID.MTTDBCUSTOM_COMPONENT, TCRMErrorCode.INSERT_RECORD_ERROR,
                    MTTDBCustomErrorReasonCode.ADDMTTACTFINANCIAL_FAILED, theMTTActFinancialBObj.getControl(), errHandler);
        }
        
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction updateMTTActFinancial.
     *
     * @param theBObj
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleUpdateMTTActFinancial
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.UPDATEMTTACTFINANCIAL_FAILED
    )
     public DWLResponse updateMTTActFinancial(MTTActFinancialBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateMTTActFinancial(MTTActFinancialBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateMTTActFinancial", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before execution of transaction updateMTTActFinancial.";
      logger.finest("updateMTTActFinancial(MTTActFinancialBObj theBObj) " + infoForLogging);
    }	
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After execution of transaction updateMTTActFinancial.";
      logger.finest("updateMTTActFinancial(MTTActFinancialBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateMTTActFinancial(MTTActFinancialBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Updates the specified MTTActFinancial with new attribute values.
     *
     * @param theMTTActFinancialBObj
     *     The object that contains MTTActFinancial attribute values to be
     *     updated
     * @return
     *     DWLResponse containing a MTTActFinancialBObj of the updated object.
     * @exception Exception
     * @generated
     */
    public DWLResponse handleUpdateMTTActFinancial(MTTActFinancialBObj theMTTActFinancialBObj) throws Exception {

        DWLStatus status = theMTTActFinancialBObj.getStatus();

        if (status == null) {
            status = new DWLStatus();
            theMTTActFinancialBObj.setStatus(status);
        }
        
            // set lastupdatetxid with txnid from dwlcontrol
            theMTTActFinancialBObj.getEObjMTTActFinancial().setLastUpdateTxId(new Long(theMTTActFinancialBObj.getControl().getTxnId()));
         Persistence theMTTActFinancialBObjPersistence = getBObjPersistenceFactory().createMTTActFinancialBObjPersistence(MTTActFinancialBObjQuery.MTTACT_FINANCIAL_UPDATE, theMTTActFinancialBObj);
         theMTTActFinancialBObjPersistence.persistUpdate();

        DWLResponse response = createDWLResponse();
        response.setData(theMTTActFinancialBObj);
        response.setStatus(theMTTActFinancialBObj.getStatus());

        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(MTTActReportingBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(MTTActReportingBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		MTTActReportingBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getMTTActReporting( bObj.getMTTActReportingIdPk(), bObj.getControl());
    			beforeImage = (MTTActReportingBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(MTTActReportingBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  MTTDBCustomComponentID.MTTACT_REPORTING_BOBJ, 
                                  "DIERR",
                                  MTTDBCustomErrorReasonCode.MTTACTREPORTING_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(MTTActReportingBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  MTTDBCustomComponentID.MTTACT_REPORTING_BOBJ, 
                                  "DIERR",
                                  MTTDBCustomErrorReasonCode.MTTACTREPORTING_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(MTTActReportingBObj bObj)");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populates the parent MTTActReportingBObj with all contained BObjs and
     * Type Codes.
     * @generated
    **/
    public void postRetrieveMTTActReportingBObj(MTTActReportingBObj theBObj, String inquiryLevel, String filter, DWLControl control) throws Exception {
    logger.finest("ENTER postRetrieveMTTActReportingBObj(MTTActReportingBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
        // processing code types  
        String langId = (String) theBObj.getControl().get(TCRMControlKeys.LANG_ID);
        CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
  
        String ChannelGroupTp = theBObj.getChannelGroupType();
        if( ChannelGroupTp != null && !ChannelGroupTp.equals("")){
            CodeTypeBObj ChannelGroupBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdchannelgrptp", langId, ChannelGroupTp,
                          theBObj.getControl());

            if (ChannelGroupBObj != null) {
                theBObj.setChannelGroupValue(ChannelGroupBObj.getvalue());
            }

    }
        String AgentNumberTp = theBObj.getAgentNumberType();
        if( AgentNumberTp != null && !AgentNumberTp.equals("")){
            CodeTypeBObj AgentNumberBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdagentnumtp", langId, AgentNumberTp,
                          theBObj.getControl());

            if (AgentNumberBObj != null) {
                theBObj.setAgentNumberValue(AgentNumberBObj.getvalue());
            }

    }
        String UserLocalityTp = theBObj.getUserLocalityType();
        if( UserLocalityTp != null && !UserLocalityTp.equals("")){
            CodeTypeBObj UserLocalityBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcduserlocalitytp", langId, UserLocalityTp,
                          theBObj.getControl());

            if (UserLocalityBObj != null) {
                theBObj.setUserLocalityValue(UserLocalityBObj.getvalue());
            }

    }
        String CustomerClassTp = theBObj.getCustomerClassType();
        if( CustomerClassTp != null && !CustomerClassTp.equals("")){
            CodeTypeBObj CustomerClassBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdcusclasstp", langId, CustomerClassTp,
                          theBObj.getControl());

            if (CustomerClassBObj != null) {
                theBObj.setCustomerClassValue(CustomerClassBObj.getvalue());
            }

    }
    logger.finest("RETURN postRetrieveMTTActReportingBObj(MTTActReportingBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(MTTIdentifierBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(MTTIdentifierBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		MTTIdentifierBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getMTTIdentifier( bObj.getMTTIdentifierIdPk(), bObj.getControl());
    			beforeImage = (MTTIdentifierBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(MTTIdentifierBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  MTTDBCustomComponentID.MTTIDENTIFIER_BOBJ, 
                                  "DIERR",
                                  MTTDBCustomErrorReasonCode.MTTIDENTIFIER_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(MTTIdentifierBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  MTTDBCustomComponentID.MTTIDENTIFIER_BOBJ, 
                                  "DIERR",
                                  MTTDBCustomErrorReasonCode.MTTIDENTIFIER_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(MTTIdentifierBObj bObj)");
    }
	 


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populates the parent MTTIdentifierBObj with all contained BObjs and Type
     * Codes.
     * @generated
    **/
    public void postRetrieveMTTIdentifierBObj(MTTIdentifierBObj theBObj, String inquiryLevel, String filter, DWLControl control) throws Exception {
    logger.finest("ENTER postRetrieveMTTIdentifierBObj(MTTIdentifierBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
        // processing code types  
        String langId = (String) theBObj.getControl().get(TCRMControlKeys.LANG_ID);
        CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
  
        String IdentifierSubTp = theBObj.getIdentifierSubType();
        if( IdentifierSubTp != null && !IdentifierSubTp.equals("")){
            CodeTypeBObj IdentifierSubBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdidentifiersubtp", langId, IdentifierSubTp,
                          theBObj.getControl());

            if (IdentifierSubBObj != null) {
                theBObj.setIdentifierSubValue(IdentifierSubBObj.getvalue());
            }

    }
    logger.finest("RETURN postRetrieveMTTIdentifierBObj(MTTIdentifierBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(MTTStoreBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(MTTStoreBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		MTTStoreBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getMTTStore( bObj.getMTTStoreIdPk(), bObj.getControl());
    			beforeImage = (MTTStoreBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(MTTStoreBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  MTTDBCustomComponentID.MTTSTORE_BOBJ, 
                                  "DIERR",
                                  MTTDBCustomErrorReasonCode.MTTSTORE_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(MTTStoreBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  MTTDBCustomComponentID.MTTSTORE_BOBJ, 
                                  "DIERR",
                                  MTTDBCustomErrorReasonCode.MTTSTORE_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(MTTStoreBObj bObj)");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populates the parent MTTStoreBObj with all contained BObjs and Type
     * Codes.
     * @generated
    **/
    public void postRetrieveMTTStoreBObj(MTTStoreBObj theBObj, String inquiryLevel, String filter, DWLControl control) throws Exception {
    logger.finest("ENTER postRetrieveMTTStoreBObj(MTTStoreBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
        // processing code types  
        String langId = (String) theBObj.getControl().get(TCRMControlKeys.LANG_ID);
        CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
  
        String MSOTp = theBObj.getMSOType();
        if( MSOTp != null && !MSOTp.equals("")){
            CodeTypeBObj MSOBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdmsotp", langId, MSOTp,
                          theBObj.getControl());

            if (MSOBObj != null) {
                theBObj.setMSOValue(MSOBObj.getvalue());
            }

    }
    logger.finest("RETURN postRetrieveMTTStoreBObj(MTTStoreBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(MTTActCreditTaxBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(MTTActCreditTaxBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		MTTActCreditTaxBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getMTTActCreditTax( bObj.getMTTActCreditTaxIdPk(), bObj.getControl());
    			beforeImage = (MTTActCreditTaxBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(MTTActCreditTaxBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  MTTDBCustomComponentID.MTTACT_CREDIT_TAX_BOBJ, 
                                  "DIERR",
                                  MTTDBCustomErrorReasonCode.MTTACTCREDITTAX_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(MTTActCreditTaxBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  MTTDBCustomComponentID.MTTACT_CREDIT_TAX_BOBJ, 
                                  "DIERR",
                                  MTTDBCustomErrorReasonCode.MTTACTCREDITTAX_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(MTTActCreditTaxBObj bObj)");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populates the parent MTTActCreditTaxBObj with all contained BObjs and
     * Type Codes.
     * @generated
    **/
    public void postRetrieveMTTActCreditTaxBObj(MTTActCreditTaxBObj theBObj, String inquiryLevel, String filter, DWLControl control) throws Exception {
    logger.finest("ENTER postRetrieveMTTActCreditTaxBObj(MTTActCreditTaxBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
        // processing code types  
        String langId = (String) theBObj.getControl().get(TCRMControlKeys.LANG_ID);
        CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
  
        String InvoiceTermsTp = theBObj.getInvoiceTermsType();
        if( InvoiceTermsTp != null && !InvoiceTermsTp.equals("")){
            CodeTypeBObj InvoiceTermsBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdinvtermstp", langId, InvoiceTermsTp,
                          theBObj.getControl());

            if (InvoiceTermsBObj != null) {
                theBObj.setInvoiceTermsValue(InvoiceTermsBObj.getvalue());
            }

    }
        String CustomerGroupTp = theBObj.getCustomerGroupType();
        if( CustomerGroupTp != null && !CustomerGroupTp.equals("")){
            CodeTypeBObj CustomerGroupBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdcusgrptp", langId, CustomerGroupTp,
                          theBObj.getControl());

            if (CustomerGroupBObj != null) {
                theBObj.setCustomerGroupValue(CustomerGroupBObj.getvalue());
            }

    }
        String ChequeLimitCurrencyTp = theBObj.getChequeLimitCurrencyType();
        if( ChequeLimitCurrencyTp != null && !ChequeLimitCurrencyTp.equals("")){
            CodeTypeBObj ChequeLimitCurrencyBObj = codeTypeCompHelper
                    .getCodeTypeByCode("cdcurrencytp", langId, ChequeLimitCurrencyTp,
                          theBObj.getControl());

            if (ChequeLimitCurrencyBObj != null) {
                theBObj.setChequeLimitCurrencyValue(ChequeLimitCurrencyBObj.getvalue());
            }

    }
        String SalesRepTp = theBObj.getSalesRepType();
        if( SalesRepTp != null && !SalesRepTp.equals("")){
            CodeTypeBObj SalesRepBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdsalesreptp", langId, SalesRepTp,
                          theBObj.getControl());

            if (SalesRepBObj != null) {
                theBObj.setSalesRepValue(SalesRepBObj.getvalue());
            }

    }
    logger.finest("RETURN postRetrieveMTTActCreditTaxBObj(MTTActCreditTaxBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(MTTActOrderInvoiceBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(MTTActOrderInvoiceBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		MTTActOrderInvoiceBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getMTTActOrderInvoice( bObj.getMTTActOrderInvoiceIdPk(), bObj.getControl());
    			beforeImage = (MTTActOrderInvoiceBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(MTTActOrderInvoiceBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  MTTDBCustomComponentID.MTTACT_ORDER_INVOICE_BOBJ, 
                                  "DIERR",
                                  MTTDBCustomErrorReasonCode.MTTACTORDERINVOICE_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(MTTActOrderInvoiceBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  MTTDBCustomComponentID.MTTACT_ORDER_INVOICE_BOBJ, 
                                  "DIERR",
                                  MTTDBCustomErrorReasonCode.MTTACTORDERINVOICE_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(MTTActOrderInvoiceBObj bObj)");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populates the parent MTTActOrderInvoiceBObj with all contained BObjs and
     * Type Codes.
     * @generated
    **/
    public void postRetrieveMTTActOrderInvoiceBObj(MTTActOrderInvoiceBObj theBObj, String inquiryLevel, String filter, DWLControl control) throws Exception {
    logger.finest("ENTER postRetrieveMTTActOrderInvoiceBObj(MTTActOrderInvoiceBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
        // processing code types  
        String langId = (String) theBObj.getControl().get(TCRMControlKeys.LANG_ID);
        CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
  
        String InvoiceSequenceTp = theBObj.getInvoiceSequenceType();
        if( InvoiceSequenceTp != null && !InvoiceSequenceTp.equals("")){
            CodeTypeBObj InvoiceSequenceBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdinvseqtp", langId, InvoiceSequenceTp,
                          theBObj.getControl());

            if (InvoiceSequenceBObj != null) {
                theBObj.setInvoiceSequenceValue(InvoiceSequenceBObj.getvalue());
            }

    }
        String InvoiceModeTp = theBObj.getInvoiceModeType();
        if( InvoiceModeTp != null && !InvoiceModeTp.equals("")){
            CodeTypeBObj InvoiceModeBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdinvmodetp", langId, InvoiceModeTp,
                          theBObj.getControl());

            if (InvoiceModeBObj != null) {
                theBObj.setInvoiceModeValue(InvoiceModeBObj.getvalue());
            }

    }
        String OrderGuideTp = theBObj.getOrderGuideType();
        if( OrderGuideTp != null && !OrderGuideTp.equals("")){
            CodeTypeBObj OrderGuideBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdorderguidetp", langId, OrderGuideTp,
                          theBObj.getControl());

            if (OrderGuideBObj != null) {
                theBObj.setOrderGuideValue(OrderGuideBObj.getvalue());
            }

    }
        String PrintCatInvoiceBreakTp = theBObj.getPrintCatInvoiceBreakType();
        if( PrintCatInvoiceBreakTp != null && !PrintCatInvoiceBreakTp.equals("")){
            CodeTypeBObj PrintCatInvoiceBreakBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdprncatinvbrktp", langId, PrintCatInvoiceBreakTp,
                          theBObj.getControl());

            if (PrintCatInvoiceBreakBObj != null) {
                theBObj.setPrintCatInvoiceBreakValue(PrintCatInvoiceBreakBObj.getvalue());
            }

    }
        String InvoiceRecapSummaryTp = theBObj.getInvoiceRecapSummaryType();
        if( InvoiceRecapSummaryTp != null && !InvoiceRecapSummaryTp.equals("")){
            CodeTypeBObj InvoiceRecapSummaryBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdinvrecapsummarytp", langId, InvoiceRecapSummaryTp,
                          theBObj.getControl());

            if (InvoiceRecapSummaryBObj != null) {
                theBObj.setInvoiceRecapSummaryValue(InvoiceRecapSummaryBObj.getvalue());
            }

    }
        String PickupDeliverTp = theBObj.getPickupDeliverType();
        if( PickupDeliverTp != null && !PickupDeliverTp.equals("")){
            CodeTypeBObj PickupDeliverBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdpickupdelivertp", langId, PickupDeliverTp,
                          theBObj.getControl());

            if (PickupDeliverBObj != null) {
                theBObj.setPickupDeliverValue(PickupDeliverBObj.getvalue());
            }

    }
        String TotesTp = theBObj.getTotesType();
        if( TotesTp != null && !TotesTp.equals("")){
            CodeTypeBObj TotesBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdtotestp", langId, TotesTp,
                          theBObj.getControl());

            if (TotesBObj != null) {
                theBObj.setTotesValue(TotesBObj.getvalue());
            }

    }
        String UnitCaseCostPrintTp = theBObj.getUnitCaseCostPrintType();
        if( UnitCaseCostPrintTp != null && !UnitCaseCostPrintTp.equals("")){
            CodeTypeBObj UnitCaseCostPrintBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdunitcasecostprntp", langId, UnitCaseCostPrintTp,
                          theBObj.getControl());

            if (UnitCaseCostPrintBObj != null) {
                theBObj.setUnitCaseCostPrintValue(UnitCaseCostPrintBObj.getvalue());
            }

    }
        String InvoiceFormatTp = theBObj.getInvoiceFormatType();
        if( InvoiceFormatTp != null && !InvoiceFormatTp.equals("")){
            CodeTypeBObj InvoiceFormatBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdinvformattp", langId, InvoiceFormatTp,
                          theBObj.getControl());

            if (InvoiceFormatBObj != null) {
                theBObj.setInvoiceFormatValue(InvoiceFormatBObj.getvalue());
            }

    }
        String InvoiceTp = theBObj.getInvoiceType();
        if( InvoiceTp != null && !InvoiceTp.equals("")){
            CodeTypeBObj InvoiceBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdinvtp", langId, InvoiceTp,
                          theBObj.getControl());

            if (InvoiceBObj != null) {
                theBObj.setInvoiceValue(InvoiceBObj.getvalue());
            }

    }
        String DelPickPackInvoiceTp = theBObj.getDelPickPackInvoiceType();
        if( DelPickPackInvoiceTp != null && !DelPickPackInvoiceTp.equals("")){
            CodeTypeBObj DelPickPackInvoiceBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcddelpickpackinvtp", langId, DelPickPackInvoiceTp,
                          theBObj.getControl());

            if (DelPickPackInvoiceBObj != null) {
                theBObj.setDelPickPackInvoiceValue(DelPickPackInvoiceBObj.getvalue());
            }

    }
    logger.finest("RETURN postRetrieveMTTActOrderInvoiceBObj(MTTActOrderInvoiceBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(MTTActCostChargesBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(MTTActCostChargesBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		MTTActCostChargesBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getMTTActCostCharges( bObj.getMTTActCostChargesIdPk(), bObj.getControl());
    			beforeImage = (MTTActCostChargesBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(MTTActCostChargesBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  MTTDBCustomComponentID.MTTACT_COST_CHARGES_BOBJ, 
                                  "DIERR",
                                  MTTDBCustomErrorReasonCode.MTTACTCOSTCHARGES_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(MTTActCostChargesBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  MTTDBCustomComponentID.MTTACT_COST_CHARGES_BOBJ, 
                                  "DIERR",
                                  MTTDBCustomErrorReasonCode.MTTACTCOSTCHARGES_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(MTTActCostChargesBObj bObj)");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populates the parent MTTActCostChargesBObj with all contained BObjs and
     * Type Codes.
     * @generated
    **/
    public void postRetrieveMTTActCostChargesBObj(MTTActCostChargesBObj theBObj, String inquiryLevel, String filter, DWLControl control) throws Exception {
    logger.finest("ENTER postRetrieveMTTActCostChargesBObj(MTTActCostChargesBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
        // processing code types  
        String langId = (String) theBObj.getControl().get(TCRMControlKeys.LANG_ID);
        CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
  
        String CostBaseTp = theBObj.getCostBaseType();
        if( CostBaseTp != null && !CostBaseTp.equals("")){
            CodeTypeBObj CostBaseBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdcostbasetp", langId, CostBaseTp,
                          theBObj.getControl());

            if (CostBaseBObj != null) {
                theBObj.setCostBaseValue(CostBaseBObj.getvalue());
            }

    }
        String SRPComplicanceTp = theBObj.getSRPComplicanceType();
        if( SRPComplicanceTp != null && !SRPComplicanceTp.equals("")){
            CodeTypeBObj SRPComplicanceBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdsrpcompliancetp", langId, SRPComplicanceTp,
                          theBObj.getControl());

            if (SRPComplicanceBObj != null) {
                theBObj.setSRPComplicanceValue(SRPComplicanceBObj.getvalue());
            }

    }
        String BrokenCaseCalTp = theBObj.getBrokenCaseCalType();
        if( BrokenCaseCalTp != null && !BrokenCaseCalTp.equals("")){
            CodeTypeBObj BrokenCaseCalBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdbrkncasecalctp", langId, BrokenCaseCalTp,
                          theBObj.getControl());

            if (BrokenCaseCalBObj != null) {
                theBObj.setBrokenCaseCalValue(BrokenCaseCalBObj.getvalue());
            }

    }
        String PSRPTp = theBObj.getPSRPType();
        if( PSRPTp != null && !PSRPTp.equals("")){
            CodeTypeBObj PSRPBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdpsrptp", langId, PSRPTp,
                          theBObj.getControl());

            if (PSRPBObj != null) {
                theBObj.setPSRPValue(PSRPBObj.getvalue());
            }

    }
    logger.finest("RETURN postRetrieveMTTActCostChargesBObj(MTTActCostChargesBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     **/
    public void loadBeforeImage(MTTActFinancialBObj bObj) throws DWLBaseException {
    logger.finest("ENTER loadBeforeImage(MTTActFinancialBObj bObj)");
    	if( bObj.BeforeImage() == null ){
    	
    		MTTActFinancialBObj beforeImage = null;
    		DWLResponse response = null;
    		
    		try {
    			response = getMTTActFinancial( bObj.getMTTActFinancialIdPk(), bObj.getControl());
    			beforeImage = (MTTActFinancialBObj)response.getData();
    			
    		} catch( Exception e){
        if (logger.isFinestEnabled()) {
    				String infoForLogging="Error: Exception " + e.getMessage() + " while updating a record ";
      logger.finest("loadBeforeImage(MTTActFinancialBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  MTTDBCustomComponentID.MTTACT_FINANCIAL_BOBJ, 
                                  "DIERR",
                                  MTTDBCustomErrorReasonCode.MTTACTFINANCIAL_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		if( beforeImage == null ){
        if (logger.isFinestEnabled()) {
    		    	String infoForLogging="Error: Before image for updating a record is null ";
      logger.finest("loadBeforeImage(MTTActFinancialBObj bObj) " + infoForLogging);
        }
              DWLExceptionUtils.throwDWLBaseException( new DWLUpdateException(), 
            									bObj.getStatus(), DWLStatus.FATAL,
                                  MTTDBCustomComponentID.MTTACT_FINANCIAL_BOBJ, 
                                  "DIERR",
                                  MTTDBCustomErrorReasonCode.MTTACTFINANCIAL_BEFORE_IMAGE_NOT_POPULATED, 
                                  bObj.getControl(), errHandler);
    		}
    		
    		bObj.setBeforeImage(beforeImage);
    		
    	}
    logger.finest("RETURN loadBeforeImage(MTTActFinancialBObj bObj)");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populates the parent MTTActFinancialBObj with all contained BObjs and
     * Type Codes.
     * @generated
    **/
    public void postRetrieveMTTActFinancialBObj(MTTActFinancialBObj theBObj, String inquiryLevel, String filter, DWLControl control) throws Exception {
    logger.finest("ENTER postRetrieveMTTActFinancialBObj(MTTActFinancialBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
        // processing code types  
        String langId = (String) theBObj.getControl().get(TCRMControlKeys.LANG_ID);
        CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
  
        String StatementModeTp = theBObj.getStatementModeType();
        if( StatementModeTp != null && !StatementModeTp.equals("")){
            CodeTypeBObj StatementModeBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdstatementmodetp", langId, StatementModeTp,
                          theBObj.getControl());

            if (StatementModeBObj != null) {
                theBObj.setStatementModeValue(StatementModeBObj.getvalue());
            }

    }
        String DueGraceDaysTp = theBObj.getDueGraceDaysType();
        if( DueGraceDaysTp != null && !DueGraceDaysTp.equals("")){
            CodeTypeBObj DueGraceDaysBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdduegracedaystp", langId, DueGraceDaysTp,
                          theBObj.getControl());

            if (DueGraceDaysBObj != null) {
                theBObj.setDueGraceDaysValue(DueGraceDaysBObj.getvalue());
            }

    }
        String TobaccoGraceDaysTp = theBObj.getTobaccoGraceDaysType();
        if( TobaccoGraceDaysTp != null && !TobaccoGraceDaysTp.equals("")){
            CodeTypeBObj TobaccoGraceDaysBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdtobaccogracedaystp", langId, TobaccoGraceDaysTp,
                          theBObj.getControl());

            if (TobaccoGraceDaysBObj != null) {
                theBObj.setTobaccoGraceDaysValue(TobaccoGraceDaysBObj.getvalue());
            }

    }
        String BankTp = theBObj.getBankType();
        if( BankTp != null && !BankTp.equals("")){
            CodeTypeBObj BankBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdbanktp", langId, BankTp,
                          theBObj.getControl());

            if (BankBObj != null) {
                theBObj.setBankValue(BankBObj.getvalue());
            }

    }
        String CollectorTp = theBObj.getCollectorType();
        if( CollectorTp != null && !CollectorTp.equals("")){
            CodeTypeBObj CollectorBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdcollectortp", langId, CollectorTp,
                          theBObj.getControl());

            if (CollectorBObj != null) {
                theBObj.setCollectorValue(CollectorBObj.getvalue());
            }

    }
        String BankAccountTp = theBObj.getBankAccountType();
        if( BankAccountTp != null && !BankAccountTp.equals("")){
            CodeTypeBObj BankAccountBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdbankaccounttp", langId, BankAccountTp,
                          theBObj.getControl());

            if (BankAccountBObj != null) {
                theBObj.setBankAccountValue(BankAccountBObj.getvalue());
            }

    }
        String DiscountGraceDaysTp = theBObj.getDiscountGraceDaysType();
        if( DiscountGraceDaysTp != null && !DiscountGraceDaysTp.equals("")){
            CodeTypeBObj DiscountGraceDaysBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcddiscountgracedaystp", langId, DiscountGraceDaysTp,
                          theBObj.getControl());

            if (DiscountGraceDaysBObj != null) {
                theBObj.setDiscountGraceDaysValue(DiscountGraceDaysBObj.getvalue());
            }

    }
        String PaymentMethodTp = theBObj.getPaymentMethodType();
        if( PaymentMethodTp != null && !PaymentMethodTp.equals("")){
            CodeTypeBObj PaymentMethodBObj = codeTypeCompHelper
                    .getCodeTypeByCode("xcdpaymentmethodtp", langId, PaymentMethodTp,
                          theBObj.getControl());

            if (PaymentMethodBObj != null) {
                theBObj.setPaymentMethodValue(PaymentMethodBObj.getvalue());
            }

    }
    logger.finest("RETURN postRetrieveMTTActFinancialBObj(MTTActFinancialBObj theBObj, String inquiryLevel, String filter, DWLControl control)");
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Builds duplicated key throwable message. There are only two elements in
     * the vector, one is the primary key, and the other is the class name.
     * @generated
     **/
    @SuppressWarnings("unused")
    private String buildDupThrowableMessage(String[] errParams) {
    return ResourceBundleHelper.resolve(
        ResourceBundleNames.COMMON_SERVICES_STRINGS,
        EXCEPTION_DUPLICATE_KEY, errParams);

    }
  

}


