/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[2aad0e64c813f190c8a9b87f71b08ac7]
 */

package com.metcash.db.custom.bobj.query;


import com.dwl.base.DWLCommon;
import com.dwl.base.DWLControl;

import com.dwl.bobj.query.BObjQuery;
import com.dwl.bobj.query.Persistence;

import com.dwl.common.globalization.util.ResourceBundleHelper;

import com.metcash.db.custom.bobj.query.MTTActCostChargesBObjQuery;
import com.metcash.db.custom.bobj.query.MTTActCreditTaxBObjQuery;
import com.metcash.db.custom.bobj.query.MTTActFinancialBObjQuery;
import com.metcash.db.custom.bobj.query.MTTActOrderInvoiceBObjQuery;
import com.metcash.db.custom.bobj.query.MTTActReportingBObjQuery;
import com.metcash.db.custom.bobj.query.MTTIdentifierBObjQuery;

import com.metcash.db.custom.bobj.query.MTTStoreBObjQuery;
import com.metcash.db.custom.constant.ResourceBundleNames;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This factory class provides methods to return the BObjQuery instances
 * relating to the relevant business objects.
 *
 * @generated
 */
public class MTTDBCustomModuleBObjQueryFactoryImpl  implements MTTDBCustomModuleBObjQueryFactory, MTTDBCustomModuleBObjPersistenceFactory {

	private final static String EXCEPTION_QUERYNAME_EMPTY = "Exception_AbstractBObjQuery_QueryNameCannotBeEmpty";
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(MTTDBCustomModuleBObjQueryFactoryImpl.class);

    /**
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   *
     * Default constructor.
     *
     * @generated
     */
    public MTTDBCustomModuleBObjQueryFactoryImpl() {
        super();
    }
    
     /** 
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * Provides the concrete BObjQuery instance corresponding to the
      * <code>MTTActReportingBObj</code> business object.
      *
      * @return 
      * An instance of <code>MTTActReportingBObjQuery</code>.
      *
      * @generated
      */
      public BObjQuery createMTTActReportingBObjQuery(String queryName, DWLControl dwlControl) {
    logger.finest("ENTER createMTTActReportingBObjQuery(String queryName, DWLControl dwlControl)");
        if ((queryName == null) || queryName.trim().equals("")) {
      throw new IllegalArgumentException(ResourceBundleHelper.resolve(
          ResourceBundleNames.COMMON_SERVICES_STRINGS,
          EXCEPTION_QUERYNAME_EMPTY));
        }
    logger.finest("RETURN createMTTActReportingBObjQuery(String queryName, DWLControl dwlControl)");
        return new MTTActReportingBObjQuery(queryName, dwlControl);
    }

    /** 
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * This method returns an object of type <code>Persistence</code>
      * corresponding to <code>MTTActReportingBObj</code> business object.
      *
      * @param persistenceStrategyName
      * The persistence strategy name.  This parameter indicates the type of
      * database action to be taken such as addition, update or deletion of
      * records.
      * @param objectToPersist
      * The business object to be persisted.
      *      
      * @return 
      * An instance of <code>MTTActReportingBObjQuery</code>.
      *
      * @generated
      */
      public Persistence createMTTActReportingBObjPersistence(String persistenceStrategyName, DWLCommon objectToPersist) {

        return new MTTActReportingBObjQuery(persistenceStrategyName, objectToPersist);
      }

    /** 
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * Provides the concrete BObjQuery instance corresponding to the
      * <code>MTTIdentifierBObj</code> business object.
      *
      * @return 
      * An instance of <code>MTTIdentifierBObjQuery</code>.
      *
      * @generated
      */
      public BObjQuery createMTTIdentifierBObjQuery(String queryName, DWLControl dwlControl) {
    logger.finest("ENTER createMTTIdentifierBObjQuery(String queryName, DWLControl dwlControl)");
        if ((queryName == null) || queryName.trim().equals("")) {
      throw new IllegalArgumentException(ResourceBundleHelper.resolve(
          ResourceBundleNames.COMMON_SERVICES_STRINGS,
          EXCEPTION_QUERYNAME_EMPTY));
        }
    logger.finest("RETURN createMTTIdentifierBObjQuery(String queryName, DWLControl dwlControl)");
        return new MTTIdentifierBObjQuery(queryName, dwlControl);
    }
    
     /** 
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * This method returns an object of type <code>Persistence</code>
      * corresponding to <code>MTTIdentifierBObj</code> business object.
      *
      * @param persistenceStrategyName
      * The persistence strategy name.  This parameter indicates the type of
      * database action to be taken such as addition, update or deletion of
      * records.
      * @param objectToPersist
      * The business object to be persisted.
      *      
      * @return 
      * An instance of <code>MTTIdentifierBObjQuery</code>.
      *
      * @generated
      */
      public Persistence createMTTIdentifierBObjPersistence(String persistenceStrategyName, DWLCommon objectToPersist) {

        return new MTTIdentifierBObjQuery(persistenceStrategyName, objectToPersist);
      }

    /** 
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * Provides the concrete BObjQuery instance corresponding to the
      * <code>MTTStoreBObj</code> business object.
      *
      * @return 
      * An instance of <code>MTTStoreBObjQuery</code>.
      *
      * @generated
      */
      public BObjQuery createMTTStoreBObjQuery(String queryName, DWLControl dwlControl) {
    logger.finest("ENTER createMTTStoreBObjQuery(String queryName, DWLControl dwlControl)");
        if ((queryName == null) || queryName.trim().equals("")) {
      throw new IllegalArgumentException(ResourceBundleHelper.resolve(
          ResourceBundleNames.COMMON_SERVICES_STRINGS,
          EXCEPTION_QUERYNAME_EMPTY));
        }
    logger.finest("RETURN createMTTStoreBObjQuery(String queryName, DWLControl dwlControl)");
        return new MTTStoreBObjQuery(queryName, dwlControl);
    }

    /** 
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * This method returns an object of type <code>Persistence</code>
      * corresponding to <code>MTTStoreBObj</code> business object.
      *
      * @param persistenceStrategyName
      * The persistence strategy name.  This parameter indicates the type of
      * database action to be taken such as addition, update or deletion of
      * records.
      * @param objectToPersist
      * The business object to be persisted.
      *      
      * @return 
      * An instance of <code>MTTStoreBObjQuery</code>.
      *
      * @generated
      */
      public Persistence createMTTStoreBObjPersistence(String persistenceStrategyName, DWLCommon objectToPersist) {

        return new MTTStoreBObjQuery(persistenceStrategyName, objectToPersist);
      }

    /** 
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * Provides the concrete BObjQuery instance corresponding to the
      * <code>MTTActCreditTaxBObj</code> business object.
      *
      * @return 
      * An instance of <code>MTTActCreditTaxBObjQuery</code>.
      *
      * @generated
      */
      public BObjQuery createMTTActCreditTaxBObjQuery(String queryName, DWLControl dwlControl) {
    logger.finest("ENTER createMTTActCreditTaxBObjQuery(String queryName, DWLControl dwlControl)");
        if ((queryName == null) || queryName.trim().equals("")) {
      throw new IllegalArgumentException(ResourceBundleHelper.resolve(
          ResourceBundleNames.COMMON_SERVICES_STRINGS,
          EXCEPTION_QUERYNAME_EMPTY));
        }
    logger.finest("RETURN createMTTActCreditTaxBObjQuery(String queryName, DWLControl dwlControl)");
        return new MTTActCreditTaxBObjQuery(queryName, dwlControl);
    }

    /** 
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * This method returns an object of type <code>Persistence</code>
      * corresponding to <code>MTTActCreditTaxBObj</code> business object.
      *
      * @param persistenceStrategyName
      * The persistence strategy name.  This parameter indicates the type of
      * database action to be taken such as addition, update or deletion of
      * records.
      * @param objectToPersist
      * The business object to be persisted.
      *      
      * @return 
      * An instance of <code>MTTActCreditTaxBObjQuery</code>.
      *
      * @generated
      */
      public Persistence createMTTActCreditTaxBObjPersistence(String persistenceStrategyName, DWLCommon objectToPersist) {

        return new MTTActCreditTaxBObjQuery(persistenceStrategyName, objectToPersist);
      }

    /** 
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * Provides the concrete BObjQuery instance corresponding to the
      * <code>MTTActOrderInvoiceBObj</code> business object.
      *
      * @return 
      * An instance of <code>MTTActOrderInvoiceBObjQuery</code>.
      *
      * @generated
      */
      public BObjQuery createMTTActOrderInvoiceBObjQuery(String queryName, DWLControl dwlControl) {
    logger.finest("ENTER createMTTActOrderInvoiceBObjQuery(String queryName, DWLControl dwlControl)");
        if ((queryName == null) || queryName.trim().equals("")) {
      throw new IllegalArgumentException(ResourceBundleHelper.resolve(
          ResourceBundleNames.COMMON_SERVICES_STRINGS,
          EXCEPTION_QUERYNAME_EMPTY));
        }
    logger.finest("RETURN createMTTActOrderInvoiceBObjQuery(String queryName, DWLControl dwlControl)");
        return new MTTActOrderInvoiceBObjQuery(queryName, dwlControl);
    }

    /** 
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * This method returns an object of type <code>Persistence</code>
      * corresponding to <code>MTTActOrderInvoiceBObj</code> business object.
      *
      * @param persistenceStrategyName
      * The persistence strategy name.  This parameter indicates the type of
      * database action to be taken such as addition, update or deletion of
      * records.
      * @param objectToPersist
      * The business object to be persisted.
      *      
      * @return 
      * An instance of <code>MTTActOrderInvoiceBObjQuery</code>.
      *
      * @generated
      */
      public Persistence createMTTActOrderInvoiceBObjPersistence(String persistenceStrategyName, DWLCommon objectToPersist) {

        return new MTTActOrderInvoiceBObjQuery(persistenceStrategyName, objectToPersist);
      }

    /** 
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * Provides the concrete BObjQuery instance corresponding to the
      * <code>MTTActCostChargesBObj</code> business object.
      *
      * @return 
      * An instance of <code>MTTActCostChargesBObjQuery</code>.
      *
      * @generated
      */
      public BObjQuery createMTTActCostChargesBObjQuery(String queryName, DWLControl dwlControl) {
    logger.finest("ENTER createMTTActCostChargesBObjQuery(String queryName, DWLControl dwlControl)");
        if ((queryName == null) || queryName.trim().equals("")) {
      throw new IllegalArgumentException(ResourceBundleHelper.resolve(
          ResourceBundleNames.COMMON_SERVICES_STRINGS,
          EXCEPTION_QUERYNAME_EMPTY));
        }
    logger.finest("RETURN createMTTActCostChargesBObjQuery(String queryName, DWLControl dwlControl)");
        return new MTTActCostChargesBObjQuery(queryName, dwlControl);
    }

    /** 
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * This method returns an object of type <code>Persistence</code>
      * corresponding to <code>MTTActCostChargesBObj</code> business object.
      *
      * @param persistenceStrategyName
      * The persistence strategy name.  This parameter indicates the type of
      * database action to be taken such as addition, update or deletion of
      * records.
      * @param objectToPersist
      * The business object to be persisted.
      *      
      * @return 
      * An instance of <code>MTTActCostChargesBObjQuery</code>.
      *
      * @generated
      */
      public Persistence createMTTActCostChargesBObjPersistence(String persistenceStrategyName, DWLCommon objectToPersist) {

        return new MTTActCostChargesBObjQuery(persistenceStrategyName, objectToPersist);
      }

    /** 
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * Provides the concrete BObjQuery instance corresponding to the
      * <code>MTTActFinancialBObj</code> business object.
      *
      * @return 
      * An instance of <code>MTTActFinancialBObjQuery</code>.
      *
      * @generated
      */
      public BObjQuery createMTTActFinancialBObjQuery(String queryName, DWLControl dwlControl) {
    logger.finest("ENTER createMTTActFinancialBObjQuery(String queryName, DWLControl dwlControl)");
        if ((queryName == null) || queryName.trim().equals("")) {
      throw new IllegalArgumentException(ResourceBundleHelper.resolve(
          ResourceBundleNames.COMMON_SERVICES_STRINGS,
          EXCEPTION_QUERYNAME_EMPTY));
        }
    logger.finest("RETURN createMTTActFinancialBObjQuery(String queryName, DWLControl dwlControl)");
        return new MTTActFinancialBObjQuery(queryName, dwlControl);
    }

    /** 
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * This method returns an object of type <code>Persistence</code>
      * corresponding to <code>MTTActFinancialBObj</code> business object.
      *
      * @param persistenceStrategyName
      * The persistence strategy name.  This parameter indicates the type of
      * database action to be taken such as addition, update or deletion of
      * records.
      * @param objectToPersist
      * The business object to be persisted.
      *      
      * @return 
      * An instance of <code>MTTActFinancialBObjQuery</code>.
      *
      * @generated
      */
      public Persistence createMTTActFinancialBObjPersistence(String persistenceStrategyName, DWLCommon objectToPersist) {

        return new MTTActFinancialBObjQuery(persistenceStrategyName, objectToPersist);
      }
      

}


