
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[64f3e65762b01c7cb5087bab2773d1e4]
 */
package com.metcash.db.custom.bobj.query;




import com.dwl.base.DWLControl;
import com.dwl.bobj.query.BObjQueryException;
import com.dwl.base.DWLCommon;

import com.dwl.base.db.DataAccessFactory;


import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLDuplicateKeyException;

import com.dwl.base.interfaces.IGenericResultSetProcessor;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;

import com.metcash.db.custom.component.MTTActFinancialBObj;
import com.metcash.db.custom.component.MTTActFinancialResultSetProcessor;

import com.metcash.db.custom.constant.MTTDBCustomComponentID;
import com.metcash.db.custom.constant.MTTDBCustomErrorReasonCode;

import com.metcash.db.custom.entityObject.EObjMTTActFinancialData;
import com.metcash.db.custom.entityObject.MTTActFinancialInquiryData;


/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides query information for the business object
 * <code>MTTActFinancialBObj</code>.
 *
 * @generated
 */
public class MTTActFinancialBObjQuery  extends com.dwl.bobj.query.GenericBObjQuery {

     /**
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * @generated
      */
     public static final String MTTACT_FINANCIAL_QUERY = "getMTTActFinancial(Object[])";

     /**
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * @generated
      */
     public static final String MTTACT_FINANCIAL_HISTORY_QUERY = "getMTTActFinancialHistory(Object[])";

	/**
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * @generated
      */
     public static final String ALL_MTTACT_FINANCIALBY_ID_QUERY = "getAllMTTActFinancialbyID(Object[])";

    /**
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * @generated
      */
     public static final String ALL_MTTACT_FINANCIALBY_ID_HISTORY_QUERY = "getAllMTTActFinancialbyIDHistory(Object[])";

  /**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(MTTActFinancialBObjQuery.class);
     /**
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * @generated
      */
     public static final String MTTACT_FINANCIAL_ADD = "MTTACT_FINANCIAL_ADD";

     /**
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * @generated
      */
     public static final String MTTACT_FINANCIAL_DELETE = "MTTACT_FINANCIAL_DELETE";

     /**
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * @generated
      */
     public static final String MTTACT_FINANCIAL_UPDATE = "MTTACT_FINANCIAL_UPDATE";


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Default constructor.
     *
     * @param queryName
     * The name of the query.
     * @param control
     * The control object.
     *
     * @generated
     */
    public MTTActFinancialBObjQuery(String queryName, DWLControl control) {
        super(queryName, control);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Default constructor.
     *
     * @param persistenceStrategyName
     * The persistence strategy name.  This parameter indicates the type of
     * database action to be taken such as addition, update or deletion of
     * records.
     * @param objectToPersist
     * The business object to be persisted.
     *
     * @generated
     */
    public MTTActFinancialBObjQuery(String persistenceStrategyName, DWLCommon objectToPersist) {
        super(persistenceStrategyName, objectToPersist);
    }

	 
 	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
	protected void persist() throws Exception{
    logger.finest("ENTER persist()");
    if (logger.isFinestEnabled()) {
   		String infoForLogging="Persistence strategy is " + persistenceStrategyName;
      logger.finest("persist() " + infoForLogging);
        }
    if (persistenceStrategyName.equals(MTTACT_FINANCIAL_ADD)) {
      addMTTActFinancial();
    }else if(persistenceStrategyName.equals(MTTACT_FINANCIAL_UPDATE)) {
      updateMTTActFinancial();
    }else if(persistenceStrategyName.equals(MTTACT_FINANCIAL_DELETE)) {
      deleteMTTActFinancial();
    }
    logger.finest("RETURN persist()");
  }
  
 	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
      * Inserts mttactfinancial data by calling
      * <code>EObjMTTActFinancialData.createEObjMTTActFinancial</code>
     *
     * @throws Exception
     *
     * @generated
     */
	protected void addMTTActFinancial() throws Exception{
    logger.finest("ENTER addMTTActFinancial()");
    
    EObjMTTActFinancialData theEObjMTTActFinancialData = (EObjMTTActFinancialData) DataAccessFactory
      .getQuery(EObjMTTActFinancialData.class, connection);
    theEObjMTTActFinancialData.createEObjMTTActFinancial(((MTTActFinancialBObj) objectToPersist).getEObjMTTActFinancial());
    logger.finest("RETURN addMTTActFinancial()");
  }

 	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
      * Updates mttactfinancial data by calling
      * <code>EObjMTTActFinancialData.updateEObjMTTActFinancial</code>
     *
     * @throws Exception
     *
     * @generated
     */
	protected void updateMTTActFinancial() throws Exception{
    logger.finest("ENTER updateMTTActFinancial()");
    EObjMTTActFinancialData theEObjMTTActFinancialData = (EObjMTTActFinancialData) DataAccessFactory
      .getQuery(EObjMTTActFinancialData.class, connection);
    theEObjMTTActFinancialData.updateEObjMTTActFinancial(((MTTActFinancialBObj) objectToPersist).getEObjMTTActFinancial());
    logger.finest("RETURN updateMTTActFinancial()");
  }

 	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
      * Deletes {0} data by calling <{1}>{2}.{3}{4}</{1}>
   *
     * @throws Exception
     *
     * @generated
     */
	protected void deleteMTTActFinancial() throws Exception{
    logger.finest("ENTER deleteMTTActFinancial()");
         // MDM_TODO: CDKWB0018I Write customized business logic for the extension here.
    logger.finest("RETURN deleteMTTActFinancial()");
  } 
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
      * This method is overridden to construct
      * <code>DWLDuplicateKeyException</code> based on MTTActFinancial component
      * specific values.
     * 
     * @param errParams
     * The values to be substituted in the error message.
   *
     * @throws Exception
     *
     * @generated
     */
    protected void throwDuplicateKeyException(String[] errParams) throws Exception {
    if (logger.isFinestEnabled()) {
      	StringBuilder errParamsStringBuilder = new StringBuilder("Error: Duplicate key Exception parameters are ");
      	for(int i=0;i<errParams.length;i++) {
      		errParamsStringBuilder .append(errParams[i]);
      		if (i!=errParams.length-1) {
      			errParamsStringBuilder .append(" , ");
      		}
      	}
          String infoForLogging="Error: Duplicate key Exception parameters are " + errParamsStringBuilder;
      logger.finest("Unknown method " + infoForLogging);
    }
    	DWLExceptionUtils.throwDWLDuplicateKeyException(
    		new DWLDuplicateKeyException(buildDupThrowableMessage(errParams)),
    		objectToPersist.getStatus(), 
    		DWLStatus.FATAL,
    		MTTDBCustomComponentID.MTTDBCUSTOM_COMPONENT,
    		DWLErrorCode.DUPLICATE_KEY_ERROR, 
    		MTTDBCustomErrorReasonCode.DUPLICATE_PRIMARY_KEY_MTTACTFINANCIAL,
    		objectToPersist.getControl(), 
    		DWLClassFactory.getErrorHandler()
    		);
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Provides the result set processor that is used to populate the business
     * object.
     *
     * @return
     * An instance of <code>MTTActFinancialResultSetProcessor</code>.
     *
     * @see com.dwl.bobj.query.AbstractBObjQuery#provideResultSetProcessor()
     * @see com.metcash.db.custom.component.MTTActFinancialResultSetProcessor
     *
     * @generated
     */
    protected IGenericResultSetProcessor provideResultSetProcessor()
            throws BObjQueryException {

        return new MTTActFinancialResultSetProcessor();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    @Override
    protected Class<MTTActFinancialInquiryData> provideQueryInterfaceClass() throws BObjQueryException {
        return MTTActFinancialInquiryData.class;
    }

}


