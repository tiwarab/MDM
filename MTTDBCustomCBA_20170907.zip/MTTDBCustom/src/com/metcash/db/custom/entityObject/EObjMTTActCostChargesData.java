/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[3714cf8874839574b94ed767a2dc0849]
 */


package com.metcash.db.custom.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.metcash.db.custom.entityObject.EObjMTTActCostCharges;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjMTTActCostChargesData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjMTTActCostChargesSql = "select MTT_ACT_COST_CHARGES_ID, CONTRACT_ID, COST_BASE_TP_CD, DIRECT_SHIP_APPROVED_IND, DO_NOT_APPLY_DIRECT_DISC_IND, SRP_COMPLIANCE_TP_CD, PRICE_MATCH_GAP_FEE_IND, BRKN_CASE_UPCHARGE_PCT, BRKN_CASE_UPCHARGE_CAP, BRKN_CASE_UPCHARGE_IND, BRKN_CASE_CALC_TP_CD, SHELF_LABEL_PRICED_IND, PSRP_TP_CD, ADD_FRT_RECOVERY_SRP_IND, SRP_FRT_RECOVERY_VAL, SRP_FRT_RECOVERY_DIR_VAL,  LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from MTT_ACCOUNT_COST_CHARGES where MTT_ACT_COST_CHARGES_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjMTTActCostChargesSql = "insert into MTT_ACCOUNT_COST_CHARGES (MTT_ACT_COST_CHARGES_ID, CONTRACT_ID, COST_BASE_TP_CD, DIRECT_SHIP_APPROVED_IND, DO_NOT_APPLY_DIRECT_DISC_IND, SRP_COMPLIANCE_TP_CD, PRICE_MATCH_GAP_FEE_IND, BRKN_CASE_UPCHARGE_PCT, BRKN_CASE_UPCHARGE_CAP, BRKN_CASE_UPCHARGE_IND, BRKN_CASE_CALC_TP_CD, SHELF_LABEL_PRICED_IND, PSRP_TP_CD, ADD_FRT_RECOVERY_SRP_IND, SRP_FRT_RECOVERY_VAL, SRP_FRT_RECOVERY_DIR_VAL, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :mTTActCostChargesIdPk, :contractId, :costBase, :directShipApprovedInd, :doNotApplyDirectDiscountInd, :sRPComplicance, :priceMatchGapFeeInd, :brokenCaseUpchargePercentage, :brokenCaseUpchargeCap, :brokenCaseUpchargeInd, :brokenCaseCal, :shelfLabelPricedInd, :pSRP, :addFRTRecoverySRPInd, :sRPFRTRecoveryValue, :sRPFRTRecoveryDirectValue, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjMTTActCostChargesSql = "update MTT_ACCOUNT_COST_CHARGES set CONTRACT_ID = :contractId, COST_BASE_TP_CD = :costBase, DIRECT_SHIP_APPROVED_IND = :directShipApprovedInd, DO_NOT_APPLY_DIRECT_DISC_IND = :doNotApplyDirectDiscountInd, SRP_COMPLIANCE_TP_CD = :sRPComplicance, PRICE_MATCH_GAP_FEE_IND = :priceMatchGapFeeInd, BRKN_CASE_UPCHARGE_PCT = :brokenCaseUpchargePercentage, BRKN_CASE_UPCHARGE_CAP = :brokenCaseUpchargeCap, BRKN_CASE_UPCHARGE_IND = :brokenCaseUpchargeInd, BRKN_CASE_CALC_TP_CD = :brokenCaseCal, SHELF_LABEL_PRICED_IND = :shelfLabelPricedInd, PSRP_TP_CD = :pSRP, ADD_FRT_RECOVERY_SRP_IND = :addFRTRecoverySRPInd, SRP_FRT_RECOVERY_VAL = :sRPFRTRecoveryValue, SRP_FRT_RECOVERY_DIR_VAL = :sRPFRTRecoveryDirectValue, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where MTT_ACT_COST_CHARGES_ID = :mTTActCostChargesIdPk and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjMTTActCostChargesSql = "delete from MTT_ACCOUNT_COST_CHARGES where MTT_ACT_COST_CHARGES_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjMTTActCostChargesKeyField = "EObjMTTActCostCharges.mTTActCostChargesIdPk";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjMTTActCostChargesGetFields =
    "EObjMTTActCostCharges.mTTActCostChargesIdPk," +
    "EObjMTTActCostCharges.contractId," +
    "EObjMTTActCostCharges.costBase," +
    "EObjMTTActCostCharges.directShipApprovedInd," +
    "EObjMTTActCostCharges.doNotApplyDirectDiscountInd," +
    "EObjMTTActCostCharges.sRPComplicance," +
    "EObjMTTActCostCharges.priceMatchGapFeeInd," +
    "EObjMTTActCostCharges.brokenCaseUpchargePercentage," +
    "EObjMTTActCostCharges.brokenCaseUpchargeCap," +
    "EObjMTTActCostCharges.brokenCaseUpchargeInd," +
    "EObjMTTActCostCharges.brokenCaseCal," +
    "EObjMTTActCostCharges.shelfLabelPricedInd," +
    "EObjMTTActCostCharges.pSRP," +
    "EObjMTTActCostCharges.addFRTRecoverySRPInd," +
    "EObjMTTActCostCharges.sRPFRTRecoveryValue," +
    "EObjMTTActCostCharges.sRPFRTRecoveryDirectValue," +
    "EObjMTTActCostCharges.lastUpdateDt," +
    "EObjMTTActCostCharges.lastUpdateUser," +
    "EObjMTTActCostCharges.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjMTTActCostChargesAllFields =
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.mTTActCostChargesIdPk," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.contractId," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.costBase," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.directShipApprovedInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.doNotApplyDirectDiscountInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.sRPComplicance," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.priceMatchGapFeeInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.brokenCaseUpchargePercentage," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.brokenCaseUpchargeCap," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.brokenCaseUpchargeInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.brokenCaseCal," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.shelfLabelPricedInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.pSRP," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.addFRTRecoverySRPInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.sRPFRTRecoveryValue," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.sRPFRTRecoveryDirectValue," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.lastUpdateDt," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.lastUpdateUser," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjMTTActCostChargesUpdateFields =
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.contractId," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.costBase," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.directShipApprovedInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.doNotApplyDirectDiscountInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.sRPComplicance," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.priceMatchGapFeeInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.brokenCaseUpchargePercentage," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.brokenCaseUpchargeCap," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.brokenCaseUpchargeInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.brokenCaseCal," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.shelfLabelPricedInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.pSRP," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.addFRTRecoverySRPInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.sRPFRTRecoveryValue," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.sRPFRTRecoveryDirectValue," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.lastUpdateDt," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.lastUpdateUser," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.lastUpdateTxId," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.mTTActCostChargesIdPk," +
    "com.metcash.db.custom.entityObject.EObjMTTActCostCharges.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select MTTActCostCharges by parameters.
   * @generated
   */
  @Select(sql=getEObjMTTActCostChargesSql)
  @EntityMapping(parameters=EObjMTTActCostChargesKeyField, results=EObjMTTActCostChargesGetFields)
  Iterator<EObjMTTActCostCharges> getEObjMTTActCostCharges(Long mTTActCostChargesIdPk);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create MTTActCostCharges by EObjMTTActCostCharges Object.
   * @generated
   */
  @Update(sql=createEObjMTTActCostChargesSql)
  @EntityMapping(parameters=EObjMTTActCostChargesAllFields)
    int createEObjMTTActCostCharges(EObjMTTActCostCharges e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one MTTActCostCharges by EObjMTTActCostCharges object.
   * @generated
   */
  @Update(sql=updateEObjMTTActCostChargesSql)
  @EntityMapping(parameters=EObjMTTActCostChargesUpdateFields)
    int updateEObjMTTActCostCharges(EObjMTTActCostCharges e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete MTTActCostCharges by parameters.
   * @generated
   */
  @Update(sql=deleteEObjMTTActCostChargesSql)
  @EntityMapping(parameters=EObjMTTActCostChargesKeyField)
  int deleteEObjMTTActCostCharges(Long mTTActCostChargesIdPk);

}

