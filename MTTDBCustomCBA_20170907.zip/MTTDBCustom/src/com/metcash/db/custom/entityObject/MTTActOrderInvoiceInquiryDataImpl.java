package com.metcash.db.custom.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.ibm.mdm.base.db.ResultQueue1;
import com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


@SuppressWarnings("unchecked")

/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class MTTActOrderInvoiceInquiryDataImpl  extends BaseData implements MTTActOrderInvoiceInquiryData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "MTTActOrderInvoiceInquiryData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000015e4b0dbdaaL;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public MTTActOrderInvoiceInquiryDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="SELECT r.MTT_ACT_ORDER_INV_ID MTT_ACT_ORDER_INV_ID, r.CONTRACT_ID CONTRACT_ID, r.PRN_RETAIL_IND PRN_RETAIL_IND, r.PRN_PRICE_MATCH_SUMMARY_IND PRN_PRICE_MATCH_SUMMARY_IND, r.SUBSTITUTE_ITEM_IND SUBSTITUTE_ITEM_IND, r.INV_SEQ_TP_CD INV_SEQ_TP_CD, r.INV_COPIES_NUM INV_COPIES_NUM, r.INV_MODE_TP_CD INV_MODE_TP_CD, r.ORDER_GUIDE_TP_CD ORDER_GUIDE_TP_CD, r.SEP_ORDER_ITEM_RESRV_IND SEP_ORDER_ITEM_RESRV_IND, r.SPECIAL_INSTRUCTIONS SPECIAL_INSTRUCTIONS, r.PRN_CAT_INV_BRK_TP_CD PRN_CAT_INV_BRK_TP_CD, r.INV_RECAP_SUMMARY_TP_CD INV_RECAP_SUMMARY_TP_CD, r.PO_NUM_REQ_IND PO_NUM_REQ_IND, r.PICKUP_DELIVER_TP_CD PICKUP_DELIVER_TP_CD, r.PRN_ALT_TOBACCO_LICENCE_IND PRN_ALT_TOBACCO_LICENCE_IND, r.TOTES_IND TOTES_IND, r.TOTES_TP_CD TOTES_TP_CD, r.UNIT_CASE_COST_PRN_TP_CD UNIT_CASE_COST_PRN_TP_CD, r.INV_FORMAT_TP_CD INV_FORMAT_TP_CD, r.PICK_EACHES_IND PICK_EACHES_IND, r.INV_TP_CD INV_TP_CD, r.INV_STOP_MSG INV_STOP_MSG, r.DEL_PICK_PACK_INV_TP_CD DEL_PICK_PACK_INV_TP_CD, r.PRN_HO_INV_IND PRN_HO_INV_IND, r.PRN_WHOLESALE_ON_INV_IND PRN_WHOLESALE_ON_INV_IND, r.SEP_INV_PER_CUS_PO_IND SEP_INV_PER_CUS_PO_IND, r.ASN_REQ_IND ASN_REQ_IND, r.EASNMailbox EASNMailbox, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM MTT_ACCOUNT_ORDER_INVOICE r WHERE r.MTT_ACT_ORDER_INV_ID = ? ", pattern="tableAlias (MTT_ACCOUNT_ORDER_INVOICE => com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice, H_MTT_ACCOUNT_ORDER_INVOICE => com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjMTTActOrderInvoice>> getMTTActOrderInvoice (Object[] parameters)
  {
    return queryIterator (getMTTActOrderInvoiceStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getMTTActOrderInvoiceStatementDescriptor = createStatementDescriptor (
    "getMTTActOrderInvoice(Object[])",
    "SELECT r.MTT_ACT_ORDER_INV_ID MTT_ACT_ORDER_INV_ID, r.CONTRACT_ID CONTRACT_ID, r.PRN_RETAIL_IND PRN_RETAIL_IND, r.PRN_PRICE_MATCH_SUMMARY_IND PRN_PRICE_MATCH_SUMMARY_IND, r.SUBSTITUTE_ITEM_IND SUBSTITUTE_ITEM_IND, r.INV_SEQ_TP_CD INV_SEQ_TP_CD, r.INV_COPIES_NUM INV_COPIES_NUM, r.INV_MODE_TP_CD INV_MODE_TP_CD, r.ORDER_GUIDE_TP_CD ORDER_GUIDE_TP_CD, r.SEP_ORDER_ITEM_RESRV_IND SEP_ORDER_ITEM_RESRV_IND, r.SPECIAL_INSTRUCTIONS SPECIAL_INSTRUCTIONS, r.PRN_CAT_INV_BRK_TP_CD PRN_CAT_INV_BRK_TP_CD, r.INV_RECAP_SUMMARY_TP_CD INV_RECAP_SUMMARY_TP_CD, r.PO_NUM_REQ_IND PO_NUM_REQ_IND, r.PICKUP_DELIVER_TP_CD PICKUP_DELIVER_TP_CD, r.PRN_ALT_TOBACCO_LICENCE_IND PRN_ALT_TOBACCO_LICENCE_IND, r.TOTES_IND TOTES_IND, r.TOTES_TP_CD TOTES_TP_CD, r.UNIT_CASE_COST_PRN_TP_CD UNIT_CASE_COST_PRN_TP_CD, r.INV_FORMAT_TP_CD INV_FORMAT_TP_CD, r.PICK_EACHES_IND PICK_EACHES_IND, r.INV_TP_CD INV_TP_CD, r.INV_STOP_MSG INV_STOP_MSG, r.DEL_PICK_PACK_INV_TP_CD DEL_PICK_PACK_INV_TP_CD, r.PRN_HO_INV_IND PRN_HO_INV_IND, r.PRN_WHOLESALE_ON_INV_IND PRN_WHOLESALE_ON_INV_IND, r.SEP_INV_PER_CUS_PO_IND SEP_INV_PER_CUS_PO_IND, r.ASN_REQ_IND ASN_REQ_IND, r.EASNMailbox EASNMailbox, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM MTT_ACCOUNT_ORDER_INVOICE r WHERE r.MTT_ACT_ORDER_INV_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"mtt_act_order_inv_id", "contract_id", "prn_retail_ind", "prn_price_match_summary_ind", "substitute_item_ind", "inv_seq_tp_cd", "inv_copies_num", "inv_mode_tp_cd", "order_guide_tp_cd", "sep_order_item_resrv_ind", "special_instructions", "prn_cat_inv_brk_tp_cd", "inv_recap_summary_tp_cd", "po_num_req_ind", "pickup_deliver_tp_cd", "prn_alt_tobacco_licence_ind", "totes_ind", "totes_tp_cd", "unit_case_cost_prn_tp_cd", "inv_format_tp_cd", "pick_eaches_ind", "inv_tp_cd", "inv_stop_msg", "del_pick_pack_inv_tp_cd", "prn_ho_inv_ind", "prn_wholesale_on_inv_ind", "sep_inv_per_cus_po_ind", "asn_req_ind", "easnmailbox", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetMTTActOrderInvoiceParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetMTTActOrderInvoiceRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.INTEGER, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 1, 1, 1, 19, 10, 19, 19, 1, 250, 19, 19, 1, 19, 1, 1, 19, 19, 19, 1, 19, 250, 19, 1, 1, 1, 1, 100, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetMTTActOrderInvoiceParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetMTTActOrderInvoiceRowHandler extends BaseRowHandler<ResultQueue1<EObjMTTActOrderInvoice>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjMTTActOrderInvoice> handle (java.sql.ResultSet rs, ResultQueue1<EObjMTTActOrderInvoice> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjMTTActOrderInvoice> ();

      EObjMTTActOrderInvoice returnObject1 = new EObjMTTActOrderInvoice ();
      returnObject1.setMTTActOrderInvoiceIdPk(getLongObject (rs, 1)); 
      returnObject1.setContractId(getLongObject (rs, 2)); 
      returnObject1.setPrintRetailInd(getString (rs, 3)); 
      returnObject1.setPrintPriceMatchSummaryInd(getString (rs, 4)); 
      returnObject1.setSubstituteItemInd(getString (rs, 5)); 
      returnObject1.setInvoiceSequence(getLongObject (rs, 6)); 
      returnObject1.setInvoiceCopiesNumber(getIntObject (rs, 7)); 
      returnObject1.setInvoiceMode(getLongObject (rs, 8)); 
      returnObject1.setOrderGuide(getLongObject (rs, 9)); 
      returnObject1.setSepOrderItemReserveInd(getString (rs, 10)); 
      returnObject1.setSpecialInstructions(getString (rs, 11)); 
      returnObject1.setPrintCatInvoiceBreak(getLongObject (rs, 12)); 
      returnObject1.setInvoiceRecapSummary(getLongObject (rs, 13)); 
      returnObject1.setPONumberRequiredInd(getString (rs, 14)); 
      returnObject1.setPickupDeliver(getLongObject (rs, 15)); 
      returnObject1.setPrintAlternateTobaccoLicenceInd(getString (rs, 16)); 
      returnObject1.setTotesInd(getString (rs, 17)); 
      returnObject1.setTotes(getLongObject (rs, 18)); 
      returnObject1.setUnitCaseCostPrint(getLongObject (rs, 19)); 
      returnObject1.setInvoiceFormat(getLongObject (rs, 20)); 
      returnObject1.setPickEachesInd(getString (rs, 21)); 
      returnObject1.setInvoice(getLongObject (rs, 22)); 
      returnObject1.setInvoiceStopMessage(getString (rs, 23)); 
      returnObject1.setDelPickPackInvoice(getLongObject (rs, 24)); 
      returnObject1.setPrintHOInvoiceInd(getString (rs, 25)); 
      returnObject1.setPrintWholesaleOnInvoiceInd(getString (rs, 26)); 
      returnObject1.setSepInvoicePerCustomerPOInd(getString (rs, 27)); 
      returnObject1.setASNRequiredInd(getString (rs, 28)); 
      returnObject1.setEASNMailbox(getString (rs, 29)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 30)); 
      returnObject1.setLastUpdateUser(getString (rs, 31)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 32)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_MTT_ACT_ORDER_INV_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.MTT_ACT_ORDER_INV_ID MTT_ACT_ORDER_INV_ID, r.CONTRACT_ID CONTRACT_ID, r.PRN_RETAIL_IND PRN_RETAIL_IND, r.PRN_PRICE_MATCH_SUMMARY_IND PRN_PRICE_MATCH_SUMMARY_IND, r.SUBSTITUTE_ITEM_IND SUBSTITUTE_ITEM_IND, r.INV_SEQ_TP_CD INV_SEQ_TP_CD, r.INV_COPIES_NUM INV_COPIES_NUM, r.INV_MODE_TP_CD INV_MODE_TP_CD, r.ORDER_GUIDE_TP_CD ORDER_GUIDE_TP_CD, r.SEP_ORDER_ITEM_RESRV_IND SEP_ORDER_ITEM_RESRV_IND, r.SPECIAL_INSTRUCTIONS SPECIAL_INSTRUCTIONS, r.PRN_CAT_INV_BRK_TP_CD PRN_CAT_INV_BRK_TP_CD, r.INV_RECAP_SUMMARY_TP_CD INV_RECAP_SUMMARY_TP_CD, r.PO_NUM_REQ_IND PO_NUM_REQ_IND, r.PICKUP_DELIVER_TP_CD PICKUP_DELIVER_TP_CD, r.PRN_ALT_TOBACCO_LICENCE_IND PRN_ALT_TOBACCO_LICENCE_IND, r.TOTES_IND TOTES_IND, r.TOTES_TP_CD TOTES_TP_CD, r.UNIT_CASE_COST_PRN_TP_CD UNIT_CASE_COST_PRN_TP_CD, r.INV_FORMAT_TP_CD INV_FORMAT_TP_CD, r.PICK_EACHES_IND PICK_EACHES_IND, r.INV_TP_CD INV_TP_CD, r.INV_STOP_MSG INV_STOP_MSG, r.DEL_PICK_PACK_INV_TP_CD DEL_PICK_PACK_INV_TP_CD, r.PRN_HO_INV_IND PRN_HO_INV_IND, r.PRN_WHOLESALE_ON_INV_IND PRN_WHOLESALE_ON_INV_IND, r.SEP_INV_PER_CUS_PO_IND SEP_INV_PER_CUS_PO_IND, r.ASN_REQ_IND ASN_REQ_IND, r.EASNMailbox EASNMailbox, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_MTT_ACCOUNT_ORDER_INVOICE r WHERE r.H_MTT_ACT_ORDER_INV_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (MTT_ACCOUNT_ORDER_INVOICE => com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice, H_MTT_ACCOUNT_ORDER_INVOICE => com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjMTTActOrderInvoice>> getMTTActOrderInvoiceHistory (Object[] parameters)
  {
    return queryIterator (getMTTActOrderInvoiceHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getMTTActOrderInvoiceHistoryStatementDescriptor = createStatementDescriptor (
    "getMTTActOrderInvoiceHistory(Object[])",
    "SELECT r.H_MTT_ACT_ORDER_INV_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.MTT_ACT_ORDER_INV_ID MTT_ACT_ORDER_INV_ID, r.CONTRACT_ID CONTRACT_ID, r.PRN_RETAIL_IND PRN_RETAIL_IND, r.PRN_PRICE_MATCH_SUMMARY_IND PRN_PRICE_MATCH_SUMMARY_IND, r.SUBSTITUTE_ITEM_IND SUBSTITUTE_ITEM_IND, r.INV_SEQ_TP_CD INV_SEQ_TP_CD, r.INV_COPIES_NUM INV_COPIES_NUM, r.INV_MODE_TP_CD INV_MODE_TP_CD, r.ORDER_GUIDE_TP_CD ORDER_GUIDE_TP_CD, r.SEP_ORDER_ITEM_RESRV_IND SEP_ORDER_ITEM_RESRV_IND, r.SPECIAL_INSTRUCTIONS SPECIAL_INSTRUCTIONS, r.PRN_CAT_INV_BRK_TP_CD PRN_CAT_INV_BRK_TP_CD, r.INV_RECAP_SUMMARY_TP_CD INV_RECAP_SUMMARY_TP_CD, r.PO_NUM_REQ_IND PO_NUM_REQ_IND, r.PICKUP_DELIVER_TP_CD PICKUP_DELIVER_TP_CD, r.PRN_ALT_TOBACCO_LICENCE_IND PRN_ALT_TOBACCO_LICENCE_IND, r.TOTES_IND TOTES_IND, r.TOTES_TP_CD TOTES_TP_CD, r.UNIT_CASE_COST_PRN_TP_CD UNIT_CASE_COST_PRN_TP_CD, r.INV_FORMAT_TP_CD INV_FORMAT_TP_CD, r.PICK_EACHES_IND PICK_EACHES_IND, r.INV_TP_CD INV_TP_CD, r.INV_STOP_MSG INV_STOP_MSG, r.DEL_PICK_PACK_INV_TP_CD DEL_PICK_PACK_INV_TP_CD, r.PRN_HO_INV_IND PRN_HO_INV_IND, r.PRN_WHOLESALE_ON_INV_IND PRN_WHOLESALE_ON_INV_IND, r.SEP_INV_PER_CUS_PO_IND SEP_INV_PER_CUS_PO_IND, r.ASN_REQ_IND ASN_REQ_IND, r.EASNMailbox EASNMailbox, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_MTT_ACCOUNT_ORDER_INVOICE r WHERE r.H_MTT_ACT_ORDER_INV_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "mtt_act_order_inv_id", "contract_id", "prn_retail_ind", "prn_price_match_summary_ind", "substitute_item_ind", "inv_seq_tp_cd", "inv_copies_num", "inv_mode_tp_cd", "order_guide_tp_cd", "sep_order_item_resrv_ind", "special_instructions", "prn_cat_inv_brk_tp_cd", "inv_recap_summary_tp_cd", "po_num_req_ind", "pickup_deliver_tp_cd", "prn_alt_tobacco_licence_ind", "totes_ind", "totes_tp_cd", "unit_case_cost_prn_tp_cd", "inv_format_tp_cd", "pick_eaches_ind", "inv_tp_cd", "inv_stop_msg", "del_pick_pack_inv_tp_cd", "prn_ho_inv_ind", "prn_wholesale_on_inv_ind", "sep_inv_per_cus_po_ind", "asn_req_ind", "easnmailbox", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetMTTActOrderInvoiceHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetMTTActOrderInvoiceHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.INTEGER, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 19, 1, 1, 1, 19, 10, 19, 19, 1, 250, 19, 19, 1, 19, 1, 1, 19, 19, 19, 1, 19, 250, 19, 1, 1, 1, 1, 100, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class GetMTTActOrderInvoiceHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetMTTActOrderInvoiceHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjMTTActOrderInvoice>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjMTTActOrderInvoice> handle (java.sql.ResultSet rs, ResultQueue1<EObjMTTActOrderInvoice> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjMTTActOrderInvoice> ();

      EObjMTTActOrderInvoice returnObject1 = new EObjMTTActOrderInvoice ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setMTTActOrderInvoiceIdPk(getLongObject (rs, 6)); 
      returnObject1.setContractId(getLongObject (rs, 7)); 
      returnObject1.setPrintRetailInd(getString (rs, 8)); 
      returnObject1.setPrintPriceMatchSummaryInd(getString (rs, 9)); 
      returnObject1.setSubstituteItemInd(getString (rs, 10)); 
      returnObject1.setInvoiceSequence(getLongObject (rs, 11)); 
      returnObject1.setInvoiceCopiesNumber(getIntObject (rs, 12)); 
      returnObject1.setInvoiceMode(getLongObject (rs, 13)); 
      returnObject1.setOrderGuide(getLongObject (rs, 14)); 
      returnObject1.setSepOrderItemReserveInd(getString (rs, 15)); 
      returnObject1.setSpecialInstructions(getString (rs, 16)); 
      returnObject1.setPrintCatInvoiceBreak(getLongObject (rs, 17)); 
      returnObject1.setInvoiceRecapSummary(getLongObject (rs, 18)); 
      returnObject1.setPONumberRequiredInd(getString (rs, 19)); 
      returnObject1.setPickupDeliver(getLongObject (rs, 20)); 
      returnObject1.setPrintAlternateTobaccoLicenceInd(getString (rs, 21)); 
      returnObject1.setTotesInd(getString (rs, 22)); 
      returnObject1.setTotes(getLongObject (rs, 23)); 
      returnObject1.setUnitCaseCostPrint(getLongObject (rs, 24)); 
      returnObject1.setInvoiceFormat(getLongObject (rs, 25)); 
      returnObject1.setPickEachesInd(getString (rs, 26)); 
      returnObject1.setInvoice(getLongObject (rs, 27)); 
      returnObject1.setInvoiceStopMessage(getString (rs, 28)); 
      returnObject1.setDelPickPackInvoice(getLongObject (rs, 29)); 
      returnObject1.setPrintHOInvoiceInd(getString (rs, 30)); 
      returnObject1.setPrintWholesaleOnInvoiceInd(getString (rs, 31)); 
      returnObject1.setSepInvoicePerCustomerPOInd(getString (rs, 32)); 
      returnObject1.setASNRequiredInd(getString (rs, 33)); 
      returnObject1.setEASNMailbox(getString (rs, 34)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 35)); 
      returnObject1.setLastUpdateUser(getString (rs, 36)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 37)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.MTT_ACT_ORDER_INV_ID MTT_ACT_ORDER_INV_ID, r.CONTRACT_ID CONTRACT_ID, r.PRN_RETAIL_IND PRN_RETAIL_IND, r.PRN_PRICE_MATCH_SUMMARY_IND PRN_PRICE_MATCH_SUMMARY_IND, r.SUBSTITUTE_ITEM_IND SUBSTITUTE_ITEM_IND, r.INV_SEQ_TP_CD INV_SEQ_TP_CD, r.INV_COPIES_NUM INV_COPIES_NUM, r.INV_MODE_TP_CD INV_MODE_TP_CD, r.ORDER_GUIDE_TP_CD ORDER_GUIDE_TP_CD, r.SEP_ORDER_ITEM_RESRV_IND SEP_ORDER_ITEM_RESRV_IND, r.SPECIAL_INSTRUCTIONS SPECIAL_INSTRUCTIONS, r.PRN_CAT_INV_BRK_TP_CD PRN_CAT_INV_BRK_TP_CD, r.INV_RECAP_SUMMARY_TP_CD INV_RECAP_SUMMARY_TP_CD, r.PO_NUM_REQ_IND PO_NUM_REQ_IND, r.PICKUP_DELIVER_TP_CD PICKUP_DELIVER_TP_CD, r.PRN_ALT_TOBACCO_LICENCE_IND PRN_ALT_TOBACCO_LICENCE_IND, r.TOTES_IND TOTES_IND, r.TOTES_TP_CD TOTES_TP_CD, r.UNIT_CASE_COST_PRN_TP_CD UNIT_CASE_COST_PRN_TP_CD, r.INV_FORMAT_TP_CD INV_FORMAT_TP_CD, r.PICK_EACHES_IND PICK_EACHES_IND, r.INV_TP_CD INV_TP_CD, r.INV_STOP_MSG INV_STOP_MSG, r.DEL_PICK_PACK_INV_TP_CD DEL_PICK_PACK_INV_TP_CD, r.PRN_HO_INV_IND PRN_HO_INV_IND, r.PRN_WHOLESALE_ON_INV_IND PRN_WHOLESALE_ON_INV_IND, r.SEP_INV_PER_CUS_PO_IND SEP_INV_PER_CUS_PO_IND, r.ASN_REQ_IND ASN_REQ_IND, r.EASNMailbox EASNMailbox, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM MTT_ACCOUNT_ORDER_INVOICE r WHERE r.CONTRACT_ID = ? ", pattern="tableAlias (MTT_ACCOUNT_ORDER_INVOICE => com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice, H_MTT_ACCOUNT_ORDER_INVOICE => com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjMTTActOrderInvoice>> getAllMTTOrderInvoiceByID (Object[] parameters)
  {
    return queryIterator (getAllMTTOrderInvoiceByIDStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getAllMTTOrderInvoiceByIDStatementDescriptor = createStatementDescriptor (
    "getAllMTTOrderInvoiceByID(Object[])",
    "SELECT r.MTT_ACT_ORDER_INV_ID MTT_ACT_ORDER_INV_ID, r.CONTRACT_ID CONTRACT_ID, r.PRN_RETAIL_IND PRN_RETAIL_IND, r.PRN_PRICE_MATCH_SUMMARY_IND PRN_PRICE_MATCH_SUMMARY_IND, r.SUBSTITUTE_ITEM_IND SUBSTITUTE_ITEM_IND, r.INV_SEQ_TP_CD INV_SEQ_TP_CD, r.INV_COPIES_NUM INV_COPIES_NUM, r.INV_MODE_TP_CD INV_MODE_TP_CD, r.ORDER_GUIDE_TP_CD ORDER_GUIDE_TP_CD, r.SEP_ORDER_ITEM_RESRV_IND SEP_ORDER_ITEM_RESRV_IND, r.SPECIAL_INSTRUCTIONS SPECIAL_INSTRUCTIONS, r.PRN_CAT_INV_BRK_TP_CD PRN_CAT_INV_BRK_TP_CD, r.INV_RECAP_SUMMARY_TP_CD INV_RECAP_SUMMARY_TP_CD, r.PO_NUM_REQ_IND PO_NUM_REQ_IND, r.PICKUP_DELIVER_TP_CD PICKUP_DELIVER_TP_CD, r.PRN_ALT_TOBACCO_LICENCE_IND PRN_ALT_TOBACCO_LICENCE_IND, r.TOTES_IND TOTES_IND, r.TOTES_TP_CD TOTES_TP_CD, r.UNIT_CASE_COST_PRN_TP_CD UNIT_CASE_COST_PRN_TP_CD, r.INV_FORMAT_TP_CD INV_FORMAT_TP_CD, r.PICK_EACHES_IND PICK_EACHES_IND, r.INV_TP_CD INV_TP_CD, r.INV_STOP_MSG INV_STOP_MSG, r.DEL_PICK_PACK_INV_TP_CD DEL_PICK_PACK_INV_TP_CD, r.PRN_HO_INV_IND PRN_HO_INV_IND, r.PRN_WHOLESALE_ON_INV_IND PRN_WHOLESALE_ON_INV_IND, r.SEP_INV_PER_CUS_PO_IND SEP_INV_PER_CUS_PO_IND, r.ASN_REQ_IND ASN_REQ_IND, r.EASNMailbox EASNMailbox, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM MTT_ACCOUNT_ORDER_INVOICE r WHERE r.CONTRACT_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"mtt_act_order_inv_id", "contract_id", "prn_retail_ind", "prn_price_match_summary_ind", "substitute_item_ind", "inv_seq_tp_cd", "inv_copies_num", "inv_mode_tp_cd", "order_guide_tp_cd", "sep_order_item_resrv_ind", "special_instructions", "prn_cat_inv_brk_tp_cd", "inv_recap_summary_tp_cd", "po_num_req_ind", "pickup_deliver_tp_cd", "prn_alt_tobacco_licence_ind", "totes_ind", "totes_tp_cd", "unit_case_cost_prn_tp_cd", "inv_format_tp_cd", "pick_eaches_ind", "inv_tp_cd", "inv_stop_msg", "del_pick_pack_inv_tp_cd", "prn_ho_inv_ind", "prn_wholesale_on_inv_ind", "sep_inv_per_cus_po_ind", "asn_req_ind", "easnmailbox", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetAllMTTOrderInvoiceByIDParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetAllMTTOrderInvoiceByIDRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.INTEGER, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 1, 1, 1, 19, 10, 19, 19, 1, 250, 19, 19, 1, 19, 1, 1, 19, 19, 19, 1, 19, 250, 19, 1, 1, 1, 1, 100, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class GetAllMTTOrderInvoiceByIDParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetAllMTTOrderInvoiceByIDRowHandler extends BaseRowHandler<ResultQueue1<EObjMTTActOrderInvoice>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjMTTActOrderInvoice> handle (java.sql.ResultSet rs, ResultQueue1<EObjMTTActOrderInvoice> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjMTTActOrderInvoice> ();

      EObjMTTActOrderInvoice returnObject1 = new EObjMTTActOrderInvoice ();
      returnObject1.setMTTActOrderInvoiceIdPk(getLongObject (rs, 1)); 
      returnObject1.setContractId(getLongObject (rs, 2)); 
      returnObject1.setPrintRetailInd(getString (rs, 3)); 
      returnObject1.setPrintPriceMatchSummaryInd(getString (rs, 4)); 
      returnObject1.setSubstituteItemInd(getString (rs, 5)); 
      returnObject1.setInvoiceSequence(getLongObject (rs, 6)); 
      returnObject1.setInvoiceCopiesNumber(getIntObject (rs, 7)); 
      returnObject1.setInvoiceMode(getLongObject (rs, 8)); 
      returnObject1.setOrderGuide(getLongObject (rs, 9)); 
      returnObject1.setSepOrderItemReserveInd(getString (rs, 10)); 
      returnObject1.setSpecialInstructions(getString (rs, 11)); 
      returnObject1.setPrintCatInvoiceBreak(getLongObject (rs, 12)); 
      returnObject1.setInvoiceRecapSummary(getLongObject (rs, 13)); 
      returnObject1.setPONumberRequiredInd(getString (rs, 14)); 
      returnObject1.setPickupDeliver(getLongObject (rs, 15)); 
      returnObject1.setPrintAlternateTobaccoLicenceInd(getString (rs, 16)); 
      returnObject1.setTotesInd(getString (rs, 17)); 
      returnObject1.setTotes(getLongObject (rs, 18)); 
      returnObject1.setUnitCaseCostPrint(getLongObject (rs, 19)); 
      returnObject1.setInvoiceFormat(getLongObject (rs, 20)); 
      returnObject1.setPickEachesInd(getString (rs, 21)); 
      returnObject1.setInvoice(getLongObject (rs, 22)); 
      returnObject1.setInvoiceStopMessage(getString (rs, 23)); 
      returnObject1.setDelPickPackInvoice(getLongObject (rs, 24)); 
      returnObject1.setPrintHOInvoiceInd(getString (rs, 25)); 
      returnObject1.setPrintWholesaleOnInvoiceInd(getString (rs, 26)); 
      returnObject1.setSepInvoicePerCustomerPOInd(getString (rs, 27)); 
      returnObject1.setASNRequiredInd(getString (rs, 28)); 
      returnObject1.setEASNMailbox(getString (rs, 29)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 30)); 
      returnObject1.setLastUpdateUser(getString (rs, 31)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 32)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_MTT_ACT_ORDER_INV_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.MTT_ACT_ORDER_INV_ID MTT_ACT_ORDER_INV_ID, r.CONTRACT_ID CONTRACT_ID, r.PRN_RETAIL_IND PRN_RETAIL_IND, r.PRN_PRICE_MATCH_SUMMARY_IND PRN_PRICE_MATCH_SUMMARY_IND, r.SUBSTITUTE_ITEM_IND SUBSTITUTE_ITEM_IND, r.INV_SEQ_TP_CD INV_SEQ_TP_CD, r.INV_COPIES_NUM INV_COPIES_NUM, r.INV_MODE_TP_CD INV_MODE_TP_CD, r.ORDER_GUIDE_TP_CD ORDER_GUIDE_TP_CD, r.SEP_ORDER_ITEM_RESRV_IND SEP_ORDER_ITEM_RESRV_IND, r.SPECIAL_INSTRUCTIONS SPECIAL_INSTRUCTIONS, r.PRN_CAT_INV_BRK_TP_CD PRN_CAT_INV_BRK_TP_CD, r.INV_RECAP_SUMMARY_TP_CD INV_RECAP_SUMMARY_TP_CD, r.PO_NUM_REQ_IND PO_NUM_REQ_IND, r.PICKUP_DELIVER_TP_CD PICKUP_DELIVER_TP_CD, r.PRN_ALT_TOBACCO_LICENCE_IND PRN_ALT_TOBACCO_LICENCE_IND, r.TOTES_IND TOTES_IND, r.TOTES_TP_CD TOTES_TP_CD, r.UNIT_CASE_COST_PRN_TP_CD UNIT_CASE_COST_PRN_TP_CD, r.INV_FORMAT_TP_CD INV_FORMAT_TP_CD, r.PICK_EACHES_IND PICK_EACHES_IND, r.INV_TP_CD INV_TP_CD, r.INV_STOP_MSG INV_STOP_MSG, r.DEL_PICK_PACK_INV_TP_CD DEL_PICK_PACK_INV_TP_CD, r.PRN_HO_INV_IND PRN_HO_INV_IND, r.PRN_WHOLESALE_ON_INV_IND PRN_WHOLESALE_ON_INV_IND, r.SEP_INV_PER_CUS_PO_IND SEP_INV_PER_CUS_PO_IND, r.ASN_REQ_IND ASN_REQ_IND, r.EASNMailbox EASNMailbox, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_MTT_ACCOUNT_ORDER_INVOICE r WHERE r.CONTRACT_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (MTT_ACCOUNT_ORDER_INVOICE => com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice, H_MTT_ACCOUNT_ORDER_INVOICE => com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjMTTActOrderInvoice>> getAllMTTOrderInvoiceByIDHistory (Object[] parameters)
  {
    return queryIterator (getAllMTTOrderInvoiceByIDHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getAllMTTOrderInvoiceByIDHistoryStatementDescriptor = createStatementDescriptor (
    "getAllMTTOrderInvoiceByIDHistory(Object[])",
    "SELECT r.H_MTT_ACT_ORDER_INV_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.MTT_ACT_ORDER_INV_ID MTT_ACT_ORDER_INV_ID, r.CONTRACT_ID CONTRACT_ID, r.PRN_RETAIL_IND PRN_RETAIL_IND, r.PRN_PRICE_MATCH_SUMMARY_IND PRN_PRICE_MATCH_SUMMARY_IND, r.SUBSTITUTE_ITEM_IND SUBSTITUTE_ITEM_IND, r.INV_SEQ_TP_CD INV_SEQ_TP_CD, r.INV_COPIES_NUM INV_COPIES_NUM, r.INV_MODE_TP_CD INV_MODE_TP_CD, r.ORDER_GUIDE_TP_CD ORDER_GUIDE_TP_CD, r.SEP_ORDER_ITEM_RESRV_IND SEP_ORDER_ITEM_RESRV_IND, r.SPECIAL_INSTRUCTIONS SPECIAL_INSTRUCTIONS, r.PRN_CAT_INV_BRK_TP_CD PRN_CAT_INV_BRK_TP_CD, r.INV_RECAP_SUMMARY_TP_CD INV_RECAP_SUMMARY_TP_CD, r.PO_NUM_REQ_IND PO_NUM_REQ_IND, r.PICKUP_DELIVER_TP_CD PICKUP_DELIVER_TP_CD, r.PRN_ALT_TOBACCO_LICENCE_IND PRN_ALT_TOBACCO_LICENCE_IND, r.TOTES_IND TOTES_IND, r.TOTES_TP_CD TOTES_TP_CD, r.UNIT_CASE_COST_PRN_TP_CD UNIT_CASE_COST_PRN_TP_CD, r.INV_FORMAT_TP_CD INV_FORMAT_TP_CD, r.PICK_EACHES_IND PICK_EACHES_IND, r.INV_TP_CD INV_TP_CD, r.INV_STOP_MSG INV_STOP_MSG, r.DEL_PICK_PACK_INV_TP_CD DEL_PICK_PACK_INV_TP_CD, r.PRN_HO_INV_IND PRN_HO_INV_IND, r.PRN_WHOLESALE_ON_INV_IND PRN_WHOLESALE_ON_INV_IND, r.SEP_INV_PER_CUS_PO_IND SEP_INV_PER_CUS_PO_IND, r.ASN_REQ_IND ASN_REQ_IND, r.EASNMailbox EASNMailbox, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_MTT_ACCOUNT_ORDER_INVOICE r WHERE r.CONTRACT_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "mtt_act_order_inv_id", "contract_id", "prn_retail_ind", "prn_price_match_summary_ind", "substitute_item_ind", "inv_seq_tp_cd", "inv_copies_num", "inv_mode_tp_cd", "order_guide_tp_cd", "sep_order_item_resrv_ind", "special_instructions", "prn_cat_inv_brk_tp_cd", "inv_recap_summary_tp_cd", "po_num_req_ind", "pickup_deliver_tp_cd", "prn_alt_tobacco_licence_ind", "totes_ind", "totes_tp_cd", "unit_case_cost_prn_tp_cd", "inv_format_tp_cd", "pick_eaches_ind", "inv_tp_cd", "inv_stop_msg", "del_pick_pack_inv_tp_cd", "prn_ho_inv_ind", "prn_wholesale_on_inv_ind", "sep_inv_per_cus_po_ind", "asn_req_ind", "easnmailbox", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetAllMTTOrderInvoiceByIDHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetAllMTTOrderInvoiceByIDHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.INTEGER, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 19, 1, 1, 1, 19, 10, 19, 19, 1, 250, 19, 19, 1, 19, 1, 1, 19, 19, 19, 1, 19, 250, 19, 1, 1, 1, 1, 100, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class GetAllMTTOrderInvoiceByIDHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetAllMTTOrderInvoiceByIDHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjMTTActOrderInvoice>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjMTTActOrderInvoice> handle (java.sql.ResultSet rs, ResultQueue1<EObjMTTActOrderInvoice> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjMTTActOrderInvoice> ();

      EObjMTTActOrderInvoice returnObject1 = new EObjMTTActOrderInvoice ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setMTTActOrderInvoiceIdPk(getLongObject (rs, 6)); 
      returnObject1.setContractId(getLongObject (rs, 7)); 
      returnObject1.setPrintRetailInd(getString (rs, 8)); 
      returnObject1.setPrintPriceMatchSummaryInd(getString (rs, 9)); 
      returnObject1.setSubstituteItemInd(getString (rs, 10)); 
      returnObject1.setInvoiceSequence(getLongObject (rs, 11)); 
      returnObject1.setInvoiceCopiesNumber(getIntObject (rs, 12)); 
      returnObject1.setInvoiceMode(getLongObject (rs, 13)); 
      returnObject1.setOrderGuide(getLongObject (rs, 14)); 
      returnObject1.setSepOrderItemReserveInd(getString (rs, 15)); 
      returnObject1.setSpecialInstructions(getString (rs, 16)); 
      returnObject1.setPrintCatInvoiceBreak(getLongObject (rs, 17)); 
      returnObject1.setInvoiceRecapSummary(getLongObject (rs, 18)); 
      returnObject1.setPONumberRequiredInd(getString (rs, 19)); 
      returnObject1.setPickupDeliver(getLongObject (rs, 20)); 
      returnObject1.setPrintAlternateTobaccoLicenceInd(getString (rs, 21)); 
      returnObject1.setTotesInd(getString (rs, 22)); 
      returnObject1.setTotes(getLongObject (rs, 23)); 
      returnObject1.setUnitCaseCostPrint(getLongObject (rs, 24)); 
      returnObject1.setInvoiceFormat(getLongObject (rs, 25)); 
      returnObject1.setPickEachesInd(getString (rs, 26)); 
      returnObject1.setInvoice(getLongObject (rs, 27)); 
      returnObject1.setInvoiceStopMessage(getString (rs, 28)); 
      returnObject1.setDelPickPackInvoice(getLongObject (rs, 29)); 
      returnObject1.setPrintHOInvoiceInd(getString (rs, 30)); 
      returnObject1.setPrintWholesaleOnInvoiceInd(getString (rs, 31)); 
      returnObject1.setSepInvoicePerCustomerPOInd(getString (rs, 32)); 
      returnObject1.setASNRequiredInd(getString (rs, 33)); 
      returnObject1.setEASNMailbox(getString (rs, 34)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 35)); 
      returnObject1.setLastUpdateUser(getString (rs, 36)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 37)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

}
