/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[7c4fffde7f785f0b7f424549b0012938]
 */

package com.metcash.db.custom.entityObject;

import com.dwl.base.EObjCommon;
import com.ibm.mdm.base.db.DataType;
import com.ibm.pdq.annotation.Column;
import com.ibm.pdq.annotation.Table;


import com.ibm.pdq.annotation.Id;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * The entity object corresponding to the MTTActReporting business object. This
 * entity object should include all the attributes as defined by the business
 * object.
 * 
 * @generated
 */
@SuppressWarnings("serial")
@Table(name=EObjMTTActReporting.tableName)
public class EObjMTTActReporting extends EObjCommon {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public static final String tableName = "MTT_ACCOUNT_REPORTING";
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String mTTActReportingIdPkColumn = "MTT_ACT_REPORTING_ID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String mTTActReportingIdPkJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    mTTActReportingIdPkPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String channelGroupColumn = "CHANNEL_GRP_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String channelGroupJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    channelGroupPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String govtContractIndColumn = "GOV_CONTRACT_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String govtContractIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    govtContractIndPrecision = 1;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String capricornNumberColumn = "CAPRICORN_NUM";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String capricornNumberJdbcType = "INTEGER";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String iGADPerishableIndColumn = "IGAD_PERISHABLE_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String iGADPerishableIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    iGADPerishableIndPrecision = 1;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String agentNumberColumn = "AGENT_NUM_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String agentNumberJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    agentNumberPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String userLocalityColumn = "USER_LOCALITY_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String userLocalityJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    userLocalityPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String customerClassColumn = "CUS_CLASS_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String customerClassJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    customerClassPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String showPricesOnWebIndColumn = "SHOW_PRICES_ON_WEB_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String showPricesOnWebIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    showPricesOnWebIndPrecision = 1;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String contractIdColumn = "CONTRACT_ID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String contractIdJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    contractIdPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String exportCustomerIndColumn = "EXPORT_CUS_IND";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String exportCustomerIndJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    exportCustomerIndPrecision = 1;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long mTTActReportingIdPk;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long channelGroup;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String govtContractInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Integer capricornNumber;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String iGADPerishableInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long agentNumber;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long userLocality;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long customerClass;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String showPricesOnWebInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long contractId;



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String exportCustomerInd;



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Default constructor.     
     *
     * @generated
     */
    public EObjMTTActReporting() {
        super();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the mTTActReportingIdPk attribute. 
     *
     * @generated
     */
    @Id
    @Column(name=mTTActReportingIdPkColumn)
    @DataType(jdbcType=mTTActReportingIdPkJdbcType, precision=mTTActReportingIdPkPrecision)
    public Long getMTTActReportingIdPk (){
        return mTTActReportingIdPk;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the mTTActReportingIdPk attribute. 
     *
     * @param mTTActReportingIdPk
     *     The new value of MTTActReportingIdPk. 
     * @generated
     */
    public void setMTTActReportingIdPk( Long mTTActReportingIdPk ){
        this.mTTActReportingIdPk = mTTActReportingIdPk;
    
        super.setIdPK(mTTActReportingIdPk);
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the channelGroup attribute. 
     *
     * @generated
     */
    @Column(name=channelGroupColumn)
    @DataType(jdbcType=channelGroupJdbcType, precision=channelGroupPrecision)
    public Long getChannelGroup (){
        return channelGroup;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the channelGroup attribute. 
     *
     * @param channelGroup
     *     The new value of ChannelGroup. 
     * @generated
     */
    public void setChannelGroup( Long channelGroup ){
        this.channelGroup = channelGroup;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the govtContractInd attribute. 
     *
     * @generated
     */
    @Column(name=govtContractIndColumn)
    @DataType(jdbcType=govtContractIndJdbcType, precision=govtContractIndPrecision)
    public String getGovtContractInd (){
        return govtContractInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the govtContractInd attribute. 
     *
     * @param govtContractInd
     *     The new value of GovtContractInd. 
     * @generated
     */
    public void setGovtContractInd( String govtContractInd ){
        this.govtContractInd = govtContractInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the capricornNumber attribute. 
     *
     * @generated
     */
    @Column(name=capricornNumberColumn)
    @DataType(jdbcType=capricornNumberJdbcType)
    public Integer getCapricornNumber (){
        return capricornNumber;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the capricornNumber attribute. 
     *
     * @param capricornNumber
     *     The new value of CapricornNumber. 
     * @generated
     */
    public void setCapricornNumber( Integer capricornNumber ){
        this.capricornNumber = capricornNumber;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the iGADPerishableInd attribute. 
     *
     * @generated
     */
    @Column(name=iGADPerishableIndColumn)
    @DataType(jdbcType=iGADPerishableIndJdbcType, precision=iGADPerishableIndPrecision)
    public String getIGADPerishableInd (){
        return iGADPerishableInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the iGADPerishableInd attribute. 
     *
     * @param iGADPerishableInd
     *     The new value of IGADPerishableInd. 
     * @generated
     */
    public void setIGADPerishableInd( String iGADPerishableInd ){
        this.iGADPerishableInd = iGADPerishableInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the agentNumber attribute. 
     *
     * @generated
     */
    @Column(name=agentNumberColumn)
    @DataType(jdbcType=agentNumberJdbcType, precision=agentNumberPrecision)
    public Long getAgentNumber (){
        return agentNumber;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the agentNumber attribute. 
     *
     * @param agentNumber
     *     The new value of AgentNumber. 
     * @generated
     */
    public void setAgentNumber( Long agentNumber ){
        this.agentNumber = agentNumber;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the userLocality attribute. 
     *
     * @generated
     */
    @Column(name=userLocalityColumn)
    @DataType(jdbcType=userLocalityJdbcType, precision=userLocalityPrecision)
    public Long getUserLocality (){
        return userLocality;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the userLocality attribute. 
     *
     * @param userLocality
     *     The new value of UserLocality. 
     * @generated
     */
    public void setUserLocality( Long userLocality ){
        this.userLocality = userLocality;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the customerClass attribute. 
     *
     * @generated
     */
    @Column(name=customerClassColumn)
    @DataType(jdbcType=customerClassJdbcType, precision=customerClassPrecision)
    public Long getCustomerClass (){
        return customerClass;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the customerClass attribute. 
     *
     * @param customerClass
     *     The new value of CustomerClass. 
     * @generated
     */
    public void setCustomerClass( Long customerClass ){
        this.customerClass = customerClass;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the showPricesOnWebInd attribute. 
     *
     * @generated
     */
    @Column(name=showPricesOnWebIndColumn)
    @DataType(jdbcType=showPricesOnWebIndJdbcType, precision=showPricesOnWebIndPrecision)
    public String getShowPricesOnWebInd (){
        return showPricesOnWebInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the showPricesOnWebInd attribute. 
     *
     * @param showPricesOnWebInd
     *     The new value of ShowPricesOnWebInd. 
     * @generated
     */
    public void setShowPricesOnWebInd( String showPricesOnWebInd ){
        this.showPricesOnWebInd = showPricesOnWebInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contractId attribute. 
     *
     * @generated
     */
    @Column(name=contractIdColumn)
    @DataType(jdbcType=contractIdJdbcType, precision=contractIdPrecision)
    public Long getContractId (){
        return contractId;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contractId attribute. 
     *
     * @param contractId
     *     The new value of ContractId. 
     * @generated
     */
    public void setContractId( Long contractId ){
        this.contractId = contractId;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the exportCustomerInd attribute. 
     *
     * @generated
     */
    @Column(name=exportCustomerIndColumn)
    @DataType(jdbcType=exportCustomerIndJdbcType, precision=exportCustomerIndPrecision)
    public String getExportCustomerInd (){
        return exportCustomerInd;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the exportCustomerInd attribute. 
     *
     * @param exportCustomerInd
     *     The new value of ExportCustomerInd. 
     * @generated
     */
    public void setExportCustomerInd( String exportCustomerInd ){
        this.exportCustomerInd = exportCustomerInd;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the primary key. 
     *
     * @param aUniqueId
     *     The new value of the primary key. 
     * @generated
   */
	public void setPrimaryKey(Object aUniqueId) {
    this.setMTTActReportingIdPk((Long)aUniqueId);
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the primary key.
     *
     * @generated
     */
	public Object getPrimaryKey() {
    return this.getMTTActReportingIdPk();
  }
	 
}


