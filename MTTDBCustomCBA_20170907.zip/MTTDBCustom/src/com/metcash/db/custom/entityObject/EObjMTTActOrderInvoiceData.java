/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[9ee786219c2d3475ad3b5367ec5c1b7f]
 */


package com.metcash.db.custom.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjMTTActOrderInvoiceData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjMTTActOrderInvoiceSql = "select MTT_ACT_ORDER_INV_ID, CONTRACT_ID, PRN_RETAIL_IND, PRN_PRICE_MATCH_SUMMARY_IND, SUBSTITUTE_ITEM_IND, INV_SEQ_TP_CD, INV_COPIES_NUM, INV_MODE_TP_CD, ORDER_GUIDE_TP_CD, SEP_ORDER_ITEM_RESRV_IND, SPECIAL_INSTRUCTIONS, PRN_CAT_INV_BRK_TP_CD, INV_RECAP_SUMMARY_TP_CD, PO_NUM_REQ_IND, PICKUP_DELIVER_TP_CD, PRN_ALT_TOBACCO_LICENCE_IND, TOTES_IND, TOTES_TP_CD, UNIT_CASE_COST_PRN_TP_CD, INV_FORMAT_TP_CD, PICK_EACHES_IND, INV_TP_CD, INV_STOP_MSG, DEL_PICK_PACK_INV_TP_CD, PRN_HO_INV_IND, PRN_WHOLESALE_ON_INV_IND, SEP_INV_PER_CUS_PO_IND, ASN_REQ_IND, EASNMailbox,  LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from MTT_ACCOUNT_ORDER_INVOICE where MTT_ACT_ORDER_INV_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjMTTActOrderInvoiceSql = "insert into MTT_ACCOUNT_ORDER_INVOICE (MTT_ACT_ORDER_INV_ID, CONTRACT_ID, PRN_RETAIL_IND, PRN_PRICE_MATCH_SUMMARY_IND, SUBSTITUTE_ITEM_IND, INV_SEQ_TP_CD, INV_COPIES_NUM, INV_MODE_TP_CD, ORDER_GUIDE_TP_CD, SEP_ORDER_ITEM_RESRV_IND, SPECIAL_INSTRUCTIONS, PRN_CAT_INV_BRK_TP_CD, INV_RECAP_SUMMARY_TP_CD, PO_NUM_REQ_IND, PICKUP_DELIVER_TP_CD, PRN_ALT_TOBACCO_LICENCE_IND, TOTES_IND, TOTES_TP_CD, UNIT_CASE_COST_PRN_TP_CD, INV_FORMAT_TP_CD, PICK_EACHES_IND, INV_TP_CD, INV_STOP_MSG, DEL_PICK_PACK_INV_TP_CD, PRN_HO_INV_IND, PRN_WHOLESALE_ON_INV_IND, SEP_INV_PER_CUS_PO_IND, ASN_REQ_IND, EASNMailbox, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :mTTActOrderInvoiceIdPk, :contractId, :printRetailInd, :printPriceMatchSummaryInd, :substituteItemInd, :invoiceSequence, :invoiceCopiesNumber, :invoiceMode, :orderGuide, :sepOrderItemReserveInd, :specialInstructions, :printCatInvoiceBreak, :invoiceRecapSummary, :pONumberRequiredInd, :pickupDeliver, :printAlternateTobaccoLicenceInd, :totesInd, :totes, :unitCaseCostPrint, :invoiceFormat, :pickEachesInd, :invoice, :invoiceStopMessage, :delPickPackInvoice, :printHOInvoiceInd, :printWholesaleOnInvoiceInd, :sepInvoicePerCustomerPOInd, :aSNRequiredInd, :eASNMailbox, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjMTTActOrderInvoiceSql = "update MTT_ACCOUNT_ORDER_INVOICE set CONTRACT_ID = :contractId, PRN_RETAIL_IND = :printRetailInd, PRN_PRICE_MATCH_SUMMARY_IND = :printPriceMatchSummaryInd, SUBSTITUTE_ITEM_IND = :substituteItemInd, INV_SEQ_TP_CD = :invoiceSequence, INV_COPIES_NUM = :invoiceCopiesNumber, INV_MODE_TP_CD = :invoiceMode, ORDER_GUIDE_TP_CD = :orderGuide, SEP_ORDER_ITEM_RESRV_IND = :sepOrderItemReserveInd, SPECIAL_INSTRUCTIONS = :specialInstructions, PRN_CAT_INV_BRK_TP_CD = :printCatInvoiceBreak, INV_RECAP_SUMMARY_TP_CD = :invoiceRecapSummary, PO_NUM_REQ_IND = :pONumberRequiredInd, PICKUP_DELIVER_TP_CD = :pickupDeliver, PRN_ALT_TOBACCO_LICENCE_IND = :printAlternateTobaccoLicenceInd, TOTES_IND = :totesInd, TOTES_TP_CD = :totes, UNIT_CASE_COST_PRN_TP_CD = :unitCaseCostPrint, INV_FORMAT_TP_CD = :invoiceFormat, PICK_EACHES_IND = :pickEachesInd, INV_TP_CD = :invoice, INV_STOP_MSG = :invoiceStopMessage, DEL_PICK_PACK_INV_TP_CD = :delPickPackInvoice, PRN_HO_INV_IND = :printHOInvoiceInd, PRN_WHOLESALE_ON_INV_IND = :printWholesaleOnInvoiceInd, SEP_INV_PER_CUS_PO_IND = :sepInvoicePerCustomerPOInd, ASN_REQ_IND = :aSNRequiredInd, EASNMailbox = :eASNMailbox, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where MTT_ACT_ORDER_INV_ID = :mTTActOrderInvoiceIdPk and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjMTTActOrderInvoiceSql = "delete from MTT_ACCOUNT_ORDER_INVOICE where MTT_ACT_ORDER_INV_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjMTTActOrderInvoiceKeyField = "EObjMTTActOrderInvoice.mTTActOrderInvoiceIdPk";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjMTTActOrderInvoiceGetFields =
    "EObjMTTActOrderInvoice.mTTActOrderInvoiceIdPk," +
    "EObjMTTActOrderInvoice.contractId," +
    "EObjMTTActOrderInvoice.printRetailInd," +
    "EObjMTTActOrderInvoice.printPriceMatchSummaryInd," +
    "EObjMTTActOrderInvoice.substituteItemInd," +
    "EObjMTTActOrderInvoice.invoiceSequence," +
    "EObjMTTActOrderInvoice.invoiceCopiesNumber," +
    "EObjMTTActOrderInvoice.invoiceMode," +
    "EObjMTTActOrderInvoice.orderGuide," +
    "EObjMTTActOrderInvoice.sepOrderItemReserveInd," +
    "EObjMTTActOrderInvoice.specialInstructions," +
    "EObjMTTActOrderInvoice.printCatInvoiceBreak," +
    "EObjMTTActOrderInvoice.invoiceRecapSummary," +
    "EObjMTTActOrderInvoice.pONumberRequiredInd," +
    "EObjMTTActOrderInvoice.pickupDeliver," +
    "EObjMTTActOrderInvoice.printAlternateTobaccoLicenceInd," +
    "EObjMTTActOrderInvoice.totesInd," +
    "EObjMTTActOrderInvoice.totes," +
    "EObjMTTActOrderInvoice.unitCaseCostPrint," +
    "EObjMTTActOrderInvoice.invoiceFormat," +
    "EObjMTTActOrderInvoice.pickEachesInd," +
    "EObjMTTActOrderInvoice.invoice," +
    "EObjMTTActOrderInvoice.invoiceStopMessage," +
    "EObjMTTActOrderInvoice.delPickPackInvoice," +
    "EObjMTTActOrderInvoice.printHOInvoiceInd," +
    "EObjMTTActOrderInvoice.printWholesaleOnInvoiceInd," +
    "EObjMTTActOrderInvoice.sepInvoicePerCustomerPOInd," +
    "EObjMTTActOrderInvoice.aSNRequiredInd," +
    "EObjMTTActOrderInvoice.eASNMailbox," +
    "EObjMTTActOrderInvoice.lastUpdateDt," +
    "EObjMTTActOrderInvoice.lastUpdateUser," +
    "EObjMTTActOrderInvoice.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjMTTActOrderInvoiceAllFields =
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.mTTActOrderInvoiceIdPk," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.contractId," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.printRetailInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.printPriceMatchSummaryInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.substituteItemInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.invoiceSequence," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.invoiceCopiesNumber," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.invoiceMode," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.orderGuide," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.sepOrderItemReserveInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.specialInstructions," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.printCatInvoiceBreak," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.invoiceRecapSummary," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.pONumberRequiredInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.pickupDeliver," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.printAlternateTobaccoLicenceInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.totesInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.totes," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.unitCaseCostPrint," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.invoiceFormat," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.pickEachesInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.invoice," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.invoiceStopMessage," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.delPickPackInvoice," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.printHOInvoiceInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.printWholesaleOnInvoiceInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.sepInvoicePerCustomerPOInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.aSNRequiredInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.eASNMailbox," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.lastUpdateDt," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.lastUpdateUser," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjMTTActOrderInvoiceUpdateFields =
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.contractId," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.printRetailInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.printPriceMatchSummaryInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.substituteItemInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.invoiceSequence," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.invoiceCopiesNumber," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.invoiceMode," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.orderGuide," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.sepOrderItemReserveInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.specialInstructions," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.printCatInvoiceBreak," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.invoiceRecapSummary," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.pONumberRequiredInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.pickupDeliver," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.printAlternateTobaccoLicenceInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.totesInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.totes," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.unitCaseCostPrint," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.invoiceFormat," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.pickEachesInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.invoice," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.invoiceStopMessage," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.delPickPackInvoice," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.printHOInvoiceInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.printWholesaleOnInvoiceInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.sepInvoicePerCustomerPOInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.aSNRequiredInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.eASNMailbox," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.lastUpdateDt," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.lastUpdateUser," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.lastUpdateTxId," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.mTTActOrderInvoiceIdPk," +
    "com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select MTTActOrderInvoice by parameters.
   * @generated
   */
  @Select(sql=getEObjMTTActOrderInvoiceSql)
  @EntityMapping(parameters=EObjMTTActOrderInvoiceKeyField, results=EObjMTTActOrderInvoiceGetFields)
  Iterator<EObjMTTActOrderInvoice> getEObjMTTActOrderInvoice(Long mTTActOrderInvoiceIdPk);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create MTTActOrderInvoice by EObjMTTActOrderInvoice Object.
   * @generated
   */
  @Update(sql=createEObjMTTActOrderInvoiceSql)
  @EntityMapping(parameters=EObjMTTActOrderInvoiceAllFields)
    int createEObjMTTActOrderInvoice(EObjMTTActOrderInvoice e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one MTTActOrderInvoice by EObjMTTActOrderInvoice object.
   * @generated
   */
  @Update(sql=updateEObjMTTActOrderInvoiceSql)
  @EntityMapping(parameters=EObjMTTActOrderInvoiceUpdateFields)
    int updateEObjMTTActOrderInvoice(EObjMTTActOrderInvoice e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete MTTActOrderInvoice by parameters.
   * @generated
   */
  @Update(sql=deleteEObjMTTActOrderInvoiceSql)
  @EntityMapping(parameters=EObjMTTActOrderInvoiceKeyField)
  int deleteEObjMTTActOrderInvoice(Long mTTActOrderInvoiceIdPk);

}

