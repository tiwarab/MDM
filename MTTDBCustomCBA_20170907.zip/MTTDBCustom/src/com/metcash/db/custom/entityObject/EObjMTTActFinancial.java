/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[9c3cad8d794a55769b7fa7df58352311]
 */

package com.metcash.db.custom.entityObject;

import com.dwl.base.EObjCommon;
import com.ibm.mdm.base.db.DataType;
import com.ibm.pdq.annotation.Column;
import com.ibm.pdq.annotation.Table;


import com.ibm.pdq.annotation.Id;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * The entity object corresponding to the MTTActFinancial business object. This
 * entity object should include all the attributes as defined by the business
 * object.
 * 
 * @generated
 */
@SuppressWarnings("serial")
@Table(name=EObjMTTActFinancial.tableName)
public class EObjMTTActFinancial extends EObjCommon {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public static final String tableName = "MTT_ACCOUNT_FINANCIAL";
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String mTTActFinancialIdPkColumn = "MTT_ACT_FINANCIAL_ID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String mTTActFinancialIdPkJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    mTTActFinancialIdPkPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String contractIdColumn = "CONTRACT_ID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String contractIdJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    contractIdPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String statementModeColumn = "STATEMENT_MODE_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String statementModeJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    statementModePrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String dueGraceDaysColumn = "DUE_GRACE_DAYS_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String dueGraceDaysJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    dueGraceDaysPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String tobaccoGraceDaysColumn = "TOBACCO_GRACE_DAYS_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String tobaccoGraceDaysJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    tobaccoGraceDaysPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String bankColumn = "BANK_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String bankJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    bankPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String bPAYIndColumn = "BPAY_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String bPAYIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    bPAYIndPrecision = 1;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String statementPrintHoldIndColumn = "STATEMENT_PRN_HOLD_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String statementPrintHoldIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    statementPrintHoldIndPrecision = 1;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String bPAYCustomerRefNumberColumn = "BPAY_CUS_REF_NUM";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String bPAYCustomerRefNumberJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    bPAYCustomerRefNumberPrecision = 50;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String collectorColumn = "COLLECTOR_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String collectorJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    collectorPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String bankAccountColumn = "BANK_ACCOUNT_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String bankAccountJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    bankAccountPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String extTermsByShipDateIndColumn = "EXT_TERMS_BY_SHIPDATE_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String extTermsByShipDateIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    extTermsByShipDateIndPrecision = 1;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String settlementDiscountIndColumn = "SETTLEMENT_DISC_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String settlementDiscountIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    settlementDiscountIndPrecision = 1;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String accountDetailsColumn = "ACCOUNT_DETAILS";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String accountDetailsJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    accountDetailsPrecision = 250;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String discountGraceDaysColumn = "DISC_GRACE_DAYS_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String discountGraceDaysJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    discountGraceDaysPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String paymentMethodColumn = "PAYMENT_METHOD_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String paymentMethodJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    paymentMethodPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String lMAANumberColumn = "LMAA_NUM";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String lMAANumberJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    lMAANumberPrecision = 100;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long mTTActFinancialIdPk;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long contractId;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long statementMode;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long dueGraceDays;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long tobaccoGraceDays;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long bank;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String bPAYInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String statementPrintHoldInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String bPAYCustomerRefNumber;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long collector;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long bankAccount;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String extTermsByShipDateInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String settlementDiscountInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String accountDetails;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long discountGraceDays;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long paymentMethod;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String lMAANumber;



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Default constructor.     
     *
     * @generated
     */
    public EObjMTTActFinancial() {
        super();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the mTTActFinancialIdPk attribute. 
     *
     * @generated
     */
    @Id
    @Column(name=mTTActFinancialIdPkColumn)
    @DataType(jdbcType=mTTActFinancialIdPkJdbcType, precision=mTTActFinancialIdPkPrecision)
    public Long getMTTActFinancialIdPk (){
        return mTTActFinancialIdPk;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the mTTActFinancialIdPk attribute. 
     *
     * @param mTTActFinancialIdPk
     *     The new value of MTTActFinancialIdPk. 
     * @generated
     */
    public void setMTTActFinancialIdPk( Long mTTActFinancialIdPk ){
        this.mTTActFinancialIdPk = mTTActFinancialIdPk;
    
        super.setIdPK(mTTActFinancialIdPk);
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contractId attribute. 
     *
     * @generated
     */
    @Column(name=contractIdColumn)
    @DataType(jdbcType=contractIdJdbcType, precision=contractIdPrecision)
    public Long getContractId (){
        return contractId;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contractId attribute. 
     *
     * @param contractId
     *     The new value of ContractId. 
     * @generated
     */
    public void setContractId( Long contractId ){
        this.contractId = contractId;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the statementMode attribute. 
     *
     * @generated
     */
    @Column(name=statementModeColumn)
    @DataType(jdbcType=statementModeJdbcType, precision=statementModePrecision)
    public Long getStatementMode (){
        return statementMode;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the statementMode attribute. 
     *
     * @param statementMode
     *     The new value of StatementMode. 
     * @generated
     */
    public void setStatementMode( Long statementMode ){
        this.statementMode = statementMode;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the dueGraceDays attribute. 
     *
     * @generated
     */
    @Column(name=dueGraceDaysColumn)
    @DataType(jdbcType=dueGraceDaysJdbcType, precision=dueGraceDaysPrecision)
    public Long getDueGraceDays (){
        return dueGraceDays;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the dueGraceDays attribute. 
     *
     * @param dueGraceDays
     *     The new value of DueGraceDays. 
     * @generated
     */
    public void setDueGraceDays( Long dueGraceDays ){
        this.dueGraceDays = dueGraceDays;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the tobaccoGraceDays attribute. 
     *
     * @generated
     */
    @Column(name=tobaccoGraceDaysColumn)
    @DataType(jdbcType=tobaccoGraceDaysJdbcType, precision=tobaccoGraceDaysPrecision)
    public Long getTobaccoGraceDays (){
        return tobaccoGraceDays;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the tobaccoGraceDays attribute. 
     *
     * @param tobaccoGraceDays
     *     The new value of TobaccoGraceDays. 
     * @generated
     */
    public void setTobaccoGraceDays( Long tobaccoGraceDays ){
        this.tobaccoGraceDays = tobaccoGraceDays;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the bank attribute. 
     *
     * @generated
     */
    @Column(name=bankColumn)
    @DataType(jdbcType=bankJdbcType, precision=bankPrecision)
    public Long getBank (){
        return bank;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the bank attribute. 
     *
     * @param bank
     *     The new value of Bank. 
     * @generated
     */
    public void setBank( Long bank ){
        this.bank = bank;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the bPAYInd attribute. 
     *
     * @generated
     */
    @Column(name=bPAYIndColumn)
    @DataType(jdbcType=bPAYIndJdbcType, precision=bPAYIndPrecision)
    public String getBPAYInd (){
        return bPAYInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the bPAYInd attribute. 
     *
     * @param bPAYInd
     *     The new value of BPAYInd. 
     * @generated
     */
    public void setBPAYInd( String bPAYInd ){
        this.bPAYInd = bPAYInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the statementPrintHoldInd attribute. 
     *
     * @generated
     */
    @Column(name=statementPrintHoldIndColumn)
    @DataType(jdbcType=statementPrintHoldIndJdbcType, precision=statementPrintHoldIndPrecision)
    public String getStatementPrintHoldInd (){
        return statementPrintHoldInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the statementPrintHoldInd attribute. 
     *
     * @param statementPrintHoldInd
     *     The new value of StatementPrintHoldInd. 
     * @generated
     */
    public void setStatementPrintHoldInd( String statementPrintHoldInd ){
        this.statementPrintHoldInd = statementPrintHoldInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the bPAYCustomerRefNumber attribute. 
     *
     * @generated
     */
    @Column(name=bPAYCustomerRefNumberColumn)
    @DataType(jdbcType=bPAYCustomerRefNumberJdbcType)
    public String getBPAYCustomerRefNumber (){
        return bPAYCustomerRefNumber;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the bPAYCustomerRefNumber attribute. 
     *
     * @param bPAYCustomerRefNumber
     *     The new value of BPAYCustomerRefNumber. 
     * @generated
     */
    public void setBPAYCustomerRefNumber( String bPAYCustomerRefNumber ){
        this.bPAYCustomerRefNumber = bPAYCustomerRefNumber;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the collector attribute. 
     *
     * @generated
     */
    @Column(name=collectorColumn)
    @DataType(jdbcType=collectorJdbcType, precision=collectorPrecision)
    public Long getCollector (){
        return collector;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the collector attribute. 
     *
     * @param collector
     *     The new value of Collector. 
     * @generated
     */
    public void setCollector( Long collector ){
        this.collector = collector;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the bankAccount attribute. 
     *
     * @generated
     */
    @Column(name=bankAccountColumn)
    @DataType(jdbcType=bankAccountJdbcType, precision=bankAccountPrecision)
    public Long getBankAccount (){
        return bankAccount;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the bankAccount attribute. 
     *
     * @param bankAccount
     *     The new value of BankAccount. 
     * @generated
     */
    public void setBankAccount( Long bankAccount ){
        this.bankAccount = bankAccount;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the extTermsByShipDateInd attribute. 
     *
     * @generated
     */
    @Column(name=extTermsByShipDateIndColumn)
    @DataType(jdbcType=extTermsByShipDateIndJdbcType, precision=extTermsByShipDateIndPrecision)
    public String getExtTermsByShipDateInd (){
        return extTermsByShipDateInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the extTermsByShipDateInd attribute. 
     *
     * @param extTermsByShipDateInd
     *     The new value of ExtTermsByShipDateInd. 
     * @generated
     */
    public void setExtTermsByShipDateInd( String extTermsByShipDateInd ){
        this.extTermsByShipDateInd = extTermsByShipDateInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the settlementDiscountInd attribute. 
     *
     * @generated
     */
    @Column(name=settlementDiscountIndColumn)
    @DataType(jdbcType=settlementDiscountIndJdbcType, precision=settlementDiscountIndPrecision)
    public String getSettlementDiscountInd (){
        return settlementDiscountInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the settlementDiscountInd attribute. 
     *
     * @param settlementDiscountInd
     *     The new value of SettlementDiscountInd. 
     * @generated
     */
    public void setSettlementDiscountInd( String settlementDiscountInd ){
        this.settlementDiscountInd = settlementDiscountInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the accountDetails attribute. 
     *
     * @generated
     */
    @Column(name=accountDetailsColumn)
    @DataType(jdbcType=accountDetailsJdbcType, precision=accountDetailsPrecision)
    public String getAccountDetails (){
        return accountDetails;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the accountDetails attribute. 
     *
     * @param accountDetails
     *     The new value of AccountDetails. 
     * @generated
     */
    public void setAccountDetails( String accountDetails ){
        this.accountDetails = accountDetails;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the discountGraceDays attribute. 
     *
     * @generated
     */
    @Column(name=discountGraceDaysColumn)
    @DataType(jdbcType=discountGraceDaysJdbcType, precision=discountGraceDaysPrecision)
    public Long getDiscountGraceDays (){
        return discountGraceDays;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the discountGraceDays attribute. 
     *
     * @param discountGraceDays
     *     The new value of DiscountGraceDays. 
     * @generated
     */
    public void setDiscountGraceDays( Long discountGraceDays ){
        this.discountGraceDays = discountGraceDays;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the paymentMethod attribute. 
     *
     * @generated
     */
    @Column(name=paymentMethodColumn)
    @DataType(jdbcType=paymentMethodJdbcType, precision=paymentMethodPrecision)
    public Long getPaymentMethod (){
        return paymentMethod;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the paymentMethod attribute. 
     *
     * @param paymentMethod
     *     The new value of PaymentMethod. 
     * @generated
     */
    public void setPaymentMethod( Long paymentMethod ){
        this.paymentMethod = paymentMethod;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the lMAANumber attribute. 
     *
     * @generated
     */
    @Column(name=lMAANumberColumn)
    @DataType(jdbcType=lMAANumberJdbcType, precision=lMAANumberPrecision)
    public String getLMAANumber (){
        return lMAANumber;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the lMAANumber attribute. 
     *
     * @param lMAANumber
     *     The new value of LMAANumber. 
     * @generated
     */
    public void setLMAANumber( String lMAANumber ){
        this.lMAANumber = lMAANumber;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the primary key. 
     *
     * @param aUniqueId
     *     The new value of the primary key. 
     * @generated
   */
	public void setPrimaryKey(Object aUniqueId) {
    this.setMTTActFinancialIdPk((Long)aUniqueId);
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the primary key.
     *
     * @generated
     */
	public Object getPrimaryKey() {
    return this.getMTTActFinancialIdPk();
  }
	 
}


