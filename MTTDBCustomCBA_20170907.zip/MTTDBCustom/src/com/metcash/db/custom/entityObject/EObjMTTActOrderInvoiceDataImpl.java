package com.metcash.db.custom.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjMTTActOrderInvoiceDataImpl  extends BaseData implements EObjMTTActOrderInvoiceData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjMTTActOrderInvoiceData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000015e4b0dbc91L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjMTTActOrderInvoiceDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select MTT_ACT_ORDER_INV_ID, CONTRACT_ID, PRN_RETAIL_IND, PRN_PRICE_MATCH_SUMMARY_IND, SUBSTITUTE_ITEM_IND, INV_SEQ_TP_CD, INV_COPIES_NUM, INV_MODE_TP_CD, ORDER_GUIDE_TP_CD, SEP_ORDER_ITEM_RESRV_IND, SPECIAL_INSTRUCTIONS, PRN_CAT_INV_BRK_TP_CD, INV_RECAP_SUMMARY_TP_CD, PO_NUM_REQ_IND, PICKUP_DELIVER_TP_CD, PRN_ALT_TOBACCO_LICENCE_IND, TOTES_IND, TOTES_TP_CD, UNIT_CASE_COST_PRN_TP_CD, INV_FORMAT_TP_CD, PICK_EACHES_IND, INV_TP_CD, INV_STOP_MSG, DEL_PICK_PACK_INV_TP_CD, PRN_HO_INV_IND, PRN_WHOLESALE_ON_INV_IND, SEP_INV_PER_CUS_PO_IND, ASN_REQ_IND, EASNMailbox,  LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from MTT_ACCOUNT_ORDER_INVOICE where MTT_ACT_ORDER_INV_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjMTTActOrderInvoice> getEObjMTTActOrderInvoice (Long mTTActOrderInvoiceIdPk)
  {
    return queryIterator (getEObjMTTActOrderInvoiceStatementDescriptor, mTTActOrderInvoiceIdPk);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjMTTActOrderInvoiceStatementDescriptor = createStatementDescriptor (
    "getEObjMTTActOrderInvoice(Long)",
    "select MTT_ACT_ORDER_INV_ID, CONTRACT_ID, PRN_RETAIL_IND, PRN_PRICE_MATCH_SUMMARY_IND, SUBSTITUTE_ITEM_IND, INV_SEQ_TP_CD, INV_COPIES_NUM, INV_MODE_TP_CD, ORDER_GUIDE_TP_CD, SEP_ORDER_ITEM_RESRV_IND, SPECIAL_INSTRUCTIONS, PRN_CAT_INV_BRK_TP_CD, INV_RECAP_SUMMARY_TP_CD, PO_NUM_REQ_IND, PICKUP_DELIVER_TP_CD, PRN_ALT_TOBACCO_LICENCE_IND, TOTES_IND, TOTES_TP_CD, UNIT_CASE_COST_PRN_TP_CD, INV_FORMAT_TP_CD, PICK_EACHES_IND, INV_TP_CD, INV_STOP_MSG, DEL_PICK_PACK_INV_TP_CD, PRN_HO_INV_IND, PRN_WHOLESALE_ON_INV_IND, SEP_INV_PER_CUS_PO_IND, ASN_REQ_IND, EASNMailbox,  LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from MTT_ACCOUNT_ORDER_INVOICE where MTT_ACT_ORDER_INV_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"mtt_act_order_inv_id", "contract_id", "prn_retail_ind", "prn_price_match_summary_ind", "substitute_item_ind", "inv_seq_tp_cd", "inv_copies_num", "inv_mode_tp_cd", "order_guide_tp_cd", "sep_order_item_resrv_ind", "special_instructions", "prn_cat_inv_brk_tp_cd", "inv_recap_summary_tp_cd", "po_num_req_ind", "pickup_deliver_tp_cd", "prn_alt_tobacco_licence_ind", "totes_ind", "totes_tp_cd", "unit_case_cost_prn_tp_cd", "inv_format_tp_cd", "pick_eaches_ind", "inv_tp_cd", "inv_stop_msg", "del_pick_pack_inv_tp_cd", "prn_ho_inv_ind", "prn_wholesale_on_inv_ind", "sep_inv_per_cus_po_ind", "asn_req_ind", "easnmailbox", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjMTTActOrderInvoiceParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjMTTActOrderInvoiceRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.INTEGER, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 1, 1, 1, 19, 10, 19, 19, 1, 250, 19, 19, 1, 19, 1, 1, 19, 19, 19, 1, 19, 250, 19, 1, 1, 1, 1, 100, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjMTTActOrderInvoiceParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjMTTActOrderInvoiceRowHandler extends BaseRowHandler<EObjMTTActOrderInvoice>
  {
    /**
     * @generated
     */
    public EObjMTTActOrderInvoice handle (java.sql.ResultSet rs, EObjMTTActOrderInvoice returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjMTTActOrderInvoice ();
      returnObject.setMTTActOrderInvoiceIdPk(getLongObject (rs, 1)); 
      returnObject.setContractId(getLongObject (rs, 2)); 
      returnObject.setPrintRetailInd(getString (rs, 3)); 
      returnObject.setPrintPriceMatchSummaryInd(getString (rs, 4)); 
      returnObject.setSubstituteItemInd(getString (rs, 5)); 
      returnObject.setInvoiceSequence(getLongObject (rs, 6)); 
      returnObject.setInvoiceCopiesNumber(getIntObject (rs, 7)); 
      returnObject.setInvoiceMode(getLongObject (rs, 8)); 
      returnObject.setOrderGuide(getLongObject (rs, 9)); 
      returnObject.setSepOrderItemReserveInd(getString (rs, 10)); 
      returnObject.setSpecialInstructions(getString (rs, 11)); 
      returnObject.setPrintCatInvoiceBreak(getLongObject (rs, 12)); 
      returnObject.setInvoiceRecapSummary(getLongObject (rs, 13)); 
      returnObject.setPONumberRequiredInd(getString (rs, 14)); 
      returnObject.setPickupDeliver(getLongObject (rs, 15)); 
      returnObject.setPrintAlternateTobaccoLicenceInd(getString (rs, 16)); 
      returnObject.setTotesInd(getString (rs, 17)); 
      returnObject.setTotes(getLongObject (rs, 18)); 
      returnObject.setUnitCaseCostPrint(getLongObject (rs, 19)); 
      returnObject.setInvoiceFormat(getLongObject (rs, 20)); 
      returnObject.setPickEachesInd(getString (rs, 21)); 
      returnObject.setInvoice(getLongObject (rs, 22)); 
      returnObject.setInvoiceStopMessage(getString (rs, 23)); 
      returnObject.setDelPickPackInvoice(getLongObject (rs, 24)); 
      returnObject.setPrintHOInvoiceInd(getString (rs, 25)); 
      returnObject.setPrintWholesaleOnInvoiceInd(getString (rs, 26)); 
      returnObject.setSepInvoicePerCustomerPOInd(getString (rs, 27)); 
      returnObject.setASNRequiredInd(getString (rs, 28)); 
      returnObject.setEASNMailbox(getString (rs, 29)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 30)); 
      returnObject.setLastUpdateUser(getString (rs, 31)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 32)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into MTT_ACCOUNT_ORDER_INVOICE (MTT_ACT_ORDER_INV_ID, CONTRACT_ID, PRN_RETAIL_IND, PRN_PRICE_MATCH_SUMMARY_IND, SUBSTITUTE_ITEM_IND, INV_SEQ_TP_CD, INV_COPIES_NUM, INV_MODE_TP_CD, ORDER_GUIDE_TP_CD, SEP_ORDER_ITEM_RESRV_IND, SPECIAL_INSTRUCTIONS, PRN_CAT_INV_BRK_TP_CD, INV_RECAP_SUMMARY_TP_CD, PO_NUM_REQ_IND, PICKUP_DELIVER_TP_CD, PRN_ALT_TOBACCO_LICENCE_IND, TOTES_IND, TOTES_TP_CD, UNIT_CASE_COST_PRN_TP_CD, INV_FORMAT_TP_CD, PICK_EACHES_IND, INV_TP_CD, INV_STOP_MSG, DEL_PICK_PACK_INV_TP_CD, PRN_HO_INV_IND, PRN_WHOLESALE_ON_INV_IND, SEP_INV_PER_CUS_PO_IND, ASN_REQ_IND, EASNMailbox, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :mTTActOrderInvoiceIdPk, :contractId, :printRetailInd, :printPriceMatchSummaryInd, :substituteItemInd, :invoiceSequence, :invoiceCopiesNumber, :invoiceMode, :orderGuide, :sepOrderItemReserveInd, :specialInstructions, :printCatInvoiceBreak, :invoiceRecapSummary, :pONumberRequiredInd, :pickupDeliver, :printAlternateTobaccoLicenceInd, :totesInd, :totes, :unitCaseCostPrint, :invoiceFormat, :pickEachesInd, :invoice, :invoiceStopMessage, :delPickPackInvoice, :printHOInvoiceInd, :printWholesaleOnInvoiceInd, :sepInvoicePerCustomerPOInd, :aSNRequiredInd, :eASNMailbox, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjMTTActOrderInvoice (EObjMTTActOrderInvoice e)
  {
    return update (createEObjMTTActOrderInvoiceStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjMTTActOrderInvoiceStatementDescriptor = createStatementDescriptor (
    "createEObjMTTActOrderInvoice(com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice)",
    "insert into MTT_ACCOUNT_ORDER_INVOICE (MTT_ACT_ORDER_INV_ID, CONTRACT_ID, PRN_RETAIL_IND, PRN_PRICE_MATCH_SUMMARY_IND, SUBSTITUTE_ITEM_IND, INV_SEQ_TP_CD, INV_COPIES_NUM, INV_MODE_TP_CD, ORDER_GUIDE_TP_CD, SEP_ORDER_ITEM_RESRV_IND, SPECIAL_INSTRUCTIONS, PRN_CAT_INV_BRK_TP_CD, INV_RECAP_SUMMARY_TP_CD, PO_NUM_REQ_IND, PICKUP_DELIVER_TP_CD, PRN_ALT_TOBACCO_LICENCE_IND, TOTES_IND, TOTES_TP_CD, UNIT_CASE_COST_PRN_TP_CD, INV_FORMAT_TP_CD, PICK_EACHES_IND, INV_TP_CD, INV_STOP_MSG, DEL_PICK_PACK_INV_TP_CD, PRN_HO_INV_IND, PRN_WHOLESALE_ON_INV_IND, SEP_INV_PER_CUS_PO_IND, ASN_REQ_IND, EASNMailbox, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjMTTActOrderInvoiceParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.INTEGER, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 1, 1, 1, 19, 10, 19, 19, 1, 250, 19, 19, 1, 19, 1, 1, 19, 19, 19, 1, 19, 250, 19, 1, 1, 1, 1, 100, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjMTTActOrderInvoiceParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjMTTActOrderInvoice bean0 = (EObjMTTActOrderInvoice) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getMTTActOrderInvoiceIdPk());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getContractId());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getPrintRetailInd());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getPrintPriceMatchSummaryInd());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getSubstituteItemInd());
      setLong (stmt, 6, Types.BIGINT, (Long)bean0.getInvoiceSequence());
      setInteger (stmt, 7, Types.INTEGER, (Integer)bean0.getInvoiceCopiesNumber());
      setLong (stmt, 8, Types.BIGINT, (Long)bean0.getInvoiceMode());
      setLong (stmt, 9, Types.BIGINT, (Long)bean0.getOrderGuide());
      setString (stmt, 10, Types.VARCHAR, (String)bean0.getSepOrderItemReserveInd());
      setString (stmt, 11, Types.VARCHAR, (String)bean0.getSpecialInstructions());
      setLong (stmt, 12, Types.BIGINT, (Long)bean0.getPrintCatInvoiceBreak());
      setLong (stmt, 13, Types.BIGINT, (Long)bean0.getInvoiceRecapSummary());
      setString (stmt, 14, Types.VARCHAR, (String)bean0.getPONumberRequiredInd());
      setLong (stmt, 15, Types.BIGINT, (Long)bean0.getPickupDeliver());
      setString (stmt, 16, Types.VARCHAR, (String)bean0.getPrintAlternateTobaccoLicenceInd());
      setString (stmt, 17, Types.VARCHAR, (String)bean0.getTotesInd());
      setLong (stmt, 18, Types.BIGINT, (Long)bean0.getTotes());
      setLong (stmt, 19, Types.BIGINT, (Long)bean0.getUnitCaseCostPrint());
      setLong (stmt, 20, Types.BIGINT, (Long)bean0.getInvoiceFormat());
      setString (stmt, 21, Types.VARCHAR, (String)bean0.getPickEachesInd());
      setLong (stmt, 22, Types.BIGINT, (Long)bean0.getInvoice());
      setString (stmt, 23, Types.VARCHAR, (String)bean0.getInvoiceStopMessage());
      setLong (stmt, 24, Types.BIGINT, (Long)bean0.getDelPickPackInvoice());
      setString (stmt, 25, Types.VARCHAR, (String)bean0.getPrintHOInvoiceInd());
      setString (stmt, 26, Types.VARCHAR, (String)bean0.getPrintWholesaleOnInvoiceInd());
      setString (stmt, 27, Types.VARCHAR, (String)bean0.getSepInvoicePerCustomerPOInd());
      setString (stmt, 28, Types.VARCHAR, (String)bean0.getASNRequiredInd());
      setString (stmt, 29, Types.VARCHAR, (String)bean0.getEASNMailbox());
      setTimestamp (stmt, 30, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 31, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 32, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update MTT_ACCOUNT_ORDER_INVOICE set CONTRACT_ID = :contractId, PRN_RETAIL_IND = :printRetailInd, PRN_PRICE_MATCH_SUMMARY_IND = :printPriceMatchSummaryInd, SUBSTITUTE_ITEM_IND = :substituteItemInd, INV_SEQ_TP_CD = :invoiceSequence, INV_COPIES_NUM = :invoiceCopiesNumber, INV_MODE_TP_CD = :invoiceMode, ORDER_GUIDE_TP_CD = :orderGuide, SEP_ORDER_ITEM_RESRV_IND = :sepOrderItemReserveInd, SPECIAL_INSTRUCTIONS = :specialInstructions, PRN_CAT_INV_BRK_TP_CD = :printCatInvoiceBreak, INV_RECAP_SUMMARY_TP_CD = :invoiceRecapSummary, PO_NUM_REQ_IND = :pONumberRequiredInd, PICKUP_DELIVER_TP_CD = :pickupDeliver, PRN_ALT_TOBACCO_LICENCE_IND = :printAlternateTobaccoLicenceInd, TOTES_IND = :totesInd, TOTES_TP_CD = :totes, UNIT_CASE_COST_PRN_TP_CD = :unitCaseCostPrint, INV_FORMAT_TP_CD = :invoiceFormat, PICK_EACHES_IND = :pickEachesInd, INV_TP_CD = :invoice, INV_STOP_MSG = :invoiceStopMessage, DEL_PICK_PACK_INV_TP_CD = :delPickPackInvoice, PRN_HO_INV_IND = :printHOInvoiceInd, PRN_WHOLESALE_ON_INV_IND = :printWholesaleOnInvoiceInd, SEP_INV_PER_CUS_PO_IND = :sepInvoicePerCustomerPOInd, ASN_REQ_IND = :aSNRequiredInd, EASNMailbox = :eASNMailbox, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where MTT_ACT_ORDER_INV_ID = :mTTActOrderInvoiceIdPk and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjMTTActOrderInvoice (EObjMTTActOrderInvoice e)
  {
    return update (updateEObjMTTActOrderInvoiceStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjMTTActOrderInvoiceStatementDescriptor = createStatementDescriptor (
    "updateEObjMTTActOrderInvoice(com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice)",
    "update MTT_ACCOUNT_ORDER_INVOICE set CONTRACT_ID =  ? , PRN_RETAIL_IND =  ? , PRN_PRICE_MATCH_SUMMARY_IND =  ? , SUBSTITUTE_ITEM_IND =  ? , INV_SEQ_TP_CD =  ? , INV_COPIES_NUM =  ? , INV_MODE_TP_CD =  ? , ORDER_GUIDE_TP_CD =  ? , SEP_ORDER_ITEM_RESRV_IND =  ? , SPECIAL_INSTRUCTIONS =  ? , PRN_CAT_INV_BRK_TP_CD =  ? , INV_RECAP_SUMMARY_TP_CD =  ? , PO_NUM_REQ_IND =  ? , PICKUP_DELIVER_TP_CD =  ? , PRN_ALT_TOBACCO_LICENCE_IND =  ? , TOTES_IND =  ? , TOTES_TP_CD =  ? , UNIT_CASE_COST_PRN_TP_CD =  ? , INV_FORMAT_TP_CD =  ? , PICK_EACHES_IND =  ? , INV_TP_CD =  ? , INV_STOP_MSG =  ? , DEL_PICK_PACK_INV_TP_CD =  ? , PRN_HO_INV_IND =  ? , PRN_WHOLESALE_ON_INV_IND =  ? , SEP_INV_PER_CUS_PO_IND =  ? , ASN_REQ_IND =  ? , EASNMailbox =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where MTT_ACT_ORDER_INV_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjMTTActOrderInvoiceParameterHandler (),
    new int[][]{{Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.INTEGER, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 1, 1, 1, 19, 10, 19, 19, 1, 250, 19, 19, 1, 19, 1, 1, 19, 19, 19, 1, 19, 250, 19, 1, 1, 1, 1, 100, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjMTTActOrderInvoiceParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjMTTActOrderInvoice bean0 = (EObjMTTActOrderInvoice) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getContractId());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getPrintRetailInd());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getPrintPriceMatchSummaryInd());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getSubstituteItemInd());
      setLong (stmt, 5, Types.BIGINT, (Long)bean0.getInvoiceSequence());
      setInteger (stmt, 6, Types.INTEGER, (Integer)bean0.getInvoiceCopiesNumber());
      setLong (stmt, 7, Types.BIGINT, (Long)bean0.getInvoiceMode());
      setLong (stmt, 8, Types.BIGINT, (Long)bean0.getOrderGuide());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getSepOrderItemReserveInd());
      setString (stmt, 10, Types.VARCHAR, (String)bean0.getSpecialInstructions());
      setLong (stmt, 11, Types.BIGINT, (Long)bean0.getPrintCatInvoiceBreak());
      setLong (stmt, 12, Types.BIGINT, (Long)bean0.getInvoiceRecapSummary());
      setString (stmt, 13, Types.VARCHAR, (String)bean0.getPONumberRequiredInd());
      setLong (stmt, 14, Types.BIGINT, (Long)bean0.getPickupDeliver());
      setString (stmt, 15, Types.VARCHAR, (String)bean0.getPrintAlternateTobaccoLicenceInd());
      setString (stmt, 16, Types.VARCHAR, (String)bean0.getTotesInd());
      setLong (stmt, 17, Types.BIGINT, (Long)bean0.getTotes());
      setLong (stmt, 18, Types.BIGINT, (Long)bean0.getUnitCaseCostPrint());
      setLong (stmt, 19, Types.BIGINT, (Long)bean0.getInvoiceFormat());
      setString (stmt, 20, Types.VARCHAR, (String)bean0.getPickEachesInd());
      setLong (stmt, 21, Types.BIGINT, (Long)bean0.getInvoice());
      setString (stmt, 22, Types.VARCHAR, (String)bean0.getInvoiceStopMessage());
      setLong (stmt, 23, Types.BIGINT, (Long)bean0.getDelPickPackInvoice());
      setString (stmt, 24, Types.VARCHAR, (String)bean0.getPrintHOInvoiceInd());
      setString (stmt, 25, Types.VARCHAR, (String)bean0.getPrintWholesaleOnInvoiceInd());
      setString (stmt, 26, Types.VARCHAR, (String)bean0.getSepInvoicePerCustomerPOInd());
      setString (stmt, 27, Types.VARCHAR, (String)bean0.getASNRequiredInd());
      setString (stmt, 28, Types.VARCHAR, (String)bean0.getEASNMailbox());
      setTimestamp (stmt, 29, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 30, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 31, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 32, Types.BIGINT, (Long)bean0.getMTTActOrderInvoiceIdPk());
      setTimestamp (stmt, 33, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from MTT_ACCOUNT_ORDER_INVOICE where MTT_ACT_ORDER_INV_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjMTTActOrderInvoice (Long mTTActOrderInvoiceIdPk)
  {
    return update (deleteEObjMTTActOrderInvoiceStatementDescriptor, mTTActOrderInvoiceIdPk);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjMTTActOrderInvoiceStatementDescriptor = createStatementDescriptor (
    "deleteEObjMTTActOrderInvoice(Long)",
    "delete from MTT_ACCOUNT_ORDER_INVOICE where MTT_ACT_ORDER_INV_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjMTTActOrderInvoiceParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjMTTActOrderInvoiceParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
