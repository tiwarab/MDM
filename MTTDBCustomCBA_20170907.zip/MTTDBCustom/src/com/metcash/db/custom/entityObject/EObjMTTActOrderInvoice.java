/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[191f6213d6edb0afaf9d92ded5df5df8]
 */

package com.metcash.db.custom.entityObject;

import com.dwl.base.EObjCommon;
import com.ibm.mdm.base.db.DataType;
import com.ibm.pdq.annotation.Column;
import com.ibm.pdq.annotation.Table;


import com.ibm.pdq.annotation.Id;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * The entity object corresponding to the MTTActOrderInvoice business object.
 * This entity object should include all the attributes as defined by the
 * business object.
 * 
 * @generated
 */
@SuppressWarnings("serial")
@Table(name=EObjMTTActOrderInvoice.tableName)
public class EObjMTTActOrderInvoice extends EObjCommon {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public static final String tableName = "MTT_ACCOUNT_ORDER_INVOICE";
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String mTTActOrderInvoiceIdPkColumn = "MTT_ACT_ORDER_INV_ID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String mTTActOrderInvoiceIdPkJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    mTTActOrderInvoiceIdPkPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String contractIdColumn = "CONTRACT_ID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String contractIdJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    contractIdPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String printRetailIndColumn = "PRN_RETAIL_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String printRetailIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    printRetailIndPrecision = 1;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String printPriceMatchSummaryIndColumn = "PRN_PRICE_MATCH_SUMMARY_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String printPriceMatchSummaryIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    printPriceMatchSummaryIndPrecision = 1;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String substituteItemIndColumn = "SUBSTITUTE_ITEM_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String substituteItemIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    substituteItemIndPrecision = 1;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String invoiceSequenceColumn = "INV_SEQ_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String invoiceSequenceJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    invoiceSequencePrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String invoiceCopiesNumberColumn = "INV_COPIES_NUM";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String invoiceCopiesNumberJdbcType = "INTEGER";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String invoiceModeColumn = "INV_MODE_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String invoiceModeJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    invoiceModePrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String orderGuideColumn = "ORDER_GUIDE_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String orderGuideJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    orderGuidePrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String sepOrderItemReserveIndColumn = "SEP_ORDER_ITEM_RESRV_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String sepOrderItemReserveIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    sepOrderItemReserveIndPrecision = 1;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String specialInstructionsColumn = "SPECIAL_INSTRUCTIONS";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String specialInstructionsJdbcType = "VARCHAR";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    specialInstructionsPrecision = 250;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String printCatInvoiceBreakColumn = "PRN_CAT_INV_BRK_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String printCatInvoiceBreakJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    printCatInvoiceBreakPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String invoiceRecapSummaryColumn = "INV_RECAP_SUMMARY_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String invoiceRecapSummaryJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    invoiceRecapSummaryPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String pONumberRequiredIndColumn = "PO_NUM_REQ_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String pONumberRequiredIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    pONumberRequiredIndPrecision = 1;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String pickupDeliverColumn = "PICKUP_DELIVER_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String pickupDeliverJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    pickupDeliverPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String printAlternateTobaccoLicenceIndColumn = "PRN_ALT_TOBACCO_LICENCE_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String printAlternateTobaccoLicenceIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    printAlternateTobaccoLicenceIndPrecision = 1;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String totesIndColumn = "TOTES_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String totesIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    totesIndPrecision = 1;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String totesColumn = "TOTES_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String totesJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    totesPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String unitCaseCostPrintColumn = "UNIT_CASE_COST_PRN_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String unitCaseCostPrintJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    unitCaseCostPrintPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String invoiceFormatColumn = "INV_FORMAT_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String invoiceFormatJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    invoiceFormatPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String pickEachesIndColumn = "PICK_EACHES_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String pickEachesIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    pickEachesIndPrecision = 1;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String invoiceColumn = "INV_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String invoiceJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    invoicePrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String invoiceStopMessageColumn = "INV_STOP_MSG";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String invoiceStopMessageJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    invoiceStopMessagePrecision = 250;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String delPickPackInvoiceColumn = "DEL_PICK_PACK_INV_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String delPickPackInvoiceJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    delPickPackInvoicePrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String printHOInvoiceIndColumn = "PRN_HO_INV_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String printHOInvoiceIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    printHOInvoiceIndPrecision = 1;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String printWholesaleOnInvoiceIndColumn = "PRN_WHOLESALE_ON_INV_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String printWholesaleOnInvoiceIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    printWholesaleOnInvoiceIndPrecision = 1;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String sepInvoicePerCustomerPOIndColumn = "SEP_INV_PER_CUS_PO_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String sepInvoicePerCustomerPOIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    sepInvoicePerCustomerPOIndPrecision = 1;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String aSNRequiredIndColumn = "ASN_REQ_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String aSNRequiredIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    aSNRequiredIndPrecision = 1;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String eASNMailboxColumn = "EASNMAILBOX";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String eASNMailboxJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    eASNMailboxPrecision = 100;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long mTTActOrderInvoiceIdPk;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long contractId;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String printRetailInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String printPriceMatchSummaryInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String substituteItemInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long invoiceSequence;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Integer invoiceCopiesNumber;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long invoiceMode;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long orderGuide;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String sepOrderItemReserveInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String specialInstructions;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long printCatInvoiceBreak;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long invoiceRecapSummary;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String pONumberRequiredInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long pickupDeliver;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String printAlternateTobaccoLicenceInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String totesInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long totes;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long unitCaseCostPrint;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long invoiceFormat;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String pickEachesInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long invoice;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String invoiceStopMessage;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long delPickPackInvoice;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String printHOInvoiceInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String printWholesaleOnInvoiceInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String sepInvoicePerCustomerPOInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String aSNRequiredInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String eASNMailbox;



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Default constructor.     
     *
     * @generated
     */
    public EObjMTTActOrderInvoice() {
        super();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the mTTActOrderInvoiceIdPk attribute. 
     *
     * @generated
     */
    @Id
    @Column(name=mTTActOrderInvoiceIdPkColumn)
    @DataType(jdbcType=mTTActOrderInvoiceIdPkJdbcType, precision=mTTActOrderInvoiceIdPkPrecision)
    public Long getMTTActOrderInvoiceIdPk (){
        return mTTActOrderInvoiceIdPk;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the mTTActOrderInvoiceIdPk attribute. 
     *
     * @param mTTActOrderInvoiceIdPk
     *     The new value of MTTActOrderInvoiceIdPk. 
     * @generated
     */
    public void setMTTActOrderInvoiceIdPk( Long mTTActOrderInvoiceIdPk ){
        this.mTTActOrderInvoiceIdPk = mTTActOrderInvoiceIdPk;
    
        super.setIdPK(mTTActOrderInvoiceIdPk);
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contractId attribute. 
     *
     * @generated
     */
    @Column(name=contractIdColumn)
    @DataType(jdbcType=contractIdJdbcType, precision=contractIdPrecision)
    public Long getContractId (){
        return contractId;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contractId attribute. 
     *
     * @param contractId
     *     The new value of ContractId. 
     * @generated
     */
    public void setContractId( Long contractId ){
        this.contractId = contractId;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the printRetailInd attribute. 
     *
     * @generated
     */
    @Column(name=printRetailIndColumn)
    @DataType(jdbcType=printRetailIndJdbcType, precision=printRetailIndPrecision)
    public String getPrintRetailInd (){
        return printRetailInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the printRetailInd attribute. 
     *
     * @param printRetailInd
     *     The new value of PrintRetailInd. 
     * @generated
     */
    public void setPrintRetailInd( String printRetailInd ){
        this.printRetailInd = printRetailInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the printPriceMatchSummaryInd attribute. 
     *
     * @generated
     */
    @Column(name=printPriceMatchSummaryIndColumn)
    @DataType(jdbcType=printPriceMatchSummaryIndJdbcType, precision=printPriceMatchSummaryIndPrecision)
    public String getPrintPriceMatchSummaryInd (){
        return printPriceMatchSummaryInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the printPriceMatchSummaryInd attribute. 
     *
     * @param printPriceMatchSummaryInd
     *     The new value of PrintPriceMatchSummaryInd. 
     * @generated
     */
    public void setPrintPriceMatchSummaryInd( String printPriceMatchSummaryInd ){
        this.printPriceMatchSummaryInd = printPriceMatchSummaryInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the substituteItemInd attribute. 
     *
     * @generated
     */
    @Column(name=substituteItemIndColumn)
    @DataType(jdbcType=substituteItemIndJdbcType, precision=substituteItemIndPrecision)
    public String getSubstituteItemInd (){
        return substituteItemInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the substituteItemInd attribute. 
     *
     * @param substituteItemInd
     *     The new value of SubstituteItemInd. 
     * @generated
     */
    public void setSubstituteItemInd( String substituteItemInd ){
        this.substituteItemInd = substituteItemInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the invoiceSequence attribute. 
     *
     * @generated
     */
    @Column(name=invoiceSequenceColumn)
    @DataType(jdbcType=invoiceSequenceJdbcType, precision=invoiceSequencePrecision)
    public Long getInvoiceSequence (){
        return invoiceSequence;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the invoiceSequence attribute. 
     *
     * @param invoiceSequence
     *     The new value of InvoiceSequence. 
     * @generated
     */
    public void setInvoiceSequence( Long invoiceSequence ){
        this.invoiceSequence = invoiceSequence;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the invoiceCopiesNumber attribute. 
     *
     * @generated
     */
    @Column(name=invoiceCopiesNumberColumn)
    @DataType(jdbcType=invoiceCopiesNumberJdbcType)
    public Integer getInvoiceCopiesNumber (){
        return invoiceCopiesNumber;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the invoiceCopiesNumber attribute. 
     *
     * @param invoiceCopiesNumber
     *     The new value of InvoiceCopiesNumber. 
     * @generated
     */
    public void setInvoiceCopiesNumber( Integer invoiceCopiesNumber ){
        this.invoiceCopiesNumber = invoiceCopiesNumber;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the invoiceMode attribute. 
     *
     * @generated
     */
    @Column(name=invoiceModeColumn)
    @DataType(jdbcType=invoiceModeJdbcType, precision=invoiceModePrecision)
    public Long getInvoiceMode (){
        return invoiceMode;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the invoiceMode attribute. 
     *
     * @param invoiceMode
     *     The new value of InvoiceMode. 
     * @generated
     */
    public void setInvoiceMode( Long invoiceMode ){
        this.invoiceMode = invoiceMode;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the orderGuide attribute. 
     *
     * @generated
     */
    @Column(name=orderGuideColumn)
    @DataType(jdbcType=orderGuideJdbcType, precision=orderGuidePrecision)
    public Long getOrderGuide (){
        return orderGuide;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the orderGuide attribute. 
     *
     * @param orderGuide
     *     The new value of OrderGuide. 
     * @generated
     */
    public void setOrderGuide( Long orderGuide ){
        this.orderGuide = orderGuide;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sepOrderItemReserveInd attribute. 
     *
     * @generated
     */
    @Column(name=sepOrderItemReserveIndColumn)
    @DataType(jdbcType=sepOrderItemReserveIndJdbcType, precision=sepOrderItemReserveIndPrecision)
    public String getSepOrderItemReserveInd (){
        return sepOrderItemReserveInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sepOrderItemReserveInd attribute. 
     *
     * @param sepOrderItemReserveInd
     *     The new value of SepOrderItemReserveInd. 
     * @generated
     */
    public void setSepOrderItemReserveInd( String sepOrderItemReserveInd ){
        this.sepOrderItemReserveInd = sepOrderItemReserveInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the specialInstructions attribute. 
     *
     * @generated
     */
    @Column(name=specialInstructionsColumn)
    @DataType(jdbcType=specialInstructionsJdbcType, precision=specialInstructionsPrecision)
    public String getSpecialInstructions (){
        return specialInstructions;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the specialInstructions attribute. 
     *
     * @param specialInstructions
     *     The new value of SpecialInstructions. 
     * @generated
     */
    public void setSpecialInstructions( String specialInstructions ){
        this.specialInstructions = specialInstructions;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the printCatInvoiceBreak attribute. 
     *
     * @generated
     */
    @Column(name=printCatInvoiceBreakColumn)
    @DataType(jdbcType=printCatInvoiceBreakJdbcType, precision=printCatInvoiceBreakPrecision)
    public Long getPrintCatInvoiceBreak (){
        return printCatInvoiceBreak;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the printCatInvoiceBreak attribute. 
     *
     * @param printCatInvoiceBreak
     *     The new value of PrintCatInvoiceBreak. 
     * @generated
     */
    public void setPrintCatInvoiceBreak( Long printCatInvoiceBreak ){
        this.printCatInvoiceBreak = printCatInvoiceBreak;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the invoiceRecapSummary attribute. 
     *
     * @generated
     */
    @Column(name=invoiceRecapSummaryColumn)
    @DataType(jdbcType=invoiceRecapSummaryJdbcType, precision=invoiceRecapSummaryPrecision)
    public Long getInvoiceRecapSummary (){
        return invoiceRecapSummary;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the invoiceRecapSummary attribute. 
     *
     * @param invoiceRecapSummary
     *     The new value of InvoiceRecapSummary. 
     * @generated
     */
    public void setInvoiceRecapSummary( Long invoiceRecapSummary ){
        this.invoiceRecapSummary = invoiceRecapSummary;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the pONumberRequiredInd attribute. 
     *
     * @generated
     */
    @Column(name=pONumberRequiredIndColumn)
    @DataType(jdbcType=pONumberRequiredIndJdbcType, precision=pONumberRequiredIndPrecision)
    public String getPONumberRequiredInd (){
        return pONumberRequiredInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the pONumberRequiredInd attribute. 
     *
     * @param pONumberRequiredInd
     *     The new value of PONumberRequiredInd. 
     * @generated
     */
    public void setPONumberRequiredInd( String pONumberRequiredInd ){
        this.pONumberRequiredInd = pONumberRequiredInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the pickupDeliver attribute. 
     *
     * @generated
     */
    @Column(name=pickupDeliverColumn)
    @DataType(jdbcType=pickupDeliverJdbcType, precision=pickupDeliverPrecision)
    public Long getPickupDeliver (){
        return pickupDeliver;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the pickupDeliver attribute. 
     *
     * @param pickupDeliver
     *     The new value of PickupDeliver. 
     * @generated
     */
    public void setPickupDeliver( Long pickupDeliver ){
        this.pickupDeliver = pickupDeliver;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the printAlternateTobaccoLicenceInd attribute. 
     *
     * @generated
     */
    @Column(name=printAlternateTobaccoLicenceIndColumn)
    @DataType(jdbcType=printAlternateTobaccoLicenceIndJdbcType, precision=printAlternateTobaccoLicenceIndPrecision)
    public String getPrintAlternateTobaccoLicenceInd (){
        return printAlternateTobaccoLicenceInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the printAlternateTobaccoLicenceInd attribute. 
     *
     * @param printAlternateTobaccoLicenceInd
     *     The new value of PrintAlternateTobaccoLicenceInd. 
     * @generated
     */
    public void setPrintAlternateTobaccoLicenceInd( String printAlternateTobaccoLicenceInd ){
        this.printAlternateTobaccoLicenceInd = printAlternateTobaccoLicenceInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the totesInd attribute. 
     *
     * @generated
     */
    @Column(name=totesIndColumn)
    @DataType(jdbcType=totesIndJdbcType, precision=totesIndPrecision)
    public String getTotesInd (){
        return totesInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the totesInd attribute. 
     *
     * @param totesInd
     *     The new value of TotesInd. 
     * @generated
     */
    public void setTotesInd( String totesInd ){
        this.totesInd = totesInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the totes attribute. 
     *
     * @generated
     */
    @Column(name=totesColumn)
    @DataType(jdbcType=totesJdbcType, precision=totesPrecision)
    public Long getTotes (){
        return totes;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the totes attribute. 
     *
     * @param totes
     *     The new value of Totes. 
     * @generated
     */
    public void setTotes( Long totes ){
        this.totes = totes;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the unitCaseCostPrint attribute. 
     *
     * @generated
     */
    @Column(name=unitCaseCostPrintColumn)
    @DataType(jdbcType=unitCaseCostPrintJdbcType, precision=unitCaseCostPrintPrecision)
    public Long getUnitCaseCostPrint (){
        return unitCaseCostPrint;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the unitCaseCostPrint attribute. 
     *
     * @param unitCaseCostPrint
     *     The new value of UnitCaseCostPrint. 
     * @generated
     */
    public void setUnitCaseCostPrint( Long unitCaseCostPrint ){
        this.unitCaseCostPrint = unitCaseCostPrint;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the invoiceFormat attribute. 
     *
     * @generated
     */
    @Column(name=invoiceFormatColumn)
    @DataType(jdbcType=invoiceFormatJdbcType, precision=invoiceFormatPrecision)
    public Long getInvoiceFormat (){
        return invoiceFormat;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the invoiceFormat attribute. 
     *
     * @param invoiceFormat
     *     The new value of InvoiceFormat. 
     * @generated
     */
    public void setInvoiceFormat( Long invoiceFormat ){
        this.invoiceFormat = invoiceFormat;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the pickEachesInd attribute. 
     *
     * @generated
     */
    @Column(name=pickEachesIndColumn)
    @DataType(jdbcType=pickEachesIndJdbcType, precision=pickEachesIndPrecision)
    public String getPickEachesInd (){
        return pickEachesInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the pickEachesInd attribute. 
     *
     * @param pickEachesInd
     *     The new value of PickEachesInd. 
     * @generated
     */
    public void setPickEachesInd( String pickEachesInd ){
        this.pickEachesInd = pickEachesInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the invoice attribute. 
     *
     * @generated
     */
    @Column(name=invoiceColumn)
    @DataType(jdbcType=invoiceJdbcType, precision=invoicePrecision)
    public Long getInvoice (){
        return invoice;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the invoice attribute. 
     *
     * @param invoice
     *     The new value of Invoice. 
     * @generated
     */
    public void setInvoice( Long invoice ){
        this.invoice = invoice;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the invoiceStopMessage attribute. 
     *
     * @generated
     */
    @Column(name=invoiceStopMessageColumn)
    @DataType(jdbcType=invoiceStopMessageJdbcType, precision=invoiceStopMessagePrecision)
    public String getInvoiceStopMessage (){
        return invoiceStopMessage;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the invoiceStopMessage attribute. 
     *
     * @param invoiceStopMessage
     *     The new value of InvoiceStopMessage. 
     * @generated
     */
    public void setInvoiceStopMessage( String invoiceStopMessage ){
        this.invoiceStopMessage = invoiceStopMessage;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the delPickPackInvoice attribute. 
     *
     * @generated
     */
    @Column(name=delPickPackInvoiceColumn)
    @DataType(jdbcType=delPickPackInvoiceJdbcType, precision=delPickPackInvoicePrecision)
    public Long getDelPickPackInvoice (){
        return delPickPackInvoice;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the delPickPackInvoice attribute. 
     *
     * @param delPickPackInvoice
     *     The new value of DelPickPackInvoice. 
     * @generated
     */
    public void setDelPickPackInvoice( Long delPickPackInvoice ){
        this.delPickPackInvoice = delPickPackInvoice;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the printHOInvoiceInd attribute. 
     *
     * @generated
     */
    @Column(name=printHOInvoiceIndColumn)
    @DataType(jdbcType=printHOInvoiceIndJdbcType, precision=printHOInvoiceIndPrecision)
    public String getPrintHOInvoiceInd (){
        return printHOInvoiceInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the printHOInvoiceInd attribute. 
     *
     * @param printHOInvoiceInd
     *     The new value of PrintHOInvoiceInd. 
     * @generated
     */
    public void setPrintHOInvoiceInd( String printHOInvoiceInd ){
        this.printHOInvoiceInd = printHOInvoiceInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the printWholesaleOnInvoiceInd attribute. 
     *
     * @generated
     */
    @Column(name=printWholesaleOnInvoiceIndColumn)
    @DataType(jdbcType=printWholesaleOnInvoiceIndJdbcType, precision=printWholesaleOnInvoiceIndPrecision)
    public String getPrintWholesaleOnInvoiceInd (){
        return printWholesaleOnInvoiceInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the printWholesaleOnInvoiceInd attribute. 
     *
     * @param printWholesaleOnInvoiceInd
     *     The new value of PrintWholesaleOnInvoiceInd. 
     * @generated
     */
    public void setPrintWholesaleOnInvoiceInd( String printWholesaleOnInvoiceInd ){
        this.printWholesaleOnInvoiceInd = printWholesaleOnInvoiceInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sepInvoicePerCustomerPOInd attribute. 
     *
     * @generated
     */
    @Column(name=sepInvoicePerCustomerPOIndColumn)
    @DataType(jdbcType=sepInvoicePerCustomerPOIndJdbcType, precision=sepInvoicePerCustomerPOIndPrecision)
    public String getSepInvoicePerCustomerPOInd (){
        return sepInvoicePerCustomerPOInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sepInvoicePerCustomerPOInd attribute. 
     *
     * @param sepInvoicePerCustomerPOInd
     *     The new value of SepInvoicePerCustomerPOInd. 
     * @generated
     */
    public void setSepInvoicePerCustomerPOInd( String sepInvoicePerCustomerPOInd ){
        this.sepInvoicePerCustomerPOInd = sepInvoicePerCustomerPOInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the aSNRequiredInd attribute. 
     *
     * @generated
     */
    @Column(name=aSNRequiredIndColumn)
    @DataType(jdbcType=aSNRequiredIndJdbcType, precision=aSNRequiredIndPrecision)
    public String getASNRequiredInd (){
        return aSNRequiredInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the aSNRequiredInd attribute. 
     *
     * @param aSNRequiredInd
     *     The new value of ASNRequiredInd. 
     * @generated
     */
    public void setASNRequiredInd( String aSNRequiredInd ){
        this.aSNRequiredInd = aSNRequiredInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the eASNMailbox attribute. 
     *
     * @generated
     */
    @Column(name=eASNMailboxColumn)
    @DataType(jdbcType=eASNMailboxJdbcType, precision=eASNMailboxPrecision)
    public String getEASNMailbox (){
        return eASNMailbox;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the eASNMailbox attribute. 
     *
     * @param eASNMailbox
     *     The new value of EASNMailbox. 
     * @generated
     */
    public void setEASNMailbox( String eASNMailbox ){
        this.eASNMailbox = eASNMailbox;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the primary key. 
     *
     * @param aUniqueId
     *     The new value of the primary key. 
     * @generated
   */
	public void setPrimaryKey(Object aUniqueId) {
    this.setMTTActOrderInvoiceIdPk((Long)aUniqueId);
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the primary key.
     *
     * @generated
     */
	public Object getPrimaryKey() {
    return this.getMTTActOrderInvoiceIdPk();
  }
	 
}


