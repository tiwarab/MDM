/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[bb9b38de04fe1ac9acf7c3e04dff4e79]
 */

package com.metcash.db.custom.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface MTTActOrderInvoiceInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "MTT_ACCOUNT_ORDER_INVOICE => com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice, " +
                                            "H_MTT_ACCOUNT_ORDER_INVOICE => com.metcash.db.custom.entityObject.EObjMTTActOrderInvoice" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getMTTActOrderInvoiceSql = "SELECT r.MTT_ACT_ORDER_INV_ID MTT_ACT_ORDER_INV_ID, r.CONTRACT_ID CONTRACT_ID, r.PRN_RETAIL_IND PRN_RETAIL_IND, r.PRN_PRICE_MATCH_SUMMARY_IND PRN_PRICE_MATCH_SUMMARY_IND, r.SUBSTITUTE_ITEM_IND SUBSTITUTE_ITEM_IND, r.INV_SEQ_TP_CD INV_SEQ_TP_CD, r.INV_COPIES_NUM INV_COPIES_NUM, r.INV_MODE_TP_CD INV_MODE_TP_CD, r.ORDER_GUIDE_TP_CD ORDER_GUIDE_TP_CD, r.SEP_ORDER_ITEM_RESRV_IND SEP_ORDER_ITEM_RESRV_IND, r.SPECIAL_INSTRUCTIONS SPECIAL_INSTRUCTIONS, r.PRN_CAT_INV_BRK_TP_CD PRN_CAT_INV_BRK_TP_CD, r.INV_RECAP_SUMMARY_TP_CD INV_RECAP_SUMMARY_TP_CD, r.PO_NUM_REQ_IND PO_NUM_REQ_IND, r.PICKUP_DELIVER_TP_CD PICKUP_DELIVER_TP_CD, r.PRN_ALT_TOBACCO_LICENCE_IND PRN_ALT_TOBACCO_LICENCE_IND, r.TOTES_IND TOTES_IND, r.TOTES_TP_CD TOTES_TP_CD, r.UNIT_CASE_COST_PRN_TP_CD UNIT_CASE_COST_PRN_TP_CD, r.INV_FORMAT_TP_CD INV_FORMAT_TP_CD, r.PICK_EACHES_IND PICK_EACHES_IND, r.INV_TP_CD INV_TP_CD, r.INV_STOP_MSG INV_STOP_MSG, r.DEL_PICK_PACK_INV_TP_CD DEL_PICK_PACK_INV_TP_CD, r.PRN_HO_INV_IND PRN_HO_INV_IND, r.PRN_WHOLESALE_ON_INV_IND PRN_WHOLESALE_ON_INV_IND, r.SEP_INV_PER_CUS_PO_IND SEP_INV_PER_CUS_PO_IND, r.ASN_REQ_IND ASN_REQ_IND, r.EASNMailbox EASNMailbox, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM MTT_ACCOUNT_ORDER_INVOICE r WHERE r.MTT_ACT_ORDER_INV_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getMTTActOrderInvoiceParameters =
    "EObjMTTActOrderInvoice.MTTActOrderInvoiceIdPk";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getMTTActOrderInvoiceResults =
    "EObjMTTActOrderInvoice.MTTActOrderInvoiceIdPk," +
    "EObjMTTActOrderInvoice.ContractId," +
    "EObjMTTActOrderInvoice.PrintRetailInd," +
    "EObjMTTActOrderInvoice.PrintPriceMatchSummaryInd," +
    "EObjMTTActOrderInvoice.SubstituteItemInd," +
    "EObjMTTActOrderInvoice.InvoiceSequence," +
    "EObjMTTActOrderInvoice.InvoiceCopiesNumber," +
    "EObjMTTActOrderInvoice.InvoiceMode," +
    "EObjMTTActOrderInvoice.OrderGuide," +
    "EObjMTTActOrderInvoice.SepOrderItemReserveInd," +
    "EObjMTTActOrderInvoice.SpecialInstructions," +
    "EObjMTTActOrderInvoice.PrintCatInvoiceBreak," +
    "EObjMTTActOrderInvoice.InvoiceRecapSummary," +
    "EObjMTTActOrderInvoice.PONumberRequiredInd," +
    "EObjMTTActOrderInvoice.PickupDeliver," +
    "EObjMTTActOrderInvoice.PrintAlternateTobaccoLicenceInd," +
    "EObjMTTActOrderInvoice.TotesInd," +
    "EObjMTTActOrderInvoice.Totes," +
    "EObjMTTActOrderInvoice.UnitCaseCostPrint," +
    "EObjMTTActOrderInvoice.InvoiceFormat," +
    "EObjMTTActOrderInvoice.PickEachesInd," +
    "EObjMTTActOrderInvoice.Invoice," +
    "EObjMTTActOrderInvoice.InvoiceStopMessage," +
    "EObjMTTActOrderInvoice.DelPickPackInvoice," +
    "EObjMTTActOrderInvoice.PrintHOInvoiceInd," +
    "EObjMTTActOrderInvoice.PrintWholesaleOnInvoiceInd," +
    "EObjMTTActOrderInvoice.SepInvoicePerCustomerPOInd," +
    "EObjMTTActOrderInvoice.ASNRequiredInd," +
    "EObjMTTActOrderInvoice.EASNMailbox," +
    "EObjMTTActOrderInvoice.lastUpdateDt," +
    "EObjMTTActOrderInvoice.lastUpdateUser," +
    "EObjMTTActOrderInvoice.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getMTTActOrderInvoiceHistorySql = "SELECT r.H_MTT_ACT_ORDER_INV_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.MTT_ACT_ORDER_INV_ID MTT_ACT_ORDER_INV_ID, r.CONTRACT_ID CONTRACT_ID, r.PRN_RETAIL_IND PRN_RETAIL_IND, r.PRN_PRICE_MATCH_SUMMARY_IND PRN_PRICE_MATCH_SUMMARY_IND, r.SUBSTITUTE_ITEM_IND SUBSTITUTE_ITEM_IND, r.INV_SEQ_TP_CD INV_SEQ_TP_CD, r.INV_COPIES_NUM INV_COPIES_NUM, r.INV_MODE_TP_CD INV_MODE_TP_CD, r.ORDER_GUIDE_TP_CD ORDER_GUIDE_TP_CD, r.SEP_ORDER_ITEM_RESRV_IND SEP_ORDER_ITEM_RESRV_IND, r.SPECIAL_INSTRUCTIONS SPECIAL_INSTRUCTIONS, r.PRN_CAT_INV_BRK_TP_CD PRN_CAT_INV_BRK_TP_CD, r.INV_RECAP_SUMMARY_TP_CD INV_RECAP_SUMMARY_TP_CD, r.PO_NUM_REQ_IND PO_NUM_REQ_IND, r.PICKUP_DELIVER_TP_CD PICKUP_DELIVER_TP_CD, r.PRN_ALT_TOBACCO_LICENCE_IND PRN_ALT_TOBACCO_LICENCE_IND, r.TOTES_IND TOTES_IND, r.TOTES_TP_CD TOTES_TP_CD, r.UNIT_CASE_COST_PRN_TP_CD UNIT_CASE_COST_PRN_TP_CD, r.INV_FORMAT_TP_CD INV_FORMAT_TP_CD, r.PICK_EACHES_IND PICK_EACHES_IND, r.INV_TP_CD INV_TP_CD, r.INV_STOP_MSG INV_STOP_MSG, r.DEL_PICK_PACK_INV_TP_CD DEL_PICK_PACK_INV_TP_CD, r.PRN_HO_INV_IND PRN_HO_INV_IND, r.PRN_WHOLESALE_ON_INV_IND PRN_WHOLESALE_ON_INV_IND, r.SEP_INV_PER_CUS_PO_IND SEP_INV_PER_CUS_PO_IND, r.ASN_REQ_IND ASN_REQ_IND, r.EASNMailbox EASNMailbox, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_MTT_ACCOUNT_ORDER_INVOICE r WHERE r.H_MTT_ACT_ORDER_INV_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getMTTActOrderInvoiceHistoryParameters =
    "EObjMTTActOrderInvoice.MTTActOrderInvoiceIdPk," +
    "EObjMTTActOrderInvoice.lastUpdateDt," +
    "EObjMTTActOrderInvoice.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getMTTActOrderInvoiceHistoryResults =
    "EObjMTTActOrderInvoice.historyIdPK," +
    "EObjMTTActOrderInvoice.histActionCode," +
    "EObjMTTActOrderInvoice.histCreatedBy," +
    "EObjMTTActOrderInvoice.histCreateDt," +
    "EObjMTTActOrderInvoice.histEndDt," +
    "EObjMTTActOrderInvoice.MTTActOrderInvoiceIdPk," +
    "EObjMTTActOrderInvoice.ContractId," +
    "EObjMTTActOrderInvoice.PrintRetailInd," +
    "EObjMTTActOrderInvoice.PrintPriceMatchSummaryInd," +
    "EObjMTTActOrderInvoice.SubstituteItemInd," +
    "EObjMTTActOrderInvoice.InvoiceSequence," +
    "EObjMTTActOrderInvoice.InvoiceCopiesNumber," +
    "EObjMTTActOrderInvoice.InvoiceMode," +
    "EObjMTTActOrderInvoice.OrderGuide," +
    "EObjMTTActOrderInvoice.SepOrderItemReserveInd," +
    "EObjMTTActOrderInvoice.SpecialInstructions," +
    "EObjMTTActOrderInvoice.PrintCatInvoiceBreak," +
    "EObjMTTActOrderInvoice.InvoiceRecapSummary," +
    "EObjMTTActOrderInvoice.PONumberRequiredInd," +
    "EObjMTTActOrderInvoice.PickupDeliver," +
    "EObjMTTActOrderInvoice.PrintAlternateTobaccoLicenceInd," +
    "EObjMTTActOrderInvoice.TotesInd," +
    "EObjMTTActOrderInvoice.Totes," +
    "EObjMTTActOrderInvoice.UnitCaseCostPrint," +
    "EObjMTTActOrderInvoice.InvoiceFormat," +
    "EObjMTTActOrderInvoice.PickEachesInd," +
    "EObjMTTActOrderInvoice.Invoice," +
    "EObjMTTActOrderInvoice.InvoiceStopMessage," +
    "EObjMTTActOrderInvoice.DelPickPackInvoice," +
    "EObjMTTActOrderInvoice.PrintHOInvoiceInd," +
    "EObjMTTActOrderInvoice.PrintWholesaleOnInvoiceInd," +
    "EObjMTTActOrderInvoice.SepInvoicePerCustomerPOInd," +
    "EObjMTTActOrderInvoice.ASNRequiredInd," +
    "EObjMTTActOrderInvoice.EASNMailbox," +
    "EObjMTTActOrderInvoice.lastUpdateDt," +
    "EObjMTTActOrderInvoice.lastUpdateUser," +
    "EObjMTTActOrderInvoice.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllMTTOrderInvoiceByIDSql = "SELECT r.MTT_ACT_ORDER_INV_ID MTT_ACT_ORDER_INV_ID, r.CONTRACT_ID CONTRACT_ID, r.PRN_RETAIL_IND PRN_RETAIL_IND, r.PRN_PRICE_MATCH_SUMMARY_IND PRN_PRICE_MATCH_SUMMARY_IND, r.SUBSTITUTE_ITEM_IND SUBSTITUTE_ITEM_IND, r.INV_SEQ_TP_CD INV_SEQ_TP_CD, r.INV_COPIES_NUM INV_COPIES_NUM, r.INV_MODE_TP_CD INV_MODE_TP_CD, r.ORDER_GUIDE_TP_CD ORDER_GUIDE_TP_CD, r.SEP_ORDER_ITEM_RESRV_IND SEP_ORDER_ITEM_RESRV_IND, r.SPECIAL_INSTRUCTIONS SPECIAL_INSTRUCTIONS, r.PRN_CAT_INV_BRK_TP_CD PRN_CAT_INV_BRK_TP_CD, r.INV_RECAP_SUMMARY_TP_CD INV_RECAP_SUMMARY_TP_CD, r.PO_NUM_REQ_IND PO_NUM_REQ_IND, r.PICKUP_DELIVER_TP_CD PICKUP_DELIVER_TP_CD, r.PRN_ALT_TOBACCO_LICENCE_IND PRN_ALT_TOBACCO_LICENCE_IND, r.TOTES_IND TOTES_IND, r.TOTES_TP_CD TOTES_TP_CD, r.UNIT_CASE_COST_PRN_TP_CD UNIT_CASE_COST_PRN_TP_CD, r.INV_FORMAT_TP_CD INV_FORMAT_TP_CD, r.PICK_EACHES_IND PICK_EACHES_IND, r.INV_TP_CD INV_TP_CD, r.INV_STOP_MSG INV_STOP_MSG, r.DEL_PICK_PACK_INV_TP_CD DEL_PICK_PACK_INV_TP_CD, r.PRN_HO_INV_IND PRN_HO_INV_IND, r.PRN_WHOLESALE_ON_INV_IND PRN_WHOLESALE_ON_INV_IND, r.SEP_INV_PER_CUS_PO_IND SEP_INV_PER_CUS_PO_IND, r.ASN_REQ_IND ASN_REQ_IND, r.EASNMailbox EASNMailbox, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM MTT_ACCOUNT_ORDER_INVOICE r WHERE r.CONTRACT_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllMTTOrderInvoiceByIDParameters =
    "EObjMTTActOrderInvoice.ContractId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllMTTOrderInvoiceByIDResults =
    "EObjMTTActOrderInvoice.MTTActOrderInvoiceIdPk," +
    "EObjMTTActOrderInvoice.ContractId," +
    "EObjMTTActOrderInvoice.PrintRetailInd," +
    "EObjMTTActOrderInvoice.PrintPriceMatchSummaryInd," +
    "EObjMTTActOrderInvoice.SubstituteItemInd," +
    "EObjMTTActOrderInvoice.InvoiceSequence," +
    "EObjMTTActOrderInvoice.InvoiceCopiesNumber," +
    "EObjMTTActOrderInvoice.InvoiceMode," +
    "EObjMTTActOrderInvoice.OrderGuide," +
    "EObjMTTActOrderInvoice.SepOrderItemReserveInd," +
    "EObjMTTActOrderInvoice.SpecialInstructions," +
    "EObjMTTActOrderInvoice.PrintCatInvoiceBreak," +
    "EObjMTTActOrderInvoice.InvoiceRecapSummary," +
    "EObjMTTActOrderInvoice.PONumberRequiredInd," +
    "EObjMTTActOrderInvoice.PickupDeliver," +
    "EObjMTTActOrderInvoice.PrintAlternateTobaccoLicenceInd," +
    "EObjMTTActOrderInvoice.TotesInd," +
    "EObjMTTActOrderInvoice.Totes," +
    "EObjMTTActOrderInvoice.UnitCaseCostPrint," +
    "EObjMTTActOrderInvoice.InvoiceFormat," +
    "EObjMTTActOrderInvoice.PickEachesInd," +
    "EObjMTTActOrderInvoice.Invoice," +
    "EObjMTTActOrderInvoice.InvoiceStopMessage," +
    "EObjMTTActOrderInvoice.DelPickPackInvoice," +
    "EObjMTTActOrderInvoice.PrintHOInvoiceInd," +
    "EObjMTTActOrderInvoice.PrintWholesaleOnInvoiceInd," +
    "EObjMTTActOrderInvoice.SepInvoicePerCustomerPOInd," +
    "EObjMTTActOrderInvoice.ASNRequiredInd," +
    "EObjMTTActOrderInvoice.EASNMailbox," +
    "EObjMTTActOrderInvoice.lastUpdateDt," +
    "EObjMTTActOrderInvoice.lastUpdateUser," +
    "EObjMTTActOrderInvoice.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllMTTOrderInvoiceByIDHistorySql = "SELECT r.H_MTT_ACT_ORDER_INV_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.MTT_ACT_ORDER_INV_ID MTT_ACT_ORDER_INV_ID, r.CONTRACT_ID CONTRACT_ID, r.PRN_RETAIL_IND PRN_RETAIL_IND, r.PRN_PRICE_MATCH_SUMMARY_IND PRN_PRICE_MATCH_SUMMARY_IND, r.SUBSTITUTE_ITEM_IND SUBSTITUTE_ITEM_IND, r.INV_SEQ_TP_CD INV_SEQ_TP_CD, r.INV_COPIES_NUM INV_COPIES_NUM, r.INV_MODE_TP_CD INV_MODE_TP_CD, r.ORDER_GUIDE_TP_CD ORDER_GUIDE_TP_CD, r.SEP_ORDER_ITEM_RESRV_IND SEP_ORDER_ITEM_RESRV_IND, r.SPECIAL_INSTRUCTIONS SPECIAL_INSTRUCTIONS, r.PRN_CAT_INV_BRK_TP_CD PRN_CAT_INV_BRK_TP_CD, r.INV_RECAP_SUMMARY_TP_CD INV_RECAP_SUMMARY_TP_CD, r.PO_NUM_REQ_IND PO_NUM_REQ_IND, r.PICKUP_DELIVER_TP_CD PICKUP_DELIVER_TP_CD, r.PRN_ALT_TOBACCO_LICENCE_IND PRN_ALT_TOBACCO_LICENCE_IND, r.TOTES_IND TOTES_IND, r.TOTES_TP_CD TOTES_TP_CD, r.UNIT_CASE_COST_PRN_TP_CD UNIT_CASE_COST_PRN_TP_CD, r.INV_FORMAT_TP_CD INV_FORMAT_TP_CD, r.PICK_EACHES_IND PICK_EACHES_IND, r.INV_TP_CD INV_TP_CD, r.INV_STOP_MSG INV_STOP_MSG, r.DEL_PICK_PACK_INV_TP_CD DEL_PICK_PACK_INV_TP_CD, r.PRN_HO_INV_IND PRN_HO_INV_IND, r.PRN_WHOLESALE_ON_INV_IND PRN_WHOLESALE_ON_INV_IND, r.SEP_INV_PER_CUS_PO_IND SEP_INV_PER_CUS_PO_IND, r.ASN_REQ_IND ASN_REQ_IND, r.EASNMailbox EASNMailbox, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_MTT_ACCOUNT_ORDER_INVOICE r WHERE r.CONTRACT_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllMTTOrderInvoiceByIDHistoryParameters =
    "EObjMTTActOrderInvoice.ContractId," +
    "EObjMTTActOrderInvoice.lastUpdateDt," +
    "EObjMTTActOrderInvoice.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllMTTOrderInvoiceByIDHistoryResults =
    "EObjMTTActOrderInvoice.historyIdPK," +
    "EObjMTTActOrderInvoice.histActionCode," +
    "EObjMTTActOrderInvoice.histCreatedBy," +
    "EObjMTTActOrderInvoice.histCreateDt," +
    "EObjMTTActOrderInvoice.histEndDt," +
    "EObjMTTActOrderInvoice.MTTActOrderInvoiceIdPk," +
    "EObjMTTActOrderInvoice.ContractId," +
    "EObjMTTActOrderInvoice.PrintRetailInd," +
    "EObjMTTActOrderInvoice.PrintPriceMatchSummaryInd," +
    "EObjMTTActOrderInvoice.SubstituteItemInd," +
    "EObjMTTActOrderInvoice.InvoiceSequence," +
    "EObjMTTActOrderInvoice.InvoiceCopiesNumber," +
    "EObjMTTActOrderInvoice.InvoiceMode," +
    "EObjMTTActOrderInvoice.OrderGuide," +
    "EObjMTTActOrderInvoice.SepOrderItemReserveInd," +
    "EObjMTTActOrderInvoice.SpecialInstructions," +
    "EObjMTTActOrderInvoice.PrintCatInvoiceBreak," +
    "EObjMTTActOrderInvoice.InvoiceRecapSummary," +
    "EObjMTTActOrderInvoice.PONumberRequiredInd," +
    "EObjMTTActOrderInvoice.PickupDeliver," +
    "EObjMTTActOrderInvoice.PrintAlternateTobaccoLicenceInd," +
    "EObjMTTActOrderInvoice.TotesInd," +
    "EObjMTTActOrderInvoice.Totes," +
    "EObjMTTActOrderInvoice.UnitCaseCostPrint," +
    "EObjMTTActOrderInvoice.InvoiceFormat," +
    "EObjMTTActOrderInvoice.PickEachesInd," +
    "EObjMTTActOrderInvoice.Invoice," +
    "EObjMTTActOrderInvoice.InvoiceStopMessage," +
    "EObjMTTActOrderInvoice.DelPickPackInvoice," +
    "EObjMTTActOrderInvoice.PrintHOInvoiceInd," +
    "EObjMTTActOrderInvoice.PrintWholesaleOnInvoiceInd," +
    "EObjMTTActOrderInvoice.SepInvoicePerCustomerPOInd," +
    "EObjMTTActOrderInvoice.ASNRequiredInd," +
    "EObjMTTActOrderInvoice.EASNMailbox," +
    "EObjMTTActOrderInvoice.lastUpdateDt," +
    "EObjMTTActOrderInvoice.lastUpdateUser," +
    "EObjMTTActOrderInvoice.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getMTTActOrderInvoiceSql, pattern=tableAliasString)
  @EntityMapping(parameters=getMTTActOrderInvoiceParameters, results=getMTTActOrderInvoiceResults)
  Iterator<ResultQueue1<EObjMTTActOrderInvoice>> getMTTActOrderInvoice(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getMTTActOrderInvoiceHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getMTTActOrderInvoiceHistoryParameters, results=getMTTActOrderInvoiceHistoryResults)
  Iterator<ResultQueue1<EObjMTTActOrderInvoice>> getMTTActOrderInvoiceHistory(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllMTTOrderInvoiceByIDSql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllMTTOrderInvoiceByIDParameters, results=getAllMTTOrderInvoiceByIDResults)
  Iterator<ResultQueue1<EObjMTTActOrderInvoice>> getAllMTTOrderInvoiceByID(Object[] parameters);


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllMTTOrderInvoiceByIDHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllMTTOrderInvoiceByIDHistoryParameters, results=getAllMTTOrderInvoiceByIDHistoryResults)
  Iterator<ResultQueue1<EObjMTTActOrderInvoice>> getAllMTTOrderInvoiceByIDHistory(Object[] parameters);  


}


