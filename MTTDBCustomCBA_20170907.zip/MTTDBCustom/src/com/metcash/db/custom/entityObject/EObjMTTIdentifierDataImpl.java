package com.metcash.db.custom.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.metcash.db.custom.entityObject.EObjMTTIdentifier;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjMTTIdentifierDataImpl  extends BaseData implements EObjMTTIdentifierData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjMTTIdentifierData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000015daaa4ed78L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjMTTIdentifierDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select MTT_IDENTIFIER_ID, IDENTIFIER_ID, IDENTIFIER_SUB_TP_CD, START_DT, END_DT, EXPIRY_DT, DESCRIPTION,  LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from MTT_IDENTIFIER where MTT_IDENTIFIER_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjMTTIdentifier> getEObjMTTIdentifier (Long mTTIdentifierIdPk)
  {
    return queryIterator (getEObjMTTIdentifierStatementDescriptor, mTTIdentifierIdPk);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjMTTIdentifierStatementDescriptor = createStatementDescriptor (
    "getEObjMTTIdentifier(Long)",
    "select MTT_IDENTIFIER_ID, IDENTIFIER_ID, IDENTIFIER_SUB_TP_CD, START_DT, END_DT, EXPIRY_DT, DESCRIPTION,  LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from MTT_IDENTIFIER where MTT_IDENTIFIER_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"mtt_identifier_id", "identifier_id", "identifier_sub_tp_cd", "start_dt", "end_dt", "expiry_dt", "description", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjMTTIdentifierParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjMTTIdentifierRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 0, 0, 0, 250, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjMTTIdentifierParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjMTTIdentifierRowHandler extends BaseRowHandler<EObjMTTIdentifier>
  {
    /**
     * @generated
     */
    public EObjMTTIdentifier handle (java.sql.ResultSet rs, EObjMTTIdentifier returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjMTTIdentifier ();
      returnObject.setMTTIdentifierIdPk(getLongObject (rs, 1)); 
      returnObject.setIdentifierId(getLongObject (rs, 2)); 
      returnObject.setIdentifierSub(getLongObject (rs, 3)); 
      returnObject.setStartDate(getTimestamp (rs, 4)); 
      returnObject.setEndDate(getTimestamp (rs, 5)); 
      returnObject.setExpiryDate(getTimestamp (rs, 6)); 
      returnObject.setDescription(getString (rs, 7)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 8)); 
      returnObject.setLastUpdateUser(getString (rs, 9)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 10)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into MTT_IDENTIFIER (MTT_IDENTIFIER_ID, IDENTIFIER_ID, IDENTIFIER_SUB_TP_CD, START_DT, END_DT, EXPIRY_DT, DESCRIPTION, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :mTTIdentifierIdPk, :identifierId, :identifierSub, :startDate, :endDate, :expiryDate, :description, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjMTTIdentifier (EObjMTTIdentifier e)
  {
    return update (createEObjMTTIdentifierStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjMTTIdentifierStatementDescriptor = createStatementDescriptor (
    "createEObjMTTIdentifier(com.metcash.db.custom.entityObject.EObjMTTIdentifier)",
    "insert into MTT_IDENTIFIER (MTT_IDENTIFIER_ID, IDENTIFIER_ID, IDENTIFIER_SUB_TP_CD, START_DT, END_DT, EXPIRY_DT, DESCRIPTION, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjMTTIdentifierParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 0, 0, 0, 250, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjMTTIdentifierParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjMTTIdentifier bean0 = (EObjMTTIdentifier) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getMTTIdentifierIdPk());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getIdentifierId());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getIdentifierSub());
      setTimestamp (stmt, 4, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 5, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setTimestamp (stmt, 6, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getExpiryDate());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getDescription());
      setTimestamp (stmt, 8, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 10, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update MTT_IDENTIFIER set IDENTIFIER_ID = :identifierId, IDENTIFIER_SUB_TP_CD = :identifierSub, START_DT = :startDate, END_DT = :endDate, EXPIRY_DT = :expiryDate, DESCRIPTION = :description, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where MTT_IDENTIFIER_ID = :mTTIdentifierIdPk and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjMTTIdentifier (EObjMTTIdentifier e)
  {
    return update (updateEObjMTTIdentifierStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjMTTIdentifierStatementDescriptor = createStatementDescriptor (
    "updateEObjMTTIdentifier(com.metcash.db.custom.entityObject.EObjMTTIdentifier)",
    "update MTT_IDENTIFIER set IDENTIFIER_ID =  ? , IDENTIFIER_SUB_TP_CD =  ? , START_DT =  ? , END_DT =  ? , EXPIRY_DT =  ? , DESCRIPTION =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where MTT_IDENTIFIER_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjMTTIdentifierParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 19, 0, 0, 0, 250, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjMTTIdentifierParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjMTTIdentifier bean0 = (EObjMTTIdentifier) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getIdentifierId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getIdentifierSub());
      setTimestamp (stmt, 3, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getStartDate());
      setTimestamp (stmt, 4, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getEndDate());
      setTimestamp (stmt, 5, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getExpiryDate());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getDescription());
      setTimestamp (stmt, 7, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 9, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 10, Types.BIGINT, (Long)bean0.getMTTIdentifierIdPk());
      setTimestamp (stmt, 11, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from MTT_IDENTIFIER where MTT_IDENTIFIER_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjMTTIdentifier (Long mTTIdentifierIdPk)
  {
    return update (deleteEObjMTTIdentifierStatementDescriptor, mTTIdentifierIdPk);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjMTTIdentifierStatementDescriptor = createStatementDescriptor (
    "deleteEObjMTTIdentifier(Long)",
    "delete from MTT_IDENTIFIER where MTT_IDENTIFIER_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjMTTIdentifierParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjMTTIdentifierParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
