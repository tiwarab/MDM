package com.metcash.db.custom.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.ibm.mdm.base.db.ResultQueue1;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.metcash.db.custom.entityObject.EObjMTTActCostCharges;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


@SuppressWarnings("unchecked")

/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class MTTActCostChargesInquiryDataImpl  extends BaseData implements MTTActCostChargesInquiryData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "MTTActCostChargesInquiryData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000015daaa4ee22L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public MTTActCostChargesInquiryDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="SELECT r.MTT_ACT_COST_CHARGES_ID MTT_ACT_COST_CHARGES_ID, r.CONTRACT_ID CONTRACT_ID, r.COST_BASE_TP_CD COST_BASE_TP_CD, r.DIRECT_SHIP_APPROVED_IND DIRECT_SHIP_APPROVED_IND, r.DO_NOT_APPLY_DIRECT_DISC_IND DO_NOT_APPLY_DIRECT_DISC_IND, r.SRP_COMPLIANCE_TP_CD SRP_COMPLIANCE_TP_CD, r.PRICE_MATCH_GAP_FEE_IND PRICE_MATCH_GAP_FEE_IND, r.BRKN_CASE_UPCHARGE_PCT BRKN_CASE_UPCHARGE_PCT, r.BRKN_CASE_UPCHARGE_CAP BRKN_CASE_UPCHARGE_CAP, r.BRKN_CASE_UPCHARGE_IND BRKN_CASE_UPCHARGE_IND, r.BRKN_CASE_CALC_TP_CD BRKN_CASE_CALC_TP_CD, r.SHELF_LABEL_PRICED_IND SHELF_LABEL_PRICED_IND, r.PSRP_TP_CD PSRP_TP_CD, r.ADD_FRT_RECOVERY_SRP_IND ADD_FRT_RECOVERY_SRP_IND, r.SRP_FRT_RECOVERY_VAL SRP_FRT_RECOVERY_VAL, r.SRP_FRT_RECOVERY_DIR_VAL SRP_FRT_RECOVERY_DIR_VAL, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM MTT_ACCOUNT_COST_CHARGES r WHERE r.MTT_ACT_COST_CHARGES_ID = ? ", pattern="tableAlias (MTT_ACCOUNT_COST_CHARGES => com.metcash.db.custom.entityObject.EObjMTTActCostCharges, H_MTT_ACCOUNT_COST_CHARGES => com.metcash.db.custom.entityObject.EObjMTTActCostCharges)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjMTTActCostCharges>> getMTTActCostCharges (Object[] parameters)
  {
    return queryIterator (getMTTActCostChargesStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getMTTActCostChargesStatementDescriptor = createStatementDescriptor (
    "getMTTActCostCharges(Object[])",
    "SELECT r.MTT_ACT_COST_CHARGES_ID MTT_ACT_COST_CHARGES_ID, r.CONTRACT_ID CONTRACT_ID, r.COST_BASE_TP_CD COST_BASE_TP_CD, r.DIRECT_SHIP_APPROVED_IND DIRECT_SHIP_APPROVED_IND, r.DO_NOT_APPLY_DIRECT_DISC_IND DO_NOT_APPLY_DIRECT_DISC_IND, r.SRP_COMPLIANCE_TP_CD SRP_COMPLIANCE_TP_CD, r.PRICE_MATCH_GAP_FEE_IND PRICE_MATCH_GAP_FEE_IND, r.BRKN_CASE_UPCHARGE_PCT BRKN_CASE_UPCHARGE_PCT, r.BRKN_CASE_UPCHARGE_CAP BRKN_CASE_UPCHARGE_CAP, r.BRKN_CASE_UPCHARGE_IND BRKN_CASE_UPCHARGE_IND, r.BRKN_CASE_CALC_TP_CD BRKN_CASE_CALC_TP_CD, r.SHELF_LABEL_PRICED_IND SHELF_LABEL_PRICED_IND, r.PSRP_TP_CD PSRP_TP_CD, r.ADD_FRT_RECOVERY_SRP_IND ADD_FRT_RECOVERY_SRP_IND, r.SRP_FRT_RECOVERY_VAL SRP_FRT_RECOVERY_VAL, r.SRP_FRT_RECOVERY_DIR_VAL SRP_FRT_RECOVERY_DIR_VAL, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM MTT_ACCOUNT_COST_CHARGES r WHERE r.MTT_ACT_COST_CHARGES_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"mtt_act_cost_charges_id", "contract_id", "cost_base_tp_cd", "direct_ship_approved_ind", "do_not_apply_direct_disc_ind", "srp_compliance_tp_cd", "price_match_gap_fee_ind", "brkn_case_upcharge_pct", "brkn_case_upcharge_cap", "brkn_case_upcharge_ind", "brkn_case_calc_tp_cd", "shelf_label_priced_ind", "psrp_tp_cd", "add_frt_recovery_srp_ind", "srp_frt_recovery_val", "srp_frt_recovery_dir_val", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetMTTActCostChargesParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetMTTActCostChargesRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.REAL, Types.REAL, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.REAL, Types.REAL, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 1, 1, 19, 1, 16, 16, 1, 19, 1, 19, 1, 16, 16, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetMTTActCostChargesParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetMTTActCostChargesRowHandler extends BaseRowHandler<ResultQueue1<EObjMTTActCostCharges>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjMTTActCostCharges> handle (java.sql.ResultSet rs, ResultQueue1<EObjMTTActCostCharges> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjMTTActCostCharges> ();

      EObjMTTActCostCharges returnObject1 = new EObjMTTActCostCharges ();
      returnObject1.setMTTActCostChargesIdPk(getLongObject (rs, 1)); 
      returnObject1.setContractId(getLongObject (rs, 2)); 
      returnObject1.setCostBase(getLongObject (rs, 3)); 
      returnObject1.setDirectShipApprovedInd(getString (rs, 4)); 
      returnObject1.setDoNotApplyDirectDiscountInd(getString (rs, 5)); 
      returnObject1.setSRPComplicance(getLongObject (rs, 6)); 
      returnObject1.setPriceMatchGapFeeInd(getString (rs, 7)); 
      returnObject1.setBrokenCaseUpchargePercentage(getFloatObject (rs, 8)); 
      returnObject1.setBrokenCaseUpchargeCap(getFloatObject (rs, 9)); 
      returnObject1.setBrokenCaseUpchargeInd(getString (rs, 10)); 
      returnObject1.setBrokenCaseCal(getLongObject (rs, 11)); 
      returnObject1.setShelfLabelPricedInd(getString (rs, 12)); 
      returnObject1.setPSRP(getLongObject (rs, 13)); 
      returnObject1.setAddFRTRecoverySRPInd(getString (rs, 14)); 
      returnObject1.setSRPFRTRecoveryValue(getFloatObject (rs, 15)); 
      returnObject1.setSRPFRTRecoveryDirectValue(getFloatObject (rs, 16)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 17)); 
      returnObject1.setLastUpdateUser(getString (rs, 18)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 19)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_MTT_ACT_COST_CHARGES_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.MTT_ACT_COST_CHARGES_ID MTT_ACT_COST_CHARGES_ID, r.CONTRACT_ID CONTRACT_ID, r.COST_BASE_TP_CD COST_BASE_TP_CD, r.DIRECT_SHIP_APPROVED_IND DIRECT_SHIP_APPROVED_IND, r.DO_NOT_APPLY_DIRECT_DISC_IND DO_NOT_APPLY_DIRECT_DISC_IND, r.SRP_COMPLIANCE_TP_CD SRP_COMPLIANCE_TP_CD, r.PRICE_MATCH_GAP_FEE_IND PRICE_MATCH_GAP_FEE_IND, r.BRKN_CASE_UPCHARGE_PCT BRKN_CASE_UPCHARGE_PCT, r.BRKN_CASE_UPCHARGE_CAP BRKN_CASE_UPCHARGE_CAP, r.BRKN_CASE_UPCHARGE_IND BRKN_CASE_UPCHARGE_IND, r.BRKN_CASE_CALC_TP_CD BRKN_CASE_CALC_TP_CD, r.SHELF_LABEL_PRICED_IND SHELF_LABEL_PRICED_IND, r.PSRP_TP_CD PSRP_TP_CD, r.ADD_FRT_RECOVERY_SRP_IND ADD_FRT_RECOVERY_SRP_IND, r.SRP_FRT_RECOVERY_VAL SRP_FRT_RECOVERY_VAL, r.SRP_FRT_RECOVERY_DIR_VAL SRP_FRT_RECOVERY_DIR_VAL, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_MTT_ACCOUNT_COST_CHARGES r WHERE r.H_MTT_ACT_COST_CHARGES_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (MTT_ACCOUNT_COST_CHARGES => com.metcash.db.custom.entityObject.EObjMTTActCostCharges, H_MTT_ACCOUNT_COST_CHARGES => com.metcash.db.custom.entityObject.EObjMTTActCostCharges)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjMTTActCostCharges>> getMTTActCostChargesHistory (Object[] parameters)
  {
    return queryIterator (getMTTActCostChargesHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getMTTActCostChargesHistoryStatementDescriptor = createStatementDescriptor (
    "getMTTActCostChargesHistory(Object[])",
    "SELECT r.H_MTT_ACT_COST_CHARGES_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.MTT_ACT_COST_CHARGES_ID MTT_ACT_COST_CHARGES_ID, r.CONTRACT_ID CONTRACT_ID, r.COST_BASE_TP_CD COST_BASE_TP_CD, r.DIRECT_SHIP_APPROVED_IND DIRECT_SHIP_APPROVED_IND, r.DO_NOT_APPLY_DIRECT_DISC_IND DO_NOT_APPLY_DIRECT_DISC_IND, r.SRP_COMPLIANCE_TP_CD SRP_COMPLIANCE_TP_CD, r.PRICE_MATCH_GAP_FEE_IND PRICE_MATCH_GAP_FEE_IND, r.BRKN_CASE_UPCHARGE_PCT BRKN_CASE_UPCHARGE_PCT, r.BRKN_CASE_UPCHARGE_CAP BRKN_CASE_UPCHARGE_CAP, r.BRKN_CASE_UPCHARGE_IND BRKN_CASE_UPCHARGE_IND, r.BRKN_CASE_CALC_TP_CD BRKN_CASE_CALC_TP_CD, r.SHELF_LABEL_PRICED_IND SHELF_LABEL_PRICED_IND, r.PSRP_TP_CD PSRP_TP_CD, r.ADD_FRT_RECOVERY_SRP_IND ADD_FRT_RECOVERY_SRP_IND, r.SRP_FRT_RECOVERY_VAL SRP_FRT_RECOVERY_VAL, r.SRP_FRT_RECOVERY_DIR_VAL SRP_FRT_RECOVERY_DIR_VAL, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_MTT_ACCOUNT_COST_CHARGES r WHERE r.H_MTT_ACT_COST_CHARGES_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "mtt_act_cost_charges_id", "contract_id", "cost_base_tp_cd", "direct_ship_approved_ind", "do_not_apply_direct_disc_ind", "srp_compliance_tp_cd", "price_match_gap_fee_ind", "brkn_case_upcharge_pct", "brkn_case_upcharge_cap", "brkn_case_upcharge_ind", "brkn_case_calc_tp_cd", "shelf_label_priced_ind", "psrp_tp_cd", "add_frt_recovery_srp_ind", "srp_frt_recovery_val", "srp_frt_recovery_dir_val", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetMTTActCostChargesHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetMTTActCostChargesHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.REAL, Types.REAL, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.REAL, Types.REAL, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 19, 19, 1, 1, 19, 1, 16, 16, 1, 19, 1, 19, 1, 16, 16, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class GetMTTActCostChargesHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetMTTActCostChargesHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjMTTActCostCharges>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjMTTActCostCharges> handle (java.sql.ResultSet rs, ResultQueue1<EObjMTTActCostCharges> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjMTTActCostCharges> ();

      EObjMTTActCostCharges returnObject1 = new EObjMTTActCostCharges ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setMTTActCostChargesIdPk(getLongObject (rs, 6)); 
      returnObject1.setContractId(getLongObject (rs, 7)); 
      returnObject1.setCostBase(getLongObject (rs, 8)); 
      returnObject1.setDirectShipApprovedInd(getString (rs, 9)); 
      returnObject1.setDoNotApplyDirectDiscountInd(getString (rs, 10)); 
      returnObject1.setSRPComplicance(getLongObject (rs, 11)); 
      returnObject1.setPriceMatchGapFeeInd(getString (rs, 12)); 
      returnObject1.setBrokenCaseUpchargePercentage(getFloatObject (rs, 13)); 
      returnObject1.setBrokenCaseUpchargeCap(getFloatObject (rs, 14)); 
      returnObject1.setBrokenCaseUpchargeInd(getString (rs, 15)); 
      returnObject1.setBrokenCaseCal(getLongObject (rs, 16)); 
      returnObject1.setShelfLabelPricedInd(getString (rs, 17)); 
      returnObject1.setPSRP(getLongObject (rs, 18)); 
      returnObject1.setAddFRTRecoverySRPInd(getString (rs, 19)); 
      returnObject1.setSRPFRTRecoveryValue(getFloatObject (rs, 20)); 
      returnObject1.setSRPFRTRecoveryDirectValue(getFloatObject (rs, 21)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 22)); 
      returnObject1.setLastUpdateUser(getString (rs, 23)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 24)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.MTT_ACT_COST_CHARGES_ID MTT_ACT_COST_CHARGES_ID, r.CONTRACT_ID CONTRACT_ID, r.COST_BASE_TP_CD COST_BASE_TP_CD, r.DIRECT_SHIP_APPROVED_IND DIRECT_SHIP_APPROVED_IND, r.DO_NOT_APPLY_DIRECT_DISC_IND DO_NOT_APPLY_DIRECT_DISC_IND, r.SRP_COMPLIANCE_TP_CD SRP_COMPLIANCE_TP_CD, r.PRICE_MATCH_GAP_FEE_IND PRICE_MATCH_GAP_FEE_IND, r.BRKN_CASE_UPCHARGE_PCT BRKN_CASE_UPCHARGE_PCT, r.BRKN_CASE_UPCHARGE_CAP BRKN_CASE_UPCHARGE_CAP, r.BRKN_CASE_UPCHARGE_IND BRKN_CASE_UPCHARGE_IND, r.BRKN_CASE_CALC_TP_CD BRKN_CASE_CALC_TP_CD, r.SHELF_LABEL_PRICED_IND SHELF_LABEL_PRICED_IND, r.PSRP_TP_CD PSRP_TP_CD, r.ADD_FRT_RECOVERY_SRP_IND ADD_FRT_RECOVERY_SRP_IND, r.SRP_FRT_RECOVERY_VAL SRP_FRT_RECOVERY_VAL, r.SRP_FRT_RECOVERY_DIR_VAL SRP_FRT_RECOVERY_DIR_VAL, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM MTT_ACCOUNT_COST_CHARGES r WHERE r.CONTRACT_ID = ? ", pattern="tableAlias (MTT_ACCOUNT_COST_CHARGES => com.metcash.db.custom.entityObject.EObjMTTActCostCharges, H_MTT_ACCOUNT_COST_CHARGES => com.metcash.db.custom.entityObject.EObjMTTActCostCharges)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjMTTActCostCharges>> getAllMTTActCostChargesByID (Object[] parameters)
  {
    return queryIterator (getAllMTTActCostChargesByIDStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getAllMTTActCostChargesByIDStatementDescriptor = createStatementDescriptor (
    "getAllMTTActCostChargesByID(Object[])",
    "SELECT r.MTT_ACT_COST_CHARGES_ID MTT_ACT_COST_CHARGES_ID, r.CONTRACT_ID CONTRACT_ID, r.COST_BASE_TP_CD COST_BASE_TP_CD, r.DIRECT_SHIP_APPROVED_IND DIRECT_SHIP_APPROVED_IND, r.DO_NOT_APPLY_DIRECT_DISC_IND DO_NOT_APPLY_DIRECT_DISC_IND, r.SRP_COMPLIANCE_TP_CD SRP_COMPLIANCE_TP_CD, r.PRICE_MATCH_GAP_FEE_IND PRICE_MATCH_GAP_FEE_IND, r.BRKN_CASE_UPCHARGE_PCT BRKN_CASE_UPCHARGE_PCT, r.BRKN_CASE_UPCHARGE_CAP BRKN_CASE_UPCHARGE_CAP, r.BRKN_CASE_UPCHARGE_IND BRKN_CASE_UPCHARGE_IND, r.BRKN_CASE_CALC_TP_CD BRKN_CASE_CALC_TP_CD, r.SHELF_LABEL_PRICED_IND SHELF_LABEL_PRICED_IND, r.PSRP_TP_CD PSRP_TP_CD, r.ADD_FRT_RECOVERY_SRP_IND ADD_FRT_RECOVERY_SRP_IND, r.SRP_FRT_RECOVERY_VAL SRP_FRT_RECOVERY_VAL, r.SRP_FRT_RECOVERY_DIR_VAL SRP_FRT_RECOVERY_DIR_VAL, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM MTT_ACCOUNT_COST_CHARGES r WHERE r.CONTRACT_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"mtt_act_cost_charges_id", "contract_id", "cost_base_tp_cd", "direct_ship_approved_ind", "do_not_apply_direct_disc_ind", "srp_compliance_tp_cd", "price_match_gap_fee_ind", "brkn_case_upcharge_pct", "brkn_case_upcharge_cap", "brkn_case_upcharge_ind", "brkn_case_calc_tp_cd", "shelf_label_priced_ind", "psrp_tp_cd", "add_frt_recovery_srp_ind", "srp_frt_recovery_val", "srp_frt_recovery_dir_val", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetAllMTTActCostChargesByIDParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetAllMTTActCostChargesByIDRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.REAL, Types.REAL, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.REAL, Types.REAL, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 1, 1, 19, 1, 16, 16, 1, 19, 1, 19, 1, 16, 16, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class GetAllMTTActCostChargesByIDParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetAllMTTActCostChargesByIDRowHandler extends BaseRowHandler<ResultQueue1<EObjMTTActCostCharges>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjMTTActCostCharges> handle (java.sql.ResultSet rs, ResultQueue1<EObjMTTActCostCharges> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjMTTActCostCharges> ();

      EObjMTTActCostCharges returnObject1 = new EObjMTTActCostCharges ();
      returnObject1.setMTTActCostChargesIdPk(getLongObject (rs, 1)); 
      returnObject1.setContractId(getLongObject (rs, 2)); 
      returnObject1.setCostBase(getLongObject (rs, 3)); 
      returnObject1.setDirectShipApprovedInd(getString (rs, 4)); 
      returnObject1.setDoNotApplyDirectDiscountInd(getString (rs, 5)); 
      returnObject1.setSRPComplicance(getLongObject (rs, 6)); 
      returnObject1.setPriceMatchGapFeeInd(getString (rs, 7)); 
      returnObject1.setBrokenCaseUpchargePercentage(getFloatObject (rs, 8)); 
      returnObject1.setBrokenCaseUpchargeCap(getFloatObject (rs, 9)); 
      returnObject1.setBrokenCaseUpchargeInd(getString (rs, 10)); 
      returnObject1.setBrokenCaseCal(getLongObject (rs, 11)); 
      returnObject1.setShelfLabelPricedInd(getString (rs, 12)); 
      returnObject1.setPSRP(getLongObject (rs, 13)); 
      returnObject1.setAddFRTRecoverySRPInd(getString (rs, 14)); 
      returnObject1.setSRPFRTRecoveryValue(getFloatObject (rs, 15)); 
      returnObject1.setSRPFRTRecoveryDirectValue(getFloatObject (rs, 16)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 17)); 
      returnObject1.setLastUpdateUser(getString (rs, 18)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 19)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_MTT_ACT_COST_CHARGES_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.MTT_ACT_COST_CHARGES_ID MTT_ACT_COST_CHARGES_ID, r.CONTRACT_ID CONTRACT_ID, r.COST_BASE_TP_CD COST_BASE_TP_CD, r.DIRECT_SHIP_APPROVED_IND DIRECT_SHIP_APPROVED_IND, r.DO_NOT_APPLY_DIRECT_DISC_IND DO_NOT_APPLY_DIRECT_DISC_IND, r.SRP_COMPLIANCE_TP_CD SRP_COMPLIANCE_TP_CD, r.PRICE_MATCH_GAP_FEE_IND PRICE_MATCH_GAP_FEE_IND, r.BRKN_CASE_UPCHARGE_PCT BRKN_CASE_UPCHARGE_PCT, r.BRKN_CASE_UPCHARGE_CAP BRKN_CASE_UPCHARGE_CAP, r.BRKN_CASE_UPCHARGE_IND BRKN_CASE_UPCHARGE_IND, r.BRKN_CASE_CALC_TP_CD BRKN_CASE_CALC_TP_CD, r.SHELF_LABEL_PRICED_IND SHELF_LABEL_PRICED_IND, r.PSRP_TP_CD PSRP_TP_CD, r.ADD_FRT_RECOVERY_SRP_IND ADD_FRT_RECOVERY_SRP_IND, r.SRP_FRT_RECOVERY_VAL SRP_FRT_RECOVERY_VAL, r.SRP_FRT_RECOVERY_DIR_VAL SRP_FRT_RECOVERY_DIR_VAL, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_MTT_ACCOUNT_COST_CHARGES r WHERE r.CONTRACT_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (MTT_ACCOUNT_COST_CHARGES => com.metcash.db.custom.entityObject.EObjMTTActCostCharges, H_MTT_ACCOUNT_COST_CHARGES => com.metcash.db.custom.entityObject.EObjMTTActCostCharges)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjMTTActCostCharges>> getAllMTTActCostChargesByIDHistory (Object[] parameters)
  {
    return queryIterator (getAllMTTActCostChargesByIDHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getAllMTTActCostChargesByIDHistoryStatementDescriptor = createStatementDescriptor (
    "getAllMTTActCostChargesByIDHistory(Object[])",
    "SELECT r.H_MTT_ACT_COST_CHARGES_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.MTT_ACT_COST_CHARGES_ID MTT_ACT_COST_CHARGES_ID, r.CONTRACT_ID CONTRACT_ID, r.COST_BASE_TP_CD COST_BASE_TP_CD, r.DIRECT_SHIP_APPROVED_IND DIRECT_SHIP_APPROVED_IND, r.DO_NOT_APPLY_DIRECT_DISC_IND DO_NOT_APPLY_DIRECT_DISC_IND, r.SRP_COMPLIANCE_TP_CD SRP_COMPLIANCE_TP_CD, r.PRICE_MATCH_GAP_FEE_IND PRICE_MATCH_GAP_FEE_IND, r.BRKN_CASE_UPCHARGE_PCT BRKN_CASE_UPCHARGE_PCT, r.BRKN_CASE_UPCHARGE_CAP BRKN_CASE_UPCHARGE_CAP, r.BRKN_CASE_UPCHARGE_IND BRKN_CASE_UPCHARGE_IND, r.BRKN_CASE_CALC_TP_CD BRKN_CASE_CALC_TP_CD, r.SHELF_LABEL_PRICED_IND SHELF_LABEL_PRICED_IND, r.PSRP_TP_CD PSRP_TP_CD, r.ADD_FRT_RECOVERY_SRP_IND ADD_FRT_RECOVERY_SRP_IND, r.SRP_FRT_RECOVERY_VAL SRP_FRT_RECOVERY_VAL, r.SRP_FRT_RECOVERY_DIR_VAL SRP_FRT_RECOVERY_DIR_VAL, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_MTT_ACCOUNT_COST_CHARGES r WHERE r.CONTRACT_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "mtt_act_cost_charges_id", "contract_id", "cost_base_tp_cd", "direct_ship_approved_ind", "do_not_apply_direct_disc_ind", "srp_compliance_tp_cd", "price_match_gap_fee_ind", "brkn_case_upcharge_pct", "brkn_case_upcharge_cap", "brkn_case_upcharge_ind", "brkn_case_calc_tp_cd", "shelf_label_priced_ind", "psrp_tp_cd", "add_frt_recovery_srp_ind", "srp_frt_recovery_val", "srp_frt_recovery_dir_val", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetAllMTTActCostChargesByIDHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetAllMTTActCostChargesByIDHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.REAL, Types.REAL, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.REAL, Types.REAL, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 19, 19, 1, 1, 19, 1, 16, 16, 1, 19, 1, 19, 1, 16, 16, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class GetAllMTTActCostChargesByIDHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetAllMTTActCostChargesByIDHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjMTTActCostCharges>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjMTTActCostCharges> handle (java.sql.ResultSet rs, ResultQueue1<EObjMTTActCostCharges> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjMTTActCostCharges> ();

      EObjMTTActCostCharges returnObject1 = new EObjMTTActCostCharges ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setMTTActCostChargesIdPk(getLongObject (rs, 6)); 
      returnObject1.setContractId(getLongObject (rs, 7)); 
      returnObject1.setCostBase(getLongObject (rs, 8)); 
      returnObject1.setDirectShipApprovedInd(getString (rs, 9)); 
      returnObject1.setDoNotApplyDirectDiscountInd(getString (rs, 10)); 
      returnObject1.setSRPComplicance(getLongObject (rs, 11)); 
      returnObject1.setPriceMatchGapFeeInd(getString (rs, 12)); 
      returnObject1.setBrokenCaseUpchargePercentage(getFloatObject (rs, 13)); 
      returnObject1.setBrokenCaseUpchargeCap(getFloatObject (rs, 14)); 
      returnObject1.setBrokenCaseUpchargeInd(getString (rs, 15)); 
      returnObject1.setBrokenCaseCal(getLongObject (rs, 16)); 
      returnObject1.setShelfLabelPricedInd(getString (rs, 17)); 
      returnObject1.setPSRP(getLongObject (rs, 18)); 
      returnObject1.setAddFRTRecoverySRPInd(getString (rs, 19)); 
      returnObject1.setSRPFRTRecoveryValue(getFloatObject (rs, 20)); 
      returnObject1.setSRPFRTRecoveryDirectValue(getFloatObject (rs, 21)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 22)); 
      returnObject1.setLastUpdateUser(getString (rs, 23)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 24)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

}
