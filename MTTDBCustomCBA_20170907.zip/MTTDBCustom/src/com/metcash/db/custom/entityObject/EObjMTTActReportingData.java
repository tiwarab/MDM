/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[cf811b3a2aca2d9a3e785650de0d9234]
 */


package com.metcash.db.custom.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.metcash.db.custom.entityObject.EObjMTTActReporting;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjMTTActReportingData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjMTTActReportingSql = "select MTT_ACT_REPORTING_ID, CHANNEL_GRP_TP_CD, GOV_CONTRACT_IND, CAPRICORN_NUM, IGAD_PERISHABLE_IND, AGENT_NUM_TP_CD, USER_LOCALITY_TP_CD, CUS_CLASS_TP_CD, SHOW_PRICES_ON_WEB_IND, CONTRACT_ID, EXPORT_CUS_IND,  LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from MTT_ACCOUNT_REPORTING where MTT_ACT_REPORTING_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjMTTActReportingSql = "insert into MTT_ACCOUNT_REPORTING (MTT_ACT_REPORTING_ID, CHANNEL_GRP_TP_CD, GOV_CONTRACT_IND, CAPRICORN_NUM, IGAD_PERISHABLE_IND, AGENT_NUM_TP_CD, USER_LOCALITY_TP_CD, CUS_CLASS_TP_CD, SHOW_PRICES_ON_WEB_IND, CONTRACT_ID, EXPORT_CUS_IND, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :mTTActReportingIdPk, :channelGroup, :govtContractInd, :capricornNumber, :iGADPerishableInd, :agentNumber, :userLocality, :customerClass, :showPricesOnWebInd, :contractId, :exportCustomerInd, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjMTTActReportingSql = "update MTT_ACCOUNT_REPORTING set CHANNEL_GRP_TP_CD = :channelGroup, GOV_CONTRACT_IND = :govtContractInd, CAPRICORN_NUM = :capricornNumber, IGAD_PERISHABLE_IND = :iGADPerishableInd, AGENT_NUM_TP_CD = :agentNumber, USER_LOCALITY_TP_CD = :userLocality, CUS_CLASS_TP_CD = :customerClass, SHOW_PRICES_ON_WEB_IND = :showPricesOnWebInd, CONTRACT_ID = :contractId, EXPORT_CUS_IND = :exportCustomerInd, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where MTT_ACT_REPORTING_ID = :mTTActReportingIdPk and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjMTTActReportingSql = "delete from MTT_ACCOUNT_REPORTING where MTT_ACT_REPORTING_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjMTTActReportingKeyField = "EObjMTTActReporting.mTTActReportingIdPk";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjMTTActReportingGetFields =
    "EObjMTTActReporting.mTTActReportingIdPk," +
    "EObjMTTActReporting.channelGroup," +
    "EObjMTTActReporting.govtContractInd," +
    "EObjMTTActReporting.capricornNumber," +
    "EObjMTTActReporting.iGADPerishableInd," +
    "EObjMTTActReporting.agentNumber," +
    "EObjMTTActReporting.userLocality," +
    "EObjMTTActReporting.customerClass," +
    "EObjMTTActReporting.showPricesOnWebInd," +
    "EObjMTTActReporting.contractId," +
    "EObjMTTActReporting.exportCustomerInd," +
    "EObjMTTActReporting.lastUpdateDt," +
    "EObjMTTActReporting.lastUpdateUser," +
    "EObjMTTActReporting.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjMTTActReportingAllFields =
    "com.metcash.db.custom.entityObject.EObjMTTActReporting.mTTActReportingIdPk," +
    "com.metcash.db.custom.entityObject.EObjMTTActReporting.channelGroup," +
    "com.metcash.db.custom.entityObject.EObjMTTActReporting.govtContractInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActReporting.capricornNumber," +
    "com.metcash.db.custom.entityObject.EObjMTTActReporting.iGADPerishableInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActReporting.agentNumber," +
    "com.metcash.db.custom.entityObject.EObjMTTActReporting.userLocality," +
    "com.metcash.db.custom.entityObject.EObjMTTActReporting.customerClass," +
    "com.metcash.db.custom.entityObject.EObjMTTActReporting.showPricesOnWebInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActReporting.contractId," +
    "com.metcash.db.custom.entityObject.EObjMTTActReporting.exportCustomerInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActReporting.lastUpdateDt," +
    "com.metcash.db.custom.entityObject.EObjMTTActReporting.lastUpdateUser," +
    "com.metcash.db.custom.entityObject.EObjMTTActReporting.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjMTTActReportingUpdateFields =
    "com.metcash.db.custom.entityObject.EObjMTTActReporting.channelGroup," +
    "com.metcash.db.custom.entityObject.EObjMTTActReporting.govtContractInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActReporting.capricornNumber," +
    "com.metcash.db.custom.entityObject.EObjMTTActReporting.iGADPerishableInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActReporting.agentNumber," +
    "com.metcash.db.custom.entityObject.EObjMTTActReporting.userLocality," +
    "com.metcash.db.custom.entityObject.EObjMTTActReporting.customerClass," +
    "com.metcash.db.custom.entityObject.EObjMTTActReporting.showPricesOnWebInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActReporting.contractId," +
    "com.metcash.db.custom.entityObject.EObjMTTActReporting.exportCustomerInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActReporting.lastUpdateDt," +
    "com.metcash.db.custom.entityObject.EObjMTTActReporting.lastUpdateUser," +
    "com.metcash.db.custom.entityObject.EObjMTTActReporting.lastUpdateTxId," +
    "com.metcash.db.custom.entityObject.EObjMTTActReporting.mTTActReportingIdPk," +
    "com.metcash.db.custom.entityObject.EObjMTTActReporting.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select MTTActReporting by parameters.
   * @generated
   */
  @Select(sql=getEObjMTTActReportingSql)
  @EntityMapping(parameters=EObjMTTActReportingKeyField, results=EObjMTTActReportingGetFields)
  Iterator<EObjMTTActReporting> getEObjMTTActReporting(Long mTTActReportingIdPk);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create MTTActReporting by EObjMTTActReporting Object.
   * @generated
   */
  @Update(sql=createEObjMTTActReportingSql)
  @EntityMapping(parameters=EObjMTTActReportingAllFields)
    int createEObjMTTActReporting(EObjMTTActReporting e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one MTTActReporting by EObjMTTActReporting object.
   * @generated
   */
  @Update(sql=updateEObjMTTActReportingSql)
  @EntityMapping(parameters=EObjMTTActReportingUpdateFields)
    int updateEObjMTTActReporting(EObjMTTActReporting e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete MTTActReporting by parameters.
   * @generated
   */
  @Update(sql=deleteEObjMTTActReportingSql)
  @EntityMapping(parameters=EObjMTTActReportingKeyField)
  int deleteEObjMTTActReporting(Long mTTActReportingIdPk);

}

