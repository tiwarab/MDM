package com.metcash.db.custom.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import com.metcash.db.custom.entityObject.EObjMTTActFinancial;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjMTTActFinancialDataImpl  extends BaseData implements EObjMTTActFinancialData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjMTTActFinancialData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000015e316563a3L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjMTTActFinancialDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select MTT_ACT_FINANCIAL_ID, CONTRACT_ID, STATEMENT_MODE_TP_CD, DUE_GRACE_DAYS_TP_CD, TOBACCO_GRACE_DAYS_TP_CD, BANK_TP_CD, BPAY_IND, STATEMENT_PRN_HOLD_IND, BPAY_CUS_REF_NUM, COLLECTOR_TP_CD, BANK_ACCOUNT_TP_CD, EXT_TERMS_BY_SHIPDATE_IND, SETTLEMENT_DISC_IND, ACCOUNT_DETAILS, DISC_GRACE_DAYS_TP_CD, PAYMENT_METHOD_TP_CD, LMAA_NUM,  LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from MTT_ACCOUNT_FINANCIAL where MTT_ACT_FINANCIAL_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjMTTActFinancial> getEObjMTTActFinancial (Long mTTActFinancialIdPk)
  {
    return queryIterator (getEObjMTTActFinancialStatementDescriptor, mTTActFinancialIdPk);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjMTTActFinancialStatementDescriptor = createStatementDescriptor (
    "getEObjMTTActFinancial(Long)",
    "select MTT_ACT_FINANCIAL_ID, CONTRACT_ID, STATEMENT_MODE_TP_CD, DUE_GRACE_DAYS_TP_CD, TOBACCO_GRACE_DAYS_TP_CD, BANK_TP_CD, BPAY_IND, STATEMENT_PRN_HOLD_IND, BPAY_CUS_REF_NUM, COLLECTOR_TP_CD, BANK_ACCOUNT_TP_CD, EXT_TERMS_BY_SHIPDATE_IND, SETTLEMENT_DISC_IND, ACCOUNT_DETAILS, DISC_GRACE_DAYS_TP_CD, PAYMENT_METHOD_TP_CD, LMAA_NUM,  LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from MTT_ACCOUNT_FINANCIAL where MTT_ACT_FINANCIAL_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"mtt_act_financial_id", "contract_id", "statement_mode_tp_cd", "due_grace_days_tp_cd", "tobacco_grace_days_tp_cd", "bank_tp_cd", "bpay_ind", "statement_prn_hold_ind", "bpay_cus_ref_num", "collector_tp_cd", "bank_account_tp_cd", "ext_terms_by_shipdate_ind", "settlement_disc_ind", "account_details", "disc_grace_days_tp_cd", "payment_method_tp_cd", "lmaa_num", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjMTTActFinancialParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjMTTActFinancialRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 19, 19, 1, 1, 50, 19, 19, 1, 1, 250, 19, 19, 100, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjMTTActFinancialParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjMTTActFinancialRowHandler extends BaseRowHandler<EObjMTTActFinancial>
  {
    /**
     * @generated
     */
    public EObjMTTActFinancial handle (java.sql.ResultSet rs, EObjMTTActFinancial returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjMTTActFinancial ();
      returnObject.setMTTActFinancialIdPk(getLongObject (rs, 1)); 
      returnObject.setContractId(getLongObject (rs, 2)); 
      returnObject.setStatementMode(getLongObject (rs, 3)); 
      returnObject.setDueGraceDays(getLongObject (rs, 4)); 
      returnObject.setTobaccoGraceDays(getLongObject (rs, 5)); 
      returnObject.setBank(getLongObject (rs, 6)); 
      returnObject.setBPAYInd(getString (rs, 7)); 
      returnObject.setStatementPrintHoldInd(getString (rs, 8)); 
      returnObject.setBPAYCustomerRefNumber(getString (rs, 9)); 
      returnObject.setCollector(getLongObject (rs, 10)); 
      returnObject.setBankAccount(getLongObject (rs, 11)); 
      returnObject.setExtTermsByShipDateInd(getString (rs, 12)); 
      returnObject.setSettlementDiscountInd(getString (rs, 13)); 
      returnObject.setAccountDetails(getString (rs, 14)); 
      returnObject.setDiscountGraceDays(getLongObject (rs, 15)); 
      returnObject.setPaymentMethod(getLongObject (rs, 16)); 
      returnObject.setLMAANumber(getString (rs, 17)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 18)); 
      returnObject.setLastUpdateUser(getString (rs, 19)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 20)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into MTT_ACCOUNT_FINANCIAL (MTT_ACT_FINANCIAL_ID, CONTRACT_ID, STATEMENT_MODE_TP_CD, DUE_GRACE_DAYS_TP_CD, TOBACCO_GRACE_DAYS_TP_CD, BANK_TP_CD, BPAY_IND, STATEMENT_PRN_HOLD_IND, BPAY_CUS_REF_NUM, COLLECTOR_TP_CD, BANK_ACCOUNT_TP_CD, EXT_TERMS_BY_SHIPDATE_IND, SETTLEMENT_DISC_IND, ACCOUNT_DETAILS, DISC_GRACE_DAYS_TP_CD, PAYMENT_METHOD_TP_CD, LMAA_NUM, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :mTTActFinancialIdPk, :contractId, :statementMode, :dueGraceDays, :tobaccoGraceDays, :bank, :bPAYInd, :statementPrintHoldInd, :bPAYCustomerRefNumber, :collector, :bankAccount, :extTermsByShipDateInd, :settlementDiscountInd, :accountDetails, :discountGraceDays, :paymentMethod, :lMAANumber, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjMTTActFinancial (EObjMTTActFinancial e)
  {
    return update (createEObjMTTActFinancialStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjMTTActFinancialStatementDescriptor = createStatementDescriptor (
    "createEObjMTTActFinancial(com.metcash.db.custom.entityObject.EObjMTTActFinancial)",
    "insert into MTT_ACCOUNT_FINANCIAL (MTT_ACT_FINANCIAL_ID, CONTRACT_ID, STATEMENT_MODE_TP_CD, DUE_GRACE_DAYS_TP_CD, TOBACCO_GRACE_DAYS_TP_CD, BANK_TP_CD, BPAY_IND, STATEMENT_PRN_HOLD_IND, BPAY_CUS_REF_NUM, COLLECTOR_TP_CD, BANK_ACCOUNT_TP_CD, EXT_TERMS_BY_SHIPDATE_IND, SETTLEMENT_DISC_IND, ACCOUNT_DETAILS, DISC_GRACE_DAYS_TP_CD, PAYMENT_METHOD_TP_CD, LMAA_NUM, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjMTTActFinancialParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 19, 19, 1, 1, 50, 19, 19, 1, 1, 250, 19, 19, 100, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjMTTActFinancialParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjMTTActFinancial bean0 = (EObjMTTActFinancial) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getMTTActFinancialIdPk());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getContractId());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getStatementMode());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getDueGraceDays());
      setLong (stmt, 5, Types.BIGINT, (Long)bean0.getTobaccoGraceDays());
      setLong (stmt, 6, Types.BIGINT, (Long)bean0.getBank());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getBPAYInd());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getStatementPrintHoldInd());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getBPAYCustomerRefNumber());
      setLong (stmt, 10, Types.BIGINT, (Long)bean0.getCollector());
      setLong (stmt, 11, Types.BIGINT, (Long)bean0.getBankAccount());
      setString (stmt, 12, Types.VARCHAR, (String)bean0.getExtTermsByShipDateInd());
      setString (stmt, 13, Types.VARCHAR, (String)bean0.getSettlementDiscountInd());
      setString (stmt, 14, Types.VARCHAR, (String)bean0.getAccountDetails());
      setLong (stmt, 15, Types.BIGINT, (Long)bean0.getDiscountGraceDays());
      setLong (stmt, 16, Types.BIGINT, (Long)bean0.getPaymentMethod());
      setString (stmt, 17, Types.VARCHAR, (String)bean0.getLMAANumber());
      setTimestamp (stmt, 18, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 19, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 20, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update MTT_ACCOUNT_FINANCIAL set CONTRACT_ID = :contractId, STATEMENT_MODE_TP_CD = :statementMode, DUE_GRACE_DAYS_TP_CD = :dueGraceDays, TOBACCO_GRACE_DAYS_TP_CD = :tobaccoGraceDays, BANK_TP_CD = :bank, BPAY_IND = :bPAYInd, STATEMENT_PRN_HOLD_IND = :statementPrintHoldInd, BPAY_CUS_REF_NUM = :bPAYCustomerRefNumber, COLLECTOR_TP_CD = :collector, BANK_ACCOUNT_TP_CD = :bankAccount, EXT_TERMS_BY_SHIPDATE_IND = :extTermsByShipDateInd, SETTLEMENT_DISC_IND = :settlementDiscountInd, ACCOUNT_DETAILS = :accountDetails, DISC_GRACE_DAYS_TP_CD = :discountGraceDays, PAYMENT_METHOD_TP_CD = :paymentMethod, LMAA_NUM = :lMAANumber, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where MTT_ACT_FINANCIAL_ID = :mTTActFinancialIdPk and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjMTTActFinancial (EObjMTTActFinancial e)
  {
    return update (updateEObjMTTActFinancialStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjMTTActFinancialStatementDescriptor = createStatementDescriptor (
    "updateEObjMTTActFinancial(com.metcash.db.custom.entityObject.EObjMTTActFinancial)",
    "update MTT_ACCOUNT_FINANCIAL set CONTRACT_ID =  ? , STATEMENT_MODE_TP_CD =  ? , DUE_GRACE_DAYS_TP_CD =  ? , TOBACCO_GRACE_DAYS_TP_CD =  ? , BANK_TP_CD =  ? , BPAY_IND =  ? , STATEMENT_PRN_HOLD_IND =  ? , BPAY_CUS_REF_NUM =  ? , COLLECTOR_TP_CD =  ? , BANK_ACCOUNT_TP_CD =  ? , EXT_TERMS_BY_SHIPDATE_IND =  ? , SETTLEMENT_DISC_IND =  ? , ACCOUNT_DETAILS =  ? , DISC_GRACE_DAYS_TP_CD =  ? , PAYMENT_METHOD_TP_CD =  ? , LMAA_NUM =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where MTT_ACT_FINANCIAL_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjMTTActFinancialParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 19, 19, 19, 19, 1, 1, 50, 19, 19, 1, 1, 250, 19, 19, 100, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjMTTActFinancialParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjMTTActFinancial bean0 = (EObjMTTActFinancial) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getContractId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getStatementMode());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getDueGraceDays());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getTobaccoGraceDays());
      setLong (stmt, 5, Types.BIGINT, (Long)bean0.getBank());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getBPAYInd());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getStatementPrintHoldInd());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getBPAYCustomerRefNumber());
      setLong (stmt, 9, Types.BIGINT, (Long)bean0.getCollector());
      setLong (stmt, 10, Types.BIGINT, (Long)bean0.getBankAccount());
      setString (stmt, 11, Types.VARCHAR, (String)bean0.getExtTermsByShipDateInd());
      setString (stmt, 12, Types.VARCHAR, (String)bean0.getSettlementDiscountInd());
      setString (stmt, 13, Types.VARCHAR, (String)bean0.getAccountDetails());
      setLong (stmt, 14, Types.BIGINT, (Long)bean0.getDiscountGraceDays());
      setLong (stmt, 15, Types.BIGINT, (Long)bean0.getPaymentMethod());
      setString (stmt, 16, Types.VARCHAR, (String)bean0.getLMAANumber());
      setTimestamp (stmt, 17, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 18, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 19, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 20, Types.BIGINT, (Long)bean0.getMTTActFinancialIdPk());
      setTimestamp (stmt, 21, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from MTT_ACCOUNT_FINANCIAL where MTT_ACT_FINANCIAL_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjMTTActFinancial (Long mTTActFinancialIdPk)
  {
    return update (deleteEObjMTTActFinancialStatementDescriptor, mTTActFinancialIdPk);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjMTTActFinancialStatementDescriptor = createStatementDescriptor (
    "deleteEObjMTTActFinancial(Long)",
    "delete from MTT_ACCOUNT_FINANCIAL where MTT_ACT_FINANCIAL_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjMTTActFinancialParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjMTTActFinancialParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
