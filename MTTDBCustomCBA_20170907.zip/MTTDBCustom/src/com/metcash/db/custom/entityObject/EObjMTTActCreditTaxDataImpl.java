package com.metcash.db.custom.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.metcash.db.custom.entityObject.EObjMTTActCreditTax;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjMTTActCreditTaxDataImpl  extends BaseData implements EObjMTTActCreditTaxData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjMTTActCreditTaxData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000015daaa4ebc8L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjMTTActCreditTaxDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select MTT_ACT_CREDIT_TAX_ID, CONTRACT_ID, INV_TERMS_TP_CD, GST_EXEMPT_IND, CUS_GRP_TP_CD, BANK_GUARANTEE_AMT, BANK_GUARANTEE_END_DT, CASH_DEPOSIT_AMT, CASH_DEPOSIT_RECV_DT, CASH_DEPOSIT_REL_DT, FIRST_MORTGAGE, SECOND_MORTGAGE, DEED_OF_PRIORITY, PPSR_DETAILS, PMSI_DETAILS, ALLPAP_DETAILS, ARREARS, CREDIT_HOLD, NATIONAL_HOLD, CREDIT_HOLD_DT, CREDIT_STATUS_OVERRIDE, CHEQUE_LIMIT_AMT, CHEQUE_LIMIT_CURRENCY_TP_CD, WET_EXEMPT_IND, DUTY_FREE_IND, CASH_ON_DELIVERY_IND, SALES_REP_TP_CD,  LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from MTT_ACCOUNT_CREDIT_TAX where MTT_ACT_CREDIT_TAX_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjMTTActCreditTax> getEObjMTTActCreditTax (Long mTTActCreditTaxIdPk)
  {
    return queryIterator (getEObjMTTActCreditTaxStatementDescriptor, mTTActCreditTaxIdPk);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjMTTActCreditTaxStatementDescriptor = createStatementDescriptor (
    "getEObjMTTActCreditTax(Long)",
    "select MTT_ACT_CREDIT_TAX_ID, CONTRACT_ID, INV_TERMS_TP_CD, GST_EXEMPT_IND, CUS_GRP_TP_CD, BANK_GUARANTEE_AMT, BANK_GUARANTEE_END_DT, CASH_DEPOSIT_AMT, CASH_DEPOSIT_RECV_DT, CASH_DEPOSIT_REL_DT, FIRST_MORTGAGE, SECOND_MORTGAGE, DEED_OF_PRIORITY, PPSR_DETAILS, PMSI_DETAILS, ALLPAP_DETAILS, ARREARS, CREDIT_HOLD, NATIONAL_HOLD, CREDIT_HOLD_DT, CREDIT_STATUS_OVERRIDE, CHEQUE_LIMIT_AMT, CHEQUE_LIMIT_CURRENCY_TP_CD, WET_EXEMPT_IND, DUTY_FREE_IND, CASH_ON_DELIVERY_IND, SALES_REP_TP_CD,  LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from MTT_ACCOUNT_CREDIT_TAX where MTT_ACT_CREDIT_TAX_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"mtt_act_credit_tax_id", "contract_id", "inv_terms_tp_cd", "gst_exempt_ind", "cus_grp_tp_cd", "bank_guarantee_amt", "bank_guarantee_end_dt", "cash_deposit_amt", "cash_deposit_recv_dt", "cash_deposit_rel_dt", "first_mortgage", "second_mortgage", "deed_of_priority", "ppsr_details", "pmsi_details", "allpap_details", "arrears", "credit_hold", "national_hold", "credit_hold_dt", "credit_status_override", "cheque_limit_amt", "cheque_limit_currency_tp_cd", "wet_exempt_ind", "duty_free_ind", "cash_on_delivery_ind", "sales_rep_tp_cd", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjMTTActCreditTaxParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjMTTActCreditTaxRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.REAL, Types.TIMESTAMP, Types.REAL, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.REAL, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 1, 19, 16, 0, 16, 0, 0, 250, 250, 250, 250, 250, 250, 50, 50, 50, 250, 50, 16, 19, 1, 1, 1, 19, 0, 20, 19}, {0, 0, 0, 0, 0, 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjMTTActCreditTaxParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjMTTActCreditTaxRowHandler extends BaseRowHandler<EObjMTTActCreditTax>
  {
    /**
     * @generated
     */
    public EObjMTTActCreditTax handle (java.sql.ResultSet rs, EObjMTTActCreditTax returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjMTTActCreditTax ();
      returnObject.setMTTActCreditTaxIdPk(getLongObject (rs, 1)); 
      returnObject.setContractId(getLongObject (rs, 2)); 
      returnObject.setInvoiceTerms(getLongObject (rs, 3)); 
      returnObject.setGSTExemptInd(getString (rs, 4)); 
      returnObject.setCustomerGroup(getLongObject (rs, 5)); 
      returnObject.setBankGuaranteeAmount(getFloatObject (rs, 6)); 
      returnObject.setBankGuaranteeEndDate(getTimestamp (rs, 7)); 
      returnObject.setCashDepositAmount(getFloatObject (rs, 8)); 
      returnObject.setCashDepositRecieveDate(getTimestamp (rs, 9)); 
      returnObject.setCashDepositReleaseDate(getTimestamp (rs, 10)); 
      returnObject.setFirstMortgage(getString (rs, 11)); 
      returnObject.setSecondMortgage(getString (rs, 12)); 
      returnObject.setDeedOfPriority(getString (rs, 13)); 
      returnObject.setPPSRDetails(getString (rs, 14)); 
      returnObject.setPMSIDetails(getString (rs, 15)); 
      returnObject.setALLPAPDetails(getString (rs, 16)); 
      returnObject.setArrears(getString (rs, 17)); 
      returnObject.setCreditHold(getString (rs, 18)); 
      returnObject.setNationalHold(getString (rs, 19)); 
      returnObject.setCreditHoldDate(getString (rs, 20)); 
      returnObject.setCreditStatusOverride(getString (rs, 21)); 
      returnObject.setChequeLimitAmount(getFloatObject (rs, 22)); 
      returnObject.setChequeLimitCurrency(getLongObject (rs, 23)); 
      returnObject.setWETExemptInd(getString (rs, 24)); 
      returnObject.setDutyFreeInd(getString (rs, 25)); 
      returnObject.setCashOnDeliveryInd(getString (rs, 26)); 
      returnObject.setSalesRep(getLongObject (rs, 27)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 28)); 
      returnObject.setLastUpdateUser(getString (rs, 29)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 30)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into MTT_ACCOUNT_CREDIT_TAX (MTT_ACT_CREDIT_TAX_ID, CONTRACT_ID, INV_TERMS_TP_CD, GST_EXEMPT_IND, CUS_GRP_TP_CD, BANK_GUARANTEE_AMT, BANK_GUARANTEE_END_DT, CASH_DEPOSIT_AMT, CASH_DEPOSIT_RECV_DT, CASH_DEPOSIT_REL_DT, FIRST_MORTGAGE, SECOND_MORTGAGE, DEED_OF_PRIORITY, PPSR_DETAILS, PMSI_DETAILS, ALLPAP_DETAILS, ARREARS, CREDIT_HOLD, NATIONAL_HOLD, CREDIT_HOLD_DT, CREDIT_STATUS_OVERRIDE, CHEQUE_LIMIT_AMT, CHEQUE_LIMIT_CURRENCY_TP_CD, WET_EXEMPT_IND, DUTY_FREE_IND, CASH_ON_DELIVERY_IND, SALES_REP_TP_CD, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :mTTActCreditTaxIdPk, :contractId, :invoiceTerms, :gSTExemptInd, :customerGroup, :bankGuaranteeAmount, :bankGuaranteeEndDate, :cashDepositAmount, :cashDepositRecieveDate, :cashDepositReleaseDate, :firstMortgage, :secondMortgage, :deedOfPriority, :pPSRDetails, :pMSIDetails, :aLLPAPDetails, :arrears, :creditHold, :nationalHold, :creditHoldDate, :creditStatusOverride, :chequeLimitAmount, :chequeLimitCurrency, :wETExemptInd, :dutyFreeInd, :cashOnDeliveryInd, :salesRep, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjMTTActCreditTax (EObjMTTActCreditTax e)
  {
    return update (createEObjMTTActCreditTaxStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjMTTActCreditTaxStatementDescriptor = createStatementDescriptor (
    "createEObjMTTActCreditTax(com.metcash.db.custom.entityObject.EObjMTTActCreditTax)",
    "insert into MTT_ACCOUNT_CREDIT_TAX (MTT_ACT_CREDIT_TAX_ID, CONTRACT_ID, INV_TERMS_TP_CD, GST_EXEMPT_IND, CUS_GRP_TP_CD, BANK_GUARANTEE_AMT, BANK_GUARANTEE_END_DT, CASH_DEPOSIT_AMT, CASH_DEPOSIT_RECV_DT, CASH_DEPOSIT_REL_DT, FIRST_MORTGAGE, SECOND_MORTGAGE, DEED_OF_PRIORITY, PPSR_DETAILS, PMSI_DETAILS, ALLPAP_DETAILS, ARREARS, CREDIT_HOLD, NATIONAL_HOLD, CREDIT_HOLD_DT, CREDIT_STATUS_OVERRIDE, CHEQUE_LIMIT_AMT, CHEQUE_LIMIT_CURRENCY_TP_CD, WET_EXEMPT_IND, DUTY_FREE_IND, CASH_ON_DELIVERY_IND, SALES_REP_TP_CD, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjMTTActCreditTaxParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.REAL, Types.TIMESTAMP, Types.REAL, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.REAL, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 1, 19, 16, 0, 16, 0, 0, 250, 250, 250, 250, 250, 250, 50, 50, 50, 250, 50, 16, 19, 1, 1, 1, 19, 0, 0, 19}, {0, 0, 0, 0, 0, 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjMTTActCreditTaxParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjMTTActCreditTax bean0 = (EObjMTTActCreditTax) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getMTTActCreditTaxIdPk());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getContractId());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getInvoiceTerms());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getGSTExemptInd());
      setLong (stmt, 5, Types.BIGINT, (Long)bean0.getCustomerGroup());
      setFloat (stmt, 6, Types.REAL, (Float)bean0.getBankGuaranteeAmount());
      setTimestamp (stmt, 7, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getBankGuaranteeEndDate());
      setFloat (stmt, 8, Types.REAL, (Float)bean0.getCashDepositAmount());
      setTimestamp (stmt, 9, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getCashDepositRecieveDate());
      setTimestamp (stmt, 10, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getCashDepositReleaseDate());
      setString (stmt, 11, Types.VARCHAR, (String)bean0.getFirstMortgage());
      setString (stmt, 12, Types.VARCHAR, (String)bean0.getSecondMortgage());
      setString (stmt, 13, Types.VARCHAR, (String)bean0.getDeedOfPriority());
      setString (stmt, 14, Types.VARCHAR, (String)bean0.getPPSRDetails());
      setString (stmt, 15, Types.VARCHAR, (String)bean0.getPMSIDetails());
      setString (stmt, 16, Types.VARCHAR, (String)bean0.getALLPAPDetails());
      setString (stmt, 17, Types.VARCHAR, (String)bean0.getArrears());
      setString (stmt, 18, Types.VARCHAR, (String)bean0.getCreditHold());
      setString (stmt, 19, Types.VARCHAR, (String)bean0.getNationalHold());
      setString (stmt, 20, Types.VARCHAR, (String)bean0.getCreditHoldDate());
      setString (stmt, 21, Types.VARCHAR, (String)bean0.getCreditStatusOverride());
      setFloat (stmt, 22, Types.REAL, (Float)bean0.getChequeLimitAmount());
      setLong (stmt, 23, Types.BIGINT, (Long)bean0.getChequeLimitCurrency());
      setString (stmt, 24, Types.VARCHAR, (String)bean0.getWETExemptInd());
      setString (stmt, 25, Types.VARCHAR, (String)bean0.getDutyFreeInd());
      setString (stmt, 26, Types.VARCHAR, (String)bean0.getCashOnDeliveryInd());
      setLong (stmt, 27, Types.BIGINT, (Long)bean0.getSalesRep());
      setTimestamp (stmt, 28, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 29, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 30, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update MTT_ACCOUNT_CREDIT_TAX set CONTRACT_ID = :contractId, INV_TERMS_TP_CD = :invoiceTerms, GST_EXEMPT_IND = :gSTExemptInd, CUS_GRP_TP_CD = :customerGroup, BANK_GUARANTEE_AMT = :bankGuaranteeAmount, BANK_GUARANTEE_END_DT = :bankGuaranteeEndDate, CASH_DEPOSIT_AMT = :cashDepositAmount, CASH_DEPOSIT_RECV_DT = :cashDepositRecieveDate, CASH_DEPOSIT_REL_DT = :cashDepositReleaseDate, FIRST_MORTGAGE = :firstMortgage, SECOND_MORTGAGE = :secondMortgage, DEED_OF_PRIORITY = :deedOfPriority, PPSR_DETAILS = :pPSRDetails, PMSI_DETAILS = :pMSIDetails, ALLPAP_DETAILS = :aLLPAPDetails, ARREARS = :arrears, CREDIT_HOLD = :creditHold, NATIONAL_HOLD = :nationalHold, CREDIT_HOLD_DT = :creditHoldDate, CREDIT_STATUS_OVERRIDE = :creditStatusOverride, CHEQUE_LIMIT_AMT = :chequeLimitAmount, CHEQUE_LIMIT_CURRENCY_TP_CD = :chequeLimitCurrency, WET_EXEMPT_IND = :wETExemptInd, DUTY_FREE_IND = :dutyFreeInd, CASH_ON_DELIVERY_IND = :cashOnDeliveryInd, SALES_REP_TP_CD = :salesRep, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where MTT_ACT_CREDIT_TAX_ID = :mTTActCreditTaxIdPk and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjMTTActCreditTax (EObjMTTActCreditTax e)
  {
    return update (updateEObjMTTActCreditTaxStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjMTTActCreditTaxStatementDescriptor = createStatementDescriptor (
    "updateEObjMTTActCreditTax(com.metcash.db.custom.entityObject.EObjMTTActCreditTax)",
    "update MTT_ACCOUNT_CREDIT_TAX set CONTRACT_ID =  ? , INV_TERMS_TP_CD =  ? , GST_EXEMPT_IND =  ? , CUS_GRP_TP_CD =  ? , BANK_GUARANTEE_AMT =  ? , BANK_GUARANTEE_END_DT =  ? , CASH_DEPOSIT_AMT =  ? , CASH_DEPOSIT_RECV_DT =  ? , CASH_DEPOSIT_REL_DT =  ? , FIRST_MORTGAGE =  ? , SECOND_MORTGAGE =  ? , DEED_OF_PRIORITY =  ? , PPSR_DETAILS =  ? , PMSI_DETAILS =  ? , ALLPAP_DETAILS =  ? , ARREARS =  ? , CREDIT_HOLD =  ? , NATIONAL_HOLD =  ? , CREDIT_HOLD_DT =  ? , CREDIT_STATUS_OVERRIDE =  ? , CHEQUE_LIMIT_AMT =  ? , CHEQUE_LIMIT_CURRENCY_TP_CD =  ? , WET_EXEMPT_IND =  ? , DUTY_FREE_IND =  ? , CASH_ON_DELIVERY_IND =  ? , SALES_REP_TP_CD =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where MTT_ACT_CREDIT_TAX_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjMTTActCreditTaxParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.REAL, Types.TIMESTAMP, Types.REAL, Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.REAL, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 19, 1, 19, 16, 0, 16, 0, 0, 250, 250, 250, 250, 250, 250, 50, 50, 50, 250, 50, 16, 19, 1, 1, 1, 19, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjMTTActCreditTaxParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjMTTActCreditTax bean0 = (EObjMTTActCreditTax) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getContractId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getInvoiceTerms());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getGSTExemptInd());
      setLong (stmt, 4, Types.BIGINT, (Long)bean0.getCustomerGroup());
      setFloat (stmt, 5, Types.REAL, (Float)bean0.getBankGuaranteeAmount());
      setTimestamp (stmt, 6, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getBankGuaranteeEndDate());
      setFloat (stmt, 7, Types.REAL, (Float)bean0.getCashDepositAmount());
      setTimestamp (stmt, 8, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getCashDepositRecieveDate());
      setTimestamp (stmt, 9, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getCashDepositReleaseDate());
      setString (stmt, 10, Types.VARCHAR, (String)bean0.getFirstMortgage());
      setString (stmt, 11, Types.VARCHAR, (String)bean0.getSecondMortgage());
      setString (stmt, 12, Types.VARCHAR, (String)bean0.getDeedOfPriority());
      setString (stmt, 13, Types.VARCHAR, (String)bean0.getPPSRDetails());
      setString (stmt, 14, Types.VARCHAR, (String)bean0.getPMSIDetails());
      setString (stmt, 15, Types.VARCHAR, (String)bean0.getALLPAPDetails());
      setString (stmt, 16, Types.VARCHAR, (String)bean0.getArrears());
      setString (stmt, 17, Types.VARCHAR, (String)bean0.getCreditHold());
      setString (stmt, 18, Types.VARCHAR, (String)bean0.getNationalHold());
      setString (stmt, 19, Types.VARCHAR, (String)bean0.getCreditHoldDate());
      setString (stmt, 20, Types.VARCHAR, (String)bean0.getCreditStatusOverride());
      setFloat (stmt, 21, Types.REAL, (Float)bean0.getChequeLimitAmount());
      setLong (stmt, 22, Types.BIGINT, (Long)bean0.getChequeLimitCurrency());
      setString (stmt, 23, Types.VARCHAR, (String)bean0.getWETExemptInd());
      setString (stmt, 24, Types.VARCHAR, (String)bean0.getDutyFreeInd());
      setString (stmt, 25, Types.VARCHAR, (String)bean0.getCashOnDeliveryInd());
      setLong (stmt, 26, Types.BIGINT, (Long)bean0.getSalesRep());
      setTimestamp (stmt, 27, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 28, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 29, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 30, Types.BIGINT, (Long)bean0.getMTTActCreditTaxIdPk());
      setTimestamp (stmt, 31, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from MTT_ACCOUNT_CREDIT_TAX where MTT_ACT_CREDIT_TAX_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjMTTActCreditTax (Long mTTActCreditTaxIdPk)
  {
    return update (deleteEObjMTTActCreditTaxStatementDescriptor, mTTActCreditTaxIdPk);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjMTTActCreditTaxStatementDescriptor = createStatementDescriptor (
    "deleteEObjMTTActCreditTax(Long)",
    "delete from MTT_ACCOUNT_CREDIT_TAX where MTT_ACT_CREDIT_TAX_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjMTTActCreditTaxParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjMTTActCreditTaxParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
