/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[0e6f4fe7845922ff588d48b1d3935d8b]
 */

package com.metcash.services.custom.compositeTxn;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;

import com.dwl.base.DWLCommon;
import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLStatus;
import com.dwl.base.requestHandler.DWLTransactionPersistent;
import com.dwl.base.requestHandler.DWLTxnBP;
import com.dwl.tcrm.common.TCRMResponse;
import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.dwl.unifi.tx.exception.BusinessProxyException;


import com.dwl.base.DWLControl;
import com.dwl.base.DWLResponse;
import com.dwl.tcrm.coreParty.component.TCRMOrganizationBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyIdentificationBObj;
import com.metcash.db.custom.component.MTTIdentifierBObj;
import com.metcash.services.custom.component.MetcashIdentifierBObj;
import com.metcash.services.custom.component.MetcashLegalEntityBObj;
import com.metcash.services.custom.constant.MTTServicesComponentID;
import com.metcash.services.custom.constant.MTTServicesErrorReasonCode;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * 
 * @generated
 */
public class MaintainMTTLegalEntityCompositeTxnBP  extends DWLTxnBP {

	/**
	 * @generated
	 **/
	private IDWLErrorMessage errHandler;
	
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(MaintainMTTLegalEntityCompositeTxnBP.class);
	/**
	 * @generated
	 **/
    public MaintainMTTLegalEntityCompositeTxnBP() {
        super();
        errHandler = TCRMClassFactory.getErrorHandler();
    }
	/**
	 * @generated NOT
	 **/
    public Object execute(Object inputObj) throws BusinessProxyException {
    logger.finest("ENTER Object execute(Object inputObj)");

        TCRMResponse outputTxnObj = null;
        DWLTransactionPersistent inputTxnObj = (DWLTransactionPersistent) inputObj;
        DWLControl control = inputTxnObj.getTxnControl();
        DWLCommon topLevelObject = (DWLCommon) inputTxnObj.getTxnTopLevelObject();
        if (!(topLevelObject instanceof MetcashLegalEntityBObj)) {
            // MDM_TODO0: CDKWB0014I optionally use a more appropriate error code than
            // "MAINTAINMTTLEGALENTITY_FAILED".
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTLEGAL_ENTITY_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTLEGALENTITY_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        
        MetcashLegalEntityBObj mainInput = (MetcashLegalEntityBObj) topLevelObject;        
        
        // Handle transaction "addOrganization"

        // MDM_TODO: CDKWB0016I Populate the mandatory fields of "addOrganizationInput".
        TCRMOrganizationBObj addOrganizationInput = new TCRMOrganizationBObj();
        addOrganizationInput.setControl(control);
        
        addOrganizationInput = (TCRMOrganizationBObj) mainInput.getTCRMOrganizationBObj();
        DWLTransactionPersistent addOrganizationRequest = new DWLTransactionPersistent();
        
                // Prepare a new DWLTransactionPersistent instance.
        
        addOrganizationRequest.setTxnControl(control);
        addOrganizationRequest.setTxnType("addOrganization");
        addOrganizationRequest.setTxnTopLevelObject(addOrganizationInput);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse addOrganizationResponse = null;
        
        // Invoke the "addOrganization" transaction.
        try {
            addOrganizationResponse = (DWLResponse) super.execute(addOrganizationRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTLEGAL_ENTITY_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTLEGALENTITY_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }
        
        if (addOrganizationResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTLEGAL_ENTITY_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTLEGALENTITY_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (addOrganizationResponse.getStatus().getStatus() == DWLStatus.FATAL) {
            DWLStatus status = addOrganizationResponse.getStatus();
            TCRMResponse errResponse = new TCRMResponse();
            errResponse.setStatus(status);
            return errResponse;
        }
        
        // Extract the returned business object from the response.
        TCRMOrganizationBObj addOrganizationOutput = (TCRMOrganizationBObj) addOrganizationResponse.getData();
        
        // MDM_TODO: CDKWB0013I build the response Bobj.
        MetcashLegalEntityBObj mainOutput = new MetcashLegalEntityBObj();
        
        mainOutput.setControl(control);
        mainOutput.setTCRMOrganizationBObj(addOrganizationOutput);
        
        // Handle Metcash Identifier
        
        Vector vecInputMetcashIdentifier = new Vector();
        Vector vecMetcashIdentifierResponse = new Vector();
        vecInputMetcashIdentifier = mainInput.getItemsMetcashIdentifierBObj();
        if (vecInputMetcashIdentifier.size() > 0 && vecInputMetcashIdentifier != null) {        	
        	MaintainMetcashIdentifier metcashIdentifier = new MaintainMetcashIdentifier();
        	vecMetcashIdentifierResponse = (Vector) metcashIdentifier.processMetcashIdentifier(vecInputMetcashIdentifier, addOrganizationOutput.getPartyId(), control);
        }       
        if (vecMetcashIdentifierResponse.size() > 0 && vecMetcashIdentifierResponse != null) {
        	for (int j=0; j < vecMetcashIdentifierResponse.size(); j++) {
        		mainOutput.setMetcashIdentifierBObj((MetcashIdentifierBObj)vecMetcashIdentifierResponse.elementAt(j));
        	}
        }
        
        // Construct the response object.
        DWLStatus outputStatus = new DWLStatus();
        outputStatus.setStatus(DWLStatus.SUCCESS);
        outputTxnObj = new TCRMResponse();
        outputTxnObj.setStatus(outputStatus);
        outputTxnObj.setData(mainOutput);
    logger.finest("RETURN Object execute(Object inputObj)");
        return outputTxnObj;
    }
}


