/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[8823816dcdc242dcb5e1baea914d6a44]
 */

package com.metcash.services.custom.compositeTxn;

import java.util.Vector;

import com.dwl.base.DWLCommon;
import com.dwl.base.DWLControl;
import com.dwl.base.DWLResponse;
import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.admin.services.em.obj.ProcessActionBObj;
import com.dwl.base.admin.services.em.obj.ProcessControlBObj;
import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLStatus;
import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.requestHandler.DWLTransactionInquiry;
import com.dwl.base.requestHandler.DWLTransactionPersistent;
import com.dwl.base.requestHandler.DWLTxnBP;
import com.dwl.tcrm.common.TCRMResponse;
import com.dwl.tcrm.coreParty.component.TCRMAddressComponent;
import com.dwl.tcrm.coreParty.component.TCRMAdminContEquivBObj;
import com.dwl.tcrm.coreParty.component.TCRMOrganizationBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyAddressBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyContactMethodBObj;
import com.dwl.tcrm.coreParty.component.TCRMPartyIdentificationBObj;
import com.dwl.tcrm.financial.component.TCRMAdminNativeKeyBObj;
import com.dwl.tcrm.financial.component.TCRMContractBObj;
import com.dwl.tcrm.financial.component.TCRMContractComponentBObj;
import com.dwl.tcrm.financial.component.TCRMContractPartyRoleBObj;
import com.dwl.tcrm.financial.component.TCRMContractPartyRoleIdentifierBObj;
import com.dwl.tcrm.financial.component.TCRMContractRoleLocationBObj;
import com.dwl.tcrm.financial.component.TCRMContractRoleLocationPurposeBObj;
import com.dwl.tcrm.financial.component.TCRMContractValueBObj;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.dwl.unifi.tx.exception.BusinessProxyException;
import com.metcash.db.custom.component.MTTActCostChargesBObj;
import com.metcash.db.custom.component.MTTActCreditTaxBObj;
import com.metcash.db.custom.component.MTTActFinancialBObj;
import com.metcash.db.custom.component.MTTActOrderInvoiceBObj;
import com.metcash.db.custom.component.MTTActReportingBObj;
import com.metcash.services.custom.component.MetcashAccountBObj;
import com.metcash.services.custom.component.MetcashAccountRoleBObj;
import com.metcash.services.custom.component.MetcashIdentifierBObj;
import com.metcash.services.custom.constant.MTTEMConstant;
import com.metcash.services.custom.constant.MTTServicesComponentID;
import com.metcash.services.custom.constant.MTTServicesErrorReasonCode;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * 
 * @generated
 */
public class MaintainMTTAccountCompositeTxnBP  extends DWLTxnBP {

	/**
	 * @generated
	 **/
	private IDWLErrorMessage errHandler;
	
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(MaintainMTTAccountCompositeTxnBP.class);
	/**
	 * @generated
	 **/
    public MaintainMTTAccountCompositeTxnBP() {
        super();
        errHandler = TCRMClassFactory.getErrorHandler();
    }
	/**
	 * @generated NOT
	 **/
    public Object execute(Object inputObj) throws BusinessProxyException {
    logger.finest("ENTER Object execute(Object inputObj)");

        TCRMResponse outputTxnObj = null;
        DWLTransactionPersistent inputTxnObj = (DWLTransactionPersistent) inputObj;
        DWLControl control = inputTxnObj.getTxnControl();
        DWLCommon topLevelObject = (DWLCommon) inputTxnObj.getTxnTopLevelObject();
        if (!(topLevelObject instanceof MetcashAccountBObj)) {
            // MDM_TODO0: CDKWB0014I optionally use a more appropriate error code than
            // "MAINTAINMTTACCOUNT_FAILED".
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        
        MetcashAccountBObj mainInput = (MetcashAccountBObj) topLevelObject;
        MetcashAccountBObj mainOutput = new MetcashAccountBObj();
        mainOutput.setControl(control);
        
        boolean isUpdateContract = false;
        boolean isContractExists = false;
        
        TCRMContractBObj foundContract = new TCRMContractBObj();
        
        // Contract Value object removed from request        
        Vector vecInputContractValue = new Vector();        
        if (mainInput.getTCRMContractBObj().getItemsTCRMContractValueBObj() != null && 
        		mainInput.getTCRMContractBObj().getItemsTCRMContractValueBObj().size() > 0) {
        	for (int i=0; i < mainInput.getTCRMContractBObj().getItemsTCRMContractValueBObj().size(); i++) {
        		vecInputContractValue.add(mainInput.getTCRMContractBObj().getItemsTCRMContractValueBObj().elementAt(i));
        	}
        }    	    	
    	mainInput.getTCRMContractBObj().getItemsTCRMContractValueBObj().removeAllElements();        
        isContractExists = searchContractBasic(mainInput, control);
        
        if (isContractExists) {
        	foundContract = getExistingContract(mainInput, control);
        	resolveIdentity(mainInput, foundContract, control);        	
        	updateContract (mainInput, mainOutput, control);        	
            isUpdateContract = true;        	
        } else {
        	addContract (mainInput, mainOutput, control);        	
        }
        
        // Contract Value Processing
        if (vecInputContractValue != null && vecInputContractValue.size() > 0) {
        	if (!isUpdateContract) {
        		handleContractValueAdd (vecInputContractValue, mainOutput, control);
        	} if (isUpdateContract) {
        			handleContractValueUpdate (vecInputContractValue, mainOutput, control);        		
        	}
        }
        // Credit and Tax Processing
        if (mainInput.getMTTActCreditTaxBObj() != null) {
        	MTTActCreditTaxBObj inputCreditTax = new MTTActCreditTaxBObj();
        	inputCreditTax = mainInput.getMTTActCreditTaxBObj();
        	inputCreditTax.setControl(control);
        	if (!isUpdateContract) {
                handleCreditTaxAdd (inputCreditTax, mainOutput, control);
                } if (isUpdateContract) {
                	handleCreditTaxUpdate (inputCreditTax, mainOutput, control);
             }
        }       
        // Order and Invoice Processing
        if (mainInput.getMTTActOrderInvoiceBObj() != null) {
        	MTTActOrderInvoiceBObj inputOrderInvoice = new MTTActOrderInvoiceBObj();
        	inputOrderInvoice = mainInput.getMTTActOrderInvoiceBObj();
        	inputOrderInvoice.setControl(control);
        	if (!isUpdateContract) {
        		handleOrderInvoiceAdd (inputOrderInvoice, mainOutput, control);
        	} if (isUpdateContract) {
        		handleOrderInvoiceUpdate (inputOrderInvoice, mainOutput, control);
        	}
        }        
        // Financial Processing
        if (mainInput.getMTTActFinancialBObj() != null) {
        	MTTActFinancialBObj inputFinance = new MTTActFinancialBObj();
        	inputFinance = mainInput.getMTTActFinancialBObj();
        	inputFinance.setControl(control);
        	if (!isUpdateContract) {
        		handleFinancialAdd (inputFinance, mainOutput, control);
        	} if (isUpdateContract) {
        		handleFinancialUpdate (inputFinance, mainOutput, control);
        	}
        }        
        // Cost and Charge Processing
        if (mainInput.getMTTActCostChargesBObj() != null) {
        	MTTActCostChargesBObj inputCostCharge = new MTTActCostChargesBObj();
        	inputCostCharge = mainInput.getMTTActCostChargesBObj();
        	inputCostCharge.setControl(control);
        	if (!isUpdateContract) {
        		handleCostChargeAdd (inputCostCharge, mainOutput, control);
        	} if (isUpdateContract) {
        		handleCostChargeUpdate (inputCostCharge, mainOutput, control);
        	}
        }
        // Reporting Processing
        if (mainInput.getMTTActReportingBObj() != null) {
        	MTTActReportingBObj inputReporting = new MTTActReportingBObj();
        	inputReporting = mainInput.getMTTActReportingBObj();
        	inputReporting.setControl(control);
        	if (!isUpdateContract) {
        		handleReportingAdd (inputReporting, mainOutput, control);
        	} if (isUpdateContract) {
        		handleReportingUpdate (inputReporting, mainOutput, control);
        	}
        }
        
        // Register Input Contract for Event Processing
        // triggerEventForContract (mainOutput.getTCRMContractBObj().getContractIdPK(), control);
        
        // MDM_TODO: CDKWB0013I build the response Bobj.        
        
        // Construct the response object.
        DWLStatus outputStatus = new DWLStatus();
        outputStatus.setStatus(DWLStatus.SUCCESS);
        outputTxnObj = new TCRMResponse();
        outputTxnObj.setStatus(outputStatus);
        outputTxnObj.setData(mainOutput);
        logger.finest("RETURN Object execute(Object inputObj)");
        return outputTxnObj;
    }
    
	private void addContract(MetcashAccountBObj mainInput, 
			MetcashAccountBObj mainOutput, DWLControl control) throws BusinessProxyException {    	
		
		// Clear TCRMContractPartyRole from TCRMContractBObj
    	TCRMContractComponentBObj inputContrComp = (TCRMContractComponentBObj) mainInput.getTCRMContractBObj().getItemsTCRMContractComponentBObj().firstElement();
    	inputContrComp.getItemsTCRMContractPartyRoleBObj().removeAllElements();
    	
		Vector<Object> vecInputMetcashActRole = new Vector<>();
		vecInputMetcashActRole = (Vector) mainInput.getItemsMetcashAccountRoleBObj();
		MetcashAccountRoleBObj outputMetcashLegalEntityRole = new MetcashAccountRoleBObj();
		
		if (vecInputMetcashActRole.size() > 0 && vecInputMetcashActRole != null) {
    		MetcashAccountRoleBObj inputMetcashContrRole = new MetcashAccountRoleBObj();						
    		for (int k=0; k < vecInputMetcashActRole.size(); k++) {
    			inputMetcashContrRole = (MetcashAccountRoleBObj) vecInputMetcashActRole.elementAt(k);
    			// Resolve MDM ID for contract role
    			if (inputMetcashContrRole.getTCRMContractPartyRoleBObj().getPartyId() == null) {
    				resolveIDForRole(inputMetcashContrRole.getTCRMContractPartyRoleBObj(), control);    				
    			}
    			if (inputMetcashContrRole.getTCRMContractPartyRoleBObj().getRoleType().equals(MTTServicesComponentID.LEGAL_ENTITY_ROLE_TYPE)) {
    				addMetcashAccountRole (inputMetcashContrRole, outputMetcashLegalEntityRole, control);
    			} 
    				inputContrComp.setTCRMContractPartyRoleBObj(inputMetcashContrRole.getTCRMContractPartyRoleBObj());    			    			    			
    			}	
    		}		
    	TCRMContractBObj addContractInput = mainInput.getTCRMContractBObj();
    	addContractInput.setControl(control);
    	
    	// Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent addContractRequest = new DWLTransactionPersistent();
        addContractRequest.setTxnControl(control);
        addContractRequest.setTxnType("addContract");
        addContractRequest.setTxnTopLevelObject(addContractInput);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse addContractResponse = null;
        
        // Invoke the "addContract" transaction.
        try {
            addContractResponse = (DWLResponse) super.execute(addContractRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }
        
        if (addContractResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (addContractResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	DWLStatus dwlStatus = addContractResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }
        if(addContractResponse.getData() != null) {        	
        	TCRMContractBObj outputContract = new TCRMContractBObj();
        	TCRMContractComponentBObj outputContrComp = new TCRMContractComponentBObj();        	
        	Vector vecContractRole = new Vector();
        	        	
        	outputContract = (TCRMContractBObj) addContractResponse.getData();
        	outputContrComp = (TCRMContractComponentBObj) outputContract.getItemsTCRMContractComponentBObj().firstElement();        	
        	vecContractRole = outputContrComp.getItemsTCRMContractPartyRoleBObj();
        	MetcashAccountRoleBObj outputMetcashRole = new MetcashAccountRoleBObj();
        	
        	for (int i=0; i < vecContractRole.size(); i++) {
        		TCRMContractPartyRoleBObj outputConrRole = (TCRMContractPartyRoleBObj) vecContractRole.elementAt(i);        		
        		if (outputConrRole.getRoleType().equalsIgnoreCase(MTTServicesComponentID.LEGAL_ENTITY_ROLE_TYPE)) {
        			outputMetcashLegalEntityRole.setTCRMContractPartyRoleBObj(outputConrRole);
        			mainOutput.setMetcashAccountRoleBObj(outputMetcashLegalEntityRole);
        		} else {
        			outputMetcashRole.setTCRMContractPartyRoleBObj((TCRMContractPartyRoleBObj) vecContractRole.elementAt(i));
        			mainOutput.setMetcashAccountRoleBObj(outputMetcashRole);
        		}        		
        	}        	
        	outputContrComp.getItemsTCRMContractPartyRoleBObj().removeAllElements();
        	mainOutput.setTCRMContractBObj(outputContract);
        }
	}
	private void addMetcashAccountRole (MetcashAccountRoleBObj inputMetcashContrRole, 
			MetcashAccountRoleBObj outputMetcashLegalEntityRole, DWLControl control) throws BusinessProxyException {
		
		String partyId = inputMetcashContrRole.getTCRMContractPartyRoleBObj().getPartyId();
		
		if (partyId == null) {
			DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                    "INSERR",
                    MTTServicesErrorReasonCode.CONTRACTROLE_FAILED,
                    control, new String[0]);
				throw new BusinessProxyException(error.getErrorMessage());
		}
		
		Vector vecRoleLocation = (Vector) inputMetcashContrRole.getTCRMContractPartyRoleBObj().getItemsTCRMContractRoleLocationBObj();
		Vector vecInpMetcashIdentifier = (Vector) inputMetcashContrRole.getItemsMetcashIdentifierBObj();
		
		if(vecRoleLocation.size() > 0 && vecRoleLocation != null) {			
			addRoleLocation (vecRoleLocation, partyId, control);			
			}
		if (vecInpMetcashIdentifier.size() > 0 && vecInpMetcashIdentifier != null) {
			addRoleIdentifier (inputMetcashContrRole.getTCRMContractPartyRoleBObj(), vecInpMetcashIdentifier, partyId, outputMetcashLegalEntityRole, control);
		}
	}
	private void addRoleLocation(Vector vecRoleLocation,
			String partyId, DWLControl control) throws BusinessProxyException {
		
		DWLResponse roleLocationResponse = null;		

		for (int a=0; a < vecRoleLocation.size(); a++) {
			TCRMContractRoleLocationBObj inputRoleLoc = (TCRMContractRoleLocationBObj) vecRoleLocation.elementAt(a);
			
			if (inputRoleLoc.getItemsTCRMContractRoleLocationPurposeBObj().size() == 0) {
				DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
	                    "INSERR",
	                    MTTServicesErrorReasonCode.ROLELOCPURPOSE_FAILED,
	                    control, new String[0]);
					throw new BusinessProxyException(error.getErrorMessage());
			}			
			if (inputRoleLoc.getLocationGroupId() == null) {
				TCRMPartyAddressBObj inputPartyAddr = inputRoleLoc.getTCRMPartyAddressBObj();
				TCRMPartyContactMethodBObj inputPartyContMeth = inputRoleLoc.getTCRMPartyContactMethodBObj();	
		
				if (inputPartyAddr != null) {
					inputPartyAddr.setPartyId(partyId);
					resolvePartyAddress (inputPartyAddr, control);
					if (inputPartyAddr.getPartyAddressIdPK() == null) {
						roleLocationResponse = addPartyAddress (inputPartyAddr, control);
						TCRMPartyAddressBObj partyAddrResponse = (TCRMPartyAddressBObj) roleLocationResponse.getData();
						inputRoleLoc.setLocationGroupId(partyAddrResponse.getPartyAddressIdPK());
					} else {
						inputRoleLoc.setLocationGroupId(inputPartyAddr.getPartyAddressIdPK());
					}					
				}
				if (inputPartyContMeth != null) {
					inputPartyContMeth.setPartyId(partyId);
					roleLocationResponse = addPartyContactMethod (inputPartyContMeth, control);
					TCRMPartyContactMethodBObj partyContMethResponse = (TCRMPartyContactMethodBObj) roleLocationResponse.getData();
					inputRoleLoc.setLocationGroupId(partyContMethResponse.getPartyContactMethodIdPK());
				}
			}
		}
	}
	private void resolvePartyAddress(TCRMPartyAddressBObj inputPartyAddr,
			DWLControl control) throws BusinessProxyException {
		
		Vector vecFoundPartyAddr = new Vector();
		vecFoundPartyAddr = getExistingPartyAddress (inputPartyAddr.getPartyId(), control);
		boolean isSameAddress = false;
		
		if (vecFoundPartyAddr != null) {
			TCRMAddressComponent addressComp = new TCRMAddressComponent();
			for (int k=0; k < vecFoundPartyAddr.size(); k++) {
				TCRMPartyAddressBObj foundPartyAddress = (TCRMPartyAddressBObj) vecFoundPartyAddr.elementAt(k);
				if (inputPartyAddr.getAddressUsageType().equalsIgnoreCase(foundPartyAddress.getAddressUsageType())) {
					try {
						isSameAddress = addressComp.compareAddress(inputPartyAddr.getTCRMAddressBObj(), foundPartyAddress.getTCRMAddressBObj());
						if (isSameAddress) {
							inputPartyAddr.setPartyAddressIdPK(foundPartyAddress.getPartyAddressIdPK());
							break;
						}
					} catch (Exception e) {
						throw new BusinessProxyException(e.getMessage());
					}
				}
			}
		}		
	}
	private DWLResponse addPartyContactMethod(
			TCRMPartyContactMethodBObj inputPartyContMeth, DWLControl control) throws BusinessProxyException {
		
		// Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent addPartyCMRequest = new DWLTransactionPersistent();
        addPartyCMRequest.setTxnControl(control);
        addPartyCMRequest.setTxnType("addPartyContactMethod");
        addPartyCMRequest.setTxnTopLevelObject(inputPartyContMeth);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse addPartyContMethResponse = null;
        
        try {
        	addPartyContMethResponse = (DWLResponse) super.execute(addPartyCMRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.CONTACTMETHOD_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }
        
        if (addPartyContMethResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.CONTACTMETHOD_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (addPartyContMethResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	DWLStatus dwlStatus = addPartyContMethResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }        
        return addPartyContMethResponse;
	}
	private DWLResponse addPartyAddress(TCRMPartyAddressBObj inputPartyAddr,
			DWLControl control) throws BusinessProxyException {
		
		// Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent addPartyAddrRequest = new DWLTransactionPersistent();
        addPartyAddrRequest.setTxnControl(control);
        addPartyAddrRequest.setTxnType("addPartyAddress");
        addPartyAddrRequest.setTxnTopLevelObject(inputPartyAddr);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse addPartyAddrResponse = null;
        
        try {
        	addPartyAddrResponse = (DWLResponse) super.execute(addPartyAddrRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.ADDRESS_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }
        
        if (addPartyAddrResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.ADDRESS_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (addPartyAddrResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	DWLStatus dwlStatus = addPartyAddrResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }
        
        return addPartyAddrResponse;		
	}	
	private Vector getExistingPartyAddress(String partyId, DWLControl control) throws BusinessProxyException {
		
		Vector<Object> getPartyAddressInput = new Vector<Object>();

		getPartyAddressInput.add(0, partyId);
		getPartyAddressInput.add(1, MTTServicesComponentID.FILTER_FOR_GET);
		getPartyAddressInput.add(2, MTTServicesComponentID.PARTY_ADDRESS_INQ_LVL);

		// Prepare a new DWLTransactionInquiry instance.
		DWLTransactionInquiry getPartyAddressRequest = new DWLTransactionInquiry();
		getPartyAddressRequest.setTxnControl(control);
		getPartyAddressRequest.setTxnType("getAllPartyAddresses");
		getPartyAddressRequest.setStringParameters(getPartyAddressInput);

		// Prepare a reference to hold the response for this transaction.
		DWLResponse getPartyAddressResponse = null;

		// Invoke the "getContract" transaction.
		try {
			getPartyAddressResponse = (DWLResponse) super
					.execute(getPartyAddressRequest);
		} catch (BusinessProxyException e) {
			DWLError error = errHandler.getErrorMessage(
					MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
					"READERR", MTTServicesErrorReasonCode.GETCONTRACTBYADMINSYSKEY_FAILED,
					control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage(), e);
		} if (getPartyAddressResponse == null) {
			DWLError error = errHandler.getErrorMessage(
					MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
					"READERR", MTTServicesErrorReasonCode.GETCONTRACTBYADMINSYSKEY_FAILED,
					control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage());
		}
		Vector vecPartyAddress = new Vector();
		vecPartyAddress = (Vector) getPartyAddressResponse.getData();
		return vecPartyAddress;		
	}
	private void addRoleIdentifier(TCRMContractPartyRoleBObj inputContrRole, Vector vecInpMetcashIdentifier, String partyId,
			MetcashAccountRoleBObj outputMetcashRole, DWLControl control) throws BusinessProxyException {
		MaintainMetcashIdentifier metcashIdentifier = new MaintainMetcashIdentifier();
		Vector metcashIdentfierResponse = (Vector) metcashIdentifier.processMetcashIdentifier(vecInpMetcashIdentifier, partyId, control);		
		
		
		if (metcashIdentfierResponse.size() > 0 && metcashIdentfierResponse != null) {
			for (int k=0; k < metcashIdentfierResponse.size(); k++) {
				MetcashIdentifierBObj metcashReponse = new MetcashIdentifierBObj();
				TCRMContractPartyRoleIdentifierBObj inputRoleIdentifier = new TCRMContractPartyRoleIdentifierBObj();
				inputRoleIdentifier.setControl(control);
				metcashReponse = (MetcashIdentifierBObj) metcashIdentfierResponse.elementAt(k);
				outputMetcashRole.setMetcashIdentifierBObj(metcashReponse);
				inputRoleIdentifier.setIdentifierId(metcashReponse.getTCRMPartyIdentificationBObj().getIdentificationIdPK());
				inputRoleIdentifier.setDescription(metcashReponse.getTCRMPartyIdentificationBObj().getIdentificationType());
				inputContrRole.setTCRMContractPartyRoleIdentifierBObj(inputRoleIdentifier);				
			}
		}		
	}
	private void updateContract(MetcashAccountBObj mainInput, 
			MetcashAccountBObj mainOutput, DWLControl control) throws BusinessProxyException {
		
		TCRMContractBObj updateContractInput = mainInput.getTCRMContractBObj();
		updateContractInput.setControl(control);
		// Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent updateContractRequest = new DWLTransactionPersistent();
        updateContractRequest.setTxnControl(control);
        updateContractRequest.setTxnType("updateContract");
        updateContractRequest.setTxnTopLevelObject(updateContractInput);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse updateContractResponse = null;
        
        // Invoke the "updateContract" transaction.
        try {
            updateContractResponse = (DWLResponse) super.execute(updateContractRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }
        
        if (updateContractResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (updateContractResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	DWLStatus dwlStatus = updateContractResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }
        if(updateContractResponse.getData() != null) {        	
        	TCRMContractBObj outputContract = new TCRMContractBObj();
        	TCRMContractComponentBObj outputContrComp = new TCRMContractComponentBObj();
        	MetcashAccountRoleBObj outputMetcashRole = new MetcashAccountRoleBObj();
        	Vector vecContractRole = new Vector();
        	        	
        	outputContract = (TCRMContractBObj) updateContractResponse.getData();
        	outputContrComp = (TCRMContractComponentBObj) outputContract.getItemsTCRMContractComponentBObj().firstElement();        	
        	vecContractRole = outputContrComp.getItemsTCRMContractPartyRoleBObj();
        	
        	for (int i=0; i < vecContractRole.size(); i++) {
        		outputMetcashRole.setTCRMContractPartyRoleBObj((TCRMContractPartyRoleBObj)vecContractRole.elementAt(i));
        		mainOutput.setMetcashAccountRoleBObj(outputMetcashRole);
        	}        	
        	outputContrComp.getItemsTCRMContractPartyRoleBObj().removeAllElements();
        	mainOutput.setTCRMContractBObj(outputContract);
        }
	}
    private boolean searchContractBasic(MetcashAccountBObj mainInput,
			DWLControl control) throws BusinessProxyException {
		
    	TCRMContractBObj contractBObj = mainInput.getTCRMContractBObj();
    	Vector vecAdminNativeKey = contractBObj.getItemsTCRMAdminNativeKeyBObj();

		TCRMAdminNativeKeyBObj inputAdminNativekey = new TCRMAdminNativeKeyBObj();
		inputAdminNativekey = (TCRMAdminNativeKeyBObj) vecAdminNativeKey.firstElement();
		
		String adminSysTp = inputAdminNativekey.getAdminSystemType();
		String adminContractId = inputAdminNativekey.getAdminContractId();		
		
		Vector<Object> getAdminNativeKeyInput = new Vector<Object>();

		getAdminNativeKeyInput.add(0, adminSysTp);
		getAdminNativeKeyInput.add(1, adminContractId);		

		// Prepare a new DWLTransactionInquiry instance.
		DWLTransactionInquiry getAdminNativeKeyRequest = new DWLTransactionInquiry();
		getAdminNativeKeyRequest.setTxnControl(control);
		getAdminNativeKeyRequest.setTxnType("getContractByAdminSysKey");
		getAdminNativeKeyRequest.setStringParameters(getAdminNativeKeyInput);

		// Prepare a reference to hold the response for this transaction.
		DWLResponse getAdminNativeKeyResponse = null;

		// Invoke the "getContract" transaction.
		try {
			getAdminNativeKeyResponse = (DWLResponse) super
					.execute(getAdminNativeKeyRequest);
		} catch (BusinessProxyException e) {
			DWLError error = errHandler.getErrorMessage(
					MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
					"READERR", MTTServicesErrorReasonCode.GETCONTRACTBYADMINSYSKEY_FAILED,
					control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage(), e);
		} if (getAdminNativeKeyResponse == null) {
			DWLError error = errHandler.getErrorMessage(
					MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
					"READERR", MTTServicesErrorReasonCode.GETCONTRACTBYADMINSYSKEY_FAILED,
					control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage());
		}
		if (getAdminNativeKeyResponse.getData() != null) {
			resolveContract(mainInput, getAdminNativeKeyResponse);
			return true;
		} else {
			return false;
		}
	}
    public TCRMContractBObj getExistingContract(MetcashAccountBObj mainInput, 
			DWLControl control) throws BusinessProxyException {
		
		TCRMContractBObj updateContractInput = mainInput.getTCRMContractBObj();
		updateContractInput.setControl(control);
	
		Vector<Object> getContractInput = new Vector<Object>();
		getContractInput.add(0, updateContractInput.getContractIdPK());  
		getContractInput.add(1, MTTServicesComponentID.CONTRACT_INQ_LVL);
		getContractInput.add(2, MTTServicesComponentID.CONTRACT_PARTY_INQ_LVL);

		// Prepare a new DWLTransactionInquiry instance.
		DWLTransactionInquiry getContractRequest = new DWLTransactionInquiry();
		getContractRequest.setTxnControl(control);
		getContractRequest.setTxnType("getContract");
		getContractRequest.setStringParameters(getContractInput);

		// Prepare a reference to hold the response for this transaction.
		DWLResponse getContractResponse = null;

		// Invoke the transaction.
		try {
			getContractResponse = (DWLResponse) super
					.execute(getContractRequest);
		} catch (BusinessProxyException e) {
			DWLError error = errHandler.getErrorMessage(
					MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
					"READERR", MTTServicesErrorReasonCode.GETCONTRACTBYADMINSYSKEY_FAILED,
					control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage(), e);
		} if (getContractResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	DWLStatus dwlStatus = getContractResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
		}
		TCRMContractBObj foundContract = (TCRMContractBObj) getContractResponse.getData();
		return foundContract;
		}
	private void resolveContract(MetcashAccountBObj mainInput,
			DWLResponse getAdminNativeKeyResponse) throws BusinessProxyException {
		
		TCRMContractBObj existingContract = (TCRMContractBObj) getAdminNativeKeyResponse.getData();
		mainInput.getTCRMContractBObj().setContractIdPK(existingContract.getContractIdPK());
		try {
			mainInput.getTCRMContractBObj().setContractLastUpdateDate(existingContract.getContractLastUpdateDate());
		} catch (Exception e1) {
			throw new BusinessProxyException(e1.getMessage());
		}
		// Remove Native key
		mainInput.getTCRMContractBObj().getItemsTCRMAdminNativeKeyBObj().removeAllElements();		
	}	
	private void resolveIdentity(MetcashAccountBObj mainInput,
			TCRMContractBObj foundContract, DWLControl control) throws BusinessProxyException {
		
		if (mainInput.getTCRMContractBObj().getItemsTCRMContractComponentBObj().size() > 0 && mainInput.getTCRMContractBObj().getItemsTCRMContractComponentBObj() != null) {	
		TCRMContractComponentBObj inputContrComp = (TCRMContractComponentBObj) mainInput.getTCRMContractBObj().getItemsTCRMContractComponentBObj().firstElement();    		    		
    		if (foundContract.getItemsTCRMContractComponentBObj().size() > 0 && foundContract.getItemsTCRMContractComponentBObj() != null) {
    			TCRMContractComponentBObj foundContrComp = (TCRMContractComponentBObj) foundContract.getItemsTCRMContractComponentBObj().firstElement();
    			inputContrComp.setContractComponentIdPK(foundContrComp.getContractComponentIdPK());
					try {
						inputContrComp.setContractComponentLastUpdateDate(foundContrComp.getContractComponentLastUpdateDate());
					} catch (Exception e) {
						DWLError error = errHandler.getErrorMessage(
		    					MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
		    					"READERR", MTTServicesErrorReasonCode.GETCONTRACTBYADMINSYSKEY_FAILED,
		    					control, new String[0]);
		    			throw new BusinessProxyException(error.getErrorMessage(), e);
					}
    		}
		    		// Clear TCRMContractPartyRole from TCRMContractBObj		        	
		        	inputContrComp.getItemsTCRMContractPartyRoleBObj().removeAllElements();					
    			} else {
    				mainInput.getTCRMContractBObj().setTCRMContractComponentBObj((TCRMContractComponentBObj) foundContract.getItemsTCRMContractComponentBObj().firstElement()); 
    			}
		handleMetcashRoleForUpdate(mainInput, foundContract, control);		
    	}
	private void handleMetcashRoleForUpdate(
			MetcashAccountBObj mainInput,
			TCRMContractBObj foundContract,
			DWLControl control) throws BusinessProxyException {
    	
    	Vector<Object> vecInputMetcashActRole = new Vector<>();
    	vecInputMetcashActRole = (Vector) mainInput.getItemsMetcashAccountRoleBObj();
    	boolean isResolved = false;
		
    	if (vecInputMetcashActRole.size() > 0 && vecInputMetcashActRole != null) {
    		MetcashAccountRoleBObj inputMetcashContrRole = new MetcashAccountRoleBObj();						
    		for (int k=0; k < vecInputMetcashActRole.size(); k++) {
    			inputMetcashContrRole = (MetcashAccountRoleBObj) vecInputMetcashActRole.elementAt(k);
    			// Resolve MDM ID for contract role
    			if (inputMetcashContrRole.getTCRMContractPartyRoleBObj().getPartyId() == null) {
    				resolveIDForRole(inputMetcashContrRole.getTCRMContractPartyRoleBObj(), control);			
    			}
    			TCRMContractComponentBObj foundContrComp = (TCRMContractComponentBObj) foundContract.getItemsTCRMContractComponentBObj().firstElement(); 
    			Vector vecFoundContrRole = (Vector) foundContrComp.getItemsTCRMContractPartyRoleBObj();
    			if (vecFoundContrRole.size() > 0 && vecFoundContrRole != null) {
    				for (int o=0; o < vecFoundContrRole.size(); o++) {
    					TCRMContractPartyRoleBObj foundContrPartyRole = (TCRMContractPartyRoleBObj) vecFoundContrRole.elementAt(o);
    					if (inputMetcashContrRole.getTCRMContractPartyRoleBObj().getRoleType().equalsIgnoreCase(foundContrPartyRole.getRoleType()) && 
    							inputMetcashContrRole.getTCRMContractPartyRoleBObj().getPartyId().equalsIgnoreCase(foundContrPartyRole.getPartyId())) {
    						inputMetcashContrRole.getTCRMContractPartyRoleBObj().setContractComponentId(foundContrPartyRole.getContractComponentId());
    					}
    					try {
							if (inputMetcashContrRole.getTCRMContractPartyRoleBObj().isBusinessKeySame(foundContrPartyRole)) {
								resolveIdentityForContractRole (inputMetcashContrRole, foundContrPartyRole, control);
								isResolved = true;
								break;
							}
						} catch (DWLBaseException e) {
							throw new BusinessProxyException(e.getMessage());
						} catch (Exception e) {
							throw new BusinessProxyException(e.getMessage());
						}
    				}
    			}
    			if (!isResolved) {
    				MetcashAccountRoleBObj outputMetcashLegalEntityRole = new MetcashAccountRoleBObj();
    				addMetcashAccountRole(inputMetcashContrRole, outputMetcashLegalEntityRole, control);    			   	
    			}						
    			TCRMContractComponentBObj inputContrCom = (TCRMContractComponentBObj) mainInput.getTCRMContractBObj().getItemsTCRMContractComponentBObj().firstElement();
    			inputContrCom.setTCRMContractPartyRoleBObj(inputMetcashContrRole.getTCRMContractPartyRoleBObj());    				
    			}		
    		}
		}    
	private void resolveIdentityForContractRole (MetcashAccountRoleBObj inputMetcashActRole,
			TCRMContractPartyRoleBObj foundContrPartyRole, DWLControl control) throws BusinessProxyException {		
		
		Vector vecInpMetcashIdentifier = inputMetcashActRole.getItemsMetcashIdentifierBObj();
		TCRMContractPartyRoleBObj inputContractRole = inputMetcashActRole.getTCRMContractPartyRoleBObj();
		
		if (inputContractRole.getPartyId() == null || foundContrPartyRole.getPartyId() == null 
				|| !inputContractRole.getPartyId().equalsIgnoreCase(foundContrPartyRole.getPartyId())) {
			
			DWLError error = errHandler.getErrorMessage(
					MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
					"READERR", MTTServicesErrorReasonCode.LEGAL_ENTITY_ROLE_RESOLVE,
					control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage());
		}
		try {
		if(inputContractRole.isBusinessKeySame(foundContrPartyRole)) {		
			inputContractRole.setContractRoleIdPK(foundContrPartyRole.getContractRoleIdPK());			
			inputContractRole.setContractPartyRoleLastUpdateDate(foundContrPartyRole.getContractPartyRoleLastUpdateDate());
			}
		} catch (Exception e) {
						DWLError error = errHandler.getErrorMessage(
		    					MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
		    					"READERR", MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
		    					control, new String[0]);
		    			throw new BusinessProxyException(error.getErrorMessage(), e);
					}				
		if (inputContractRole.getRoleType().equalsIgnoreCase(MTTServicesComponentID.LEGAL_ENTITY_ROLE_TYPE)) {
			resolveIdentityForRoleChild (inputContractRole, foundContrPartyRole, vecInpMetcashIdentifier, control);
			}		
		}
		private void resolveIdentityForRoleChild(
			TCRMContractPartyRoleBObj inputLegalEntityRole,
			TCRMContractPartyRoleBObj foundLegalEntityRole, Vector vecInpMetcashIdentifier, DWLControl control) throws BusinessProxyException {
		
		Vector vecInputRoleLoc = inputLegalEntityRole.getItemsTCRMContractRoleLocationBObj();
		Vector vecFoundRoleLoc = foundLegalEntityRole.getItemsTCRMContractRoleLocationBObj();		
		Vector vecFoundRoleIden = foundLegalEntityRole.getItemsTCRMContractPartyRoleIdentifierBObj();
		
		if (vecInputRoleLoc.size() > 0 && vecInputRoleLoc != null) {
			resolveRoleLocation (inputLegalEntityRole, vecInputRoleLoc, vecFoundRoleLoc, control);
		}
		if (vecInpMetcashIdentifier.size() > 0 && vecInpMetcashIdentifier != null) {
			resolveRoleIdentifier (inputLegalEntityRole, vecInpMetcashIdentifier, vecFoundRoleIden, control);
		}
		
	}
	private void resolveRoleIdentifier(TCRMContractPartyRoleBObj inputLegalEntityRole, Vector vecInpMetcashIdentifier,
			Vector vecFoundRoleIden, DWLControl control) throws BusinessProxyException {
		
		MaintainMetcashIdentifier metcashIdentifier = new MaintainMetcashIdentifier();
		Vector metcashIdentfierResponse = (Vector) metcashIdentifier.processMetcashIdentifier(vecInpMetcashIdentifier, inputLegalEntityRole.getPartyId(), control);
		MetcashIdentifierBObj inputMetcashIden = new MetcashIdentifierBObj();
		TCRMPartyIdentificationBObj inputPartyIden = new TCRMPartyIdentificationBObj();		
		TCRMContractPartyRoleIdentifierBObj foundRoleIden = new TCRMContractPartyRoleIdentifierBObj();
		TCRMContractPartyRoleIdentifierBObj inputRoleIden = new TCRMContractPartyRoleIdentifierBObj();
		boolean isResolved = false;
		
		for (int u=0; u < metcashIdentfierResponse.size(); u++) {
			inputRoleIden.setContractRoleId(inputLegalEntityRole.getContractRoleIdPK());
			inputMetcashIden = (MetcashIdentifierBObj) metcashIdentfierResponse.elementAt(u);
			inputPartyIden = inputMetcashIden.getTCRMPartyIdentificationBObj();			
			if (vecFoundRoleIden.size() > 0 && vecFoundRoleIden != null) {
			for (int v=0; v < vecFoundRoleIden.size(); v++) {
				foundRoleIden = (TCRMContractPartyRoleIdentifierBObj) vecFoundRoleIden.elementAt(v);
				if (inputPartyIden.getIdentificationType().equalsIgnoreCase(foundRoleIden.getDescription())) {
					inputRoleIden.setControl(control);
					inputRoleIden.setContractPartyRoleIdentifierIdPK(foundRoleIden.getContractPartyRoleIdentifierIdPK());
					try {
						inputRoleIden.setContractPartyRoleIdentifierLastUpdateDate(foundRoleIden.getContractPartyRoleIdentifierLastUpdateDate());
					} catch (Exception e) {
						throw new BusinessProxyException(e.getMessage());
					}
					inputRoleIden.setIdentifierId(inputPartyIden.getIdentificationIdPK());
					inputRoleIden.setDescription(inputPartyIden.getIdentificationType());
					inputLegalEntityRole.setTCRMContractPartyRoleIdentifierBObj(inputRoleIden);
					isResolved = true;
					break;
					} 
				}
			} if (!isResolved) {
			inputRoleIden.setControl(control);			
			inputRoleIden.setIdentifierId(inputPartyIden.getIdentificationIdPK());
			inputRoleIden.setDescription(inputPartyIden.getIdentificationType());
			inputLegalEntityRole.setTCRMContractPartyRoleIdentifierBObj(inputRoleIden);
			}
		}
	}
	private void resolveRoleLocation(TCRMContractPartyRoleBObj inputLegalEntityRole, Vector vecInputRoleLoc,
			Vector vecFoundRoleLoc, DWLControl control) throws BusinessProxyException {
		
		String partyId = inputLegalEntityRole.getPartyId();
		
		for (int h=0; h < vecInputRoleLoc.size(); h++) {
			
			boolean isInpRoleLocationAddr = false;
			boolean isInpRoleLocationCM = false;			
			boolean isResolved = false;
			TCRMContractRoleLocationBObj inputRoleLoc = new TCRMContractRoleLocationBObj();
			TCRMContractRoleLocationPurposeBObj inputRoleLocPurpose = new TCRMContractRoleLocationPurposeBObj();
			
			inputRoleLoc = (TCRMContractRoleLocationBObj) vecInputRoleLoc.elementAt(h);
			inputRoleLoc.setContractRoleId(inputLegalEntityRole.getContractRoleIdPK());
			inputRoleLocPurpose = (TCRMContractRoleLocationPurposeBObj) inputRoleLoc.getItemsTCRMContractRoleLocationPurposeBObj().firstElement();
			if (inputRoleLoc.getTCRMPartyAddressBObj() != null) {
				isInpRoleLocationAddr = true;
			}
			if (inputRoleLoc.getTCRMPartyContactMethodBObj() != null) {
				isInpRoleLocationCM = true;
			}
			if (vecFoundRoleLoc.size() > 0 && vecFoundRoleLoc != null) {
			for (int j=0; j < vecFoundRoleLoc.size(); j++) {
				
				boolean isFoundRoleLocAddr = false;
				boolean isFoundRoleLocCM = false;
				TCRMContractRoleLocationBObj foundRoleLoc = new TCRMContractRoleLocationBObj();
				TCRMContractRoleLocationPurposeBObj foundRoleLocPurpose = new TCRMContractRoleLocationPurposeBObj();
				
				foundRoleLoc = (TCRMContractRoleLocationBObj) vecFoundRoleLoc.elementAt(j);
				foundRoleLocPurpose = (TCRMContractRoleLocationPurposeBObj) foundRoleLoc.getItemsTCRMContractRoleLocationPurposeBObj().firstElement();				
				if (foundRoleLoc.getTCRMPartyAddressBObj() != null) {
					isFoundRoleLocAddr = true;
				}
				if (foundRoleLoc.getTCRMPartyContactMethodBObj() != null) {
					isFoundRoleLocCM = true;
				}				
				try {
				if (isInpRoleLocationAddr && isFoundRoleLocAddr && 
						inputRoleLocPurpose.isBusinessKeySame(foundRoleLocPurpose)) {					
						handlePartyAddressUpdate (inputRoleLoc.getTCRMPartyAddressBObj(), foundRoleLoc.getTCRMPartyAddressBObj(), partyId, control);						
						inputRoleLoc.setContractRoleLocationIdPK(foundRoleLoc.getContractRoleLocationIdPK());
						inputRoleLoc.setContractRoleLocationLastUpdateDate(foundRoleLoc.getContractRoleLocationLastUpdateDate());
						inputRoleLocPurpose.setContractRoleLocationPurposeIdPK(foundRoleLocPurpose.getContractRoleLocationPurposeIdPK());
						inputRoleLocPurpose.setContractRoleLocationPurposeLastUpdateDate(foundRoleLocPurpose.getContractRoleLocationPurposeLastUpdateDate());
						isResolved = true;
						break;
					} 
				if (isInpRoleLocationCM && isFoundRoleLocCM && 
						inputRoleLocPurpose.isBusinessKeySame(foundRoleLocPurpose)) {					
						handlePartyContMethUpdate (inputRoleLoc.getTCRMPartyContactMethodBObj(), foundRoleLoc.getTCRMPartyContactMethodBObj(), partyId, control);
						inputRoleLoc.setContractRoleLocationIdPK(foundRoleLoc.getContractRoleLocationIdPK());
						inputRoleLoc.setContractRoleLocationLastUpdateDate(foundRoleLoc.getContractRoleLocationLastUpdateDate());
						inputRoleLocPurpose.setContractRoleLocationPurposeIdPK(foundRoleLocPurpose.getContractRoleLocationPurposeIdPK());
						inputRoleLocPurpose.setContractRoleLocationPurposeLastUpdateDate(foundRoleLocPurpose.getContractRoleLocationPurposeLastUpdateDate());
						isResolved = true;
						break;
					} 
				} catch (Exception e) {
						DWLError error = errHandler.getErrorMessage(
								MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
								"READERR", MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
								control, new String[0]);
						throw new BusinessProxyException(error.getErrorMessage(), e);
						}						
					}
			}
				if (isInpRoleLocationAddr || isInpRoleLocationCM) {
					if (!isResolved) {
					Vector vecRoleLoc = new Vector();
					vecRoleLoc.add(inputRoleLoc);
					addRoleLocation (vecRoleLoc, inputLegalEntityRole.getPartyId(), control);					
					}
				}
			}
		}
	private void handlePartyContMethUpdate(
			TCRMPartyContactMethodBObj inputPartyContactMethodBObj,
			TCRMPartyContactMethodBObj foundPartyContactMethodBObj, String partyId, DWLControl control) throws BusinessProxyException {
		
		boolean isPhone = false;
		
		if (inputPartyContactMethodBObj.getTCRMContactMethodBObj().getTCRMPhoneNumberBObj() != null) {
			isPhone = true;
		}
		
		inputPartyContactMethodBObj.setControl(control);
		inputPartyContactMethodBObj.setPartyId(foundPartyContactMethodBObj.getPartyId());
		inputPartyContactMethodBObj.setPartyContactMethodIdPK(foundPartyContactMethodBObj.getPartyContactMethodIdPK());		
		inputPartyContactMethodBObj.setContactMethodId(foundPartyContactMethodBObj.getContactMethodId());
		inputPartyContactMethodBObj.getTCRMContactMethodBObj().setContactMethodIdPK(foundPartyContactMethodBObj.getTCRMContactMethodBObj().getContactMethodIdPK());
		if (isPhone) {
		inputPartyContactMethodBObj.getTCRMContactMethodBObj().getTCRMPhoneNumberBObj().setPhoneNumberId(foundPartyContactMethodBObj.getTCRMContactMethodBObj().getTCRMPhoneNumberBObj().getPhoneNumberId());
		}
		try {
			inputPartyContactMethodBObj.setLocationGroupLastUpdateDate(foundPartyContactMethodBObj.getLocationGroupLastUpdateDate());
			inputPartyContactMethodBObj.setContactMethodGroupLastUpdateDate(foundPartyContactMethodBObj.getContactMethodGroupLastUpdateDate());
			inputPartyContactMethodBObj.getTCRMContactMethodBObj().setContactMethodLastUpdateDate(foundPartyContactMethodBObj.getTCRMContactMethodBObj().getContactMethodLastUpdateDate());
			if (isPhone) {
			inputPartyContactMethodBObj.getTCRMContactMethodBObj().getTCRMPhoneNumberBObj().setPhoneLastUpdateDate(foundPartyContactMethodBObj.getTCRMContactMethodBObj().getTCRMPhoneNumberBObj().getPhoneLastUpdateDate());
			}
		} catch (Exception e1) {
			DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                    "INSERR",
                    MTTServicesErrorReasonCode.CONTACTMETHOD_FAILED,
                    control, new String[0]);
					throw new BusinessProxyException(error.getErrorMessage(), e1);
		}
		// Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent updatePartyCMRequest = new DWLTransactionPersistent();
        updatePartyCMRequest.setTxnControl(control);
        updatePartyCMRequest.setTxnType("updatePartyContactMethod");
        updatePartyCMRequest.setTxnTopLevelObject(inputPartyContactMethodBObj);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse updatePartyCMResponse = null;
        
        try {
        	updatePartyCMResponse = (DWLResponse) super.execute(updatePartyCMRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.CONTACTMETHOD_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }
        
        if (updatePartyCMResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.CONTACTMETHOD_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (updatePartyCMResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	DWLStatus dwlStatus = updatePartyCMResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }		
	}
	private void handlePartyAddressUpdate(
			TCRMPartyAddressBObj inputPartyAddress, TCRMPartyAddressBObj foundPartyAddress, String partyId, DWLControl control) throws BusinessProxyException {
		
		inputPartyAddress.setControl(control);
		inputPartyAddress.setPartyId(partyId);
		inputPartyAddress.setPartyAddressIdPK(foundPartyAddress.getPartyAddressIdPK());
		inputPartyAddress.setAddressId(foundPartyAddress.getAddressId());
		inputPartyAddress.getTCRMAddressBObj().setAddressIdPK(foundPartyAddress.getTCRMAddressBObj().getAddressIdPK());
		try {
			inputPartyAddress.setLocationGroupLastUpdateDate(foundPartyAddress.getLocationGroupLastUpdateDate());
			inputPartyAddress.setAddressGroupLastUpdateDate(foundPartyAddress.getAddressGroupLastUpdateDate());		
			inputPartyAddress.getTCRMAddressBObj().setAddressLastUpdateDate(foundPartyAddress.getTCRMAddressBObj().getAddressLastUpdateDate());
		} catch (Exception e1) {
			DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                    "INSERR",
                    MTTServicesErrorReasonCode.ADDRESS_FAILED,
                    control, new String[0]);
					throw new BusinessProxyException(error.getErrorMessage(), e1);
		}
		// Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent updatePartyAddrRequest = new DWLTransactionPersistent();
        updatePartyAddrRequest.setTxnControl(control);
        updatePartyAddrRequest.setTxnType("updatePartyAddress");
        updatePartyAddrRequest.setTxnTopLevelObject(inputPartyAddress);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse updatePartyAddrResponse = null;        
        try {
        	updatePartyAddrResponse = (DWLResponse) super.execute(updatePartyAddrRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.ADDRESS_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }        
        if (updatePartyAddrResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.ADDRESS_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (updatePartyAddrResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	DWLStatus dwlStatus = updatePartyAddrResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }		
	}	
	private void resolveIDForRole(TCRMContractPartyRoleBObj inputContrRole,
			DWLControl control) throws BusinessProxyException {
		
		TCRMPartyBObj inputParty = new TCRMPartyBObj();
		inputParty = (TCRMPartyBObj) inputContrRole.getTCRMPartyBObj();
		
		Vector vecAdminContequiv = new Vector<>();
		vecAdminContequiv = (Vector) inputParty.getItemsTCRMAdminContEquivBObj();
		
		if (vecAdminContequiv.size() > 0 && vecAdminContequiv != null) {
			for (int k=0; k < vecAdminContequiv.size(); k++) {
				TCRMAdminContEquivBObj inputAdminContequiv = new TCRMAdminContEquivBObj();
				inputAdminContequiv = (TCRMAdminContEquivBObj) vecAdminContequiv.elementAt(k);
				
				String systemId = inputAdminContequiv.getAdminPartyId();
				String systemType = inputAdminContequiv.getAdminSystemType();
				
				Vector<Object> getAdminContequivInput = new Vector<Object>();

				getAdminContequivInput.add(0, systemType);
				getAdminContequivInput.add(1, systemId);
				getAdminContequivInput.add(2, MTTServicesComponentID.PARTY_INQ_LVL);

				// Prepare a new DWLTransactionInquiry instance.
				DWLTransactionInquiry getAdminContequivRequest = new DWLTransactionInquiry();
				getAdminContequivRequest.setTxnControl(control);
				getAdminContequivRequest.setTxnType("getPartyByAdminSysKey");
				getAdminContequivRequest.setStringParameters(getAdminContequivInput);

				// Prepare a reference to hold the response for this transaction.
				DWLResponse getAdminContequivResponse = null;

				// Invoke the "getPartyByAdminSysKey" transaction.
				try {
					getAdminContequivResponse = (DWLResponse) super
							.execute(getAdminContequivRequest);
				} catch (BusinessProxyException e) {
					DWLError error = errHandler.getErrorMessage(
							MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
							"READERR", MTTServicesErrorReasonCode.GETPARTYBYADMINSYSKEY_FAILED,
							control, new String[0]);
					throw new BusinessProxyException(error.getErrorMessage() + " System ID is :: " + systemId, e);
				}

				if (getAdminContequivResponse == null) {
					DWLError error = errHandler.getErrorMessage(
							MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
							"READERR", MTTServicesErrorReasonCode.GETPARTYBYADMINSYSKEY_FAILED,
							control, new String[0]);
					throw new BusinessProxyException(error.getErrorMessage() + " System ID is :: " + systemId);
				}
				TCRMOrganizationBObj existingParty = (TCRMOrganizationBObj) getAdminContequivResponse.getData();
				if (existingParty != null) {
				inputContrRole.setPartyId(existingParty.getPartyId());
				// Clear Party BObj for Location
				inputContrRole.setTCRMPartyBObj(null);
				} else {
					DWLError error = errHandler.getErrorMessage(
							MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
							"READERR", MTTServicesErrorReasonCode.GETPARTYBYADMINSYSKEY_FAILED,
							control, new String[0]);
					throw new BusinessProxyException(error.getErrorMessage()  + " System ID is :: " + systemId);
				}
					
			}
		}		
	}
	private void handleCreditTaxAdd(MTTActCreditTaxBObj addMTTActCreditTaxInput,
			MetcashAccountBObj mainOutput, DWLControl control) throws BusinessProxyException {
    	// STEP #2
        // START :: Handle ADD CREDIT TAX transaction
        try {
			addMTTActCreditTaxInput.setContractId(mainOutput.getTCRMContractBObj().getContractIdPK());
			addMTTActCreditTaxInput.setMTTActCreditTaxLastUpdateTxId(control.getTxnId());
			addMTTActCreditTaxInput.setMTTActCreditTaxLastUpdateUser(mainOutput.getTCRMContractBObj().getContractLastUpdateUser());
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                    "INSERR",
                    MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                    control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage(), e2);
		}
        // Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent addMTTActCreditTaxRequest = new DWLTransactionPersistent();
        addMTTActCreditTaxRequest.setTxnControl(control);
        addMTTActCreditTaxRequest.setTxnType("addMTTActCreditTax");
        addMTTActCreditTaxRequest.setTxnTopLevelObject(addMTTActCreditTaxInput);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse addMTTActCreditTaxResponse = null;
        
        // Invoke the "addMTTActCreditTax" transaction.
        try {
            addMTTActCreditTaxResponse = (DWLResponse) super.execute(addMTTActCreditTaxRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }
        
        if (addMTTActCreditTaxResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (addMTTActCreditTaxResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	
        	DWLStatus dwlStatus = addMTTActCreditTaxResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }        
        // Extract the returned business object from the response.
        if (addMTTActCreditTaxResponse.getData() != null) {
        	MTTActCreditTaxBObj addMTTActCreditTaxOutput = (MTTActCreditTaxBObj) addMTTActCreditTaxResponse.getData();        
            mainOutput.setMTTActCreditTaxBObj(addMTTActCreditTaxOutput);
            
            // END :: Handle ADD CREDIT TAX transaction
        } 
	}
	private void handleCreditTaxUpdate(MTTActCreditTaxBObj updateMTTActCreditTaxInput,
			MetcashAccountBObj mainOutput, DWLControl control) throws BusinessProxyException {
    	
    	String contractId = mainOutput.getTCRMContractBObj().getContractIdPK();
    	MTTActCreditTaxBObj foundCreditTax = new  MTTActCreditTaxBObj();
    	foundCreditTax = getExistingCreditTax(contractId, control);
    	
		if (foundCreditTax == null) {
			handleCreditTaxAdd(updateMTTActCreditTaxInput, mainOutput, control);
		}
		if (foundCreditTax != null) {    	
        try {
        	updateMTTActCreditTaxInput.setMTTActCreditTaxIdPk(foundCreditTax.getMTTActCreditTaxIdPk());
        	updateMTTActCreditTaxInput.setMTTActCreditTaxLastUpdateDate(foundCreditTax.getMTTActCreditTaxLastUpdateDate());
        	updateMTTActCreditTaxInput.setMTTActCreditTaxLastUpdateTxId(control.getTxnId());
        	updateMTTActCreditTaxInput.setMTTActCreditTaxLastUpdateUser(mainOutput.getTCRMContractBObj().getContractLastUpdateUser());
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                    "INSERR",
                    MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                    control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage(), e2);
		}
        // Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent updateMTTActCreditTaxRequest = new DWLTransactionPersistent();
        updateMTTActCreditTaxRequest.setTxnControl(control);
        updateMTTActCreditTaxRequest.setTxnType("updateMTTActCreditTax");
        updateMTTActCreditTaxRequest.setTxnTopLevelObject(updateMTTActCreditTaxInput);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse updateMTTActCreditTaxResponse = null;
        
        // Invoke the "updateMTTActCreditTax" transaction.
        try {
        	updateMTTActCreditTaxResponse = (DWLResponse) super.execute(updateMTTActCreditTaxRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }        
        if (updateMTTActCreditTaxResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (updateMTTActCreditTaxResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	
        	DWLStatus dwlStatus = updateMTTActCreditTaxResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }        
        // Extract the returned business object from the response.
        if (updateMTTActCreditTaxResponse.getData() != null) {
        	MTTActCreditTaxBObj addMTTActCreditTaxOutput = (MTTActCreditTaxBObj) updateMTTActCreditTaxResponse.getData();        
            mainOutput.setMTTActCreditTaxBObj(addMTTActCreditTaxOutput);
        	}
        }
	}
	private MTTActCreditTaxBObj getExistingCreditTax(String contractId,
			DWLControl control) throws BusinessProxyException {
		
		Vector<Object> getCreditTaxInput = new Vector<Object>();
    	getCreditTaxInput.add(0, contractId);

		// Prepare a new DWLTransactionInquiry instance.
		DWLTransactionInquiry getCreditTaxRequest = new DWLTransactionInquiry();
		getCreditTaxRequest.setTxnControl(control);
		getCreditTaxRequest.setTxnType("getAllMTTCreditTaxByID");
		getCreditTaxRequest.setStringParameters(getCreditTaxInput);

		// Prepare a reference to hold the response for this transaction.
		DWLResponse getCreditTaxResponse = null;

		// Invoke the transaction.
		try {
			getCreditTaxResponse = (DWLResponse) super
					.execute(getCreditTaxRequest);
		} catch (BusinessProxyException e) {
			DWLError error = errHandler.getErrorMessage(
					MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
					"READERR", MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
					control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage(), e);
		}    		
		MTTActCreditTaxBObj foundCreditTax = (MTTActCreditTaxBObj) getCreditTaxResponse.getData();
		if (foundCreditTax != null) {
		return foundCreditTax;
		} else {
			return null;
		}
	}
	private void handleReportingAdd (MTTActReportingBObj addMTTActReportingInput,
			MetcashAccountBObj mainOutput, DWLControl control) throws BusinessProxyException {
    	// STEP #6
        // START :: Handle ADD REPORTING transaction
        try {
			addMTTActReportingInput.setContractId(mainOutput.getTCRMContractBObj().getContractIdPK());
			addMTTActReportingInput.setMTTActReportingLastUpdateTxId(control.getTxnId());
			addMTTActReportingInput.setMTTActReportingLastUpdateUser(mainOutput.getTCRMContractBObj().getContractLastUpdateUser());
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                    "INSERR",
                    MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                    control, new String[0]);
				throw new BusinessProxyException(error.getErrorMessage(), e1);
		}

        // Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent addMTTActReportingRequest = new DWLTransactionPersistent();
        addMTTActReportingRequest.setTxnControl(control);
        addMTTActReportingRequest.setTxnType("addMTTActReporting");
        addMTTActReportingRequest.setTxnTopLevelObject(addMTTActReportingInput);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse addMTTActReportingResponse = null;
        
        // Invoke the "addMTTActReporting" transaction.
        try {
            addMTTActReportingResponse = (DWLResponse) super.execute(addMTTActReportingRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }
        
        if (addMTTActReportingResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (addMTTActReportingResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	DWLStatus dwlStatus = addMTTActReportingResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }        
        // Extract the returned business object from the response.
        if (addMTTActReportingResponse.getData() != null) {
        	MTTActReportingBObj addMTTActReportingOutput = (MTTActReportingBObj) addMTTActReportingResponse.getData();        
            mainOutput.setMTTActReportingBObj(addMTTActReportingOutput);
        	}
        // END :: Handle ADD REPORTING transaction
      }
	private void handleCostChargeAdd (MTTActCostChargesBObj addMTTActCostChargesInput,
			MetcashAccountBObj mainOutput, DWLControl control) throws BusinessProxyException {
    	// STEP #5
        // START :: Handle ADD COST CHARGE transaction
        try {
			addMTTActCostChargesInput.setContractId(mainOutput.getTCRMContractBObj().getContractIdPK());
			addMTTActCostChargesInput.setMTTActCostChargesLastUpdateTxId(mainOutput.getTCRMContractBObj().getContractLastUpdateTxId());
			addMTTActCostChargesInput.setMTTActCostChargesLastUpdateUser(mainOutput.getTCRMContractBObj().getContractLastUpdateUser());
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                    "INSERR",
                    MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                    control, new String[0]);
				throw new BusinessProxyException(error.getErrorMessage(), e1);
		}

        // Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent addMTTActCostChargesRequest = new DWLTransactionPersistent();
        addMTTActCostChargesRequest.setTxnControl(control);
        addMTTActCostChargesRequest.setTxnType("addMTTActCostCharges");
        addMTTActCostChargesRequest.setTxnTopLevelObject(addMTTActCostChargesInput);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse addMTTActCostChargesResponse = null;
        
        // Invoke the "addMTTActCostCharges" transaction.
        try {
            addMTTActCostChargesResponse = (DWLResponse) super.execute(addMTTActCostChargesRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }        
        if (addMTTActCostChargesResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (addMTTActCostChargesResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	DWLStatus dwlStatus = addMTTActCostChargesResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }
        
        // Extract the returned business object from the response.
        if (addMTTActCostChargesResponse.getData() != null) {
        	MTTActCostChargesBObj addMTTActCostChargesOutput = (MTTActCostChargesBObj) addMTTActCostChargesResponse.getData();        
            mainOutput.setMTTActCostChargesBObj(addMTTActCostChargesOutput);
        }        
        // END :: Handle ADD COST CHARGE transaction
        }
	private void handleFinancialAdd(MTTActFinancialBObj addMTTActFinancialInput,
			MetcashAccountBObj mainOutput, DWLControl control) throws BusinessProxyException {
    	// STEP #4
        // START :: Handle ADD FINANCIAL transaction
        try {
			addMTTActFinancialInput.setContractId(mainOutput.getTCRMContractBObj().getContractIdPK());
			addMTTActFinancialInput.setMTTActFinancialLastUpdateTxId(control.getTxnId());
			addMTTActFinancialInput.setMTTActFinancialLastUpdateUser(mainOutput.getTCRMContractBObj().getContractLastUpdateUser());
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                    "INSERR",
                    MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                    control, new String[0]);
				throw new BusinessProxyException(error.getErrorMessage(), e1);
		}
        // Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent addMTTActFinancialRequest = new DWLTransactionPersistent();
        addMTTActFinancialRequest.setTxnControl(control);
        addMTTActFinancialRequest.setTxnType("addMTTActFinancial");
        addMTTActFinancialRequest.setTxnTopLevelObject(addMTTActFinancialInput);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse addMTTActFinancialResponse = null;
        
        // Invoke the "addMTTActFinancial" transaction.
        try {
            addMTTActFinancialResponse = (DWLResponse) super.execute(addMTTActFinancialRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }
        
        if (addMTTActFinancialResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (addMTTActFinancialResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	DWLStatus dwlStatus = addMTTActFinancialResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }
        
        // Extract the returned business object from the response.
        if (addMTTActFinancialResponse.getData() != null) {
        	MTTActFinancialBObj addMTTActFinancialOutput = (MTTActFinancialBObj) addMTTActFinancialResponse.getData();        
            mainOutput.setMTTActFinancialBObj(addMTTActFinancialOutput);
        }
        // END :: Handle ADD FINANCIAL transaction
      }
	private void handleOrderInvoiceAdd (MTTActOrderInvoiceBObj addMTTActOrderInvoiceInput,
			MetcashAccountBObj mainOutput, DWLControl control) throws BusinessProxyException {
		
    	// STEP #3
        // START :: Handle ADD ORDER INVOICE transaction        
        try {
			addMTTActOrderInvoiceInput.setContractId(mainOutput.getTCRMContractBObj().getContractIdPK());
			addMTTActOrderInvoiceInput.setMTTActOrderInvoiceLastUpdateTxId(control.getTxnId());
			addMTTActOrderInvoiceInput.setMTTActOrderInvoiceLastUpdateUser(mainOutput.getTCRMContractBObj().getContractLastUpdateUser());
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                    "INSERR",
                    MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                    control, new String[0]);
				throw new BusinessProxyException(error.getErrorMessage(), e1);
		}

        // Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent addMTTActOrderInvoiceRequest = new DWLTransactionPersistent();
        addMTTActOrderInvoiceRequest.setTxnControl(control);
        addMTTActOrderInvoiceRequest.setTxnType("addMTTActOrderInvoice");
        addMTTActOrderInvoiceRequest.setTxnTopLevelObject(addMTTActOrderInvoiceInput);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse addMTTActOrderInvoiceResponse = null;
        
        // Invoke the "addMTTActOrderInvoice" transaction.
        try {
            addMTTActOrderInvoiceResponse = (DWLResponse) super.execute(addMTTActOrderInvoiceRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }
        
        if (addMTTActOrderInvoiceResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (addMTTActOrderInvoiceResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	DWLStatus dwlStatus = addMTTActOrderInvoiceResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }
        
        // Extract the returned business object from the response.
        if (addMTTActOrderInvoiceResponse.getData() != null) {
        	MTTActOrderInvoiceBObj addMTTActOrderInvoiceOutput = (MTTActOrderInvoiceBObj) addMTTActOrderInvoiceResponse.getData();        
            mainOutput.setMTTActOrderInvoiceBObj(addMTTActOrderInvoiceOutput);
        }
        
        // END :: Handle ADD ORDER INVOICE transaction
      }
	private void handleReportingUpdate(MTTActReportingBObj updateMTTActReportingInput,
			MetcashAccountBObj mainOutput, DWLControl control) throws BusinessProxyException {
		
    	String contractId = mainOutput.getTCRMContractBObj().getContractIdPK();
    	MTTActReportingBObj foundReporting = new  MTTActReportingBObj();
    	foundReporting = getExistingReporting(contractId, control);
    	
		if (foundReporting == null) {
			handleReportingAdd(updateMTTActReportingInput, mainOutput, control);
		}
		if (foundReporting != null) {    	
        try {
        	updateMTTActReportingInput.setMTTActReportingIdPk(foundReporting.getMTTActReportingIdPk());
        	updateMTTActReportingInput.setMTTActReportingLastUpdateDate(foundReporting.getMTTActReportingLastUpdateDate());
        	updateMTTActReportingInput.setMTTActReportingLastUpdateTxId(control.getTxnId());        	
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                    "INSERR",
                    MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                    control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage(), e2);
		}
        // Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent updateMTTActReportingRequest = new DWLTransactionPersistent();
        updateMTTActReportingRequest.setTxnControl(control);
        updateMTTActReportingRequest.setTxnType("updateMTTActReporting");
        updateMTTActReportingRequest.setTxnTopLevelObject(updateMTTActReportingInput);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse updateMTTActReportingResponse = null;
        
        // Invoke the "updateMTTActCreditTax" transaction.
        try {
        	updateMTTActReportingResponse = (DWLResponse) super.execute(updateMTTActReportingRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }        
        if (updateMTTActReportingResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (updateMTTActReportingResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	
        	DWLStatus dwlStatus = updateMTTActReportingResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }        
        // Extract the returned business object from the response.
        if (updateMTTActReportingResponse.getData() != null) {
        	MTTActReportingBObj updateMTTActReportingOutput = (MTTActReportingBObj) updateMTTActReportingResponse.getData();        
            mainOutput.setMTTActReportingBObj(updateMTTActReportingOutput);
        	}        
        }
	}
	private MTTActReportingBObj getExistingReporting(String contractId,
			DWLControl control) throws BusinessProxyException {
		
		Vector<Object> getReportingInput = new Vector<Object>();
		getReportingInput.add(0, contractId);

		// Prepare a new DWLTransactionInquiry instance.
		DWLTransactionInquiry getReportingRequest = new DWLTransactionInquiry();
		getReportingRequest.setTxnControl(control);
		getReportingRequest.setTxnType("getAllMTTReportByID");
		getReportingRequest.setStringParameters(getReportingInput);

		// Prepare a reference to hold the response for this transaction.
		DWLResponse getReportingResponse = null;

		// Invoke the transaction.
		try {
			getReportingResponse = (DWLResponse) super
					.execute(getReportingRequest);
		} catch (BusinessProxyException e) {
			DWLError error = errHandler.getErrorMessage(
					MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
					"READERR", MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
					control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage(), e);
		}    		
		MTTActReportingBObj foundReporting = (MTTActReportingBObj) getReportingResponse.getData();
		if (foundReporting != null) {
		return foundReporting;
		} else {
			return null;
		}
	
	}
	private void handleCostChargeUpdate(MTTActCostChargesBObj updateMTTActCostChargeInput,
			MetcashAccountBObj mainOutput, DWLControl control) throws BusinessProxyException {
		
    	String contractId = mainOutput.getTCRMContractBObj().getContractIdPK();
    	MTTActCostChargesBObj foundCostCharge = new  MTTActCostChargesBObj();
    	foundCostCharge = getExistingCostCharge(contractId, control);
    	
		if (foundCostCharge == null) {
			handleCostChargeAdd(updateMTTActCostChargeInput, mainOutput, control);
		}
		if (foundCostCharge != null) {    	
        try {
        	updateMTTActCostChargeInput.setMTTActCostChargesIdPk(foundCostCharge.getMTTActCostChargesIdPk());
        	updateMTTActCostChargeInput.setMTTActCostChargesLastUpdateDate(foundCostCharge.getMTTActCostChargesLastUpdateDate());
        	updateMTTActCostChargeInput.setMTTActCostChargesLastUpdateTxId(control.getTxnId());        	
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                    "INSERR",
                    MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                    control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage(), e2);
		}
        // Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent updateMTTActCostChargeRequest = new DWLTransactionPersistent();
        updateMTTActCostChargeRequest.setTxnControl(control);
        updateMTTActCostChargeRequest.setTxnType("updateMTTActCostCharges");
        updateMTTActCostChargeRequest.setTxnTopLevelObject(updateMTTActCostChargeInput);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse updateMTTActCostChargeResponse = null;
        
        // Invoke the "updateMTTActCreditTax" transaction.
        try {
        	updateMTTActCostChargeResponse = (DWLResponse) super.execute(updateMTTActCostChargeRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }        
        if (updateMTTActCostChargeResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (updateMTTActCostChargeResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	
        	DWLStatus dwlStatus = updateMTTActCostChargeResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }        
        // Extract the returned business object from the response.
        if (updateMTTActCostChargeResponse.getData() != null) {
        	MTTActCostChargesBObj updateMTTActCostChargeOutput = (MTTActCostChargesBObj) updateMTTActCostChargeResponse.getData();        
            mainOutput.setMTTActCostChargesBObj(updateMTTActCostChargeOutput);
        	}        
        }
	}
	private MTTActCostChargesBObj getExistingCostCharge(String contractId,
			DWLControl control) throws BusinessProxyException {
		
		Vector<Object> getCostChargeInput = new Vector<Object>();
		getCostChargeInput.add(0, contractId);

		// Prepare a new DWLTransactionInquiry instance.
		DWLTransactionInquiry getCostChargeRequest = new DWLTransactionInquiry();
		getCostChargeRequest.setTxnControl(control);
		getCostChargeRequest.setTxnType("getAllMTTActCostChargesByID");
		getCostChargeRequest.setStringParameters(getCostChargeInput);

		// Prepare a reference to hold the response for this transaction.
		DWLResponse getCostChargeResponse = null;

		// Invoke the transaction.
		try {
			getCostChargeResponse = (DWLResponse) super
					.execute(getCostChargeRequest);
		} catch (BusinessProxyException e) {
			DWLError error = errHandler.getErrorMessage(
					MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
					"READERR", MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
					control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage(), e);
		}    		
		MTTActCostChargesBObj foundCostCharge = (MTTActCostChargesBObj) getCostChargeResponse.getData();
		if (foundCostCharge != null) {
		return foundCostCharge;
		} else {
			return null;
		}
	}
	private void handleFinancialUpdate(MTTActFinancialBObj updateMTTActFinancialInput,
			MetcashAccountBObj mainOutput, DWLControl control) throws BusinessProxyException {
    	
    	String contractId = mainOutput.getTCRMContractBObj().getContractIdPK();
    	MTTActFinancialBObj foundFinancial = new  MTTActFinancialBObj();
    	foundFinancial = getExistingFinancial(contractId, control);
    	
		if (foundFinancial == null) {
			handleFinancialAdd(updateMTTActFinancialInput, mainOutput, control);
		}
		if (foundFinancial != null) {    	
        try {
        	updateMTTActFinancialInput.setMTTActFinancialIdPk(foundFinancial.getMTTActFinancialIdPk());
        	updateMTTActFinancialInput.setMTTActFinancialLastUpdateDate(foundFinancial.getMTTActFinancialLastUpdateDate());
        	updateMTTActFinancialInput.setMTTActFinancialLastUpdateTxId(control.getTxnId());        	
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                    "INSERR",
                    MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                    control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage(), e2);
		}
        // Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent updateMTTActFinancialRequest = new DWLTransactionPersistent();
        updateMTTActFinancialRequest.setTxnControl(control);
        updateMTTActFinancialRequest.setTxnType("updateMTTActFinancial");
        updateMTTActFinancialRequest.setTxnTopLevelObject(updateMTTActFinancialInput);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse updateMTTActFinancialResponse = null;
        
        // Invoke the "updateMTTActCreditTax" transaction.
        try {
        	updateMTTActFinancialResponse = (DWLResponse) super.execute(updateMTTActFinancialRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }        
        if (updateMTTActFinancialResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (updateMTTActFinancialResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	
        	DWLStatus dwlStatus = updateMTTActFinancialResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }        
        // Extract the returned business object from the response.
        if (updateMTTActFinancialResponse.getData() != null) {
        	MTTActFinancialBObj updateMTTActFinancialOutput = (MTTActFinancialBObj) updateMTTActFinancialResponse.getData();        
            mainOutput.setMTTActFinancialBObj(updateMTTActFinancialOutput);
        	}
        }
	}
	private void handleOrderInvoiceUpdate(MTTActOrderInvoiceBObj updateMTTActOrderInvoiceInput,
			MetcashAccountBObj mainOutput, DWLControl control) throws BusinessProxyException {
		
    	String contractId = mainOutput.getTCRMContractBObj().getContractIdPK();
    	MTTActOrderInvoiceBObj foundOrderInvoice = new  MTTActOrderInvoiceBObj();
    	foundOrderInvoice = getExistingOrderInvoice(contractId, control);
    	
		if (foundOrderInvoice == null) {
			handleOrderInvoiceAdd(updateMTTActOrderInvoiceInput, mainOutput, control);
		}
		if (foundOrderInvoice != null) {    	
        try {
        	updateMTTActOrderInvoiceInput.setMTTActOrderInvoiceIdPk(foundOrderInvoice.getMTTActOrderInvoiceIdPk());
        	updateMTTActOrderInvoiceInput.setMTTActOrderInvoiceLastUpdateDate(foundOrderInvoice.getMTTActOrderInvoiceLastUpdateDate());
        	updateMTTActOrderInvoiceInput.setMTTActOrderInvoiceLastUpdateTxId(control.getTxnId());        	
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                    "INSERR",
                    MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                    control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage(), e2);
		}
        // Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent updateMTTActOrderInvoiceRequest = new DWLTransactionPersistent();
        updateMTTActOrderInvoiceRequest.setTxnControl(control);
        updateMTTActOrderInvoiceRequest.setTxnType("updateMTTActOrderInvoice");
        updateMTTActOrderInvoiceRequest.setTxnTopLevelObject(updateMTTActOrderInvoiceInput);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse updateMTTActOrderInvoiceResponse = null;
        
        // Invoke the "updateMTTActCreditTax" transaction.
        try {
        	updateMTTActOrderInvoiceResponse = (DWLResponse) super.execute(updateMTTActOrderInvoiceRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }        
        if (updateMTTActOrderInvoiceResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (updateMTTActOrderInvoiceResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	
        	DWLStatus dwlStatus = updateMTTActOrderInvoiceResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }        
        // Extract the returned business object from the response.
        if (updateMTTActOrderInvoiceResponse.getData() != null) {
        	MTTActOrderInvoiceBObj updateMTTActOrderInvoiceOutput = (MTTActOrderInvoiceBObj) updateMTTActOrderInvoiceResponse.getData();        
            mainOutput.setMTTActOrderInvoiceBObj(updateMTTActOrderInvoiceOutput);
        	}
        }
	}
	private MTTActFinancialBObj getExistingFinancial(String contractId,
			DWLControl control) throws BusinessProxyException {
		Vector<Object> getFinancialInput = new Vector<Object>();
		getFinancialInput.add(0, contractId);

		// Prepare a new DWLTransactionInquiry instance.
		DWLTransactionInquiry getFinancialRequest = new DWLTransactionInquiry();
		getFinancialRequest.setTxnControl(control);
		getFinancialRequest.setTxnType("getAllMTTActFinancialbyID");
		getFinancialRequest.setStringParameters(getFinancialInput);

		// Prepare a reference to hold the response for this transaction.
		DWLResponse getFinancialResponse = null;

		// Invoke the transaction.
		try {
			getFinancialResponse = (DWLResponse) super
					.execute(getFinancialRequest);
		} catch (BusinessProxyException e) {
			DWLError error = errHandler.getErrorMessage(
					MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
					"READERR", MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
					control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage(), e);
		}    		
		MTTActFinancialBObj foundFinancial = (MTTActFinancialBObj) getFinancialResponse.getData();
		if (foundFinancial != null) {
		return foundFinancial;
		} else {
			return null;
		}
	}
	private MTTActOrderInvoiceBObj getExistingOrderInvoice(String contractId,
			DWLControl control) throws BusinessProxyException {
		
		Vector<Object> getOrderInvoiceInput = new Vector<Object>();
		getOrderInvoiceInput.add(0, contractId);

		// Prepare a new DWLTransactionInquiry instance.
		DWLTransactionInquiry getOrderInvoiceRequest = new DWLTransactionInquiry();
		getOrderInvoiceRequest.setTxnControl(control);
		getOrderInvoiceRequest.setTxnType("getAllMTTOrderInvoiceByID");
		getOrderInvoiceRequest.setStringParameters(getOrderInvoiceInput);

		// Prepare a reference to hold the response for this transaction.
		DWLResponse getOrderInvoiceResponse = null;

		// Invoke the transaction.
		try {
			getOrderInvoiceResponse = (DWLResponse) super
					.execute(getOrderInvoiceRequest);
		} catch (BusinessProxyException e) {
			DWLError error = errHandler.getErrorMessage(
					MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
					"READERR", MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
					control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage(), e);
		}    		
		MTTActOrderInvoiceBObj foundOrderInvoice = (MTTActOrderInvoiceBObj) getOrderInvoiceResponse.getData();
		if (foundOrderInvoice != null) {
		return foundOrderInvoice;
		} else {
			return null;
		}
	}
	private void handleContractValueUpdate(Vector vecInputContractValue,
			MetcashAccountBObj mainOutput, DWLControl control) throws BusinessProxyException {
		
		Vector vecFoundContractValue = new Vector();
		String contractId = mainOutput.getTCRMContractBObj().getContractIdPK();
		vecFoundContractValue = getExistingContractValue(contractId, control);
    	
    	if (vecFoundContractValue == null) {
			handleContractValueAdd(vecInputContractValue, mainOutput, control);
		}
		
		if (vecFoundContractValue != null && vecFoundContractValue.size() > 0) {
    	Vector vecContractValueAdd = new Vector();
    	Vector vecContractValueUpdate = new Vector();
    	
    	for (int k=0; k < vecInputContractValue.size(); k++) {
    		boolean isResolved = false;
    		TCRMContractValueBObj inputContractValue = new TCRMContractValueBObj();
    		inputContractValue = (TCRMContractValueBObj) vecInputContractValue.elementAt(k);
    		for (int l=0; l < vecFoundContractValue.size(); l++) {
    			TCRMContractValueBObj foundContractValue = new TCRMContractValueBObj();
    			foundContractValue = (TCRMContractValueBObj) vecFoundContractValue.elementAt(l);
    			try {
					if (inputContractValue.isBusinessKeySame(foundContractValue)) {
						inputContractValue.setControl(control);
						inputContractValue.setContractId(foundContractValue.getContractId());
						inputContractValue.setContractValueId(foundContractValue.getContractValueId());
						inputContractValue.setContractValueLastUpdateDate(foundContractValue.getContractValueLastUpdateDate());
						inputContractValue.setContractValueLastUpdateTxId(control.getTxnId()); 
						vecContractValueUpdate.add(inputContractValue);
						isResolved = true;
						break;
					}
				} catch (DWLBaseException e) {
					throw new BusinessProxyException(e.getMessage());
				} catch (Exception e) {
					throw new BusinessProxyException(e.getMessage());
				}
    		} if (!isResolved) {						
				vecContractValueAdd.add(inputContractValue);
    		}
    	}
    	if (vecContractValueAdd != null && vecContractValueAdd.size() > 0) {
    		handleContractValueAdd (vecContractValueAdd, mainOutput, control);
    	}
    	if (vecContractValueUpdate != null && vecContractValueUpdate.size() > 0) {    		
    		Vector vecOutputContractValueUpdt = new Vector();	        
            for (int i=0; i < vecContractValueUpdate.size(); i++) {
            	TCRMContractValueBObj updateContractValueInput = new TCRMContractValueBObj();
            	updateContractValueInput = (TCRMContractValueBObj) vecContractValueUpdate.elementAt(i);
            	
            // Prepare a new DWLTransactionPersistent instance.
            DWLTransactionPersistent updateContractValueRequest = new DWLTransactionPersistent();
            updateContractValueRequest.setTxnControl(control);
            updateContractValueRequest.setTxnType("updateContractValue");
            updateContractValueRequest.setTxnTopLevelObject(updateContractValueInput);
            
            // Prepare a reference to hold the response for this transaction.
            DWLResponse updateContractValueResponse = null;
            
            // Invoke the "addMTTActOrderInvoice" transaction.
            try {
            	updateContractValueResponse = (DWLResponse) super.execute(updateContractValueRequest);
            }
            catch (BusinessProxyException e) {
                DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                            "INSERR",
                                                            MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                            control, new String[0]);
                throw new BusinessProxyException(error.getErrorMessage(), e);
            }
            
            if (updateContractValueResponse == null)  {
                DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                            "INSERR",
                                                            MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                            control, new String[0]);
                throw new BusinessProxyException(error.getErrorMessage());
            }
            else if (updateContractValueResponse.getStatus().getStatus() == DWLStatus.FATAL) {
            	DWLStatus dwlStatus = updateContractValueResponse.getStatus();
            	Vector vecError = dwlStatus.getDwlErrorGroup();
            	DWLError dwlError = (DWLError) vecError.get(0);
            	
            	throw new BusinessProxyException(dwlError.getErrorMessage());
            }
            
            // Extract the returned business object from the response.
            if (updateContractValueResponse.getData() != null) {
            	vecOutputContractValueUpdt.add(updateContractValueResponse.getData());        	
            	}
            }        
            if (vecOutputContractValueUpdt != null && vecOutputContractValueUpdt.size() > 0) {
            	for (int j=0; j < vecOutputContractValueUpdt.size(); j++) {
            		TCRMContractValueBObj updateContractValueOutput = new TCRMContractValueBObj();
            		updateContractValueOutput = (TCRMContractValueBObj) vecOutputContractValueUpdt.elementAt(j);
                	mainOutput.getTCRMContractBObj().setTCRMContractValueBObj(updateContractValueOutput);
            		}
            	}
    		}
		}		
	}	
	private Vector getExistingContractValue(String contractId,
			DWLControl control) throws BusinessProxyException {
		
		Vector vecExistingContractValue = new Vector();
		Vector<Object> getContractValueInput = new Vector<Object>();
		getContractValueInput.add(0, contractId);
		getContractValueInput.add(1, MTTServicesComponentID.FILTER_FOR_GET);

		// Prepare a new DWLTransactionInquiry instance.
		DWLTransactionInquiry getContractValueRequest = new DWLTransactionInquiry();
		getContractValueRequest.setTxnControl(control);
		getContractValueRequest.setTxnType("getAllContractValues");
		getContractValueRequest.setStringParameters(getContractValueInput);

		// Prepare a reference to hold the response for this transaction.
		DWLResponse getContractValueResponse = null;

		// Invoke the transaction.
		try {
			getContractValueResponse = (DWLResponse) super
					.execute(getContractValueRequest);
		} catch (BusinessProxyException e) {
			DWLError error = errHandler.getErrorMessage(
					MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
					"READERR", MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
					control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage(), e);
		}
		if (getContractValueResponse.getData() != null) {
			if (getContractValueResponse.getData() instanceof Vector) {
				vecExistingContractValue = (Vector) getContractValueResponse.getData();
			}
		}
		return vecExistingContractValue;	
	}
	private void handleContractValueAdd(Vector vecInputContractValue,
			MetcashAccountBObj mainOutput, DWLControl control) throws BusinessProxyException {
		
    	Vector vecOutputContractValue = new Vector();
    	        
        for (int i=0; i < vecInputContractValue.size(); i++) {
        	TCRMContractValueBObj addContractValueInput = new TCRMContractValueBObj();
        	addContractValueInput.setControl(control);
        	addContractValueInput = (TCRMContractValueBObj) vecInputContractValue.elementAt(i);
        	addContractValueInput.setContractId(mainOutput.getTCRMContractBObj().getContractIdPK());
        	addContractValueInput.setContractValueLastUpdateTxId(control.getTxnId());        		
        	
        // Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent addContractValueRequest = new DWLTransactionPersistent();
        addContractValueRequest.setTxnControl(control);
        addContractValueRequest.setTxnType("addContractValue");
        addContractValueRequest.setTxnTopLevelObject(addContractValueInput);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse addContractValueResponse = null;
        
        // Invoke the "addMTTActOrderInvoice" transaction.
        try {
        	addContractValueResponse = (DWLResponse) super.execute(addContractValueRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }
        
        if (addContractValueResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (addContractValueResponse.getStatus().getStatus() == DWLStatus.FATAL) {
        	DWLStatus dwlStatus = addContractValueResponse.getStatus();
        	Vector vecError = dwlStatus.getDwlErrorGroup();
        	DWLError dwlError = (DWLError) vecError.get(0);
        	
        	throw new BusinessProxyException(dwlError.getErrorMessage());
        }
        
        // Extract the returned business object from the response.
        if (addContractValueResponse.getData() != null) {
        	vecOutputContractValue.add(addContractValueResponse.getData());        	
        		}
        	}        
        if (vecOutputContractValue != null && vecOutputContractValue.size() > 0) {
        	for (int j=0; j < vecOutputContractValue.size(); j++) {
        		TCRMContractValueBObj addContractValueOutput = new TCRMContractValueBObj();
            	addContractValueOutput = (TCRMContractValueBObj) vecOutputContractValue.elementAt(j);
            	mainOutput.getTCRMContractBObj().setTCRMContractValueBObj(addContractValueOutput);
        	}
        }        
	}
        
         		
		
	
			/*private void triggerEventForContract(String contractIdPK, DWLControl control) throws BusinessProxyException {
	
			ProcessControlBObj inpProcessControl = new ProcessControlBObj();
			ProcessActionBObj inpProcessAction = new ProcessActionBObj();
	
			inpProcessAction.setControl(control);
			inpProcessAction.setEventStatus(MTTEMConstant.EM_STATUS);
			inpProcessAction.setEventCatCode(MTTEMConstant.EM_EVENTCAT);
			inpProcessAction.setEntityName(MTTEMConstant.EM_ENTITY_CONTRACT);
			inpProcessAction.setInstancePK(contractIdPK);
	
			inpProcessControl.setControl(control);
			inpProcessControl.setEntityName(MTTEMConstant.EM_ENTITY_CONTRACT);
			inpProcessControl.setInstancePK(contractIdPK);
			inpProcessControl.setProdEntityId(MTTEMConstant.EM_PRODENTITY_ID);
			inpProcessControl.setProcessActionBObj(inpProcessAction);
			
			DWLTransactionPersistent addEMRequest = new DWLTransactionPersistent();
			addEMRequest.setTxnControl(control);
			addEMRequest.setTxnType("addProcessControl");
			addEMRequest.setTxnTopLevelObject(inpProcessControl);
	        
	        // Prepare a reference to hold the response for this transaction.
	        DWLResponse addEMResponse = null;
	        
	        // Invoke the "addMTTActCreditTax" transaction.
	        try {
	        	addEMResponse = (DWLResponse) super.execute(addEMRequest);
	        }
	        catch (BusinessProxyException e) {
	            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
	                                                        "INSERR",
	                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
	                                                        control, new String[0]);
	            throw new BusinessProxyException(error.getErrorMessage(), e);
	        }
	        
	        if (addEMResponse == null)  {
	            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTACCOUNT_BUSINESS_PROXY,
	                                                        "INSERR",
	                                                        MTTServicesErrorReasonCode.MAINTAINMTTACCOUNT_FAILED,
	                                                        control, new String[0]);
	            throw new BusinessProxyException(error.getErrorMessage());
	        }
	        else if (addEMResponse.getStatus().getStatus() == DWLStatus.FATAL) {
	        	
	        	DWLStatus dwlStatus = addEMResponse.getStatus();
	        	Vector vecError = dwlStatus.getDwlErrorGroup();
	        	DWLError dwlError = (DWLError) vecError.get(0);
	        	
	        	throw new BusinessProxyException(dwlError.getErrorMessage());
	        }
	
		}*/
	
	
	}