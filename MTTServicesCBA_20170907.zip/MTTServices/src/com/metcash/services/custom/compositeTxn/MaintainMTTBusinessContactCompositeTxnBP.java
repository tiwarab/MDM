/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[a54c23ed6c6570575a283456c432a8dc]
 */

package com.metcash.services.custom.compositeTxn;

import com.dwl.base.DWLCommon;
import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLStatus;
import com.dwl.base.requestHandler.DWLTransactionPersistent;
import com.dwl.base.requestHandler.DWLTxnBP;
import com.dwl.tcrm.common.TCRMResponse;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.dwl.unifi.tx.exception.BusinessProxyException;


import com.dwl.base.DWLControl;
import com.dwl.base.DWLResponse;

import com.dwl.tcrm.coreParty.component.TCRMPersonBObj;

import com.metcash.services.custom.component.MetcashBusinessContactBObj;

import com.metcash.services.custom.constant.MTTServicesComponentID;
import com.metcash.services.custom.constant.MTTServicesErrorReasonCode;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * 
 * @generated
 */
public class MaintainMTTBusinessContactCompositeTxnBP  extends DWLTxnBP {

	/**
	 * @generated
	 **/
	private IDWLErrorMessage errHandler;
	
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(MaintainMTTBusinessContactCompositeTxnBP.class);
	/**
	 * @generated
	 **/
    public MaintainMTTBusinessContactCompositeTxnBP() {
        super();
        errHandler = TCRMClassFactory.getErrorHandler();
    }
	/**
	 * @generated NOT
	 **/
    public Object execute(Object inputObj) throws BusinessProxyException {
    logger.finest("ENTER Object execute(Object inputObj)");

        TCRMResponse outputTxnObj = null;
        DWLTransactionPersistent inputTxnObj = (DWLTransactionPersistent) inputObj;
        DWLControl control = inputTxnObj.getTxnControl();
        DWLCommon topLevelObject = (DWLCommon) inputTxnObj.getTxnTopLevelObject();
        if (!(topLevelObject instanceof MetcashBusinessContactBObj)) {
            // MDM_TODO0: CDKWB0014I optionally use a more appropriate error code than
            // "MAINTAINMTTBUSINESSCONTACT_FAILED".
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTBUSINESS_CONTACT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTBUSINESSCONTACT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        
        MetcashBusinessContactBObj mainInput = (MetcashBusinessContactBObj) topLevelObject;
        
        
        // Handle transaction "addPerson"

        // MDM_TODO: CDKWB0016I Populate the mandatory fields of "addPersonInput".
        TCRMPersonBObj addPersonInput = new TCRMPersonBObj();
        addPersonInput.setControl(control);
        
        addPersonInput = (TCRMPersonBObj) mainInput.getTCRMPersonBObj();

        // Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent addPersonRequest = new DWLTransactionPersistent();
        addPersonRequest.setTxnControl(control);
        addPersonRequest.setTxnType("addPerson");
        addPersonRequest.setTxnTopLevelObject(addPersonInput);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse addPersonResponse = null;
        
        // Invoke the "addPerson" transaction.
        try {
            addPersonResponse = (DWLResponse) super.execute(addPersonRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTBUSINESS_CONTACT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTBUSINESSCONTACT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }
        
        if (addPersonResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTAIN_MTTBUSINESS_CONTACT_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTAINMTTBUSINESSCONTACT_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (addPersonResponse.getStatus().getStatus() == DWLStatus.FATAL) {
            DWLStatus status = addPersonResponse.getStatus();
            TCRMResponse errResponse = new TCRMResponse();
            errResponse.setStatus(status);
            return errResponse;
        }
        
        // Extract the returned business object from the response.
        TCRMPersonBObj addPersonOutput = (TCRMPersonBObj) addPersonResponse.getData();
        
        
        // MDM_TODO: CDKWB0013I build the response Bobj.
        MetcashBusinessContactBObj mainOutput = new MetcashBusinessContactBObj();
        mainOutput.setControl(control);
        
        mainOutput.setTCRMPersonBObj(addPersonOutput);

        // Construct the response object.
        DWLStatus outputStatus = new DWLStatus();
        outputStatus.setStatus(DWLStatus.SUCCESS);
        outputTxnObj = new TCRMResponse();
        outputTxnObj.setStatus(outputStatus);
        outputTxnObj.setData(mainOutput);
    logger.finest("RETURN Object execute(Object inputObj)");
        return outputTxnObj;
    }
}


