package com.metcash.services.custom.constant;

public class MTTEMConstant {
	
	public final static String EM_PRODENTITY_ID = "12";
    
    public final static String EM_STATUS = "3";
    
    public final static String EM_EVENTCAT = "1000001";
    
    public final static String EM_ENTITY_CONTRACT = "CONTRACT";

}
