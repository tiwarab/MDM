
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[458bd8ac23cd4ed66d6a5ef59dbfca45]
 */

package com.metcash.services.custom.component;

import com.dwl.tcrm.common.TCRMCommon;
import com.dwl.base.error.DWLStatus;
import com.dwl.tcrm.common.ITCRMValidation;
import com.dwl.base.DWLControl;


import com.dwl.tcrm.financial.component.TCRMContractPartyRoleBObj;

import com.metcash.db.custom.component.MTTIdentifierBObj;
import com.metcash.services.custom.component.MetcashIdentifierBObj;
import com.metcash.db.custom.component.MTTStoreBObj;
import com.metcash.services.custom.component.MetcashBusinessContactBObj;
import com.metcash.services.custom.component.MetcashLegalEntityBObj;
import com.metcash.services.custom.component.MetcashLocationBObj;

import com.metcash.services.custom.component.MetcashStoreBObj;
import com.metcash.services.custom.constant.MTTServicesComponentID;
import java.util.Vector;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>MetcashAccountRoleBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 
@SuppressWarnings("serial")
public class MetcashAccountRoleBObj extends TCRMCommon  {

	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(MetcashAccountRoleBObj.class);
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected TCRMContractPartyRoleBObj TCRMContractPartyRoleBObj;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected MTTStoreBObj MTTStoreBObj;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    @SuppressWarnings("rawtypes")
    protected Vector vecMetcashIdentifierBObj;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    @SuppressWarnings("rawtypes")
    public MetcashAccountRoleBObj() {
        super();
        init();

        vecMetcashIdentifierBObj = new Vector();
        setComponentID(MTTServicesComponentID.METCASH_ACCOUNT_ROLE_BOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
    }


/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the TCRMContractPartyRoleBObj attribute.
     * 
     * @generated
     */
    public TCRMContractPartyRoleBObj getTCRMContractPartyRoleBObj (){
      return TCRMContractPartyRoleBObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public void setTCRMContractPartyRoleBObj(TCRMContractPartyRoleBObj newBObj ) {
    TCRMContractPartyRoleBObj = newBObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTStoreBObj attribute.
     * 
     * @generated
     */
    public MTTStoreBObj getMTTStoreBObj (){
      return MTTStoreBObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    @SuppressWarnings("unchecked")
    public void setMTTStoreBObj(MTTStoreBObj newBObj ) {
    MTTStoreBObj = newBObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MetcashIdentifierBObj attribute.
     * 
     * @generated
     */
    @SuppressWarnings("rawtypes")
    public Vector getItemsMetcashIdentifierBObj (){
      return vecMetcashIdentifierBObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    @SuppressWarnings("unchecked")
    public void setMetcashIdentifierBObj(MetcashIdentifierBObj newBObj ) {
        vecMetcashIdentifierBObj.addElement( newBObj );
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateAdd(int level, DWLStatus status)");

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

            TCRMContractPartyRoleBObj contractPartyRole = getTCRMContractPartyRoleBObj();
            if( contractPartyRole != null ){
            	status = contractPartyRole.validateAdd(level, status);
            }

            MTTStoreBObj mTTStore = getMTTStoreBObj();
            if( mTTStore != null ){
            	status = mTTStore.validateAdd(level, status);
            }

            for (int i = 0; i < getItemsMetcashIdentifierBObj().size(); i++) {
                MetcashIdentifierBObj metcashIdentifier = (MetcashIdentifierBObj) getItemsMetcashIdentifierBObj().elementAt(i);
                status = metcashIdentifier.validateAdd(level, status);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateAdd(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");
        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction
           TCRMContractPartyRoleBObj contractPartyRole = (TCRMContractPartyRoleBObj) getTCRMContractPartyRoleBObj();
           if( contractPartyRole != null ){
           		if (contractPartyRole.getEObjContractRole().getPrimaryKey() == null) {
               		status = contractPartyRole.validateAdd(level, status);
           		} else  {
               		status = contractPartyRole.validateUpdate(level, status);
           		}
           }
           MTTStoreBObj mTTStore = (MTTStoreBObj) getMTTStoreBObj();
           if( mTTStore != null ){
           		if (mTTStore.getEObjMTTStore().getPrimaryKey() == null) {
               		status = mTTStore.validateAdd(level, status);
           		} else  {
               		status = mTTStore.validateUpdate(level, status);
           		}
           }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
      String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
        }
        if (logger.isFinestEnabled()) {
      	String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }
    


}


