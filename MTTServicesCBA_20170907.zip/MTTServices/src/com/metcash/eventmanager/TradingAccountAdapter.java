package com.metcash.eventmanager;

import java.io.Serializable;
import java.util.HashMap;

import com.dwl.base.requestHandler.beans.DWLServiceControllerLocal;
import com.dwl.base.requestHandler.beans.DWLServiceControllerLocalHome;
import com.dwl.commoncomponents.eventmanager.DataObjectCollection;
import com.dwl.commoncomponents.eventmanager.EMException;
import com.dwl.commoncomponents.eventmanager.IEventBusinessAdapter;
import com.metcash.services.custom.component.MetcashAccountBObj;

public class TradingAccountAdapter implements IEventBusinessAdapter {
	
	/** The first portion of the constructed XML for getContract transaction */
	public static String XML_BEGIN = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><TCRMService xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns=\"http://www.ibm.com/mdm/schema\" xsi:schemaLocation=\"http://www.ibm.com/mdm/schema MDMDomains.xsd\"><RequestControl><requestID>100189</requestID><DWLControl><requesterName>cusadmin</requesterName><requesterLanguage>100</requesterLanguage></DWLControl></RequestControl><TCRMInquiry><InquiryType>getMTTAccount</InquiryType><InquiryParam><tcrmParam name=\"contractId\">";
	/** The last portion of the constructed XML for getContract transaction */
	public static final String XML_END = "</tcrmParam><tcrmParam name=\"ContractInquiryLevel\">4</tcrmParam><tcrmParam name=\"PartyInquiryLevel\">3</tcrmParam></InquiryParam></TCRMInquiry></TCRMService>";	
	/** JNDI Name for CONTRACT */
	public final static String CONTRACT_JNDI_NAME="com/dwl/base/requestHandler/beans/DWLServiceController";	
	/** The entity name of <code>CONTRACT</code>. */
	public final static String ENTITY_NAME_FOR_CONTRACT = "TRADING_ACCOUNT";
	
	@Override
	public DataObjectCollection getDataObjects(Serializable transObj, String busObjKey,
			String busEntity) throws EMException {
		
		try {
			return getContractData(busObjKey);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}	
	public DataObjectCollection getContractData(String busObjKey)
			throws Exception {
				
				DataObjectCollection coll = new DataObjectCollection();
				com.dwl.base.util.ServiceLocator wccServiceLocator = com.dwl.base.util.ServiceLocator.getInstance();
				DWLServiceControllerLocalHome homeInterface = (DWLServiceControllerLocalHome) wccServiceLocator.getLocalHome(CONTRACT_JNDI_NAME);
				DWLServiceControllerLocal serviceController = homeInterface.create();

				HashMap hash = new HashMap();
				hash.put("RequestType", "standard");
				hash.put("TargetApplication", "tcrm");
				hash.put("ResponseType", "standard");
				hash.put("Constructor", "NullConstructor");
				
				// Security Mechanism: Setting the channel flag for special handling.
				// hash.put(SecurityUtil.CHANNEL, SecurityUtil.Channel_EM);

				StringBuffer strBuff = new StringBuffer(560);
				strBuff.append(XML_BEGIN);
				// Contract ID comes from task object
				strBuff.append(busObjKey);
				// append end of XML
				strBuff.append(XML_END);				

				MetcashAccountBObj managedAccount = (MetcashAccountBObj)serviceController.processRequest(hash, strBuff.toString());				
				if (managedAccount != null) {
				coll.add((Serializable)managedAccount, ENTITY_NAME_FOR_CONTRACT, busObjKey);
				return coll;
				} 
				return null;
			}
	}