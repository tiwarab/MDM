/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[8dc67bd04bed4f5a426e0fa6d2666c8c]
 */

package com.metcash.services.custom.compositeTxn;

import com.dwl.base.DWLCommon;
import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLStatus;
import com.dwl.base.requestHandler.DWLTransactionPersistent;
import com.dwl.base.requestHandler.DWLTxnBP;
import com.dwl.tcrm.common.TCRMResponse;
import com.dwl.tcrm.coreParty.component.TCRMPartyIdentificationBObj;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.dwl.unifi.tx.exception.BusinessProxyException;
import com.dwl.base.DWLControl;
import com.dwl.base.DWLResponse;
import com.dwl.base.requestHandler.DWLTransactionInquiry;
import com.dwl.base.util.DWLDateTimeUtilities;
import com.dwl.tcrm.financial.component.TCRMContractBObj;
import com.dwl.tcrm.financial.component.TCRMContractComponentBObj;
import com.dwl.tcrm.financial.component.TCRMContractPartyRoleBObj;
import com.dwl.tcrm.financial.component.TCRMContractPartyRoleIdentifierBObj;
import com.dwl.tcrm.financial.component.TCRMContractRoleLocationBObj;
import com.metcash.db.custom.component.MTTActCostChargesBObj;
import com.metcash.db.custom.component.MTTActCreditTaxBObj;
import com.metcash.db.custom.component.MTTActFinancialBObj;
import com.metcash.db.custom.component.MTTActOrderInvoiceBObj;
import com.metcash.db.custom.component.MTTActReportingBObj;
import com.metcash.db.custom.component.MTTIdentifierBObj;
import com.metcash.services.custom.component.MetcashAccountBObj;
import com.metcash.services.custom.component.MetcashAccountRoleBObj;
import com.metcash.services.custom.component.MetcashIdentifierBObj;
import com.metcash.services.custom.constant.MTTServicesComponentID;
import com.metcash.services.custom.constant.MTTServicesErrorReasonCode;

import java.util.Vector;

/**
 * <!-- begin-user-doc --> <!-- end-user-doc -->
 *
 * 
 * @generated
 */
public class GetMTTAccountCompositeTxnBP extends DWLTxnBP {

	/**
	 * @generated
	 **/
	private IDWLErrorMessage errHandler;

	/**
    * <!-- begin-user-doc --> <!-- end-user-doc -->
    * @generated 
    */
	private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(GetMTTAccountCompositeTxnBP.class);

	/**
	 * @generated
	 **/
	public GetMTTAccountCompositeTxnBP() {
        super();
        errHandler = TCRMClassFactory.getErrorHandler();
    }

	/**
	 * @generated NOT
	 **/
	public Object execute(Object inputObj) throws BusinessProxyException {
		logger.finest("ENTER Object execute(Object inputObj)");

		TCRMResponse outputTxnObj = null;
		DWLTransactionInquiry inputTxnObj = (DWLTransactionInquiry) inputObj;
		DWLControl control = inputTxnObj.getTxnControl();

		// Extract the request parameters. These will appear in the order
		// supplied.
		Vector parameters = inputTxnObj.getStringParameters();

		// Ensure that the correct number of parameters are present.
		if (parameters == null || parameters.size() != 3) {
			DWLError error = errHandler.getErrorMessage(
					MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
					"READERR", MTTServicesErrorReasonCode.GETMTTACCOUNT_FAILED,
					control, new String[0]);
			throw new BusinessProxyException(error.getErrorMessage());
		}

		// Handle transaction "getContract"

		// MDM_TODO: CDKWB0017I Populate this vector with the parameters to
		// "getContract".
		
		Vector vecContractResponse = new Vector();
		Vector<Object> getContractParams = new Vector<Object>();
		getContractParams.add(0, parameters.get(0));
		getContractParams.add(1, parameters.get(1));
		getContractParams.add(2, parameters.get(2));
		String contractTxnType = "getContract";
		vecContractResponse = (Vector) populateGetResponse (getContractParams, contractTxnType, control);
		TCRMContractBObj getContractOutput = new TCRMContractBObj();

		if (vecContractResponse != null && vecContractResponse.size() > 0) {
			// Extract the returned business object from the response.
			getContractOutput = (TCRMContractBObj) vecContractResponse.firstElement();
		}

		// MDM_TODO: CDKWB0013I build the response Bobj.
		MetcashAccountBObj mainOutput = new MetcashAccountBObj();
		mainOutput.setControl(control);

		Vector<Object> vecContractComp = new Vector<Object>();
		Vector<Object> vecContractRole = new Vector<Object>();
		TCRMContractComponentBObj outputContrComp = new TCRMContractComponentBObj();

		if (getContractOutput != null) {
			vecContractComp = getContractOutput
					.getItemsTCRMContractComponentBObj();

			if (vecContractComp.size() > 0 && vecContractComp != null) {
				outputContrComp = (TCRMContractComponentBObj) vecContractComp.firstElement();
				vecContractRole = outputContrComp.getItemsTCRMContractPartyRoleBObj();
			}
		}

		if (vecContractRole.size() > 0 && vecContractRole != null) {
			for (int i = 0; i < vecContractRole.size(); i++) {				
				MetcashAccountRoleBObj outputMetcashActRole = new MetcashAccountRoleBObj();
				TCRMContractPartyRoleBObj outputContrRole = new TCRMContractPartyRoleBObj();
				outputContrRole = (TCRMContractPartyRoleBObj) vecContractRole.elementAt(i);
				
				if (outputContrRole.getRoleType().equalsIgnoreCase(MTTServicesComponentID.LEGAL_ENTITY_ROLE_TYPE)) {
					populateMetcashRole (outputContrRole, outputMetcashActRole, control);
				}
				outputMetcashActRole.setTCRMContractPartyRoleBObj(outputContrRole);
				mainOutput.setMetcashAccountRoleBObj(outputMetcashActRole);
			}
		}

		outputContrComp.getItemsTCRMContractPartyRoleBObj().clear();
		mainOutput.setTCRMContractBObj(getContractOutput);

		// Handle transaction "getCreditTax"

		Vector vecCreditTaxResponse = new Vector();
		Vector<Object> getCreditTaxParams = new Vector<Object>();
		getCreditTaxParams.add(0, getContractOutput.getContractIdPK());		
		String creditTaxTxnType = "getAllMTTCreditTaxByID";		
		vecCreditTaxResponse = (Vector) populateGetResponse (getCreditTaxParams, creditTaxTxnType, control);

		if (vecCreditTaxResponse != null && vecCreditTaxResponse.size() > 0) {
			mainOutput.setMTTActCreditTaxBObj((MTTActCreditTaxBObj) vecCreditTaxResponse.firstElement());			
		}

		// Handle transaction "getOrderInvoice"

		Vector vecOrderInvoiceResponse = new Vector();
		Vector<Object> getOrderInvoiceParams = new Vector<Object>();
		getOrderInvoiceParams.add(0, getContractOutput.getContractIdPK());
		String orderInvoiceTxnType = "getAllMTTOrderInvoiceByID";		
		vecOrderInvoiceResponse = (Vector) populateGetResponse (getOrderInvoiceParams, orderInvoiceTxnType, control);
		
		if (vecOrderInvoiceResponse != null && vecOrderInvoiceResponse.size() > 0) {
			mainOutput.setMTTActOrderInvoiceBObj((MTTActOrderInvoiceBObj) vecOrderInvoiceResponse.firstElement());
		}

		// Handle transaction "getFinance"
		
		Vector vecFinanceResponse = new Vector();
		Vector<Object> getFinanceParams = new Vector<Object>();
		getFinanceParams.add(0, getContractOutput.getContractIdPK());
		String financeTxnType = "getAllMTTActFinancialbyID";
		vecFinanceResponse = (Vector) populateGetResponse (getFinanceParams, financeTxnType, control);

		if (vecFinanceResponse != null && vecFinanceResponse.size() > 0) {
			mainOutput.setMTTActFinancialBObj ((MTTActFinancialBObj) vecFinanceResponse.firstElement());
		}		

		// Handle transaction "getCostCharge"
		
		Vector vecCostChargeResponse = new Vector<>();
		Vector<Object> getCostChargeParams = new Vector<Object>();
		getCostChargeParams.add(0, getContractOutput.getContractIdPK());
		String costChargeTxnType = "getAllMTTActCostChargesByID";
		vecCostChargeResponse = (Vector) populateGetResponse (getCostChargeParams, costChargeTxnType, control);
		
		if (vecCostChargeResponse != null && vecCostChargeResponse.size() > 0) {
			mainOutput.setMTTActCostChargesBObj((MTTActCostChargesBObj) vecCostChargeResponse.firstElement());
		}

		// Handle transaction "getCostCharge"

		Vector vecReportResponse = new Vector();
		Vector<Object> getReportParams = new Vector<Object>();
		getReportParams.add(0, getContractOutput.getContractIdPK());
		String reportTxnType = "getAllMTTReportByID";
		vecReportResponse = (Vector) populateGetResponse (getReportParams, reportTxnType, control);
		
		if (vecReportResponse != null && vecReportResponse.size() > 0) {
			mainOutput.setMTTActReportingBObj((MTTActReportingBObj) vecReportResponse.firstElement());
		}

		// Construct the response object.
		DWLStatus outputStatus = new DWLStatus();
		outputStatus.setStatus(DWLStatus.SUCCESS);
		outputTxnObj = new TCRMResponse();
		outputTxnObj.setStatus(outputStatus);
		outputTxnObj.setData(mainOutput);
		logger.finest("RETURN Object execute(Object inputObj)");
		return outputTxnObj;
	}

	private void populateMetcashRole(TCRMContractPartyRoleBObj outputContrRole,
			MetcashAccountRoleBObj outputMetcashActRole, DWLControl control) throws BusinessProxyException {
		
			MetcashIdentifierBObj outputMetcashIdentifier = new MetcashIdentifierBObj();	
			Vector vecRoleIdentifier = new Vector();
			vecRoleIdentifier = outputContrRole.getItemsTCRMContractPartyRoleIdentifierBObj();
			String partyID = outputContrRole.getPartyId();

			if (vecRoleIdentifier.size() > 0 && vecRoleIdentifier != null) {
				for (int j = 0; j < vecRoleIdentifier.size(); j++) {
					TCRMContractPartyRoleIdentifierBObj contrRoleIden = new TCRMContractPartyRoleIdentifierBObj();
					TCRMPartyIdentificationBObj identifierResponse = new TCRMPartyIdentificationBObj();					
					
					contrRoleIden = (TCRMContractPartyRoleIdentifierBObj) vecRoleIdentifier.get(j);				
					
					Vector vecIdentifierResponse = new Vector();
					Vector<Object> getIdentifierParams = new Vector<Object>();
					getIdentifierParams.add(0, partyID);
					getIdentifierParams.add(1, contrRoleIden.getDescription());
					
					String identifierTxnType = "getPartyIdentification";
					
					vecIdentifierResponse = (Vector) populateGetResponse (getIdentifierParams, identifierTxnType, control);					
					if (vecIdentifierResponse != null) {
						for (int p=0; p < vecIdentifierResponse.size(); p++) {
							identifierResponse = (TCRMPartyIdentificationBObj) vecIdentifierResponse.elementAt(p);
							if (identifierResponse.getIdentificationIdPK().equalsIgnoreCase(contrRoleIden.getIdentifierId())) {								
								outputMetcashIdentifier.setTCRMPartyIdentificationBObj(identifierResponse);
								break;
							}
						}
						Vector vecMTTResponse = new Vector<>();
						Vector<Object> getMTTIdentifierParams = new Vector<Object>();
						getMTTIdentifierParams.add(0, identifierResponse.getIdentificationIdPK());
						getMTTIdentifierParams.add(1, MTTServicesComponentID.FILTER_FOR_GET);
						
						String MTTIdentifierTxnType = "getAllMTTIdentifierByID";
						
						vecMTTResponse = (Vector) populateGetResponse (getMTTIdentifierParams, MTTIdentifierTxnType, control);
						
						if (vecMTTResponse != null) {
							for (int k = 0; k < vecMTTResponse.size(); k++) {
								outputMetcashIdentifier.setMTTIdentifierBObj((MTTIdentifierBObj) vecMTTResponse.elementAt(k));
								}
							}
						}	
					}
						outputMetcashActRole.setMetcashIdentifierBObj(outputMetcashIdentifier);
					}
				}
	private Object populateGetResponse(Vector<Object> getRequestParams,
			String txnType, DWLControl control) throws BusinessProxyException {
		
		// Prepare a new DWLTransactionInquiry instance.
				DWLTransactionInquiry getRequest = new DWLTransactionInquiry();
				getRequest.setTxnControl(control);
				getRequest.setTxnType(txnType);
				getRequest.setStringParameters(getRequestParams);

				// Prepare a reference to hold the response for this transaction.
				DWLResponse getResponse = null;

				// Handle GET transaction
					try {
						getResponse = (DWLResponse) super.execute(getRequest);
					} catch (BusinessProxyException e) {
						DWLError error = errHandler
								.getErrorMessage(
										MTTServicesComponentID.GET_MTTACCOUNT_BUSINESS_PROXY,
										"READERR",
										MTTServicesErrorReasonCode.GETMTTACCOUNT_FAILED,
										control, new String[0]);
						throw new BusinessProxyException(
								error.getErrorMessage(), e);
					}
					if (getResponse.getStatus().getStatus() == DWLStatus.FATAL) {
						DWLStatus dwlStatus = getResponse.getStatus();
			        	Vector vecError = dwlStatus.getDwlErrorGroup();
			        	DWLError dwlError = (DWLError) vecError.get(0);
			        	
			        	throw new BusinessProxyException(dwlError.getErrorMessage());
					}
					// Extract the returned business object from the response.
					Vector vecResponse = new Vector();
					Vector vecResponseData = new Vector();
					
					if (getResponse.getData() != null) {
						if (getResponse.getData() instanceof Vector) {
							vecResponseData = (Vector) getResponse.getData();
							for (int i=0; i < vecResponseData.size(); i++) {
								vecResponse.add(vecResponseData.elementAt(i));
							}
						} else {
							vecResponse.add(getResponse.getData());
						}						
					}					
					return vecResponse;					
				}	
		}
