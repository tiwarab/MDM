/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[67ffd8794a2b7eccf1d9efbcb67ad42c]
 */

package com.metcash.services.custom.compositeTxn;

import com.dwl.base.DWLCommon;
import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLStatus;
import com.dwl.base.requestHandler.DWLTransactionPersistent;
import com.dwl.base.requestHandler.DWLTxnBP;
import com.dwl.tcrm.common.TCRMResponse;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.dwl.unifi.tx.exception.BusinessProxyException;


import com.dwl.base.DWLControl;
import com.dwl.base.DWLResponse;

import com.dwl.tcrm.coreParty.component.TCRMOrganizationBObj;

import com.metcash.db.custom.component.MTTStoreBObj;

import com.metcash.services.custom.component.MetcashStoreBObj;

import com.metcash.services.custom.constant.MTTServicesComponentID;
import com.metcash.services.custom.constant.MTTServicesErrorReasonCode;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * 
 * @generated
 */
public class MaintianMTTStoreCompositeTxnBP  extends DWLTxnBP {

	/**
	 * @generated
	 **/
	private IDWLErrorMessage errHandler;
	
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(MaintianMTTStoreCompositeTxnBP.class);
	/**
	 * @generated
	 **/
    public MaintianMTTStoreCompositeTxnBP() {
        super();
        errHandler = TCRMClassFactory.getErrorHandler();
    }
	/**
	 * @generated NOT
	 **/
    public Object execute(Object inputObj) throws BusinessProxyException {
    logger.finest("ENTER Object execute(Object inputObj)");

        TCRMResponse outputTxnObj = null;
        DWLTransactionPersistent inputTxnObj = (DWLTransactionPersistent) inputObj;
        DWLControl control = inputTxnObj.getTxnControl();
        DWLCommon topLevelObject = (DWLCommon) inputTxnObj.getTxnTopLevelObject();
        if (!(topLevelObject instanceof MetcashStoreBObj)) {
            // MDM_TODO0: CDKWB0014I optionally use a more appropriate error code than
            // "MAINTIANMTTSTORE_FAILED".
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTIAN_MTTSTORE_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTIANMTTSTORE_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        
        MetcashStoreBObj mainInput = (MetcashStoreBObj) topLevelObject;
        
        
        // Handle transaction "addOrganization"

        // MDM_TODO: CDKWB0016I Populate the mandatory fields of "addOrganizationInput".
        TCRMOrganizationBObj addOrganizationInput = new TCRMOrganizationBObj();
        addOrganizationInput.setControl(control);

        // Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent addOrganizationRequest = new DWLTransactionPersistent();
        addOrganizationRequest.setTxnControl(control);
        addOrganizationRequest.setTxnType("addOrganization");
        addOrganizationRequest.setTxnTopLevelObject(addOrganizationInput);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse addOrganizationResponse = null;
        
        // Invoke the "addOrganization" transaction.
        try {
            addOrganizationResponse = (DWLResponse) super.execute(addOrganizationRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTIAN_MTTSTORE_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTIANMTTSTORE_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }
        
        if (addOrganizationResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTIAN_MTTSTORE_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTIANMTTSTORE_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (addOrganizationResponse.getStatus().getStatus() == DWLStatus.FATAL) {
            DWLStatus status = addOrganizationResponse.getStatus();
            TCRMResponse errResponse = new TCRMResponse();
            errResponse.setStatus(status);
            return errResponse;
        }
        
        // Extract the returned business object from the response.
        TCRMOrganizationBObj addOrganizationOutput = (TCRMOrganizationBObj) addOrganizationResponse.getData();
        
        
        // Handle transaction "addMTTStore"

        // MDM_TODO: CDKWB0016I Populate the mandatory fields of "addMTTStoreInput".
        MTTStoreBObj addMTTStoreInput = new MTTStoreBObj();
        addMTTStoreInput.setControl(control);

        // Prepare a new DWLTransactionPersistent instance.
        DWLTransactionPersistent addMTTStoreRequest = new DWLTransactionPersistent();
        addMTTStoreRequest.setTxnControl(control);
        addMTTStoreRequest.setTxnType("addMTTStore");
        addMTTStoreRequest.setTxnTopLevelObject(addMTTStoreInput);
        
        // Prepare a reference to hold the response for this transaction.
        DWLResponse addMTTStoreResponse = null;
        
        // Invoke the "addMTTStore" transaction.
        try {
            addMTTStoreResponse = (DWLResponse) super.execute(addMTTStoreRequest);
        }
        catch (BusinessProxyException e) {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTIAN_MTTSTORE_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTIANMTTSTORE_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage(), e);
        }
        
        if (addMTTStoreResponse == null)  {
            DWLError error = errHandler.getErrorMessage(MTTServicesComponentID.MAINTIAN_MTTSTORE_BUSINESS_PROXY,
                                                        "INSERR",
                                                        MTTServicesErrorReasonCode.MAINTIANMTTSTORE_FAILED,
                                                        control, new String[0]);
            throw new BusinessProxyException(error.getErrorMessage());
        }
        else if (addMTTStoreResponse.getStatus().getStatus() == DWLStatus.FATAL) {
            DWLStatus status = addMTTStoreResponse.getStatus();
            TCRMResponse errResponse = new TCRMResponse();
            errResponse.setStatus(status);
            return errResponse;
        }
        
        // Extract the returned business object from the response.
        MTTStoreBObj addMTTStoreOutput = (MTTStoreBObj) addMTTStoreResponse.getData();
        
        
        // MDM_TODO: CDKWB0013I build the response Bobj.
        MetcashStoreBObj mainOutput = new MetcashStoreBObj();
        mainOutput.setControl(control);

        // Construct the response object.
        DWLStatus outputStatus = new DWLStatus();
        outputStatus.setStatus(DWLStatus.SUCCESS);
        outputTxnObj = new TCRMResponse();
        outputTxnObj.setStatus(outputStatus);
        outputTxnObj.setData(mainOutput);
    logger.finest("RETURN Object execute(Object inputObj)");
        return outputTxnObj;
    }
}


