package com.metcash.eventmanager;

import com.dwl.commoncomponents.eventmanager.EMException;
import com.dwl.commoncomponents.eventmanager.EventObj;
import com.dwl.commoncomponents.eventmanager.EventTaskObject;
import com.dwl.commoncomponents.eventmanager.test.BaseRule;

public class TradingAccountRule extends BaseRule {
	
	protected final Long tradingAccount = new Long(1000001);

	@Override
	public void executeRules(EventTaskObject task) throws EMException {
		EventObj event = new EventObj("", tradingAccount);
		task.addPendingEventObject(event);		
	}

}
