
-- @SqlSnippetPriority 100
-- @SqlModuleOrdering 4

-- The following source code ("Code") may only be used in accordance with the terms
-- and conditions of the license agreement you have with IBM Corporation. The Code 
-- is provided to you on an "AS IS" basis, without warranty of any kind.  
-- SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
-- WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
-- TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
-- PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
-- IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
-- CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
-- LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
-- ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
-- DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
-- INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
-- NOT APPLY TO YOU.

-- Notes
-- MDM_TODO: CDKWB0046I Statements are placed in the generated SQL file when user changes are required.
-- 1. Edit the following SQL files following any associated instructions.
-- 2. Connect to the database.
-- 3. Run each SQL file as shown below and in the same order.
-- 			sqlplus userid/password@host @MTTDBCustom_SETUP_ORACLE.sql
-- 			sqlplus userid/password@host @MTTDBCustom_TRIGGERS_ORACLE.sql
-- 			sqlplus userid/password@host @MTTDBCustom_CONSTRAINTS_ORACLE.sql
--			sqlplus userid/password@host @MTTDBCustom_ERRORS_100_ORACLE.sql
-- 			sqlplus userid/password@host @MTTDBCustom_MetaData_ORACLE.sql
-- 			sqlplus userid/password@host CONFIG_XMLSERVICES_RESPONSE_ORACLE.sql
-- 			sqlplus userid/password@host @MTTDBCustom_CODETABLES_ORACLE.sql
  
CREATE TABLE MDMDB.MTT_ACCOUNT_REPORTING (
	MTT_ACT_REPORTING_ID NUMBER(19, 0)   NOT NULL  , 
	CHANNEL_GRP_TP_CD NUMBER(19, 0)    , 
	GOV_CONTRACT_IND VARCHAR2(1)    , 
	CAPRICORN_NUM INTEGER    , 
	IGAD_PERISHABLE_IND VARCHAR2(1)    , 
	AGENT_NUM_TP_CD NUMBER(19, 0)    , 
	USER_LOCALITY_TP_CD NUMBER(19, 0)    , 
	CUS_CLASS_TP_CD NUMBER(19, 0)    , 
	SHOW_PRICES_ON_WEB_IND VARCHAR2(1)    , 
	CONTRACT_ID NUMBER(19, 0)   NOT NULL  , 
	EXPORT_CUS_IND VARCHAR2(1)    , 
	LAST_UPDATE_DT TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	LAST_UPDATE_TX_ID NUMBER(19, 0)    , 
	LAST_UPDATE_USER VARCHAR2(20)    
  );

ALTER TABLE MDMDB.MTT_ACCOUNT_REPORTING
  ADD PRIMARY KEY (
	MTT_ACT_REPORTING_ID
  );

  
CREATE TABLE MDMDB.MTT_IDENTIFIER (
	MTT_IDENTIFIER_ID NUMBER(19, 0)   NOT NULL  , 
	IDENTIFIER_ID NUMBER(19, 0)   NOT NULL  , 
	IDENTIFIER_SUB_TP_CD NUMBER(19, 0)   NOT NULL  , 
	START_DT TIMESTAMP   NOT NULL  , 
	END_DT TIMESTAMP    , 
	EXPIRY_DT TIMESTAMP    , 
	DESCRIPTION VARCHAR2(250)    , 
	LAST_UPDATE_DT TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	LAST_UPDATE_TX_ID NUMBER(19, 0)    , 
	LAST_UPDATE_USER VARCHAR2(20)    
  );

ALTER TABLE MDMDB.MTT_IDENTIFIER
  ADD PRIMARY KEY (
	MTT_IDENTIFIER_ID
  );

  
CREATE TABLE MDMDB.MTT_STORE (
	MTT_STORE_ID NUMBER(19, 0)   NOT NULL  , 
	CONT_ID NUMBER(19, 0)   NOT NULL  , 
	MSO_TP_CD NUMBER(19, 0)    , 
	STORE_OPEN_DT TIMESTAMP    , 
	STORE_CLOSE_DT TIMESTAMP    , 
	LAST_UPDATE_DT TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	LAST_UPDATE_TX_ID NUMBER(19, 0)    , 
	LAST_UPDATE_USER VARCHAR2(20)    
  );

ALTER TABLE MDMDB.MTT_STORE
  ADD PRIMARY KEY (
	MTT_STORE_ID
  );

  
CREATE TABLE MDMDB.MTT_ACCOUNT_CREDIT_TAX (
	MTT_ACT_CREDIT_TAX_ID NUMBER(19, 0)   NOT NULL  , 
	CONTRACT_ID NUMBER(19, 0)   NOT NULL  , 
	INV_TERMS_TP_CD NUMBER(19, 0)    , 
	GST_EXEMPT_IND VARCHAR2(1)    , 
	CUS_GRP_TP_CD NUMBER(19, 0)    , 
	BANK_GUARANTEE_AMT REAL    , 
	BANK_GUARANTEE_END_DT TIMESTAMP    , 
	CASH_DEPOSIT_AMT REAL    , 
	CASH_DEPOSIT_RECV_DT TIMESTAMP    , 
	CASH_DEPOSIT_REL_DT TIMESTAMP    , 
	FIRST_MORTGAGE VARCHAR2(250)    , 
	SECOND_MORTGAGE VARCHAR2(250)    , 
	DEED_OF_PRIORITY VARCHAR2(250)    , 
	PPSR_DETAILS VARCHAR2(250)    , 
	PMSI_DETAILS VARCHAR2(250)    , 
	ALLPAP_DETAILS VARCHAR2(250)    , 
	ARREARS VARCHAR2(50)    , 
	CREDIT_HOLD VARCHAR2(50)    , 
	NATIONAL_HOLD VARCHAR2(50)    , 
	CREDIT_HOLD_DT VARCHAR2(250)    , 
	CREDIT_STATUS_OVERRIDE VARCHAR2(50)    , 
	CHEQUE_LIMIT_AMT REAL    , 
	CHEQUE_LIMIT_CURRENCY_TP_CD NUMBER(19, 0)    , 
	WET_EXEMPT_IND VARCHAR2(1)    , 
	DUTY_FREE_IND VARCHAR2(1)    , 
	CASH_ON_DELIVERY_IND VARCHAR2(1)    , 
	SALES_REP_TP_CD NUMBER(19, 0)    , 
	LAST_UPDATE_DT TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	LAST_UPDATE_TX_ID NUMBER(19, 0)    , 
	LAST_UPDATE_USER VARCHAR2(20)    
  );

ALTER TABLE MDMDB.MTT_ACCOUNT_CREDIT_TAX
  ADD PRIMARY KEY (
	MTT_ACT_CREDIT_TAX_ID
  );

  
CREATE TABLE MDMDB.MTT_ACCOUNT_ORDER_INVOICE (
	MTT_ACT_ORDER_INV_ID NUMBER(19, 0)   NOT NULL  , 
	CONTRACT_ID NUMBER(19, 0)   NOT NULL  , 
	PRN_RETAIL_IND VARCHAR2(1)    , 
	PRN_PRICE_MATCH_SUMMARY_IND VARCHAR2(1)    , 
	SUBSTITUTE_ITEM_IND VARCHAR2(1)    , 
	INV_SEQ_TP_CD NUMBER(19, 0)    , 
	INV_COPIES_NUM INTEGER    , 
	INV_MODE_TP_CD NUMBER(19, 0)    , 
	ORDER_GUIDE_TP_CD NUMBER(19, 0)    , 
	SEP_ORDER_ITEM_RESRV_IND VARCHAR2(1)    , 
	SPECIAL_INSTRUCTIONS VARCHAR2(250)    , 
	PRN_CAT_INV_BRK_TP_CD NUMBER(19, 0)    , 
	INV_RECAP_SUMMARY_TP_CD NUMBER(19, 0)    , 
	PO_NUM_REQ_IND VARCHAR2(1)    , 
	PICKUP_DELIVER_TP_CD NUMBER(19, 0)    , 
	PRN_ALT_TOBACCO_LICENCE_IND VARCHAR2(1)    , 
	TOTES_IND VARCHAR2(1)    , 
	TOTES_TP_CD NUMBER(19, 0)    , 
	UNIT_CASE_COST_PRN_TP_CD NUMBER(19, 0)    , 
	INV_FORMAT_TP_CD NUMBER(19, 0)    , 
	PICK_EACHES_IND VARCHAR2(1)    , 
	INV_TP_CD NUMBER(19, 0)    , 
	INV_STOP_MSG VARCHAR2(250)    , 
	DEL_PICK_PACK_INV_TP_CD NUMBER(19, 0)    , 
	PRN_HO_INV_IND VARCHAR2(1)    , 
	PRN_WHOLESALE_ON_INV_IND VARCHAR2(1)    , 
	SEP_INV_PER_CUS_PO_IND VARCHAR2(1)    , 
	ASN_REQ_IND VARCHAR2(1)    , 
	EASNMailbox VARCHAR2(100)    , 
	LAST_UPDATE_DT TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	LAST_UPDATE_TX_ID NUMBER(19, 0)    , 
	LAST_UPDATE_USER VARCHAR2(20)    
  );

ALTER TABLE MDMDB.MTT_ACCOUNT_ORDER_INVOICE
  ADD PRIMARY KEY (
	MTT_ACT_ORDER_INV_ID
  );

  
CREATE TABLE MDMDB.MTT_ACCOUNT_COST_CHARGES (
	MTT_ACT_COST_CHARGES_ID NUMBER(19, 0)   NOT NULL  , 
	CONTRACT_ID NUMBER(19, 0)   NOT NULL  , 
	COST_BASE_TP_CD NUMBER(19, 0)    , 
	DIRECT_SHIP_APPROVED_IND VARCHAR2(1)    , 
	DO_NOT_APPLY_DIRECT_DISC_IND VARCHAR2(1)    , 
	SRP_COMPLIANCE_TP_CD NUMBER(19, 0)    , 
	PRICE_MATCH_GAP_FEE_IND VARCHAR2(1)    , 
	BRKN_CASE_UPCHARGE_PCT REAL    , 
	BRKN_CASE_UPCHARGE_CAP REAL    , 
	BRKN_CASE_UPCHARGE_IND VARCHAR2(1)    , 
	BRKN_CASE_CALC_TP_CD NUMBER(19, 0)    , 
	SHELF_LABEL_PRICED_IND VARCHAR2(1)    , 
	PSRP_TP_CD NUMBER(19, 0)    , 
	ADD_FRT_RECOVERY_SRP_IND VARCHAR2(1)    , 
	SRP_FRT_RECOVERY_VAL REAL    , 
	SRP_FRT_RECOVERY_DIR_VAL REAL    , 
	LAST_UPDATE_DT TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	LAST_UPDATE_TX_ID NUMBER(19, 0)    , 
	LAST_UPDATE_USER VARCHAR2(20)    
  );

ALTER TABLE MDMDB.MTT_ACCOUNT_COST_CHARGES
  ADD PRIMARY KEY (
	MTT_ACT_COST_CHARGES_ID
  );

  
CREATE TABLE MDMDB.MTT_ACCOUNT_FINANCIAL (
	MTT_ACT_FINANCIAL_ID NUMBER(19, 0)   NOT NULL  , 
	CONTRACT_ID NUMBER(19, 0)   NOT NULL  , 
	STATEMENT_MODE_TP_CD NUMBER(19, 0)    , 
	DUE_GRACE_DAYS_TP_CD NUMBER(19, 0)    , 
	TOBACCO_GRACE_DAYS_TP_CD NUMBER(19, 0)    , 
	BANK_TP_CD NUMBER(19, 0)    , 
	BPAY_IND VARCHAR2(1)    , 
	STATEMENT_PRN_HOLD_IND VARCHAR2(1)    , 
	BPAY_CUS_REF_NUM INTEGER    , 
	COLLECTOR_TP_CD NUMBER(19, 0)    , 
	BANK_ACCOUNT_TP_CD NUMBER(19, 0)    , 
	EXT_TERMS_BY_SHIPDATE_IND VARCHAR2(1)    , 
	SETTLEMENT_DISC_IND VARCHAR2(1)    , 
	ACCOUNT_DETAILS VARCHAR2(250)    , 
	DISC_GRACE_DAYS_TP_CD NUMBER(19, 0)    , 
	PAYMENT_METHOD_TP_CD NUMBER(19, 0)    , 
	LMAA_NUM VARCHAR2(100)    , 
	LAST_UPDATE_DT TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	LAST_UPDATE_TX_ID NUMBER(19, 0)    , 
	LAST_UPDATE_USER VARCHAR2(20)    
  );

ALTER TABLE MDMDB.MTT_ACCOUNT_FINANCIAL
  ADD PRIMARY KEY (
	MTT_ACT_FINANCIAL_ID
  );

  
CREATE TABLE MDMDB.XCDCHANNELGRPTP (
	lang_tp_cd NUMBER(19, 0)   NOT NULL  , 
	Channel_Grp_TP_CD NUMBER(19, 0)   NOT NULL  , 
	name VARCHAR2(120)   NOT NULL  , 
	description VARCHAR2(250)    , 
	expiry_dt TIMESTAMP    , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	last_update_user VARCHAR2(20)    
  );

ALTER TABLE MDMDB.XCDCHANNELGRPTP
  ADD PRIMARY KEY (
	lang_tp_cd, 
	Channel_Grp_TP_CD
  );

  
CREATE TABLE MDMDB.XCDAGENTNUMTP (
	lang_tp_cd NUMBER(19, 0)   NOT NULL  , 
	Agent_Num_TP_CD NUMBER(19, 0)   NOT NULL  , 
	name VARCHAR2(120)   NOT NULL  , 
	description VARCHAR2(250)    , 
	expiry_dt TIMESTAMP    , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	last_update_user VARCHAR2(20)    
  );

ALTER TABLE MDMDB.XCDAGENTNUMTP
  ADD PRIMARY KEY (
	lang_tp_cd, 
	Agent_Num_TP_CD
  );

  
CREATE TABLE MDMDB.XCDUSERLOCALITYTP (
	lang_tp_cd NUMBER(19, 0)   NOT NULL  , 
	User_Locality_TP_CD NUMBER(19, 0)   NOT NULL  , 
	name VARCHAR2(120)   NOT NULL  , 
	description VARCHAR2(250)    , 
	expiry_dt TIMESTAMP    , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	last_update_user VARCHAR2(20)    
  );

ALTER TABLE MDMDB.XCDUSERLOCALITYTP
  ADD PRIMARY KEY (
	lang_tp_cd, 
	User_Locality_TP_CD
  );

  
CREATE TABLE MDMDB.XCDCUSCLASSTP (
	lang_tp_cd NUMBER(19, 0)   NOT NULL  , 
	Cus_Class_TP_CD NUMBER(19, 0)   NOT NULL  , 
	name VARCHAR2(120)   NOT NULL  , 
	description VARCHAR2(250)    , 
	expiry_dt TIMESTAMP    , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	last_update_user VARCHAR2(20)    
  );

ALTER TABLE MDMDB.XCDCUSCLASSTP
  ADD PRIMARY KEY (
	lang_tp_cd, 
	Cus_Class_TP_CD
  );

  
CREATE TABLE MDMDB.XCDINVTERMSTP (
	lang_tp_cd NUMBER(19, 0)   NOT NULL  , 
	INV_TERMS_TP_CD NUMBER(19, 0)   NOT NULL  , 
	name VARCHAR2(120)   NOT NULL  , 
	description VARCHAR2(250)    , 
	expiry_dt TIMESTAMP    , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	last_update_user VARCHAR2(20)    
  );

ALTER TABLE MDMDB.XCDINVTERMSTP
  ADD PRIMARY KEY (
	lang_tp_cd, 
	INV_TERMS_TP_CD
  );

  
CREATE TABLE MDMDB.XCDCUSTOMERGRPTP (
	lang_tp_cd NUMBER(19, 0)   NOT NULL  , 
	CUS_GRP_TP_CD NUMBER(19, 0)   NOT NULL  , 
	name VARCHAR2(120)   NOT NULL  , 
	description VARCHAR2(250)    , 
	expiry_dt TIMESTAMP    , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	last_update_user VARCHAR2(20)    
  );

ALTER TABLE MDMDB.XCDCUSTOMERGRPTP
  ADD PRIMARY KEY (
	lang_tp_cd, 
	CUS_GRP_TP_CD
  );

  
CREATE TABLE MDMDB.XCDINVOICESEQTP (
	lang_tp_cd NUMBER(19, 0)   NOT NULL  , 
	INV_SEQ_TP_CD NUMBER(19, 0)   NOT NULL  , 
	name VARCHAR2(120)   NOT NULL  , 
	description VARCHAR2(250)    , 
	expiry_dt TIMESTAMP    , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	last_update_user VARCHAR2(20)    
  );

ALTER TABLE MDMDB.XCDINVOICESEQTP
  ADD PRIMARY KEY (
	lang_tp_cd, 
	INV_SEQ_TP_CD
  );

  
CREATE TABLE MDMDB.XCDINVOICEMODETP (
	lang_tp_cd NUMBER(19, 0)   NOT NULL  , 
	INV_MODE_TP_CD NUMBER(19, 0)   NOT NULL  , 
	name VARCHAR2(120)   NOT NULL  , 
	description VARCHAR2(250)    , 
	expiry_dt TIMESTAMP    , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	last_update_user VARCHAR2(20)    
  );

ALTER TABLE MDMDB.XCDINVOICEMODETP
  ADD PRIMARY KEY (
	lang_tp_cd, 
	INV_MODE_TP_CD
  );

  
CREATE TABLE MDMDB.XCDORDERGUIDETP (
	lang_tp_cd NUMBER(19, 0)   NOT NULL  , 
	ORDER_GUIDE_TP_CD NUMBER(19, 0)   NOT NULL  , 
	name VARCHAR2(120)   NOT NULL  , 
	description VARCHAR2(250)    , 
	expiry_dt TIMESTAMP    , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	last_update_user VARCHAR2(20)    
  );

ALTER TABLE MDMDB.XCDORDERGUIDETP
  ADD PRIMARY KEY (
	lang_tp_cd, 
	ORDER_GUIDE_TP_CD
  );

  
CREATE TABLE MDMDB.XCDPRNCATINVBRKTP (
	lang_tp_cd NUMBER(19, 0)   NOT NULL  , 
	PRN_CAT_INV_BRK_TP_CD NUMBER(19, 0)   NOT NULL  , 
	name VARCHAR2(120)   NOT NULL  , 
	description VARCHAR2(250)    , 
	expiry_dt TIMESTAMP    , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	last_update_user VARCHAR2(20)    
  );

ALTER TABLE MDMDB.XCDPRNCATINVBRKTP
  ADD PRIMARY KEY (
	lang_tp_cd, 
	PRN_CAT_INV_BRK_TP_CD
  );

  
CREATE TABLE MDMDB.XCDINVRECAPSUMMTP (
	lang_tp_cd NUMBER(19, 0)   NOT NULL  , 
	INV_RECAP_SUMMARY_TP_CD NUMBER(19, 0)   NOT NULL  , 
	name VARCHAR2(120)   NOT NULL  , 
	description VARCHAR2(250)    , 
	expiry_dt TIMESTAMP    , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	last_update_user VARCHAR2(20)    
  );

ALTER TABLE MDMDB.XCDINVRECAPSUMMTP
  ADD PRIMARY KEY (
	lang_tp_cd, 
	INV_RECAP_SUMMARY_TP_CD
  );

  
CREATE TABLE MDMDB.XCDPICKUPDELIVERTP (
	lang_tp_cd NUMBER(19, 0)   NOT NULL  , 
	PICKUP_DELIVER_TP_CD NUMBER(19, 0)   NOT NULL  , 
	name VARCHAR2(120)   NOT NULL  , 
	description VARCHAR2(250)    , 
	expiry_dt TIMESTAMP    , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	last_update_user VARCHAR2(20)    
  );

ALTER TABLE MDMDB.XCDPICKUPDELIVERTP
  ADD PRIMARY KEY (
	lang_tp_cd, 
	PICKUP_DELIVER_TP_CD
  );

  
CREATE TABLE MDMDB.XCDUNITCASECOSTPRNTP (
	lang_tp_cd NUMBER(19, 0)   NOT NULL  , 
	UNIT_CASE_COST_PRN_TP_CD NUMBER(19, 0)   NOT NULL  , 
	name VARCHAR2(120)   NOT NULL  , 
	description VARCHAR2(250)    , 
	expiry_dt TIMESTAMP    , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	last_update_user VARCHAR2(20)    
  );

ALTER TABLE MDMDB.XCDUNITCASECOSTPRNTP
  ADD PRIMARY KEY (
	lang_tp_cd, 
	UNIT_CASE_COST_PRN_TP_CD
  );

  
CREATE TABLE MDMDB.XCDINVFORMATTP (
	lang_tp_cd NUMBER(19, 0)   NOT NULL  , 
	INV_FORMAT_TP_CD NUMBER(19, 0)   NOT NULL  , 
	name VARCHAR2(120)   NOT NULL  , 
	description VARCHAR2(250)    , 
	expiry_dt TIMESTAMP    , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	last_update_user VARCHAR2(20)    
  );

ALTER TABLE MDMDB.XCDINVFORMATTP
  ADD PRIMARY KEY (
	lang_tp_cd, 
	INV_FORMAT_TP_CD
  );

  
CREATE TABLE MDMDB.XCDDELPICKPACKINVTP (
	lang_tp_cd NUMBER(19, 0)   NOT NULL  , 
	DEL_PICK_PACK_INV_TP_CD NUMBER(19, 0)   NOT NULL  , 
	name VARCHAR2(120)   NOT NULL  , 
	description VARCHAR2(250)    , 
	expiry_dt TIMESTAMP    , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	last_update_user VARCHAR2(20)    
  );

ALTER TABLE MDMDB.XCDDELPICKPACKINVTP
  ADD PRIMARY KEY (
	lang_tp_cd, 
	DEL_PICK_PACK_INV_TP_CD
  );

  
CREATE TABLE MDMDB.XCDTOTETP (
	lang_tp_cd NUMBER(19, 0)   NOT NULL  , 
	TOTES_TP_CD NUMBER(19, 0)   NOT NULL  , 
	name VARCHAR2(120)   NOT NULL  , 
	description VARCHAR2(250)    , 
	expiry_dt TIMESTAMP    , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	last_update_user VARCHAR2(20)    
  );

ALTER TABLE MDMDB.XCDTOTETP
  ADD PRIMARY KEY (
	lang_tp_cd, 
	TOTES_TP_CD
  );

  
CREATE TABLE MDMDB.XCDINVTP (
	lang_tp_cd NUMBER(19, 0)   NOT NULL  , 
	INV_TP_CD NUMBER(19, 0)   NOT NULL  , 
	name VARCHAR2(120)   NOT NULL  , 
	description VARCHAR2(250)    , 
	expiry_dt TIMESTAMP    , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	last_update_user VARCHAR2(20)    
  );

ALTER TABLE MDMDB.XCDINVTP
  ADD PRIMARY KEY (
	lang_tp_cd, 
	INV_TP_CD
  );

  
CREATE TABLE MDMDB.XCDCOSTBASETP (
	lang_tp_cd NUMBER(19, 0)   NOT NULL  , 
	COST_BASE_TP_CD NUMBER(19, 0)   NOT NULL  , 
	name VARCHAR2(120)   NOT NULL  , 
	description VARCHAR2(250)    , 
	expiry_dt TIMESTAMP    , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	last_update_user VARCHAR2(20)    
  );

ALTER TABLE MDMDB.XCDCOSTBASETP
  ADD PRIMARY KEY (
	lang_tp_cd, 
	COST_BASE_TP_CD
  );

  
CREATE TABLE MDMDB.XCDSRPCOMPLIANCETP (
	lang_tp_cd NUMBER(19, 0)   NOT NULL  , 
	SRP_COMPLIANCE_TP_CD NUMBER(19, 0)   NOT NULL  , 
	name VARCHAR2(120)   NOT NULL  , 
	description VARCHAR2(250)    , 
	expiry_dt TIMESTAMP    , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	last_update_user VARCHAR2(20)    
  );

ALTER TABLE MDMDB.XCDSRPCOMPLIANCETP
  ADD PRIMARY KEY (
	lang_tp_cd, 
	SRP_COMPLIANCE_TP_CD
  );

  
CREATE TABLE MDMDB.XCDBRKNCASECALCTP (
	lang_tp_cd NUMBER(19, 0)   NOT NULL  , 
	BRKN_CASE_UPCHARGE_TP_CD NUMBER(19, 0)   NOT NULL  , 
	name VARCHAR2(120)   NOT NULL  , 
	description VARCHAR2(250)    , 
	expiry_dt TIMESTAMP    , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	last_update_user VARCHAR2(20)    
  );

ALTER TABLE MDMDB.XCDBRKNCASECALCTP
  ADD PRIMARY KEY (
	lang_tp_cd, 
	BRKN_CASE_UPCHARGE_TP_CD
  );

  
CREATE TABLE MDMDB.XCDPSRPTP (
	lang_tp_cd NUMBER(19, 0)   NOT NULL  , 
	PSRP_TP_CD NUMBER(19, 0)   NOT NULL  , 
	name VARCHAR2(120)   NOT NULL  , 
	description VARCHAR2(250)    , 
	expiry_dt TIMESTAMP    , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	last_update_user VARCHAR2(20)    
  );

ALTER TABLE MDMDB.XCDPSRPTP
  ADD PRIMARY KEY (
	lang_tp_cd, 
	PSRP_TP_CD
  );

  
CREATE TABLE MDMDB.XCDSTATEMENTMODETP (
	lang_tp_cd NUMBER(19, 0)   NOT NULL  , 
	STATEMENT_MODE_TP_CD NUMBER(19, 0)   NOT NULL  , 
	name VARCHAR2(120)   NOT NULL  , 
	description VARCHAR2(250)    , 
	expiry_dt TIMESTAMP    , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	last_update_user VARCHAR2(20)    
  );

ALTER TABLE MDMDB.XCDSTATEMENTMODETP
  ADD PRIMARY KEY (
	lang_tp_cd, 
	STATEMENT_MODE_TP_CD
  );

  
CREATE TABLE MDMDB.XCDGRACEDAYSTP (
	lang_tp_cd NUMBER(19, 0)   NOT NULL  , 
	GRACE_DAYS_TP_CD NUMBER(19, 0)   NOT NULL  , 
	name VARCHAR2(120)   NOT NULL  , 
	description VARCHAR2(250)    , 
	expiry_dt TIMESTAMP    , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	last_update_user VARCHAR2(20)    
  );

ALTER TABLE MDMDB.XCDGRACEDAYSTP
  ADD PRIMARY KEY (
	lang_tp_cd, 
	GRACE_DAYS_TP_CD
  );

  
CREATE TABLE MDMDB.XCDCOLLECTORTP (
	lang_tp_cd NUMBER(19, 0)   NOT NULL  , 
	COLLECTOR_TP_CD NUMBER(19, 0)   NOT NULL  , 
	name VARCHAR2(120)   NOT NULL  , 
	description VARCHAR2(250)    , 
	expiry_dt TIMESTAMP    , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	last_update_user VARCHAR2(20)    
  );

ALTER TABLE MDMDB.XCDCOLLECTORTP
  ADD PRIMARY KEY (
	lang_tp_cd, 
	COLLECTOR_TP_CD
  );

  
CREATE TABLE MDMDB.XCDPAYMENTMETHODTP (
	lang_tp_cd NUMBER(19, 0)   NOT NULL  , 
	PAYMENT_METHOD_TP_CD NUMBER(19, 0)   NOT NULL  , 
	name VARCHAR2(120)   NOT NULL  , 
	description VARCHAR2(250)    , 
	expiry_dt TIMESTAMP    , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	last_update_user VARCHAR2(20)    
  );

ALTER TABLE MDMDB.XCDPAYMENTMETHODTP
  ADD PRIMARY KEY (
	lang_tp_cd, 
	PAYMENT_METHOD_TP_CD
  );

  
CREATE TABLE MDMDB.XCDBANKTP (
	lang_tp_cd NUMBER(19, 0)   NOT NULL  , 
	BANK_TP_CD NUMBER(19, 0)   NOT NULL  , 
	name VARCHAR2(120)   NOT NULL  , 
	description VARCHAR2(250)    , 
	expiry_dt TIMESTAMP    , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	last_update_user VARCHAR2(20)    
  );

ALTER TABLE MDMDB.XCDBANKTP
  ADD PRIMARY KEY (
	lang_tp_cd, 
	BANK_TP_CD
  );

  
CREATE TABLE MDMDB.XCDBANKACCOUNTTP (
	lang_tp_cd NUMBER(19, 0)   NOT NULL  , 
	BANK_ACCOUNT_TP_CD NUMBER(19, 0)   NOT NULL  , 
	name VARCHAR2(120)   NOT NULL  , 
	description VARCHAR2(250)    , 
	expiry_dt TIMESTAMP    , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	last_update_user VARCHAR2(20)    
  );

ALTER TABLE MDMDB.XCDBANKACCOUNTTP
  ADD PRIMARY KEY (
	lang_tp_cd, 
	BANK_ACCOUNT_TP_CD
  );

  
CREATE TABLE MDMDB.XCDSALESREPTP (
	lang_tp_cd NUMBER(19, 0)   NOT NULL  , 
	tp_cd NUMBER(19, 0)   NOT NULL  , 
	name VARCHAR2(120)   NOT NULL  , 
	description VARCHAR2(250)    , 
	expiry_dt TIMESTAMP    , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	last_update_user VARCHAR2(20)    
  );

ALTER TABLE MDMDB.XCDSALESREPTP
  ADD PRIMARY KEY (
	lang_tp_cd, 
	tp_cd
  );

  
CREATE TABLE MDMDB.XCDIDENTIFIERSUBTP (
	lang_tp_cd NUMBER(19, 0)   NOT NULL  , 
	Identifier_Sub_TP_CD NUMBER(19, 0)   NOT NULL  , 
	name VARCHAR2(120)   NOT NULL  , 
	description VARCHAR2(250)    , 
	expiry_dt TIMESTAMP    , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	last_update_user VARCHAR2(20)    
  );

ALTER TABLE MDMDB.XCDIDENTIFIERSUBTP
  ADD PRIMARY KEY (
	lang_tp_cd, 
	Identifier_Sub_TP_CD
  );

  
CREATE TABLE MDMDB.XCDMSO (
	lang_tp_cd NUMBER(19, 0)   NOT NULL  , 
	MSO_TP_CD NUMBER(19, 0)   NOT NULL  , 
	name VARCHAR2(120)   NOT NULL  , 
	description VARCHAR2(250)    , 
	expiry_dt TIMESTAMP    , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL  , 
	last_update_user VARCHAR2(20)    
  );

ALTER TABLE MDMDB.XCDMSO
  ADD PRIMARY KEY (
	lang_tp_cd, 
	MSO_TP_CD
  );

  
CREATE TABLE MDMDB.H_MTT_ACCOUNT_REPORTING (
	h_MTT_ACT_REPORTING_ID NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	MTT_ACT_REPORTING_ID NUMBER(19, 0)   NOT NULL , 
	CHANNEL_GRP_TP_CD NUMBER(19, 0)   , 
	GOV_CONTRACT_IND VARCHAR2(1)   , 
	CAPRICORN_NUM INTEGER   , 
	IGAD_PERISHABLE_IND VARCHAR2(1)   , 
	AGENT_NUM_TP_CD NUMBER(19, 0)   , 
	USER_LOCALITY_TP_CD NUMBER(19, 0)   , 
	CUS_CLASS_TP_CD NUMBER(19, 0)   , 
	SHOW_PRICES_ON_WEB_IND VARCHAR2(1)   , 
	CONTRACT_ID NUMBER(19, 0)   NOT NULL , 
	EXPORT_CUS_IND VARCHAR2(1)   , 
	LAST_UPDATE_DT TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	LAST_UPDATE_TX_ID NUMBER(19, 0)   , 
	LAST_UPDATE_USER VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_MTT_ACCOUNT_REPORTING
  ADD PRIMARY KEY (
	h_MTT_ACT_REPORTING_ID,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_MTT_IDENTIFIER (
	h_MTT_IDENTIFIER_ID NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	MTT_IDENTIFIER_ID NUMBER(19, 0)   NOT NULL , 
	IDENTIFIER_ID NUMBER(19, 0)   NOT NULL , 
	IDENTIFIER_SUB_TP_CD NUMBER(19, 0)   NOT NULL , 
	START_DT TIMESTAMP   NOT NULL , 
	END_DT TIMESTAMP   , 
	EXPIRY_DT TIMESTAMP   , 
	DESCRIPTION VARCHAR2(250)   , 
	LAST_UPDATE_DT TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	LAST_UPDATE_TX_ID NUMBER(19, 0)   , 
	LAST_UPDATE_USER VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_MTT_IDENTIFIER
  ADD PRIMARY KEY (
	h_MTT_IDENTIFIER_ID,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_MTT_STORE (
	h_MTT_STORE_ID NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	MTT_STORE_ID NUMBER(19, 0)   NOT NULL , 
	CONT_ID NUMBER(19, 0)   NOT NULL , 
	MSO_TP_CD NUMBER(19, 0)   , 
	STORE_OPEN_DT TIMESTAMP   , 
	STORE_CLOSE_DT TIMESTAMP   , 
	LAST_UPDATE_DT TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	LAST_UPDATE_TX_ID NUMBER(19, 0)   , 
	LAST_UPDATE_USER VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_MTT_STORE
  ADD PRIMARY KEY (
	h_MTT_STORE_ID,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_MTT_ACCOUNT_CREDIT_TAX (
	h_MTT_ACT_CREDIT_TAX_ID NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	MTT_ACT_CREDIT_TAX_ID NUMBER(19, 0)   NOT NULL , 
	CONTRACT_ID NUMBER(19, 0)   NOT NULL , 
	INV_TERMS_TP_CD NUMBER(19, 0)   , 
	GST_EXEMPT_IND VARCHAR2(1)   , 
	CUS_GRP_TP_CD NUMBER(19, 0)   , 
	BANK_GUARANTEE_AMT REAL   , 
	BANK_GUARANTEE_END_DT TIMESTAMP   , 
	CASH_DEPOSIT_AMT REAL   , 
	CASH_DEPOSIT_RECV_DT TIMESTAMP   , 
	CASH_DEPOSIT_REL_DT TIMESTAMP   , 
	FIRST_MORTGAGE VARCHAR2(250)   , 
	SECOND_MORTGAGE VARCHAR2(250)   , 
	DEED_OF_PRIORITY VARCHAR2(250)   , 
	PPSR_DETAILS VARCHAR2(250)   , 
	PMSI_DETAILS VARCHAR2(250)   , 
	ALLPAP_DETAILS VARCHAR2(250)   , 
	ARREARS VARCHAR2(50)   , 
	CREDIT_HOLD VARCHAR2(50)   , 
	NATIONAL_HOLD VARCHAR2(50)   , 
	CREDIT_HOLD_DT VARCHAR2(250)   , 
	CREDIT_STATUS_OVERRIDE VARCHAR2(50)   , 
	CHEQUE_LIMIT_AMT REAL   , 
	CHEQUE_LIMIT_CURRENCY_TP_CD NUMBER(19, 0)   , 
	WET_EXEMPT_IND VARCHAR2(1)   , 
	DUTY_FREE_IND VARCHAR2(1)   , 
	CASH_ON_DELIVERY_IND VARCHAR2(1)   , 
	SALES_REP_TP_CD NUMBER(19, 0)   , 
	LAST_UPDATE_DT TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	LAST_UPDATE_TX_ID NUMBER(19, 0)   , 
	LAST_UPDATE_USER VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_MTT_ACCOUNT_CREDIT_TAX
  ADD PRIMARY KEY (
	h_MTT_ACT_CREDIT_TAX_ID,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_MTT_ACCOUNT_ORDER_INVOICE (
	h_MTT_ACT_ORDER_INV_ID NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	MTT_ACT_ORDER_INV_ID NUMBER(19, 0)   NOT NULL , 
	CONTRACT_ID NUMBER(19, 0)   NOT NULL , 
	PRN_RETAIL_IND VARCHAR2(1)   , 
	PRN_PRICE_MATCH_SUMMARY_IND VARCHAR2(1)   , 
	SUBSTITUTE_ITEM_IND VARCHAR2(1)   , 
	INV_SEQ_TP_CD NUMBER(19, 0)   , 
	INV_COPIES_NUM INTEGER   , 
	INV_MODE_TP_CD NUMBER(19, 0)   , 
	ORDER_GUIDE_TP_CD NUMBER(19, 0)   , 
	SEP_ORDER_ITEM_RESRV_IND VARCHAR2(1)   , 
	SPECIAL_INSTRUCTIONS VARCHAR2(250)   , 
	PRN_CAT_INV_BRK_TP_CD NUMBER(19, 0)   , 
	INV_RECAP_SUMMARY_TP_CD NUMBER(19, 0)   , 
	PO_NUM_REQ_IND VARCHAR2(1)   , 
	PICKUP_DELIVER_TP_CD NUMBER(19, 0)   , 
	PRN_ALT_TOBACCO_LICENCE_IND VARCHAR2(1)   , 
	TOTES_IND VARCHAR2(1)   , 
	TOTES_TP_CD NUMBER(19, 0)   , 
	UNIT_CASE_COST_PRN_TP_CD NUMBER(19, 0)   , 
	INV_FORMAT_TP_CD NUMBER(19, 0)   , 
	PICK_EACHES_IND VARCHAR2(1)   , 
	INV_TP_CD NUMBER(19, 0)   , 
	INV_STOP_MSG VARCHAR2(250)   , 
	DEL_PICK_PACK_INV_TP_CD NUMBER(19, 0)   , 
	PRN_HO_INV_IND VARCHAR2(1)   , 
	PRN_WHOLESALE_ON_INV_IND VARCHAR2(1)   , 
	SEP_INV_PER_CUS_PO_IND VARCHAR2(1)   , 
	ASN_REQ_IND VARCHAR2(1)   , 
	EASNMailbox VARCHAR2(100)   , 
	LAST_UPDATE_DT TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	LAST_UPDATE_TX_ID NUMBER(19, 0)   , 
	LAST_UPDATE_USER VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_MTT_ACCOUNT_ORDER_INVOICE
  ADD PRIMARY KEY (
	h_MTT_ACT_ORDER_INV_ID,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_MTT_ACCOUNT_COST_CHARGES (
	h_MTT_ACT_COST_CHARGES_ID NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	MTT_ACT_COST_CHARGES_ID NUMBER(19, 0)   NOT NULL , 
	CONTRACT_ID NUMBER(19, 0)   NOT NULL , 
	COST_BASE_TP_CD NUMBER(19, 0)   , 
	DIRECT_SHIP_APPROVED_IND VARCHAR2(1)   , 
	DO_NOT_APPLY_DIRECT_DISC_IND VARCHAR2(1)   , 
	SRP_COMPLIANCE_TP_CD NUMBER(19, 0)   , 
	PRICE_MATCH_GAP_FEE_IND VARCHAR2(1)   , 
	BRKN_CASE_UPCHARGE_PCT REAL   , 
	BRKN_CASE_UPCHARGE_CAP REAL   , 
	BRKN_CASE_UPCHARGE_IND VARCHAR2(1)   , 
	BRKN_CASE_CALC_TP_CD NUMBER(19, 0)   , 
	SHELF_LABEL_PRICED_IND VARCHAR2(1)   , 
	PSRP_TP_CD NUMBER(19, 0)   , 
	ADD_FRT_RECOVERY_SRP_IND VARCHAR2(1)   , 
	SRP_FRT_RECOVERY_VAL REAL   , 
	SRP_FRT_RECOVERY_DIR_VAL REAL   , 
	LAST_UPDATE_DT TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	LAST_UPDATE_TX_ID NUMBER(19, 0)   , 
	LAST_UPDATE_USER VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_MTT_ACCOUNT_COST_CHARGES
  ADD PRIMARY KEY (
	h_MTT_ACT_COST_CHARGES_ID,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_MTT_ACCOUNT_FINANCIAL (
	h_MTT_ACT_FINANCIAL_ID NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	MTT_ACT_FINANCIAL_ID NUMBER(19, 0)   NOT NULL , 
	CONTRACT_ID NUMBER(19, 0)   NOT NULL , 
	STATEMENT_MODE_TP_CD NUMBER(19, 0)   , 
	DUE_GRACE_DAYS_TP_CD NUMBER(19, 0)   , 
	TOBACCO_GRACE_DAYS_TP_CD NUMBER(19, 0)   , 
	BANK_TP_CD NUMBER(19, 0)   , 
	BPAY_IND VARCHAR2(1)   , 
	STATEMENT_PRN_HOLD_IND VARCHAR2(1)   , 
	BPAY_CUS_REF_NUM INTEGER   , 
	COLLECTOR_TP_CD NUMBER(19, 0)   , 
	BANK_ACCOUNT_TP_CD NUMBER(19, 0)   , 
	EXT_TERMS_BY_SHIPDATE_IND VARCHAR2(1)   , 
	SETTLEMENT_DISC_IND VARCHAR2(1)   , 
	ACCOUNT_DETAILS VARCHAR2(250)   , 
	DISC_GRACE_DAYS_TP_CD NUMBER(19, 0)   , 
	PAYMENT_METHOD_TP_CD NUMBER(19, 0)   , 
	LMAA_NUM VARCHAR2(100)   , 
	LAST_UPDATE_DT TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	LAST_UPDATE_TX_ID NUMBER(19, 0)   , 
	LAST_UPDATE_USER VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_MTT_ACCOUNT_FINANCIAL
  ADD PRIMARY KEY (
	h_MTT_ACT_FINANCIAL_ID,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_XCDCHANNELGRPTP (
	h_lang_tp_cd NUMBER(19, 0)   NOT NULL,
	h_Channel_Grp_TP_CD NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	lang_tp_cd NUMBER(19, 0)   NOT NULL , 
	Channel_Grp_TP_CD NUMBER(19, 0)   NOT NULL , 
	name VARCHAR2(120)   NOT NULL , 
	description VARCHAR2(250)   , 
	expiry_dt TIMESTAMP   , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	last_update_user VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_XCDCHANNELGRPTP
  ADD PRIMARY KEY (
	h_lang_tp_cd,
	h_Channel_Grp_TP_CD,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_XCDAGENTNUMTP (
	h_lang_tp_cd NUMBER(19, 0)   NOT NULL,
	h_Agent_Num_TP_CD NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	lang_tp_cd NUMBER(19, 0)   NOT NULL , 
	Agent_Num_TP_CD NUMBER(19, 0)   NOT NULL , 
	name VARCHAR2(120)   NOT NULL , 
	description VARCHAR2(250)   , 
	expiry_dt TIMESTAMP   , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	last_update_user VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_XCDAGENTNUMTP
  ADD PRIMARY KEY (
	h_lang_tp_cd,
	h_Agent_Num_TP_CD,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_XCDUSERLOCALITYTP (
	h_lang_tp_cd NUMBER(19, 0)   NOT NULL,
	h_User_Locality_TP_CD NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	lang_tp_cd NUMBER(19, 0)   NOT NULL , 
	User_Locality_TP_CD NUMBER(19, 0)   NOT NULL , 
	name VARCHAR2(120)   NOT NULL , 
	description VARCHAR2(250)   , 
	expiry_dt TIMESTAMP   , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	last_update_user VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_XCDUSERLOCALITYTP
  ADD PRIMARY KEY (
	h_lang_tp_cd,
	h_User_Locality_TP_CD,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_XCDCUSCLASSTP (
	h_lang_tp_cd NUMBER(19, 0)   NOT NULL,
	h_Cus_Class_TP_CD NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	lang_tp_cd NUMBER(19, 0)   NOT NULL , 
	Cus_Class_TP_CD NUMBER(19, 0)   NOT NULL , 
	name VARCHAR2(120)   NOT NULL , 
	description VARCHAR2(250)   , 
	expiry_dt TIMESTAMP   , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	last_update_user VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_XCDCUSCLASSTP
  ADD PRIMARY KEY (
	h_lang_tp_cd,
	h_Cus_Class_TP_CD,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_XCDINVTERMSTP (
	h_lang_tp_cd NUMBER(19, 0)   NOT NULL,
	h_INV_TERMS_TP_CD NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	lang_tp_cd NUMBER(19, 0)   NOT NULL , 
	INV_TERMS_TP_CD NUMBER(19, 0)   NOT NULL , 
	name VARCHAR2(120)   NOT NULL , 
	description VARCHAR2(250)   , 
	expiry_dt TIMESTAMP   , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	last_update_user VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_XCDINVTERMSTP
  ADD PRIMARY KEY (
	h_lang_tp_cd,
	h_INV_TERMS_TP_CD,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_XCDCUSTOMERGRPTP (
	h_lang_tp_cd NUMBER(19, 0)   NOT NULL,
	h_CUS_GRP_TP_CD NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	lang_tp_cd NUMBER(19, 0)   NOT NULL , 
	CUS_GRP_TP_CD NUMBER(19, 0)   NOT NULL , 
	name VARCHAR2(120)   NOT NULL , 
	description VARCHAR2(250)   , 
	expiry_dt TIMESTAMP   , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	last_update_user VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_XCDCUSTOMERGRPTP
  ADD PRIMARY KEY (
	h_lang_tp_cd,
	h_CUS_GRP_TP_CD,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_XCDINVOICESEQTP (
	h_lang_tp_cd NUMBER(19, 0)   NOT NULL,
	h_INV_SEQ_TP_CD NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	lang_tp_cd NUMBER(19, 0)   NOT NULL , 
	INV_SEQ_TP_CD NUMBER(19, 0)   NOT NULL , 
	name VARCHAR2(120)   NOT NULL , 
	description VARCHAR2(250)   , 
	expiry_dt TIMESTAMP   , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	last_update_user VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_XCDINVOICESEQTP
  ADD PRIMARY KEY (
	h_lang_tp_cd,
	h_INV_SEQ_TP_CD,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_XCDINVOICEMODETP (
	h_lang_tp_cd NUMBER(19, 0)   NOT NULL,
	h_INV_MODE_TP_CD NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	lang_tp_cd NUMBER(19, 0)   NOT NULL , 
	INV_MODE_TP_CD NUMBER(19, 0)   NOT NULL , 
	name VARCHAR2(120)   NOT NULL , 
	description VARCHAR2(250)   , 
	expiry_dt TIMESTAMP   , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	last_update_user VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_XCDINVOICEMODETP
  ADD PRIMARY KEY (
	h_lang_tp_cd,
	h_INV_MODE_TP_CD,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_XCDORDERGUIDETP (
	h_lang_tp_cd NUMBER(19, 0)   NOT NULL,
	h_ORDER_GUIDE_TP_CD NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	lang_tp_cd NUMBER(19, 0)   NOT NULL , 
	ORDER_GUIDE_TP_CD NUMBER(19, 0)   NOT NULL , 
	name VARCHAR2(120)   NOT NULL , 
	description VARCHAR2(250)   , 
	expiry_dt TIMESTAMP   , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	last_update_user VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_XCDORDERGUIDETP
  ADD PRIMARY KEY (
	h_lang_tp_cd,
	h_ORDER_GUIDE_TP_CD,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_XCDPRNCATINVBRKTP (
	h_lang_tp_cd NUMBER(19, 0)   NOT NULL,
	h_PRN_CAT_INV_BRK_TP_CD NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	lang_tp_cd NUMBER(19, 0)   NOT NULL , 
	PRN_CAT_INV_BRK_TP_CD NUMBER(19, 0)   NOT NULL , 
	name VARCHAR2(120)   NOT NULL , 
	description VARCHAR2(250)   , 
	expiry_dt TIMESTAMP   , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	last_update_user VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_XCDPRNCATINVBRKTP
  ADD PRIMARY KEY (
	h_lang_tp_cd,
	h_PRN_CAT_INV_BRK_TP_CD,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_XCDINVRECAPSUMMTP (
	h_lang_tp_cd NUMBER(19, 0)   NOT NULL,
	h_INV_RECAP_SUMMARY_TP_CD NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	lang_tp_cd NUMBER(19, 0)   NOT NULL , 
	INV_RECAP_SUMMARY_TP_CD NUMBER(19, 0)   NOT NULL , 
	name VARCHAR2(120)   NOT NULL , 
	description VARCHAR2(250)   , 
	expiry_dt TIMESTAMP   , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	last_update_user VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_XCDINVRECAPSUMMTP
  ADD PRIMARY KEY (
	h_lang_tp_cd,
	h_INV_RECAP_SUMMARY_TP_CD,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_XCDPICKUPDELIVERTP (
	h_lang_tp_cd NUMBER(19, 0)   NOT NULL,
	h_PICKUP_DELIVER_TP_CD NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	lang_tp_cd NUMBER(19, 0)   NOT NULL , 
	PICKUP_DELIVER_TP_CD NUMBER(19, 0)   NOT NULL , 
	name VARCHAR2(120)   NOT NULL , 
	description VARCHAR2(250)   , 
	expiry_dt TIMESTAMP   , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	last_update_user VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_XCDPICKUPDELIVERTP
  ADD PRIMARY KEY (
	h_lang_tp_cd,
	h_PICKUP_DELIVER_TP_CD,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_XCDUNITCASECOSTPRNTP (
	h_lang_tp_cd NUMBER(19, 0)   NOT NULL,
	h_UNIT_CASE_COST_PRN_TP_CD NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	lang_tp_cd NUMBER(19, 0)   NOT NULL , 
	UNIT_CASE_COST_PRN_TP_CD NUMBER(19, 0)   NOT NULL , 
	name VARCHAR2(120)   NOT NULL , 
	description VARCHAR2(250)   , 
	expiry_dt TIMESTAMP   , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	last_update_user VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_XCDUNITCASECOSTPRNTP
  ADD PRIMARY KEY (
	h_lang_tp_cd,
	h_UNIT_CASE_COST_PRN_TP_CD,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_XCDINVFORMATTP (
	h_lang_tp_cd NUMBER(19, 0)   NOT NULL,
	h_INV_FORMAT_TP_CD NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	lang_tp_cd NUMBER(19, 0)   NOT NULL , 
	INV_FORMAT_TP_CD NUMBER(19, 0)   NOT NULL , 
	name VARCHAR2(120)   NOT NULL , 
	description VARCHAR2(250)   , 
	expiry_dt TIMESTAMP   , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	last_update_user VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_XCDINVFORMATTP
  ADD PRIMARY KEY (
	h_lang_tp_cd,
	h_INV_FORMAT_TP_CD,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_XCDDELPICKPACKINVTP (
	h_lang_tp_cd NUMBER(19, 0)   NOT NULL,
	h_DEL_PICK_PACK_INV_TP_CD NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	lang_tp_cd NUMBER(19, 0)   NOT NULL , 
	DEL_PICK_PACK_INV_TP_CD NUMBER(19, 0)   NOT NULL , 
	name VARCHAR2(120)   NOT NULL , 
	description VARCHAR2(250)   , 
	expiry_dt TIMESTAMP   , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	last_update_user VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_XCDDELPICKPACKINVTP
  ADD PRIMARY KEY (
	h_lang_tp_cd,
	h_DEL_PICK_PACK_INV_TP_CD,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_XCDTOTETP (
	h_lang_tp_cd NUMBER(19, 0)   NOT NULL,
	h_TOTES_TP_CD NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	lang_tp_cd NUMBER(19, 0)   NOT NULL , 
	TOTES_TP_CD NUMBER(19, 0)   NOT NULL , 
	name VARCHAR2(120)   NOT NULL , 
	description VARCHAR2(250)   , 
	expiry_dt TIMESTAMP   , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	last_update_user VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_XCDTOTETP
  ADD PRIMARY KEY (
	h_lang_tp_cd,
	h_TOTES_TP_CD,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_XCDINVTP (
	h_lang_tp_cd NUMBER(19, 0)   NOT NULL,
	h_INV_TP_CD NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	lang_tp_cd NUMBER(19, 0)   NOT NULL , 
	INV_TP_CD NUMBER(19, 0)   NOT NULL , 
	name VARCHAR2(120)   NOT NULL , 
	description VARCHAR2(250)   , 
	expiry_dt TIMESTAMP   , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	last_update_user VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_XCDINVTP
  ADD PRIMARY KEY (
	h_lang_tp_cd,
	h_INV_TP_CD,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_XCDCOSTBASETP (
	h_lang_tp_cd NUMBER(19, 0)   NOT NULL,
	h_COST_BASE_TP_CD NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	lang_tp_cd NUMBER(19, 0)   NOT NULL , 
	COST_BASE_TP_CD NUMBER(19, 0)   NOT NULL , 
	name VARCHAR2(120)   NOT NULL , 
	description VARCHAR2(250)   , 
	expiry_dt TIMESTAMP   , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	last_update_user VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_XCDCOSTBASETP
  ADD PRIMARY KEY (
	h_lang_tp_cd,
	h_COST_BASE_TP_CD,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_XCDSRPCOMPLIANCETP (
	h_lang_tp_cd NUMBER(19, 0)   NOT NULL,
	h_SRP_COMPLIANCE_TP_CD NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	lang_tp_cd NUMBER(19, 0)   NOT NULL , 
	SRP_COMPLIANCE_TP_CD NUMBER(19, 0)   NOT NULL , 
	name VARCHAR2(120)   NOT NULL , 
	description VARCHAR2(250)   , 
	expiry_dt TIMESTAMP   , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	last_update_user VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_XCDSRPCOMPLIANCETP
  ADD PRIMARY KEY (
	h_lang_tp_cd,
	h_SRP_COMPLIANCE_TP_CD,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_XCDBRKNCASECALCTP (
	h_lang_tp_cd NUMBER(19, 0)   NOT NULL,
	h_BRKN_CASE_UPCHARGE_TP_CD NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	lang_tp_cd NUMBER(19, 0)   NOT NULL , 
	BRKN_CASE_UPCHARGE_TP_CD NUMBER(19, 0)   NOT NULL , 
	name VARCHAR2(120)   NOT NULL , 
	description VARCHAR2(250)   , 
	expiry_dt TIMESTAMP   , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	last_update_user VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_XCDBRKNCASECALCTP
  ADD PRIMARY KEY (
	h_lang_tp_cd,
	h_BRKN_CASE_UPCHARGE_TP_CD,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_XCDPSRPTP (
	h_lang_tp_cd NUMBER(19, 0)   NOT NULL,
	h_PSRP_TP_CD NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	lang_tp_cd NUMBER(19, 0)   NOT NULL , 
	PSRP_TP_CD NUMBER(19, 0)   NOT NULL , 
	name VARCHAR2(120)   NOT NULL , 
	description VARCHAR2(250)   , 
	expiry_dt TIMESTAMP   , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	last_update_user VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_XCDPSRPTP
  ADD PRIMARY KEY (
	h_lang_tp_cd,
	h_PSRP_TP_CD,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_XCDSTATEMENTMODETP (
	h_lang_tp_cd NUMBER(19, 0)   NOT NULL,
	h_STATEMENT_MODE_TP_CD NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	lang_tp_cd NUMBER(19, 0)   NOT NULL , 
	STATEMENT_MODE_TP_CD NUMBER(19, 0)   NOT NULL , 
	name VARCHAR2(120)   NOT NULL , 
	description VARCHAR2(250)   , 
	expiry_dt TIMESTAMP   , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	last_update_user VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_XCDSTATEMENTMODETP
  ADD PRIMARY KEY (
	h_lang_tp_cd,
	h_STATEMENT_MODE_TP_CD,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_XCDGRACEDAYSTP (
	h_lang_tp_cd NUMBER(19, 0)   NOT NULL,
	h_GRACE_DAYS_TP_CD NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	lang_tp_cd NUMBER(19, 0)   NOT NULL , 
	GRACE_DAYS_TP_CD NUMBER(19, 0)   NOT NULL , 
	name VARCHAR2(120)   NOT NULL , 
	description VARCHAR2(250)   , 
	expiry_dt TIMESTAMP   , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	last_update_user VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_XCDGRACEDAYSTP
  ADD PRIMARY KEY (
	h_lang_tp_cd,
	h_GRACE_DAYS_TP_CD,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_XCDCOLLECTORTP (
	h_lang_tp_cd NUMBER(19, 0)   NOT NULL,
	h_COLLECTOR_TP_CD NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	lang_tp_cd NUMBER(19, 0)   NOT NULL , 
	COLLECTOR_TP_CD NUMBER(19, 0)   NOT NULL , 
	name VARCHAR2(120)   NOT NULL , 
	description VARCHAR2(250)   , 
	expiry_dt TIMESTAMP   , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	last_update_user VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_XCDCOLLECTORTP
  ADD PRIMARY KEY (
	h_lang_tp_cd,
	h_COLLECTOR_TP_CD,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_XCDPAYMENTMETHODTP (
	h_lang_tp_cd NUMBER(19, 0)   NOT NULL,
	h_PAYMENT_METHOD_TP_CD NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	lang_tp_cd NUMBER(19, 0)   NOT NULL , 
	PAYMENT_METHOD_TP_CD NUMBER(19, 0)   NOT NULL , 
	name VARCHAR2(120)   NOT NULL , 
	description VARCHAR2(250)   , 
	expiry_dt TIMESTAMP   , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	last_update_user VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_XCDPAYMENTMETHODTP
  ADD PRIMARY KEY (
	h_lang_tp_cd,
	h_PAYMENT_METHOD_TP_CD,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_XCDBANKTP (
	h_lang_tp_cd NUMBER(19, 0)   NOT NULL,
	h_BANK_TP_CD NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	lang_tp_cd NUMBER(19, 0)   NOT NULL , 
	BANK_TP_CD NUMBER(19, 0)   NOT NULL , 
	name VARCHAR2(120)   NOT NULL , 
	description VARCHAR2(250)   , 
	expiry_dt TIMESTAMP   , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	last_update_user VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_XCDBANKTP
  ADD PRIMARY KEY (
	h_lang_tp_cd,
	h_BANK_TP_CD,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_XCDBANKACCOUNTTP (
	h_lang_tp_cd NUMBER(19, 0)   NOT NULL,
	h_BANK_ACCOUNT_TP_CD NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	lang_tp_cd NUMBER(19, 0)   NOT NULL , 
	BANK_ACCOUNT_TP_CD NUMBER(19, 0)   NOT NULL , 
	name VARCHAR2(120)   NOT NULL , 
	description VARCHAR2(250)   , 
	expiry_dt TIMESTAMP   , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	last_update_user VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_XCDBANKACCOUNTTP
  ADD PRIMARY KEY (
	h_lang_tp_cd,
	h_BANK_ACCOUNT_TP_CD,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_XCDSALESREPTP (
	h_lang_tp_cd NUMBER(19, 0)   NOT NULL,
	h_tp_cd NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	lang_tp_cd NUMBER(19, 0)   NOT NULL , 
	tp_cd NUMBER(19, 0)   NOT NULL , 
	name VARCHAR2(120)   NOT NULL , 
	description VARCHAR2(250)   , 
	expiry_dt TIMESTAMP   , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	last_update_user VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_XCDSALESREPTP
  ADD PRIMARY KEY (
	h_lang_tp_cd,
	h_tp_cd,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_XCDIDENTIFIERSUBTP (
	h_lang_tp_cd NUMBER(19, 0)   NOT NULL,
	h_Identifier_Sub_TP_CD NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	lang_tp_cd NUMBER(19, 0)   NOT NULL , 
	Identifier_Sub_TP_CD NUMBER(19, 0)   NOT NULL , 
	name VARCHAR2(120)   NOT NULL , 
	description VARCHAR2(250)   , 
	expiry_dt TIMESTAMP   , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	last_update_user VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_XCDIDENTIFIERSUBTP
  ADD PRIMARY KEY (
	h_lang_tp_cd,
	h_Identifier_Sub_TP_CD,
   	h_create_dt    
 );

  
CREATE TABLE MDMDB.H_XCDMSO (
	h_lang_tp_cd NUMBER(19, 0)   NOT NULL,
	h_MSO_TP_CD NUMBER(19, 0)   NOT NULL,
	h_action_code                                    CHAR(1)         NOT NULL,
	h_created_by                                     VARCHAR2(20)    NOT NULL,
	h_create_dt                                      TIMESTAMP 	     DEFAULT LOCALTIMESTAMP NOT NULL,
	h_end_dt                                         TIMESTAMP,
	lang_tp_cd NUMBER(19, 0)   NOT NULL , 
	MSO_TP_CD NUMBER(19, 0)   NOT NULL , 
	name VARCHAR2(120)   NOT NULL , 
	description VARCHAR2(250)   , 
	expiry_dt TIMESTAMP   , 
	last_update_dt TIMESTAMP  DEFAULT LOCALTIMESTAMP  NOT NULL , 
	last_update_user VARCHAR2(20)   
  );

ALTER TABLE MDMDB.H_XCDMSO
  ADD PRIMARY KEY (
	h_lang_tp_cd,
	h_MSO_TP_CD,
   	h_create_dt    
 );

