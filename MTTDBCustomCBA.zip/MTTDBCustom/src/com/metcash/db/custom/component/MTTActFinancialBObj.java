
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[8267ccdb4f9cfe13adb60ee1208ef820]
 */

package com.metcash.db.custom.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;

import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;

import com.metcash.db.custom.constant.MTTDBCustomComponentID;
import com.metcash.db.custom.constant.MTTDBCustomErrorReasonCode;
import com.metcash.db.custom.constant.MTTDBCustomPropertyKeys;

import com.metcash.db.custom.entityObject.EObjMTTActFinancial;

import com.metcash.db.custom.interfaces.MTTDBCustom;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>MTTActFinancialBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class MTTActFinancialBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjMTTActFinancial eObjMTTActFinancial;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(MTTActFinancialBObj.class);
		
 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String statementModeValue;
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String dueGraceDaysValue;
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String tobaccoGraceDaysValue;
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String bankValue;
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String collectorValue;
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String bankAccountValue;
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String discountGraceDaysValue;
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String paymentMethodValue;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public MTTActFinancialBObj() {
        super();
        init();
        eObjMTTActFinancial = new EObjMTTActFinancial();
        setComponentID(MTTDBCustomComponentID.MTTACT_FINANCIAL_BOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("MTTActFinancialIdPk", null);
        metaDataMap.put("ContractId", null);
        metaDataMap.put("StatementModeType", null);
        metaDataMap.put("StatementModeValue", null);
        metaDataMap.put("DueGraceDaysType", null);
        metaDataMap.put("DueGraceDaysValue", null);
        metaDataMap.put("TobaccoGraceDaysType", null);
        metaDataMap.put("TobaccoGraceDaysValue", null);
        metaDataMap.put("BankType", null);
        metaDataMap.put("BankValue", null);
        metaDataMap.put("BPAYInd", null);
        metaDataMap.put("StatementPrintHoldInd", null);
        metaDataMap.put("BPAYCustomerRefNumber", null);
        metaDataMap.put("CollectorType", null);
        metaDataMap.put("CollectorValue", null);
        metaDataMap.put("BankAccountType", null);
        metaDataMap.put("BankAccountValue", null);
        metaDataMap.put("ExtTermsByShipDateInd", null);
        metaDataMap.put("SettlementDiscountInd", null);
        metaDataMap.put("AccountDetails", null);
        metaDataMap.put("DiscountGraceDaysType", null);
        metaDataMap.put("DiscountGraceDaysValue", null);
        metaDataMap.put("PaymentMethodType", null);
        metaDataMap.put("PaymentMethodValue", null);
        metaDataMap.put("LMAANumber", null);
        metaDataMap.put("MTTActFinancialHistActionCode", null);
        metaDataMap.put("MTTActFinancialHistCreateDate", null);
        metaDataMap.put("MTTActFinancialHistCreatedBy", null);
        metaDataMap.put("MTTActFinancialHistEndDate", null);
        metaDataMap.put("MTTActFinancialHistoryIdPK", null);
        metaDataMap.put("MTTActFinancialLastUpdateDate", null);
        metaDataMap.put("MTTActFinancialLastUpdateTxId", null);
        metaDataMap.put("MTTActFinancialLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("MTTActFinancialIdPk", getMTTActFinancialIdPk());
            metaDataMap.put("ContractId", getContractId());
            metaDataMap.put("StatementModeType", getStatementModeType());
            metaDataMap.put("StatementModeValue", getStatementModeValue());
            metaDataMap.put("DueGraceDaysType", getDueGraceDaysType());
            metaDataMap.put("DueGraceDaysValue", getDueGraceDaysValue());
            metaDataMap.put("TobaccoGraceDaysType", getTobaccoGraceDaysType());
            metaDataMap.put("TobaccoGraceDaysValue", getTobaccoGraceDaysValue());
            metaDataMap.put("BankType", getBankType());
            metaDataMap.put("BankValue", getBankValue());
            metaDataMap.put("BPAYInd", getBPAYInd());
            metaDataMap.put("StatementPrintHoldInd", getStatementPrintHoldInd());
            metaDataMap.put("BPAYCustomerRefNumber", getBPAYCustomerRefNumber());
            metaDataMap.put("CollectorType", getCollectorType());
            metaDataMap.put("CollectorValue", getCollectorValue());
            metaDataMap.put("BankAccountType", getBankAccountType());
            metaDataMap.put("BankAccountValue", getBankAccountValue());
            metaDataMap.put("ExtTermsByShipDateInd", getExtTermsByShipDateInd());
            metaDataMap.put("SettlementDiscountInd", getSettlementDiscountInd());
            metaDataMap.put("AccountDetails", getAccountDetails());
            metaDataMap.put("DiscountGraceDaysType", getDiscountGraceDaysType());
            metaDataMap.put("DiscountGraceDaysValue", getDiscountGraceDaysValue());
            metaDataMap.put("PaymentMethodType", getPaymentMethodType());
            metaDataMap.put("PaymentMethodValue", getPaymentMethodValue());
            metaDataMap.put("LMAANumber", getLMAANumber());
            metaDataMap.put("MTTActFinancialHistActionCode", getMTTActFinancialHistActionCode());
            metaDataMap.put("MTTActFinancialHistCreateDate", getMTTActFinancialHistCreateDate());
            metaDataMap.put("MTTActFinancialHistCreatedBy", getMTTActFinancialHistCreatedBy());
            metaDataMap.put("MTTActFinancialHistEndDate", getMTTActFinancialHistEndDate());
            metaDataMap.put("MTTActFinancialHistoryIdPK", getMTTActFinancialHistoryIdPK());
            metaDataMap.put("MTTActFinancialLastUpdateDate", getMTTActFinancialLastUpdateDate());
            metaDataMap.put("MTTActFinancialLastUpdateTxId", getMTTActFinancialLastUpdateTxId());
            metaDataMap.put("MTTActFinancialLastUpdateUser", getMTTActFinancialLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjMTTActFinancial != null) {
            eObjMTTActFinancial.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjMTTActFinancial getEObjMTTActFinancial() {
        bRequireMapRefresh = true;
        return eObjMTTActFinancial;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjMTTActFinancial
     *            The eObjMTTActFinancial to set.
     * @generated
     */
    public void setEObjMTTActFinancial(EObjMTTActFinancial eObjMTTActFinancial) {
        bRequireMapRefresh = true;
        this.eObjMTTActFinancial = eObjMTTActFinancial;
        if (this.eObjMTTActFinancial != null && this.eObjMTTActFinancial.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjMTTActFinancial.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the mTTActFinancialIdPk attribute.
     * 
     * @generated
     */
    public String getMTTActFinancialIdPk (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActFinancial.getMTTActFinancialIdPk());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the mTTActFinancialIdPk attribute.
     * 
     * @param newMTTActFinancialIdPk
     *     The new value of mTTActFinancialIdPk.
     * @generated
     */
    public void setMTTActFinancialIdPk( String newMTTActFinancialIdPk ) throws Exception {
        metaDataMap.put("MTTActFinancialIdPk", newMTTActFinancialIdPk);

        if (newMTTActFinancialIdPk == null || newMTTActFinancialIdPk.equals("")) {
            newMTTActFinancialIdPk = null;


        }
        eObjMTTActFinancial.setMTTActFinancialIdPk( DWLFunctionUtils.getLongFromString(newMTTActFinancialIdPk) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contractId attribute.
     * 
     * @generated
     */
    public String getContractId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActFinancial.getContractId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contractId attribute.
     * 
     * @param newContractId
     *     The new value of contractId.
     * @generated
     */
    public void setContractId( String newContractId ) throws Exception {
        metaDataMap.put("ContractId", newContractId);

        if (newContractId == null || newContractId.equals("")) {
            newContractId = null;


        }
        eObjMTTActFinancial.setContractId( DWLFunctionUtils.getLongFromString(newContractId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the statementModeType attribute.
     * 
     * @generated
     */
    public String getStatementModeType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActFinancial.getStatementMode());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the statementModeType attribute.
     * 
     * @param newStatementModeType
     *     The new value of statementModeType.
     * @generated
     */
    public void setStatementModeType( String newStatementModeType ) throws Exception {
        metaDataMap.put("StatementModeType", newStatementModeType);

        if (newStatementModeType == null || newStatementModeType.equals("")) {
            newStatementModeType = null;


        }
        eObjMTTActFinancial.setStatementMode( DWLFunctionUtils.getLongFromString(newStatementModeType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the statementModeValue attribute.
     * 
     * @generated
     */
    public String getStatementModeValue (){
      return statementModeValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the statementModeValue attribute.
     * 
     * @param newStatementModeValue
     *     The new value of statementModeValue.
     * @generated
     */
    public void setStatementModeValue( String newStatementModeValue ) throws Exception {
        metaDataMap.put("StatementModeValue", newStatementModeValue);

        if (newStatementModeValue == null || newStatementModeValue.equals("")) {
            newStatementModeValue = null;


        }
        statementModeValue = newStatementModeValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the dueGraceDaysType attribute.
     * 
     * @generated
     */
    public String getDueGraceDaysType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActFinancial.getDueGraceDays());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the dueGraceDaysType attribute.
     * 
     * @param newDueGraceDaysType
     *     The new value of dueGraceDaysType.
     * @generated
     */
    public void setDueGraceDaysType( String newDueGraceDaysType ) throws Exception {
        metaDataMap.put("DueGraceDaysType", newDueGraceDaysType);

        if (newDueGraceDaysType == null || newDueGraceDaysType.equals("")) {
            newDueGraceDaysType = null;


        }
        eObjMTTActFinancial.setDueGraceDays( DWLFunctionUtils.getLongFromString(newDueGraceDaysType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the dueGraceDaysValue attribute.
     * 
     * @generated
     */
    public String getDueGraceDaysValue (){
      return dueGraceDaysValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the dueGraceDaysValue attribute.
     * 
     * @param newDueGraceDaysValue
     *     The new value of dueGraceDaysValue.
     * @generated
     */
    public void setDueGraceDaysValue( String newDueGraceDaysValue ) throws Exception {
        metaDataMap.put("DueGraceDaysValue", newDueGraceDaysValue);

        if (newDueGraceDaysValue == null || newDueGraceDaysValue.equals("")) {
            newDueGraceDaysValue = null;


        }
        dueGraceDaysValue = newDueGraceDaysValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the tobaccoGraceDaysType attribute.
     * 
     * @generated
     */
    public String getTobaccoGraceDaysType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActFinancial.getTobaccoGraceDays());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the tobaccoGraceDaysType attribute.
     * 
     * @param newTobaccoGraceDaysType
     *     The new value of tobaccoGraceDaysType.
     * @generated
     */
    public void setTobaccoGraceDaysType( String newTobaccoGraceDaysType ) throws Exception {
        metaDataMap.put("TobaccoGraceDaysType", newTobaccoGraceDaysType);

        if (newTobaccoGraceDaysType == null || newTobaccoGraceDaysType.equals("")) {
            newTobaccoGraceDaysType = null;


        }
        eObjMTTActFinancial.setTobaccoGraceDays( DWLFunctionUtils.getLongFromString(newTobaccoGraceDaysType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the tobaccoGraceDaysValue attribute.
     * 
     * @generated
     */
    public String getTobaccoGraceDaysValue (){
      return tobaccoGraceDaysValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the tobaccoGraceDaysValue attribute.
     * 
     * @param newTobaccoGraceDaysValue
     *     The new value of tobaccoGraceDaysValue.
     * @generated
     */
    public void setTobaccoGraceDaysValue( String newTobaccoGraceDaysValue ) throws Exception {
        metaDataMap.put("TobaccoGraceDaysValue", newTobaccoGraceDaysValue);

        if (newTobaccoGraceDaysValue == null || newTobaccoGraceDaysValue.equals("")) {
            newTobaccoGraceDaysValue = null;


        }
        tobaccoGraceDaysValue = newTobaccoGraceDaysValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the bankType attribute.
     * 
     * @generated
     */
    public String getBankType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActFinancial.getBank());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the bankType attribute.
     * 
     * @param newBankType
     *     The new value of bankType.
     * @generated
     */
    public void setBankType( String newBankType ) throws Exception {
        metaDataMap.put("BankType", newBankType);

        if (newBankType == null || newBankType.equals("")) {
            newBankType = null;


        }
        eObjMTTActFinancial.setBank( DWLFunctionUtils.getLongFromString(newBankType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the bankValue attribute.
     * 
     * @generated
     */
    public String getBankValue (){
      return bankValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the bankValue attribute.
     * 
     * @param newBankValue
     *     The new value of bankValue.
     * @generated
     */
    public void setBankValue( String newBankValue ) throws Exception {
        metaDataMap.put("BankValue", newBankValue);

        if (newBankValue == null || newBankValue.equals("")) {
            newBankValue = null;


        }
        bankValue = newBankValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the bPAYInd attribute.
     * 
     * @generated
     */
    public String getBPAYInd (){
   
        return eObjMTTActFinancial.getBPAYInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the bPAYInd attribute.
     * 
     * @param newBPAYInd
     *     The new value of bPAYInd.
     * @generated
     */
    public void setBPAYInd( String newBPAYInd ) throws Exception {
        metaDataMap.put("BPAYInd", newBPAYInd);

        if (newBPAYInd == null || newBPAYInd.equals("")) {
            newBPAYInd = null;


        }
        eObjMTTActFinancial.setBPAYInd( newBPAYInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the statementPrintHoldInd attribute.
     * 
     * @generated
     */
    public String getStatementPrintHoldInd (){
   
        return eObjMTTActFinancial.getStatementPrintHoldInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the statementPrintHoldInd attribute.
     * 
     * @param newStatementPrintHoldInd
     *     The new value of statementPrintHoldInd.
     * @generated
     */
    public void setStatementPrintHoldInd( String newStatementPrintHoldInd ) throws Exception {
        metaDataMap.put("StatementPrintHoldInd", newStatementPrintHoldInd);

        if (newStatementPrintHoldInd == null || newStatementPrintHoldInd.equals("")) {
            newStatementPrintHoldInd = null;


        }
        eObjMTTActFinancial.setStatementPrintHoldInd( newStatementPrintHoldInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the bPAYCustomerRefNumber attribute.
     * 
     * @generated
     */
    public String getBPAYCustomerRefNumber (){
   
        return DWLFunctionUtils.getStringFromInteger(eObjMTTActFinancial.getBPAYCustomerRefNumber());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the bPAYCustomerRefNumber attribute.
     * 
     * @param newBPAYCustomerRefNumber
     *     The new value of bPAYCustomerRefNumber.
     * @generated
     */
    public void setBPAYCustomerRefNumber( String newBPAYCustomerRefNumber ) throws Exception {
        metaDataMap.put("BPAYCustomerRefNumber", newBPAYCustomerRefNumber);

        if (newBPAYCustomerRefNumber == null || newBPAYCustomerRefNumber.equals("")) {
            newBPAYCustomerRefNumber = null;


        }
        eObjMTTActFinancial.setBPAYCustomerRefNumber( DWLFunctionUtils.getIntegerFromString(newBPAYCustomerRefNumber) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the collectorType attribute.
     * 
     * @generated
     */
    public String getCollectorType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActFinancial.getCollector());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the collectorType attribute.
     * 
     * @param newCollectorType
     *     The new value of collectorType.
     * @generated
     */
    public void setCollectorType( String newCollectorType ) throws Exception {
        metaDataMap.put("CollectorType", newCollectorType);

        if (newCollectorType == null || newCollectorType.equals("")) {
            newCollectorType = null;


        }
        eObjMTTActFinancial.setCollector( DWLFunctionUtils.getLongFromString(newCollectorType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the collectorValue attribute.
     * 
     * @generated
     */
    public String getCollectorValue (){
      return collectorValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the collectorValue attribute.
     * 
     * @param newCollectorValue
     *     The new value of collectorValue.
     * @generated
     */
    public void setCollectorValue( String newCollectorValue ) throws Exception {
        metaDataMap.put("CollectorValue", newCollectorValue);

        if (newCollectorValue == null || newCollectorValue.equals("")) {
            newCollectorValue = null;


        }
        collectorValue = newCollectorValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the bankAccountType attribute.
     * 
     * @generated
     */
    public String getBankAccountType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActFinancial.getBankAccount());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the bankAccountType attribute.
     * 
     * @param newBankAccountType
     *     The new value of bankAccountType.
     * @generated
     */
    public void setBankAccountType( String newBankAccountType ) throws Exception {
        metaDataMap.put("BankAccountType", newBankAccountType);

        if (newBankAccountType == null || newBankAccountType.equals("")) {
            newBankAccountType = null;


        }
        eObjMTTActFinancial.setBankAccount( DWLFunctionUtils.getLongFromString(newBankAccountType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the bankAccountValue attribute.
     * 
     * @generated
     */
    public String getBankAccountValue (){
      return bankAccountValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the bankAccountValue attribute.
     * 
     * @param newBankAccountValue
     *     The new value of bankAccountValue.
     * @generated
     */
    public void setBankAccountValue( String newBankAccountValue ) throws Exception {
        metaDataMap.put("BankAccountValue", newBankAccountValue);

        if (newBankAccountValue == null || newBankAccountValue.equals("")) {
            newBankAccountValue = null;


        }
        bankAccountValue = newBankAccountValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the extTermsByShipDateInd attribute.
     * 
     * @generated
     */
    public String getExtTermsByShipDateInd (){
   
        return eObjMTTActFinancial.getExtTermsByShipDateInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the extTermsByShipDateInd attribute.
     * 
     * @param newExtTermsByShipDateInd
     *     The new value of extTermsByShipDateInd.
     * @generated
     */
    public void setExtTermsByShipDateInd( String newExtTermsByShipDateInd ) throws Exception {
        metaDataMap.put("ExtTermsByShipDateInd", newExtTermsByShipDateInd);

        if (newExtTermsByShipDateInd == null || newExtTermsByShipDateInd.equals("")) {
            newExtTermsByShipDateInd = null;


        }
        eObjMTTActFinancial.setExtTermsByShipDateInd( newExtTermsByShipDateInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the settlementDiscountInd attribute.
     * 
     * @generated
     */
    public String getSettlementDiscountInd (){
   
        return eObjMTTActFinancial.getSettlementDiscountInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the settlementDiscountInd attribute.
     * 
     * @param newSettlementDiscountInd
     *     The new value of settlementDiscountInd.
     * @generated
     */
    public void setSettlementDiscountInd( String newSettlementDiscountInd ) throws Exception {
        metaDataMap.put("SettlementDiscountInd", newSettlementDiscountInd);

        if (newSettlementDiscountInd == null || newSettlementDiscountInd.equals("")) {
            newSettlementDiscountInd = null;


        }
        eObjMTTActFinancial.setSettlementDiscountInd( newSettlementDiscountInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the accountDetails attribute.
     * 
     * @generated
     */
    public String getAccountDetails (){
   
        return eObjMTTActFinancial.getAccountDetails();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the accountDetails attribute.
     * 
     * @param newAccountDetails
     *     The new value of accountDetails.
     * @generated
     */
    public void setAccountDetails( String newAccountDetails ) throws Exception {
        metaDataMap.put("AccountDetails", newAccountDetails);

        if (newAccountDetails == null || newAccountDetails.equals("")) {
            newAccountDetails = null;


        }
        eObjMTTActFinancial.setAccountDetails( newAccountDetails );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the discountGraceDaysType attribute.
     * 
     * @generated
     */
    public String getDiscountGraceDaysType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActFinancial.getDiscountGraceDays());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the discountGraceDaysType attribute.
     * 
     * @param newDiscountGraceDaysType
     *     The new value of discountGraceDaysType.
     * @generated
     */
    public void setDiscountGraceDaysType( String newDiscountGraceDaysType ) throws Exception {
        metaDataMap.put("DiscountGraceDaysType", newDiscountGraceDaysType);

        if (newDiscountGraceDaysType == null || newDiscountGraceDaysType.equals("")) {
            newDiscountGraceDaysType = null;


        }
        eObjMTTActFinancial.setDiscountGraceDays( DWLFunctionUtils.getLongFromString(newDiscountGraceDaysType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the discountGraceDaysValue attribute.
     * 
     * @generated
     */
    public String getDiscountGraceDaysValue (){
      return discountGraceDaysValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the discountGraceDaysValue attribute.
     * 
     * @param newDiscountGraceDaysValue
     *     The new value of discountGraceDaysValue.
     * @generated
     */
    public void setDiscountGraceDaysValue( String newDiscountGraceDaysValue ) throws Exception {
        metaDataMap.put("DiscountGraceDaysValue", newDiscountGraceDaysValue);

        if (newDiscountGraceDaysValue == null || newDiscountGraceDaysValue.equals("")) {
            newDiscountGraceDaysValue = null;


        }
        discountGraceDaysValue = newDiscountGraceDaysValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the paymentMethodType attribute.
     * 
     * @generated
     */
    public String getPaymentMethodType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActFinancial.getPaymentMethod());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the paymentMethodType attribute.
     * 
     * @param newPaymentMethodType
     *     The new value of paymentMethodType.
     * @generated
     */
    public void setPaymentMethodType( String newPaymentMethodType ) throws Exception {
        metaDataMap.put("PaymentMethodType", newPaymentMethodType);

        if (newPaymentMethodType == null || newPaymentMethodType.equals("")) {
            newPaymentMethodType = null;


        }
        eObjMTTActFinancial.setPaymentMethod( DWLFunctionUtils.getLongFromString(newPaymentMethodType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the paymentMethodValue attribute.
     * 
     * @generated
     */
    public String getPaymentMethodValue (){
      return paymentMethodValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the paymentMethodValue attribute.
     * 
     * @param newPaymentMethodValue
     *     The new value of paymentMethodValue.
     * @generated
     */
    public void setPaymentMethodValue( String newPaymentMethodValue ) throws Exception {
        metaDataMap.put("PaymentMethodValue", newPaymentMethodValue);

        if (newPaymentMethodValue == null || newPaymentMethodValue.equals("")) {
            newPaymentMethodValue = null;


        }
        paymentMethodValue = newPaymentMethodValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the lMAANumber attribute.
     * 
     * @generated
     */
    public String getLMAANumber (){
   
        return eObjMTTActFinancial.getLMAANumber();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the lMAANumber attribute.
     * 
     * @param newLMAANumber
     *     The new value of lMAANumber.
     * @generated
     */
    public void setLMAANumber( String newLMAANumber ) throws Exception {
        metaDataMap.put("LMAANumber", newLMAANumber);

        if (newLMAANumber == null || newLMAANumber.equals("")) {
            newLMAANumber = null;


        }
        eObjMTTActFinancial.setLMAANumber( newLMAANumber );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getMTTActFinancialLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjMTTActFinancial.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getMTTActFinancialLastUpdateUser() {
        return eObjMTTActFinancial.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getMTTActFinancialLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjMTTActFinancial.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setMTTActFinancialLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("MTTActFinancialLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjMTTActFinancial.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setMTTActFinancialLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("MTTActFinancialLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjMTTActFinancial.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setMTTActFinancialLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("MTTActFinancialLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjMTTActFinancial.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTActFinancialHistActionCode history attribute.
     *
     * @generated
     */
    public String getMTTActFinancialHistActionCode() {
        return eObjMTTActFinancial.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTActFinancialHistActionCode history attribute.
     *
     * @param aMTTActFinancialHistActionCode
     *     The new value of MTTActFinancialHistActionCode.
     * @generated
     */
    public void setMTTActFinancialHistActionCode(String aMTTActFinancialHistActionCode) {
        metaDataMap.put("MTTActFinancialHistActionCode", aMTTActFinancialHistActionCode);

        if ((aMTTActFinancialHistActionCode == null) || aMTTActFinancialHistActionCode.equals("")) {
            aMTTActFinancialHistActionCode = null;
        }
        eObjMTTActFinancial.setHistActionCode(aMTTActFinancialHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTActFinancialHistCreateDate history attribute.
     *
     * @generated
     */
    public String getMTTActFinancialHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjMTTActFinancial.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTActFinancialHistCreateDate history attribute.
     *
     * @param aMTTActFinancialHistCreateDate
     *     The new value of MTTActFinancialHistCreateDate.
     * @generated
     */
    public void setMTTActFinancialHistCreateDate(String aMTTActFinancialHistCreateDate) throws Exception{
        metaDataMap.put("MTTActFinancialHistCreateDate", aMTTActFinancialHistCreateDate);

        if ((aMTTActFinancialHistCreateDate == null) || aMTTActFinancialHistCreateDate.equals("")) {
            aMTTActFinancialHistCreateDate = null;
        }

        eObjMTTActFinancial.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aMTTActFinancialHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTActFinancialHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getMTTActFinancialHistCreatedBy() {
        return eObjMTTActFinancial.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTActFinancialHistCreatedBy history attribute.
     *
     * @param aMTTActFinancialHistCreatedBy
     *     The new value of MTTActFinancialHistCreatedBy.
     * @generated
     */
    public void setMTTActFinancialHistCreatedBy(String aMTTActFinancialHistCreatedBy) {
        metaDataMap.put("MTTActFinancialHistCreatedBy", aMTTActFinancialHistCreatedBy);

        if ((aMTTActFinancialHistCreatedBy == null) || aMTTActFinancialHistCreatedBy.equals("")) {
            aMTTActFinancialHistCreatedBy = null;
        }

        eObjMTTActFinancial.setHistCreatedBy(aMTTActFinancialHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTActFinancialHistEndDate history attribute.
     *
     * @generated
     */
    public String getMTTActFinancialHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjMTTActFinancial.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTActFinancialHistEndDate history attribute.
     *
     * @param aMTTActFinancialHistEndDate
     *     The new value of MTTActFinancialHistEndDate.
     * @generated
     */
    public void setMTTActFinancialHistEndDate(String aMTTActFinancialHistEndDate) throws Exception{
        metaDataMap.put("MTTActFinancialHistEndDate", aMTTActFinancialHistEndDate);

        if ((aMTTActFinancialHistEndDate == null) || aMTTActFinancialHistEndDate.equals("")) {
            aMTTActFinancialHistEndDate = null;
        }
        eObjMTTActFinancial.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aMTTActFinancialHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTActFinancialHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getMTTActFinancialHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjMTTActFinancial.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTActFinancialHistoryIdPK history attribute.
     *
     * @param aMTTActFinancialHistoryIdPK
     *     The new value of MTTActFinancialHistoryIdPK.
     * @generated
     */
    public void setMTTActFinancialHistoryIdPK(String aMTTActFinancialHistoryIdPK) {
        metaDataMap.put("MTTActFinancialHistoryIdPK", aMTTActFinancialHistoryIdPK);

        if ((aMTTActFinancialHistoryIdPK == null) || aMTTActFinancialHistoryIdPK.equals("")) {
            aMTTActFinancialHistoryIdPK = null;
        }
        eObjMTTActFinancial.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aMTTActFinancialHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjMTTActFinancial.getMTTActFinancialIdPk() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_FINANCIAL_BOBJ).longValue());
                err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.MTTACTFINANCIAL_MTTACTFINANCIALIDPK_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity MTTActFinancial, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjMTTActFinancial.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_FINANCIAL_BOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity MTTActFinancial, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        MTTDBCustom comp = null;
        try {
        
      comp = (MTTDBCustom)TCRMClassFactory.getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  MTTDBCustomComponentID.MTTACT_FINANCIAL_BOBJ, 
                                  "DIERR",
                                  MTTDBCustomErrorReasonCode.MTTACTFINANCIAL_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
        }
        
        comp.loadBeforeImage(this);
    logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_ContractId(status);
    		controllerValidation_StatementMode(status);
    		controllerValidation_DueGraceDays(status);
    		controllerValidation_TobaccoGraceDays(status);
    		controllerValidation_Bank(status);
    		controllerValidation_Collector(status);
    		controllerValidation_BankAccount(status);
    		controllerValidation_DiscountGraceDays(status);
    		controllerValidation_PaymentMethod(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_ContractId(status);
    		componentValidation_StatementMode(status);
    		componentValidation_DueGraceDays(status);
    		componentValidation_TobaccoGraceDays(status);
    		componentValidation_Bank(status);
    		componentValidation_Collector(status);
    		componentValidation_BankAccount(status);
    		componentValidation_DiscountGraceDays(status);
    		componentValidation_PaymentMethod(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "ContractId"
     *
     * @generated
     */
	private void componentValidation_ContractId(DWLStatus status) {
  
            boolean isContractIdNull = (eObjMTTActFinancial.getContractId() == null);
            if (isContractIdNull) {
                DWLError err = createDWLError("MTTActFinancial", "ContractId", MTTDBCustomErrorReasonCode.MTTACTFINANCIAL_CONTRACTID_NULL);
                status.addError(err); 
            }
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "StatementMode"
     *
     * @generated
     */
  private void componentValidation_StatementMode(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "DueGraceDays"
     *
     * @generated
     */
  private void componentValidation_DueGraceDays(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "TobaccoGraceDays"
     *
     * @generated
     */
  private void componentValidation_TobaccoGraceDays(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "Bank"
     *
     * @generated
     */
  private void componentValidation_Bank(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "Collector"
     *
     * @generated
     */
  private void componentValidation_Collector(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "BankAccount"
     *
     * @generated
     */
  private void componentValidation_BankAccount(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "DiscountGraceDays"
     *
     * @generated
     */
  private void componentValidation_DiscountGraceDays(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "PaymentMethod"
     *
     * @generated
     */
  private void componentValidation_PaymentMethod(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "ContractId"
     *
     * @generated
     */
	private void controllerValidation_ContractId(DWLStatus status) throws Exception {
  
            boolean isContractIdNull = (eObjMTTActFinancial.getContractId() == null);
            if (isContractIdNull) {
                DWLError err = createDWLError("MTTActFinancial", "ContractId", MTTDBCustomErrorReasonCode.MTTACTFINANCIAL_CONTRACTID_NULL);
                status.addError(err); 
            }
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "StatementMode"
     *
     * @generated
     */
  private void controllerValidation_StatementMode(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isStatementModeNull = false;
            if ((eObjMTTActFinancial.getStatementMode() == null) &&
               ((getStatementModeValue() == null) || 
                 getStatementModeValue().trim().equals(""))) {
                isStatementModeNull = true;
            }
            if (!isStatementModeNull) {
                if (checkForInvalidMttactfinancialStatementmode()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_FINANCIAL_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTFINANCIAL_STATEMENTMODE).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTActFinancial, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_StatementMode " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "DueGraceDays"
     *
     * @generated
     */
  private void controllerValidation_DueGraceDays(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isDueGraceDaysNull = false;
            if ((eObjMTTActFinancial.getDueGraceDays() == null) &&
               ((getDueGraceDaysValue() == null) || 
                 getDueGraceDaysValue().trim().equals(""))) {
                isDueGraceDaysNull = true;
            }
            if (!isDueGraceDaysNull) {
                if (checkForInvalidMttactfinancialDuegracedays()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_FINANCIAL_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTFINANCIAL_DUEGRACEDAYS).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTActFinancial, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_DueGraceDays " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "TobaccoGraceDays"
     *
     * @generated
     */
  private void controllerValidation_TobaccoGraceDays(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isTobaccoGraceDaysNull = false;
            if ((eObjMTTActFinancial.getTobaccoGraceDays() == null) &&
               ((getTobaccoGraceDaysValue() == null) || 
                 getTobaccoGraceDaysValue().trim().equals(""))) {
                isTobaccoGraceDaysNull = true;
            }
            if (!isTobaccoGraceDaysNull) {
                if (checkForInvalidMttactfinancialTobaccogracedays()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_FINANCIAL_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTFINANCIAL_TOBACCOGRACEDAYS).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTActFinancial, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_TobaccoGraceDays " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "Bank"
     *
     * @generated
     */
  private void controllerValidation_Bank(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isBankNull = false;
            if ((eObjMTTActFinancial.getBank() == null) &&
               ((getBankValue() == null) || 
                 getBankValue().trim().equals(""))) {
                isBankNull = true;
            }
            if (!isBankNull) {
                if (checkForInvalidMttactfinancialBank()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_FINANCIAL_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTFINANCIAL_BANK).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTActFinancial, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_Bank " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "Collector"
     *
     * @generated
     */
  private void controllerValidation_Collector(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isCollectorNull = false;
            if ((eObjMTTActFinancial.getCollector() == null) &&
               ((getCollectorValue() == null) || 
                 getCollectorValue().trim().equals(""))) {
                isCollectorNull = true;
            }
            if (!isCollectorNull) {
                if (checkForInvalidMttactfinancialCollector()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_FINANCIAL_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTFINANCIAL_COLLECTOR).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTActFinancial, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_Collector " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "BankAccount"
     *
     * @generated
     */
  private void controllerValidation_BankAccount(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isBankAccountNull = false;
            if ((eObjMTTActFinancial.getBankAccount() == null) &&
               ((getBankAccountValue() == null) || 
                 getBankAccountValue().trim().equals(""))) {
                isBankAccountNull = true;
            }
            if (!isBankAccountNull) {
                if (checkForInvalidMttactfinancialBankaccount()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_FINANCIAL_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTFINANCIAL_BANKACCOUNT).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTActFinancial, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_BankAccount " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "DiscountGraceDays"
     *
     * @generated
     */
  private void controllerValidation_DiscountGraceDays(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isDiscountGraceDaysNull = false;
            if ((eObjMTTActFinancial.getDiscountGraceDays() == null) &&
               ((getDiscountGraceDaysValue() == null) || 
                 getDiscountGraceDaysValue().trim().equals(""))) {
                isDiscountGraceDaysNull = true;
            }
            if (!isDiscountGraceDaysNull) {
                if (checkForInvalidMttactfinancialDiscountgracedays()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_FINANCIAL_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTFINANCIAL_DISCOUNTGRACEDAYS).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTActFinancial, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_DiscountGraceDays " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "PaymentMethod"
     *
     * @generated
     */
  private void controllerValidation_PaymentMethod(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isPaymentMethodNull = false;
            if ((eObjMTTActFinancial.getPaymentMethod() == null) &&
               ((getPaymentMethodValue() == null) || 
                 getPaymentMethodValue().trim().equals(""))) {
                isPaymentMethodNull = true;
            }
            if (!isPaymentMethodNull) {
                if (checkForInvalidMttactfinancialPaymentmethod()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_FINANCIAL_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTFINANCIAL_PAYMENTMETHOD).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTActFinancial, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_PaymentMethod " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_FINANCIAL_BOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field StatementMode and return true if the error
     * reason INVALID_MTTACTFINANCIAL_STATEMENTMODE should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttactfinancialStatementmode() throws Exception {
    logger.finest("ENTER checkForInvalidMttactfinancialStatementmode()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getStatementModeType() );
    String codeValue = getStatementModeValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdstatementmodetp", langId, getStatementModeType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdstatementmodetp", langId, getStatementModeType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setStatementModeValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttactfinancialStatementmode() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdstatementmodetp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setStatementModeType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttactfinancialStatementmode() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdstatementmodetp", langId, getStatementModeType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttactfinancialStatementmode() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttactfinancialStatementmode() " + returnValue);
    }
    return notValid;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field DueGraceDays and return true if the error
     * reason INVALID_MTTACTFINANCIAL_DUEGRACEDAYS should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttactfinancialDuegracedays() throws Exception {
    logger.finest("ENTER checkForInvalidMttactfinancialDuegracedays()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getDueGraceDaysType() );
    String codeValue = getDueGraceDaysValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdgracedaystp", langId, getDueGraceDaysType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdgracedaystp", langId, getDueGraceDaysType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setDueGraceDaysValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttactfinancialDuegracedays() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdgracedaystp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setDueGraceDaysType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttactfinancialDuegracedays() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdgracedaystp", langId, getDueGraceDaysType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttactfinancialDuegracedays() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttactfinancialDuegracedays() " + returnValue);
    }
    return notValid;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field TobaccoGraceDays and return true if the
     * error reason INVALID_MTTACTFINANCIAL_TOBACCOGRACEDAYS should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttactfinancialTobaccogracedays() throws Exception {
    logger.finest("ENTER checkForInvalidMttactfinancialTobaccogracedays()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getTobaccoGraceDaysType() );
    String codeValue = getTobaccoGraceDaysValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdgracedaystp", langId, getTobaccoGraceDaysType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdgracedaystp", langId, getTobaccoGraceDaysType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setTobaccoGraceDaysValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttactfinancialTobaccogracedays() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdgracedaystp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setTobaccoGraceDaysType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttactfinancialTobaccogracedays() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdgracedaystp", langId, getTobaccoGraceDaysType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttactfinancialTobaccogracedays() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttactfinancialTobaccogracedays() " + returnValue);
    }
    return notValid;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field Bank and return true if the error reason
     * INVALID_MTTACTFINANCIAL_BANK should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttactfinancialBank() throws Exception {
    logger.finest("ENTER checkForInvalidMttactfinancialBank()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getBankType() );
    String codeValue = getBankValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdbanktp", langId, getBankType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdbanktp", langId, getBankType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setBankValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttactfinancialBank() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdbanktp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setBankType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttactfinancialBank() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdbanktp", langId, getBankType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttactfinancialBank() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttactfinancialBank() " + returnValue);
    }
    return notValid;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field Collector and return true if the error
     * reason INVALID_MTTACTFINANCIAL_COLLECTOR should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttactfinancialCollector() throws Exception {
    logger.finest("ENTER checkForInvalidMttactfinancialCollector()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getCollectorType() );
    String codeValue = getCollectorValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdcollectortp", langId, getCollectorType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdcollectortp", langId, getCollectorType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setCollectorValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttactfinancialCollector() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdcollectortp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setCollectorType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttactfinancialCollector() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdcollectortp", langId, getCollectorType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttactfinancialCollector() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttactfinancialCollector() " + returnValue);
    }
    return notValid;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field BankAccount and return true if the error
     * reason INVALID_MTTACTFINANCIAL_BANKACCOUNT should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttactfinancialBankaccount() throws Exception {
    logger.finest("ENTER checkForInvalidMttactfinancialBankaccount()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getBankAccountType() );
    String codeValue = getBankAccountValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdbankaccounttp", langId, getBankAccountType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdbankaccounttp", langId, getBankAccountType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setBankAccountValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttactfinancialBankaccount() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdbankaccounttp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setBankAccountType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttactfinancialBankaccount() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdbankaccounttp", langId, getBankAccountType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttactfinancialBankaccount() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttactfinancialBankaccount() " + returnValue);
    }
    return notValid;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field DiscountGraceDays and return true if the
     * error reason INVALID_MTTACTFINANCIAL_DISCOUNTGRACEDAYS should be
     * returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttactfinancialDiscountgracedays() throws Exception {
    logger.finest("ENTER checkForInvalidMttactfinancialDiscountgracedays()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getDiscountGraceDaysType() );
    String codeValue = getDiscountGraceDaysValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdgracedaystp", langId, getDiscountGraceDaysType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdgracedaystp", langId, getDiscountGraceDaysType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setDiscountGraceDaysValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttactfinancialDiscountgracedays() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdgracedaystp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setDiscountGraceDaysType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttactfinancialDiscountgracedays() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdgracedaystp", langId, getDiscountGraceDaysType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttactfinancialDiscountgracedays() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttactfinancialDiscountgracedays() " + returnValue);
    }
    return notValid;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field PaymentMethod and return true if the error
     * reason INVALID_MTTACTFINANCIAL_PAYMENTMETHOD should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttactfinancialPaymentmethod() throws Exception {
    logger.finest("ENTER checkForInvalidMttactfinancialPaymentmethod()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getPaymentMethodType() );
    String codeValue = getPaymentMethodValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdpaymentmethodtp", langId, getPaymentMethodType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdpaymentmethodtp", langId, getPaymentMethodType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setPaymentMethodValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttactfinancialPaymentmethod() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdpaymentmethodtp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setPaymentMethodType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttactfinancialPaymentmethod() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdpaymentmethodtp", langId, getPaymentMethodType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttactfinancialPaymentmethod() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttactfinancialPaymentmethod() " + returnValue);
    }
    return notValid;
     } 
				 



}

