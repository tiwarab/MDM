
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[2b92df02ad03673d966209720252a981]
 */

package com.metcash.db.custom.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.management.config.client.Configuration;

import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;
import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;

import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;

import com.metcash.db.custom.constant.MTTDBCustomComponentID;
import com.metcash.db.custom.constant.MTTDBCustomErrorReasonCode;
import com.metcash.db.custom.constant.MTTDBCustomPropertyKeys;

import com.metcash.db.custom.entityObject.EObjMTTActCreditTax;

import com.metcash.db.custom.interfaces.MTTDBCustom;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>MTTActCreditTaxBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class MTTActCreditTaxBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjMTTActCreditTax eObjMTTActCreditTax;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(MTTActCreditTaxBObj.class);
		
 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String invoiceTermsValue;
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String customerGroupValue;
    protected boolean isValidBankGuaranteeEndDate = true;
	
	protected boolean isValidCashDepositRecieveDate = true;
	
	protected boolean isValidCashDepositReleaseDate = true;
	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String chequeLimitCurrencyValue;
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String salesRepValue;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public MTTActCreditTaxBObj() {
        super();
        init();
        eObjMTTActCreditTax = new EObjMTTActCreditTax();
        setComponentID(MTTDBCustomComponentID.MTTACT_CREDIT_TAX_BOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("MTTActCreditTaxIdPk", null);
        metaDataMap.put("ContractId", null);
        metaDataMap.put("InvoiceTermsType", null);
        metaDataMap.put("InvoiceTermsValue", null);
        metaDataMap.put("GSTExemptInd", null);
        metaDataMap.put("CustomerGroupType", null);
        metaDataMap.put("CustomerGroupValue", null);
        metaDataMap.put("BankGuaranteeAmount", null);
        metaDataMap.put("BankGuaranteeEndDate", null);
        metaDataMap.put("CashDepositAmount", null);
        metaDataMap.put("CashDepositRecieveDate", null);
        metaDataMap.put("CashDepositReleaseDate", null);
        metaDataMap.put("FirstMortgage", null);
        metaDataMap.put("SecondMortgage", null);
        metaDataMap.put("DeedOfPriority", null);
        metaDataMap.put("PPSRDetails", null);
        metaDataMap.put("PMSIDetails", null);
        metaDataMap.put("ALLPAPDetails", null);
        metaDataMap.put("Arrears", null);
        metaDataMap.put("CreditHold", null);
        metaDataMap.put("NationalHold", null);
        metaDataMap.put("CreditHoldDate", null);
        metaDataMap.put("CreditStatusOverride", null);
        metaDataMap.put("ChequeLimitAmount", null);
        metaDataMap.put("ChequeLimitCurrencyType", null);
        metaDataMap.put("ChequeLimitCurrencyValue", null);
        metaDataMap.put("WETExemptInd", null);
        metaDataMap.put("DutyFreeInd", null);
        metaDataMap.put("CashOnDeliveryInd", null);
        metaDataMap.put("SalesRepType", null);
        metaDataMap.put("SalesRepValue", null);
        metaDataMap.put("MTTActCreditTaxHistActionCode", null);
        metaDataMap.put("MTTActCreditTaxHistCreateDate", null);
        metaDataMap.put("MTTActCreditTaxHistCreatedBy", null);
        metaDataMap.put("MTTActCreditTaxHistEndDate", null);
        metaDataMap.put("MTTActCreditTaxHistoryIdPK", null);
        metaDataMap.put("MTTActCreditTaxLastUpdateDate", null);
        metaDataMap.put("MTTActCreditTaxLastUpdateTxId", null);
        metaDataMap.put("MTTActCreditTaxLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("MTTActCreditTaxIdPk", getMTTActCreditTaxIdPk());
            metaDataMap.put("ContractId", getContractId());
            metaDataMap.put("InvoiceTermsType", getInvoiceTermsType());
            metaDataMap.put("InvoiceTermsValue", getInvoiceTermsValue());
            metaDataMap.put("GSTExemptInd", getGSTExemptInd());
            metaDataMap.put("CustomerGroupType", getCustomerGroupType());
            metaDataMap.put("CustomerGroupValue", getCustomerGroupValue());
            metaDataMap.put("BankGuaranteeAmount", getBankGuaranteeAmount());
            metaDataMap.put("BankGuaranteeEndDate", getBankGuaranteeEndDate());
            metaDataMap.put("CashDepositAmount", getCashDepositAmount());
            metaDataMap.put("CashDepositRecieveDate", getCashDepositRecieveDate());
            metaDataMap.put("CashDepositReleaseDate", getCashDepositReleaseDate());
            metaDataMap.put("FirstMortgage", getFirstMortgage());
            metaDataMap.put("SecondMortgage", getSecondMortgage());
            metaDataMap.put("DeedOfPriority", getDeedOfPriority());
            metaDataMap.put("PPSRDetails", getPPSRDetails());
            metaDataMap.put("PMSIDetails", getPMSIDetails());
            metaDataMap.put("ALLPAPDetails", getALLPAPDetails());
            metaDataMap.put("Arrears", getArrears());
            metaDataMap.put("CreditHold", getCreditHold());
            metaDataMap.put("NationalHold", getNationalHold());
            metaDataMap.put("CreditHoldDate", getCreditHoldDate());
            metaDataMap.put("CreditStatusOverride", getCreditStatusOverride());
            metaDataMap.put("ChequeLimitAmount", getChequeLimitAmount());
            metaDataMap.put("ChequeLimitCurrencyType", getChequeLimitCurrencyType());
            metaDataMap.put("ChequeLimitCurrencyValue", getChequeLimitCurrencyValue());
            metaDataMap.put("WETExemptInd", getWETExemptInd());
            metaDataMap.put("DutyFreeInd", getDutyFreeInd());
            metaDataMap.put("CashOnDeliveryInd", getCashOnDeliveryInd());
            metaDataMap.put("SalesRepType", getSalesRepType());
            metaDataMap.put("SalesRepValue", getSalesRepValue());
            metaDataMap.put("MTTActCreditTaxHistActionCode", getMTTActCreditTaxHistActionCode());
            metaDataMap.put("MTTActCreditTaxHistCreateDate", getMTTActCreditTaxHistCreateDate());
            metaDataMap.put("MTTActCreditTaxHistCreatedBy", getMTTActCreditTaxHistCreatedBy());
            metaDataMap.put("MTTActCreditTaxHistEndDate", getMTTActCreditTaxHistEndDate());
            metaDataMap.put("MTTActCreditTaxHistoryIdPK", getMTTActCreditTaxHistoryIdPK());
            metaDataMap.put("MTTActCreditTaxLastUpdateDate", getMTTActCreditTaxLastUpdateDate());
            metaDataMap.put("MTTActCreditTaxLastUpdateTxId", getMTTActCreditTaxLastUpdateTxId());
            metaDataMap.put("MTTActCreditTaxLastUpdateUser", getMTTActCreditTaxLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjMTTActCreditTax != null) {
            eObjMTTActCreditTax.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjMTTActCreditTax getEObjMTTActCreditTax() {
        bRequireMapRefresh = true;
        return eObjMTTActCreditTax;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjMTTActCreditTax
     *            The eObjMTTActCreditTax to set.
     * @generated
     */
    public void setEObjMTTActCreditTax(EObjMTTActCreditTax eObjMTTActCreditTax) {
        bRequireMapRefresh = true;
        this.eObjMTTActCreditTax = eObjMTTActCreditTax;
        if (this.eObjMTTActCreditTax != null && this.eObjMTTActCreditTax.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjMTTActCreditTax.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the mTTActCreditTaxIdPk attribute.
     * 
     * @generated
     */
    public String getMTTActCreditTaxIdPk (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActCreditTax.getMTTActCreditTaxIdPk());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the mTTActCreditTaxIdPk attribute.
     * 
     * @param newMTTActCreditTaxIdPk
     *     The new value of mTTActCreditTaxIdPk.
     * @generated
     */
    public void setMTTActCreditTaxIdPk( String newMTTActCreditTaxIdPk ) throws Exception {
        metaDataMap.put("MTTActCreditTaxIdPk", newMTTActCreditTaxIdPk);

        if (newMTTActCreditTaxIdPk == null || newMTTActCreditTaxIdPk.equals("")) {
            newMTTActCreditTaxIdPk = null;


        }
        eObjMTTActCreditTax.setMTTActCreditTaxIdPk( DWLFunctionUtils.getLongFromString(newMTTActCreditTaxIdPk) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contractId attribute.
     * 
     * @generated
     */
    public String getContractId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActCreditTax.getContractId());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contractId attribute.
     * 
     * @param newContractId
     *     The new value of contractId.
     * @generated
     */
    public void setContractId( String newContractId ) throws Exception {
        metaDataMap.put("ContractId", newContractId);

        if (newContractId == null || newContractId.equals("")) {
            newContractId = null;


        }
        eObjMTTActCreditTax.setContractId( DWLFunctionUtils.getLongFromString(newContractId) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the invoiceTermsType attribute.
     * 
     * @generated
     */
    public String getInvoiceTermsType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActCreditTax.getInvoiceTerms());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the invoiceTermsType attribute.
     * 
     * @param newInvoiceTermsType
     *     The new value of invoiceTermsType.
     * @generated
     */
    public void setInvoiceTermsType( String newInvoiceTermsType ) throws Exception {
        metaDataMap.put("InvoiceTermsType", newInvoiceTermsType);

        if (newInvoiceTermsType == null || newInvoiceTermsType.equals("")) {
            newInvoiceTermsType = null;


        }
        eObjMTTActCreditTax.setInvoiceTerms( DWLFunctionUtils.getLongFromString(newInvoiceTermsType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the invoiceTermsValue attribute.
     * 
     * @generated
     */
    public String getInvoiceTermsValue (){
      return invoiceTermsValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the invoiceTermsValue attribute.
     * 
     * @param newInvoiceTermsValue
     *     The new value of invoiceTermsValue.
     * @generated
     */
    public void setInvoiceTermsValue( String newInvoiceTermsValue ) throws Exception {
        metaDataMap.put("InvoiceTermsValue", newInvoiceTermsValue);

        if (newInvoiceTermsValue == null || newInvoiceTermsValue.equals("")) {
            newInvoiceTermsValue = null;


        }
        invoiceTermsValue = newInvoiceTermsValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the gSTExemptInd attribute.
     * 
     * @generated
     */
    public String getGSTExemptInd (){
   
        return eObjMTTActCreditTax.getGSTExemptInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the gSTExemptInd attribute.
     * 
     * @param newGSTExemptInd
     *     The new value of gSTExemptInd.
     * @generated
     */
    public void setGSTExemptInd( String newGSTExemptInd ) throws Exception {
        metaDataMap.put("GSTExemptInd", newGSTExemptInd);

        if (newGSTExemptInd == null || newGSTExemptInd.equals("")) {
            newGSTExemptInd = null;


        }
        eObjMTTActCreditTax.setGSTExemptInd( newGSTExemptInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the customerGroupType attribute.
     * 
     * @generated
     */
    public String getCustomerGroupType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActCreditTax.getCustomerGroup());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the customerGroupType attribute.
     * 
     * @param newCustomerGroupType
     *     The new value of customerGroupType.
     * @generated
     */
    public void setCustomerGroupType( String newCustomerGroupType ) throws Exception {
        metaDataMap.put("CustomerGroupType", newCustomerGroupType);

        if (newCustomerGroupType == null || newCustomerGroupType.equals("")) {
            newCustomerGroupType = null;


        }
        eObjMTTActCreditTax.setCustomerGroup( DWLFunctionUtils.getLongFromString(newCustomerGroupType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the customerGroupValue attribute.
     * 
     * @generated
     */
    public String getCustomerGroupValue (){
      return customerGroupValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the customerGroupValue attribute.
     * 
     * @param newCustomerGroupValue
     *     The new value of customerGroupValue.
     * @generated
     */
    public void setCustomerGroupValue( String newCustomerGroupValue ) throws Exception {
        metaDataMap.put("CustomerGroupValue", newCustomerGroupValue);

        if (newCustomerGroupValue == null || newCustomerGroupValue.equals("")) {
            newCustomerGroupValue = null;


        }
        customerGroupValue = newCustomerGroupValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the bankGuaranteeAmount attribute.
     * 
     * @generated
     */
    public String getBankGuaranteeAmount (){
   
        return DWLFunctionUtils.getStringFromFloat(eObjMTTActCreditTax.getBankGuaranteeAmount());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the bankGuaranteeAmount attribute.
     * 
     * @param newBankGuaranteeAmount
     *     The new value of bankGuaranteeAmount.
     * @generated
     */
    public void setBankGuaranteeAmount( String newBankGuaranteeAmount ) throws Exception {
        metaDataMap.put("BankGuaranteeAmount", newBankGuaranteeAmount);

        if (newBankGuaranteeAmount == null || newBankGuaranteeAmount.equals("")) {
            newBankGuaranteeAmount = null;


        }
        eObjMTTActCreditTax.setBankGuaranteeAmount( DWLFunctionUtils.getFloatFromString(newBankGuaranteeAmount) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the bankGuaranteeEndDate attribute.
     * 
     * @generated
     */
    public String getBankGuaranteeEndDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjMTTActCreditTax.getBankGuaranteeEndDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the bankGuaranteeEndDate attribute.
     * 
     * @param newBankGuaranteeEndDate
     *     The new value of bankGuaranteeEndDate.
     * @generated
     */
    public void setBankGuaranteeEndDate( String newBankGuaranteeEndDate ) throws Exception {
        metaDataMap.put("BankGuaranteeEndDate", newBankGuaranteeEndDate);
       	isValidBankGuaranteeEndDate = true;

        if (newBankGuaranteeEndDate == null || newBankGuaranteeEndDate.equals("")) {
            newBankGuaranteeEndDate = null;
            eObjMTTActCreditTax.setBankGuaranteeEndDate(null);


        }
    else {
        	if (DateValidator.validates(newBankGuaranteeEndDate)) {
           		eObjMTTActCreditTax.setBankGuaranteeEndDate(DateFormatter.getStartDateTimestamp(newBankGuaranteeEndDate));
            	metaDataMap.put("BankGuaranteeEndDate", getBankGuaranteeEndDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("BankGuaranteeEndDate") != null) {
                    	metaDataMap.put("BankGuaranteeEndDate", "");
                	}
                	isValidBankGuaranteeEndDate = false;
                	eObjMTTActCreditTax.setBankGuaranteeEndDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the cashDepositAmount attribute.
     * 
     * @generated
     */
    public String getCashDepositAmount (){
   
        return DWLFunctionUtils.getStringFromFloat(eObjMTTActCreditTax.getCashDepositAmount());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the cashDepositAmount attribute.
     * 
     * @param newCashDepositAmount
     *     The new value of cashDepositAmount.
     * @generated
     */
    public void setCashDepositAmount( String newCashDepositAmount ) throws Exception {
        metaDataMap.put("CashDepositAmount", newCashDepositAmount);

        if (newCashDepositAmount == null || newCashDepositAmount.equals("")) {
            newCashDepositAmount = null;


        }
        eObjMTTActCreditTax.setCashDepositAmount( DWLFunctionUtils.getFloatFromString(newCashDepositAmount) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the cashDepositRecieveDate attribute.
     * 
     * @generated
     */
    public String getCashDepositRecieveDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjMTTActCreditTax.getCashDepositRecieveDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the cashDepositRecieveDate attribute.
     * 
     * @param newCashDepositRecieveDate
     *     The new value of cashDepositRecieveDate.
     * @generated
     */
    public void setCashDepositRecieveDate( String newCashDepositRecieveDate ) throws Exception {
        metaDataMap.put("CashDepositRecieveDate", newCashDepositRecieveDate);
       	isValidCashDepositRecieveDate = true;

        if (newCashDepositRecieveDate == null || newCashDepositRecieveDate.equals("")) {
            newCashDepositRecieveDate = null;
            eObjMTTActCreditTax.setCashDepositRecieveDate(null);


        }
    else {
        	if (DateValidator.validates(newCashDepositRecieveDate)) {
           		eObjMTTActCreditTax.setCashDepositRecieveDate(DateFormatter.getStartDateTimestamp(newCashDepositRecieveDate));
            	metaDataMap.put("CashDepositRecieveDate", getCashDepositRecieveDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("CashDepositRecieveDate") != null) {
                    	metaDataMap.put("CashDepositRecieveDate", "");
                	}
                	isValidCashDepositRecieveDate = false;
                	eObjMTTActCreditTax.setCashDepositRecieveDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the cashDepositReleaseDate attribute.
     * 
     * @generated
     */
    public String getCashDepositReleaseDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjMTTActCreditTax.getCashDepositReleaseDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the cashDepositReleaseDate attribute.
     * 
     * @param newCashDepositReleaseDate
     *     The new value of cashDepositReleaseDate.
     * @generated
     */
    public void setCashDepositReleaseDate( String newCashDepositReleaseDate ) throws Exception {
        metaDataMap.put("CashDepositReleaseDate", newCashDepositReleaseDate);
       	isValidCashDepositReleaseDate = true;

        if (newCashDepositReleaseDate == null || newCashDepositReleaseDate.equals("")) {
            newCashDepositReleaseDate = null;
            eObjMTTActCreditTax.setCashDepositReleaseDate(null);


        }
    else {
        	if (DateValidator.validates(newCashDepositReleaseDate)) {
           		eObjMTTActCreditTax.setCashDepositReleaseDate(DateFormatter.getStartDateTimestamp(newCashDepositReleaseDate));
            	metaDataMap.put("CashDepositReleaseDate", getCashDepositReleaseDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("CashDepositReleaseDate") != null) {
                    	metaDataMap.put("CashDepositReleaseDate", "");
                	}
                	isValidCashDepositReleaseDate = false;
                	eObjMTTActCreditTax.setCashDepositReleaseDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the firstMortgage attribute.
     * 
     * @generated
     */
    public String getFirstMortgage (){
   
        return eObjMTTActCreditTax.getFirstMortgage();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the firstMortgage attribute.
     * 
     * @param newFirstMortgage
     *     The new value of firstMortgage.
     * @generated
     */
    public void setFirstMortgage( String newFirstMortgage ) throws Exception {
        metaDataMap.put("FirstMortgage", newFirstMortgage);

        if (newFirstMortgage == null || newFirstMortgage.equals("")) {
            newFirstMortgage = null;


        }
        eObjMTTActCreditTax.setFirstMortgage( newFirstMortgage );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the secondMortgage attribute.
     * 
     * @generated
     */
    public String getSecondMortgage (){
   
        return eObjMTTActCreditTax.getSecondMortgage();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the secondMortgage attribute.
     * 
     * @param newSecondMortgage
     *     The new value of secondMortgage.
     * @generated
     */
    public void setSecondMortgage( String newSecondMortgage ) throws Exception {
        metaDataMap.put("SecondMortgage", newSecondMortgage);

        if (newSecondMortgage == null || newSecondMortgage.equals("")) {
            newSecondMortgage = null;


        }
        eObjMTTActCreditTax.setSecondMortgage( newSecondMortgage );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the deedOfPriority attribute.
     * 
     * @generated
     */
    public String getDeedOfPriority (){
   
        return eObjMTTActCreditTax.getDeedOfPriority();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the deedOfPriority attribute.
     * 
     * @param newDeedOfPriority
     *     The new value of deedOfPriority.
     * @generated
     */
    public void setDeedOfPriority( String newDeedOfPriority ) throws Exception {
        metaDataMap.put("DeedOfPriority", newDeedOfPriority);

        if (newDeedOfPriority == null || newDeedOfPriority.equals("")) {
            newDeedOfPriority = null;


        }
        eObjMTTActCreditTax.setDeedOfPriority( newDeedOfPriority );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the pPSRDetails attribute.
     * 
     * @generated
     */
    public String getPPSRDetails (){
   
        return eObjMTTActCreditTax.getPPSRDetails();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the pPSRDetails attribute.
     * 
     * @param newPPSRDetails
     *     The new value of pPSRDetails.
     * @generated
     */
    public void setPPSRDetails( String newPPSRDetails ) throws Exception {
        metaDataMap.put("PPSRDetails", newPPSRDetails);

        if (newPPSRDetails == null || newPPSRDetails.equals("")) {
            newPPSRDetails = null;


        }
        eObjMTTActCreditTax.setPPSRDetails( newPPSRDetails );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the pMSIDetails attribute.
     * 
     * @generated
     */
    public String getPMSIDetails (){
   
        return eObjMTTActCreditTax.getPMSIDetails();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the pMSIDetails attribute.
     * 
     * @param newPMSIDetails
     *     The new value of pMSIDetails.
     * @generated
     */
    public void setPMSIDetails( String newPMSIDetails ) throws Exception {
        metaDataMap.put("PMSIDetails", newPMSIDetails);

        if (newPMSIDetails == null || newPMSIDetails.equals("")) {
            newPMSIDetails = null;


        }
        eObjMTTActCreditTax.setPMSIDetails( newPMSIDetails );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the aLLPAPDetails attribute.
     * 
     * @generated
     */
    public String getALLPAPDetails (){
   
        return eObjMTTActCreditTax.getALLPAPDetails();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the aLLPAPDetails attribute.
     * 
     * @param newALLPAPDetails
     *     The new value of aLLPAPDetails.
     * @generated
     */
    public void setALLPAPDetails( String newALLPAPDetails ) throws Exception {
        metaDataMap.put("ALLPAPDetails", newALLPAPDetails);

        if (newALLPAPDetails == null || newALLPAPDetails.equals("")) {
            newALLPAPDetails = null;


        }
        eObjMTTActCreditTax.setALLPAPDetails( newALLPAPDetails );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the arrears attribute.
     * 
     * @generated
     */
    public String getArrears (){
   
        return eObjMTTActCreditTax.getArrears();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the arrears attribute.
     * 
     * @param newArrears
     *     The new value of arrears.
     * @generated
     */
    public void setArrears( String newArrears ) throws Exception {
        metaDataMap.put("Arrears", newArrears);

        if (newArrears == null || newArrears.equals("")) {
            newArrears = null;


        }
        eObjMTTActCreditTax.setArrears( newArrears );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the creditHold attribute.
     * 
     * @generated
     */
    public String getCreditHold (){
   
        return eObjMTTActCreditTax.getCreditHold();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the creditHold attribute.
     * 
     * @param newCreditHold
     *     The new value of creditHold.
     * @generated
     */
    public void setCreditHold( String newCreditHold ) throws Exception {
        metaDataMap.put("CreditHold", newCreditHold);

        if (newCreditHold == null || newCreditHold.equals("")) {
            newCreditHold = null;


        }
        eObjMTTActCreditTax.setCreditHold( newCreditHold );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the nationalHold attribute.
     * 
     * @generated
     */
    public String getNationalHold (){
   
        return eObjMTTActCreditTax.getNationalHold();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the nationalHold attribute.
     * 
     * @param newNationalHold
     *     The new value of nationalHold.
     * @generated
     */
    public void setNationalHold( String newNationalHold ) throws Exception {
        metaDataMap.put("NationalHold", newNationalHold);

        if (newNationalHold == null || newNationalHold.equals("")) {
            newNationalHold = null;


        }
        eObjMTTActCreditTax.setNationalHold( newNationalHold );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the creditHoldDate attribute.
     * 
     * @generated
     */
    public String getCreditHoldDate (){
   
        return eObjMTTActCreditTax.getCreditHoldDate();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the creditHoldDate attribute.
     * 
     * @param newCreditHoldDate
     *     The new value of creditHoldDate.
     * @generated
     */
    public void setCreditHoldDate( String newCreditHoldDate ) throws Exception {
        metaDataMap.put("CreditHoldDate", newCreditHoldDate);

        if (newCreditHoldDate == null || newCreditHoldDate.equals("")) {
            newCreditHoldDate = null;


        }
        eObjMTTActCreditTax.setCreditHoldDate( newCreditHoldDate );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the creditStatusOverride attribute.
     * 
     * @generated
     */
    public String getCreditStatusOverride (){
   
        return eObjMTTActCreditTax.getCreditStatusOverride();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the creditStatusOverride attribute.
     * 
     * @param newCreditStatusOverride
     *     The new value of creditStatusOverride.
     * @generated
     */
    public void setCreditStatusOverride( String newCreditStatusOverride ) throws Exception {
        metaDataMap.put("CreditStatusOverride", newCreditStatusOverride);

        if (newCreditStatusOverride == null || newCreditStatusOverride.equals("")) {
            newCreditStatusOverride = null;


        }
        eObjMTTActCreditTax.setCreditStatusOverride( newCreditStatusOverride );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the chequeLimitAmount attribute.
     * 
     * @generated
     */
    public String getChequeLimitAmount (){
   
        return DWLFunctionUtils.getStringFromFloat(eObjMTTActCreditTax.getChequeLimitAmount());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the chequeLimitAmount attribute.
     * 
     * @param newChequeLimitAmount
     *     The new value of chequeLimitAmount.
     * @generated
     */
    public void setChequeLimitAmount( String newChequeLimitAmount ) throws Exception {
        metaDataMap.put("ChequeLimitAmount", newChequeLimitAmount);

        if (newChequeLimitAmount == null || newChequeLimitAmount.equals("")) {
            newChequeLimitAmount = null;


        }
        eObjMTTActCreditTax.setChequeLimitAmount( DWLFunctionUtils.getFloatFromString(newChequeLimitAmount) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the chequeLimitCurrencyType attribute.
     * 
     * @generated
     */
    public String getChequeLimitCurrencyType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActCreditTax.getChequeLimitCurrency());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the chequeLimitCurrencyType attribute.
     * 
     * @param newChequeLimitCurrencyType
     *     The new value of chequeLimitCurrencyType.
     * @generated
     */
    public void setChequeLimitCurrencyType( String newChequeLimitCurrencyType ) throws Exception {
        metaDataMap.put("ChequeLimitCurrencyType", newChequeLimitCurrencyType);

        if (newChequeLimitCurrencyType == null || newChequeLimitCurrencyType.equals("")) {
            newChequeLimitCurrencyType = null;


        }
        eObjMTTActCreditTax.setChequeLimitCurrency( DWLFunctionUtils.getLongFromString(newChequeLimitCurrencyType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the chequeLimitCurrencyValue attribute.
     * 
     * @generated
     */
    public String getChequeLimitCurrencyValue (){
      return chequeLimitCurrencyValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the chequeLimitCurrencyValue attribute.
     * 
     * @param newChequeLimitCurrencyValue
     *     The new value of chequeLimitCurrencyValue.
     * @generated
     */
    public void setChequeLimitCurrencyValue( String newChequeLimitCurrencyValue ) throws Exception {
        metaDataMap.put("ChequeLimitCurrencyValue", newChequeLimitCurrencyValue);

        if (newChequeLimitCurrencyValue == null || newChequeLimitCurrencyValue.equals("")) {
            newChequeLimitCurrencyValue = null;


        }
        chequeLimitCurrencyValue = newChequeLimitCurrencyValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the wETExemptInd attribute.
     * 
     * @generated
     */
    public String getWETExemptInd (){
   
        return eObjMTTActCreditTax.getWETExemptInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the wETExemptInd attribute.
     * 
     * @param newWETExemptInd
     *     The new value of wETExemptInd.
     * @generated
     */
    public void setWETExemptInd( String newWETExemptInd ) throws Exception {
        metaDataMap.put("WETExemptInd", newWETExemptInd);

        if (newWETExemptInd == null || newWETExemptInd.equals("")) {
            newWETExemptInd = null;


        }
        eObjMTTActCreditTax.setWETExemptInd( newWETExemptInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the dutyFreeInd attribute.
     * 
     * @generated
     */
    public String getDutyFreeInd (){
   
        return eObjMTTActCreditTax.getDutyFreeInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the dutyFreeInd attribute.
     * 
     * @param newDutyFreeInd
     *     The new value of dutyFreeInd.
     * @generated
     */
    public void setDutyFreeInd( String newDutyFreeInd ) throws Exception {
        metaDataMap.put("DutyFreeInd", newDutyFreeInd);

        if (newDutyFreeInd == null || newDutyFreeInd.equals("")) {
            newDutyFreeInd = null;


        }
        eObjMTTActCreditTax.setDutyFreeInd( newDutyFreeInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the cashOnDeliveryInd attribute.
     * 
     * @generated
     */
    public String getCashOnDeliveryInd (){
   
        return eObjMTTActCreditTax.getCashOnDeliveryInd();
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the cashOnDeliveryInd attribute.
     * 
     * @param newCashOnDeliveryInd
     *     The new value of cashOnDeliveryInd.
     * @generated
     */
    public void setCashOnDeliveryInd( String newCashOnDeliveryInd ) throws Exception {
        metaDataMap.put("CashOnDeliveryInd", newCashOnDeliveryInd);

        if (newCashOnDeliveryInd == null || newCashOnDeliveryInd.equals("")) {
            newCashOnDeliveryInd = null;


        }
        eObjMTTActCreditTax.setCashOnDeliveryInd( newCashOnDeliveryInd );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the salesRepType attribute.
     * 
     * @generated
     */
    public String getSalesRepType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTActCreditTax.getSalesRep());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the salesRepType attribute.
     * 
     * @param newSalesRepType
     *     The new value of salesRepType.
     * @generated
     */
    public void setSalesRepType( String newSalesRepType ) throws Exception {
        metaDataMap.put("SalesRepType", newSalesRepType);

        if (newSalesRepType == null || newSalesRepType.equals("")) {
            newSalesRepType = null;


        }
        eObjMTTActCreditTax.setSalesRep( DWLFunctionUtils.getLongFromString(newSalesRepType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the salesRepValue attribute.
     * 
     * @generated
     */
    public String getSalesRepValue (){
      return salesRepValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the salesRepValue attribute.
     * 
     * @param newSalesRepValue
     *     The new value of salesRepValue.
     * @generated
     */
    public void setSalesRepValue( String newSalesRepValue ) throws Exception {
        metaDataMap.put("SalesRepValue", newSalesRepValue);

        if (newSalesRepValue == null || newSalesRepValue.equals("")) {
            newSalesRepValue = null;


        }
        salesRepValue = newSalesRepValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getMTTActCreditTaxLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjMTTActCreditTax.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getMTTActCreditTaxLastUpdateUser() {
        return eObjMTTActCreditTax.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getMTTActCreditTaxLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjMTTActCreditTax.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setMTTActCreditTaxLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("MTTActCreditTaxLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjMTTActCreditTax.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setMTTActCreditTaxLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("MTTActCreditTaxLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjMTTActCreditTax.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setMTTActCreditTaxLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("MTTActCreditTaxLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjMTTActCreditTax.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTActCreditTaxHistActionCode history attribute.
     *
     * @generated
     */
    public String getMTTActCreditTaxHistActionCode() {
        return eObjMTTActCreditTax.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTActCreditTaxHistActionCode history attribute.
     *
     * @param aMTTActCreditTaxHistActionCode
     *     The new value of MTTActCreditTaxHistActionCode.
     * @generated
     */
    public void setMTTActCreditTaxHistActionCode(String aMTTActCreditTaxHistActionCode) {
        metaDataMap.put("MTTActCreditTaxHistActionCode", aMTTActCreditTaxHistActionCode);

        if ((aMTTActCreditTaxHistActionCode == null) || aMTTActCreditTaxHistActionCode.equals("")) {
            aMTTActCreditTaxHistActionCode = null;
        }
        eObjMTTActCreditTax.setHistActionCode(aMTTActCreditTaxHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTActCreditTaxHistCreateDate history attribute.
     *
     * @generated
     */
    public String getMTTActCreditTaxHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjMTTActCreditTax.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTActCreditTaxHistCreateDate history attribute.
     *
     * @param aMTTActCreditTaxHistCreateDate
     *     The new value of MTTActCreditTaxHistCreateDate.
     * @generated
     */
    public void setMTTActCreditTaxHistCreateDate(String aMTTActCreditTaxHistCreateDate) throws Exception{
        metaDataMap.put("MTTActCreditTaxHistCreateDate", aMTTActCreditTaxHistCreateDate);

        if ((aMTTActCreditTaxHistCreateDate == null) || aMTTActCreditTaxHistCreateDate.equals("")) {
            aMTTActCreditTaxHistCreateDate = null;
        }

        eObjMTTActCreditTax.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aMTTActCreditTaxHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTActCreditTaxHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getMTTActCreditTaxHistCreatedBy() {
        return eObjMTTActCreditTax.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTActCreditTaxHistCreatedBy history attribute.
     *
     * @param aMTTActCreditTaxHistCreatedBy
     *     The new value of MTTActCreditTaxHistCreatedBy.
     * @generated
     */
    public void setMTTActCreditTaxHistCreatedBy(String aMTTActCreditTaxHistCreatedBy) {
        metaDataMap.put("MTTActCreditTaxHistCreatedBy", aMTTActCreditTaxHistCreatedBy);

        if ((aMTTActCreditTaxHistCreatedBy == null) || aMTTActCreditTaxHistCreatedBy.equals("")) {
            aMTTActCreditTaxHistCreatedBy = null;
        }

        eObjMTTActCreditTax.setHistCreatedBy(aMTTActCreditTaxHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTActCreditTaxHistEndDate history attribute.
     *
     * @generated
     */
    public String getMTTActCreditTaxHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjMTTActCreditTax.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTActCreditTaxHistEndDate history attribute.
     *
     * @param aMTTActCreditTaxHistEndDate
     *     The new value of MTTActCreditTaxHistEndDate.
     * @generated
     */
    public void setMTTActCreditTaxHistEndDate(String aMTTActCreditTaxHistEndDate) throws Exception{
        metaDataMap.put("MTTActCreditTaxHistEndDate", aMTTActCreditTaxHistEndDate);

        if ((aMTTActCreditTaxHistEndDate == null) || aMTTActCreditTaxHistEndDate.equals("")) {
            aMTTActCreditTaxHistEndDate = null;
        }
        eObjMTTActCreditTax.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aMTTActCreditTaxHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTActCreditTaxHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getMTTActCreditTaxHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjMTTActCreditTax.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTActCreditTaxHistoryIdPK history attribute.
     *
     * @param aMTTActCreditTaxHistoryIdPK
     *     The new value of MTTActCreditTaxHistoryIdPK.
     * @generated
     */
    public void setMTTActCreditTaxHistoryIdPK(String aMTTActCreditTaxHistoryIdPK) {
        metaDataMap.put("MTTActCreditTaxHistoryIdPK", aMTTActCreditTaxHistoryIdPK);

        if ((aMTTActCreditTaxHistoryIdPK == null) || aMTTActCreditTaxHistoryIdPK.equals("")) {
            aMTTActCreditTaxHistoryIdPK = null;
        }
        eObjMTTActCreditTax.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aMTTActCreditTaxHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjMTTActCreditTax.getMTTActCreditTaxIdPk() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_CREDIT_TAX_BOBJ).longValue());
                err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.MTTACTCREDITTAX_MTTACTCREDITTAXIDPK_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity MTTActCreditTax, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjMTTActCreditTax.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_CREDIT_TAX_BOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity MTTActCreditTax, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        MTTDBCustom comp = null;
        try {
        
      comp = (MTTDBCustom)TCRMClassFactory.getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  MTTDBCustomComponentID.MTTACT_CREDIT_TAX_BOBJ, 
                                  "DIERR",
                                  MTTDBCustomErrorReasonCode.MTTACTCREDITTAX_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
        }
        
        comp.loadBeforeImage(this);
    logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_ContractId(status);
    		controllerValidation_InvoiceTerms(status);
    		controllerValidation_CustomerGroup(status);
    		controllerValidation_BankGuaranteeEndDate(status);
    		controllerValidation_CashDepositRecieveDate(status);
    		controllerValidation_CashDepositReleaseDate(status);
    		controllerValidation_ChequeLimitCurrency(status);
    		controllerValidation_SalesRep(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_ContractId(status);
    		componentValidation_InvoiceTerms(status);
    		componentValidation_CustomerGroup(status);
    		componentValidation_BankGuaranteeEndDate(status);
    		componentValidation_CashDepositRecieveDate(status);
    		componentValidation_CashDepositReleaseDate(status);
    		componentValidation_ChequeLimitCurrency(status);
    		componentValidation_SalesRep(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "ContractId"
     *
     * @generated
     */
	private void componentValidation_ContractId(DWLStatus status) {
  
            boolean isContractIdNull = (eObjMTTActCreditTax.getContractId() == null);
            if (isContractIdNull) {
                DWLError err = createDWLError("MTTActCreditTax", "ContractId", MTTDBCustomErrorReasonCode.MTTACTCREDITTAX_CONTRACTID_NULL);
                status.addError(err); 
            }
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "InvoiceTerms"
     *
     * @generated
     */
  private void componentValidation_InvoiceTerms(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "CustomerGroup"
     *
     * @generated
     */
  private void componentValidation_CustomerGroup(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "BankGuaranteeEndDate"
     *
     * @generated
     */
	private void componentValidation_BankGuaranteeEndDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "CashDepositRecieveDate"
     *
     * @generated
     */
	private void componentValidation_CashDepositRecieveDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "CashDepositReleaseDate"
     *
     * @generated
     */
	private void componentValidation_CashDepositReleaseDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "ChequeLimitCurrency"
     *
     * @generated
     */
  private void componentValidation_ChequeLimitCurrency(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "SalesRep"
     *
     * @generated
     */
  private void componentValidation_SalesRep(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "ContractId"
     *
     * @generated
     */
	private void controllerValidation_ContractId(DWLStatus status) throws Exception {
  
            boolean isContractIdNull = (eObjMTTActCreditTax.getContractId() == null);
            if (isContractIdNull) {
                DWLError err = createDWLError("MTTActCreditTax", "ContractId", MTTDBCustomErrorReasonCode.MTTACTCREDITTAX_CONTRACTID_NULL);
                status.addError(err); 
            }
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "InvoiceTerms"
     *
     * @generated
     */
  private void controllerValidation_InvoiceTerms(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isInvoiceTermsNull = false;
            if ((eObjMTTActCreditTax.getInvoiceTerms() == null) &&
               ((getInvoiceTermsValue() == null) || 
                 getInvoiceTermsValue().trim().equals(""))) {
                isInvoiceTermsNull = true;
            }
            if (!isInvoiceTermsNull) {
                if (checkForInvalidMttactcredittaxInvoiceterms()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_CREDIT_TAX_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTCREDITTAX_INVOICETERMS).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTActCreditTax, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_InvoiceTerms " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "CustomerGroup"
     *
     * @generated
     */
  private void controllerValidation_CustomerGroup(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isCustomerGroupNull = false;
            if ((eObjMTTActCreditTax.getCustomerGroup() == null) &&
               ((getCustomerGroupValue() == null) || 
                 getCustomerGroupValue().trim().equals(""))) {
                isCustomerGroupNull = true;
            }
            if (!isCustomerGroupNull) {
                if (checkForInvalidMttactcredittaxCustomergroup()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_CREDIT_TAX_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTCREDITTAX_CUSTOMERGROUP).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTActCreditTax, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_CustomerGroup " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "BankGuaranteeEndDate"
     *
     * @generated
     */
	private void controllerValidation_BankGuaranteeEndDate(DWLStatus status) throws Exception {
  
            boolean isBankGuaranteeEndDateNull = (eObjMTTActCreditTax.getBankGuaranteeEndDate() == null);
            if (!isValidBankGuaranteeEndDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_CREDIT_TAX_BOBJ).longValue());
               	err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTCREDITTAX_BANKGUARANTEEENDDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property BankGuaranteeEndDate in entity MTTActCreditTax, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_BankGuaranteeEndDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "CashDepositRecieveDate"
     *
     * @generated
     */
	private void controllerValidation_CashDepositRecieveDate(DWLStatus status) throws Exception {
  
            boolean isCashDepositRecieveDateNull = (eObjMTTActCreditTax.getCashDepositRecieveDate() == null);
            if (!isValidCashDepositRecieveDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_CREDIT_TAX_BOBJ).longValue());
               	err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTCREDITTAX_CASHDEPOSITRECIEVEDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property CashDepositRecieveDate in entity MTTActCreditTax, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_CashDepositRecieveDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "CashDepositReleaseDate"
     *
     * @generated
     */
	private void controllerValidation_CashDepositReleaseDate(DWLStatus status) throws Exception {
  
            boolean isCashDepositReleaseDateNull = (eObjMTTActCreditTax.getCashDepositReleaseDate() == null);
            if (!isValidCashDepositReleaseDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_CREDIT_TAX_BOBJ).longValue());
               	err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTCREDITTAX_CASHDEPOSITRELEASEDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property CashDepositReleaseDate in entity MTTActCreditTax, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_CashDepositReleaseDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "ChequeLimitCurrency"
     *
     * @generated
     */
  private void controllerValidation_ChequeLimitCurrency(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isChequeLimitCurrencyNull = false;
            if ((eObjMTTActCreditTax.getChequeLimitCurrency() == null) &&
               ((getChequeLimitCurrencyValue() == null) || 
                 getChequeLimitCurrencyValue().trim().equals(""))) {
                isChequeLimitCurrencyNull = true;
            }
            if (!isChequeLimitCurrencyNull) {
                if (checkForInvalidMttactcredittaxChequelimitcurrency()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_CREDIT_TAX_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTCREDITTAX_CHEQUELIMITCURRENCY).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTActCreditTax, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_ChequeLimitCurrency " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "SalesRep"
     *
     * @generated
     */
  private void controllerValidation_SalesRep(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isSalesRepNull = false;
            if ((eObjMTTActCreditTax.getSalesRep() == null) &&
               ((getSalesRepValue() == null) || 
                 getSalesRepValue().trim().equals(""))) {
                isSalesRepNull = true;
            }
            if (!isSalesRepNull) {
                if (checkForInvalidMttactcredittaxSalesrep()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_CREDIT_TAX_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTACTCREDITTAX_SALESREP).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTActCreditTax, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_SalesRep " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(MTTDBCustomComponentID.MTTACT_CREDIT_TAX_BOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field InvoiceTerms and return true if the error
     * reason INVALID_MTTACTCREDITTAX_INVOICETERMS should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttactcredittaxInvoiceterms() throws Exception {
    logger.finest("ENTER checkForInvalidMttactcredittaxInvoiceterms()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getInvoiceTermsType() );
    String codeValue = getInvoiceTermsValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdinvtermstp", langId, getInvoiceTermsType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdinvtermstp", langId, getInvoiceTermsType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setInvoiceTermsValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttactcredittaxInvoiceterms() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdinvtermstp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setInvoiceTermsType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttactcredittaxInvoiceterms() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdinvtermstp", langId, getInvoiceTermsType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttactcredittaxInvoiceterms() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttactcredittaxInvoiceterms() " + returnValue);
    }
    return notValid;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field CustomerGroup and return true if the error
     * reason INVALID_MTTACTCREDITTAX_CUSTOMERGROUP should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttactcredittaxCustomergroup() throws Exception {
    logger.finest("ENTER checkForInvalidMttactcredittaxCustomergroup()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getCustomerGroupType() );
    String codeValue = getCustomerGroupValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdcustomergrptp", langId, getCustomerGroupType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdcustomergrptp", langId, getCustomerGroupType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setCustomerGroupValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttactcredittaxCustomergroup() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdcustomergrptp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setCustomerGroupType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttactcredittaxCustomergroup() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdcustomergrptp", langId, getCustomerGroupType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttactcredittaxCustomergroup() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttactcredittaxCustomergroup() " + returnValue);
    }
    return notValid;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field ChequeLimitCurrency and return true if the
     * error reason INVALID_MTTACTCREDITTAX_CHEQUELIMITCURRENCY should be
     * returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttactcredittaxChequelimitcurrency() throws Exception {
    logger.finest("ENTER checkForInvalidMttactcredittaxChequelimitcurrency()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getChequeLimitCurrencyType() );
    String codeValue = getChequeLimitCurrencyValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("cdcurrencytp", langId, getChequeLimitCurrencyType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("cdcurrencytp", langId, getChequeLimitCurrencyType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setChequeLimitCurrencyValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttactcredittaxChequelimitcurrency() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("cdcurrencytp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setChequeLimitCurrencyType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttactcredittaxChequelimitcurrency() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("cdcurrencytp", langId, getChequeLimitCurrencyType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttactcredittaxChequelimitcurrency() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttactcredittaxChequelimitcurrency() " + returnValue);
    }
    return notValid;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field SalesRep and return true if the error reason
     * INVALID_MTTACTCREDITTAX_SALESREP should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttactcredittaxSalesrep() throws Exception {
    logger.finest("ENTER checkForInvalidMttactcredittaxSalesrep()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getSalesRepType() );
    String codeValue = getSalesRepValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdsalesreptp", langId, getSalesRepType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdsalesreptp", langId, getSalesRepType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setSalesRepValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttactcredittaxSalesrep() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdsalesreptp", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setSalesRepType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttactcredittaxSalesrep() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdsalesreptp", langId, getSalesRepType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttactcredittaxSalesrep() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttactcredittaxSalesrep() " + returnValue);
    }
    return notValid;
     } 
				 



}

