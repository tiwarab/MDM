
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[8505cc2c4398a6066dae83876a36776b]
 */

package com.metcash.db.custom.component;

import com.dwl.tcrm.common.TCRMCommon;



import com.dwl.base.DWLControl;

import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.constant.DWLUtilErrorReasonCode;

import com.dwl.base.error.DWLError;
import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLBaseException;
import com.dwl.base.exception.DWLUpdateException;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;
import com.dwl.base.util.DWLFunctionUtils;

import com.dwl.management.config.client.Configuration;

import com.dwl.tcrm.common.ITCRMValidation;

import com.dwl.tcrm.utilities.DateFormatter;
import com.dwl.tcrm.utilities.DateValidator;
import com.dwl.tcrm.utilities.TCRMClassFactory;

import com.ibm.mdm.common.codetype.interfaces.CodeTypeComponentHelper;

import com.ibm.mdm.common.codetype.obj.CodeTypeBObj;

import com.metcash.db.custom.constant.MTTDBCustomComponentID;
import com.metcash.db.custom.constant.MTTDBCustomErrorReasonCode;
import com.metcash.db.custom.constant.MTTDBCustomPropertyKeys;

import com.metcash.db.custom.entityObject.EObjMTTStore;

import com.metcash.db.custom.interfaces.MTTDBCustom;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides the implementation of the business object
 * <code>MTTStoreBObj</code>.
 * 
 * @see com.dwl.tcrm.common.TCRMCommon
 * @generated
 */
 

@SuppressWarnings("serial")
public class MTTStoreBObj extends TCRMCommon  {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected EObjMTTStore eObjMTTStore;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(MTTStoreBObj.class);
		
 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected String mSOValue;
    protected boolean isValidStoreOpenDate = true;
	
	protected boolean isValidStoreCloseDate = true;
	


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */     
    public MTTStoreBObj() {
        super();
        init();
        eObjMTTStore = new EObjMTTStore();
        setComponentID(MTTDBCustomComponentID.MTTSTORE_BOBJ);
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Initializes the fields required to populate the metaDataMap. Each key is
     * an element-level field of the business object.
     *
     * @generated
     */
    private void init() {
        metaDataMap.put("MTTStoreIdPk", null);
        metaDataMap.put("PartyId", null);
        metaDataMap.put("MSOType", null);
        metaDataMap.put("MSOValue", null);
        metaDataMap.put("StoreOpenDate", null);
        metaDataMap.put("StoreCloseDate", null);
        metaDataMap.put("MTTStoreHistActionCode", null);
        metaDataMap.put("MTTStoreHistCreateDate", null);
        metaDataMap.put("MTTStoreHistCreatedBy", null);
        metaDataMap.put("MTTStoreHistEndDate", null);
        metaDataMap.put("MTTStoreHistoryIdPK", null);
        metaDataMap.put("MTTStoreLastUpdateDate", null);
        metaDataMap.put("MTTStoreLastUpdateTxId", null);
        metaDataMap.put("MTTStoreLastUpdateUser", null);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Refreshes all the attributes this business object supports.
     *
     * @see com.dwl.base.DWLCommon#refreshMap()
     * @generated
     */
    public void refreshMap() {

        if (bRequireMapRefresh) {
            super.refreshMap();
            metaDataMap.put("MTTStoreIdPk", getMTTStoreIdPk());
            metaDataMap.put("PartyId", getPartyId());
            metaDataMap.put("MSOType", getMSOType());
            metaDataMap.put("MSOValue", getMSOValue());
            metaDataMap.put("StoreOpenDate", getStoreOpenDate());
            metaDataMap.put("StoreCloseDate", getStoreCloseDate());
            metaDataMap.put("MTTStoreHistActionCode", getMTTStoreHistActionCode());
            metaDataMap.put("MTTStoreHistCreateDate", getMTTStoreHistCreateDate());
            metaDataMap.put("MTTStoreHistCreatedBy", getMTTStoreHistCreatedBy());
            metaDataMap.put("MTTStoreHistEndDate", getMTTStoreHistEndDate());
            metaDataMap.put("MTTStoreHistoryIdPK", getMTTStoreHistoryIdPK());
            metaDataMap.put("MTTStoreLastUpdateDate", getMTTStoreLastUpdateDate());
            metaDataMap.put("MTTStoreLastUpdateTxId", getMTTStoreLastUpdateTxId());
            metaDataMap.put("MTTStoreLastUpdateUser", getMTTStoreLastUpdateUser());
            bRequireMapRefresh = false;
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the control object on this business object.
     *
     * @see com.dwl.base.DWLCommon#setControl(DWLControl)
     * @generated
     */
    public void setControl(DWLControl newDWLControl) {
        super.setControl(newDWLControl);

        if (eObjMTTStore != null) {
            eObjMTTStore.setControl(newDWLControl);
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the entity object associated with this business object.
     *
     * @generated
     */
    public EObjMTTStore getEObjMTTStore() {
        bRequireMapRefresh = true;
        return eObjMTTStore;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the entity object associated with this business object.
     *
     * @param eObjMTTStore
     *            The eObjMTTStore to set.
     * @generated
     */
    public void setEObjMTTStore(EObjMTTStore eObjMTTStore) {
        bRequireMapRefresh = true;
        this.eObjMTTStore = eObjMTTStore;
        if (this.eObjMTTStore != null && this.eObjMTTStore.getControl() == null) {
            DWLControl control = this.getControl();
            if (control != null) {
                this.eObjMTTStore.setControl(control);
            }
        }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the mTTStoreIdPk attribute.
     * 
     * @generated
     */
    public String getMTTStoreIdPk (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTStore.getMTTStoreIdPk());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the mTTStoreIdPk attribute.
     * 
     * @param newMTTStoreIdPk
     *     The new value of mTTStoreIdPk.
     * @generated
     */
    public void setMTTStoreIdPk( String newMTTStoreIdPk ) throws Exception {
        metaDataMap.put("MTTStoreIdPk", newMTTStoreIdPk);

        if (newMTTStoreIdPk == null || newMTTStoreIdPk.equals("")) {
            newMTTStoreIdPk = null;


        }
        eObjMTTStore.setMTTStoreIdPk( DWLFunctionUtils.getLongFromString(newMTTStoreIdPk) );
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the partyId attribute.
     * 
     * @generated
     */
    public String getPartyId (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTStore.getPartyId());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the partyId attribute.
     * 
     * @param newPartyId
     *     The new value of partyId.
     * @generated
     */
    public void setPartyId( String newPartyId ) throws Exception {
        metaDataMap.put("PartyId", newPartyId);

        if (newPartyId == null || newPartyId.equals("")) {
            newPartyId = null;


        }
        eObjMTTStore.setPartyId( DWLFunctionUtils.getLongFromString(newPartyId) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the mSOType attribute.
     * 
     * @generated
     */
    public String getMSOType (){
   
        return DWLFunctionUtils.getStringFromLong(eObjMTTStore.getMSO());
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the mSOType attribute.
     * 
     * @param newMSOType
     *     The new value of mSOType.
     * @generated
     */
    public void setMSOType( String newMSOType ) throws Exception {
        metaDataMap.put("MSOType", newMSOType);

        if (newMSOType == null || newMSOType.equals("")) {
            newMSOType = null;


        }
        eObjMTTStore.setMSO( DWLFunctionUtils.getLongFromString(newMSOType) );
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the mSOValue attribute.
     * 
     * @generated
     */
    public String getMSOValue (){
      return mSOValue;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the mSOValue attribute.
     * 
     * @param newMSOValue
     *     The new value of mSOValue.
     * @generated
     */
    public void setMSOValue( String newMSOValue ) throws Exception {
        metaDataMap.put("MSOValue", newMSOValue);

        if (newMSOValue == null || newMSOValue.equals("")) {
            newMSOValue = null;


        }
        mSOValue = newMSOValue;
     }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the storeOpenDate attribute.
     * 
     * @generated
     */
    public String getStoreOpenDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjMTTStore.getStoreOpenDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the storeOpenDate attribute.
     * 
     * @param newStoreOpenDate
     *     The new value of storeOpenDate.
     * @generated
     */
    public void setStoreOpenDate( String newStoreOpenDate ) throws Exception {
        metaDataMap.put("StoreOpenDate", newStoreOpenDate);
       	isValidStoreOpenDate = true;

        if (newStoreOpenDate == null || newStoreOpenDate.equals("")) {
            newStoreOpenDate = null;
            eObjMTTStore.setStoreOpenDate(null);


        }
    else {
        	if (DateValidator.validates(newStoreOpenDate)) {
           		eObjMTTStore.setStoreOpenDate(DateFormatter.getStartDateTimestamp(newStoreOpenDate));
            	metaDataMap.put("StoreOpenDate", getStoreOpenDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("StoreOpenDate") != null) {
                    	metaDataMap.put("StoreOpenDate", "");
                	}
                	isValidStoreOpenDate = false;
                	eObjMTTStore.setStoreOpenDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the storeCloseDate attribute.
     * 
     * @generated
     */
    public String getStoreCloseDate (){
   
        return DWLFunctionUtils.getStringFromTimestamp(eObjMTTStore.getStoreCloseDate());
    }
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the storeCloseDate attribute.
     * 
     * @param newStoreCloseDate
     *     The new value of storeCloseDate.
     * @generated
     */
    public void setStoreCloseDate( String newStoreCloseDate ) throws Exception {
        metaDataMap.put("StoreCloseDate", newStoreCloseDate);
       	isValidStoreCloseDate = true;

        if (newStoreCloseDate == null || newStoreCloseDate.equals("")) {
            newStoreCloseDate = null;
            eObjMTTStore.setStoreCloseDate(null);


        }
    else {
        	if (DateValidator.validates(newStoreCloseDate)) {
           		eObjMTTStore.setStoreCloseDate(DateFormatter.getStartDateTimestamp(newStoreCloseDate));
            	metaDataMap.put("StoreCloseDate", getStoreCloseDate());
        	} else {
            	if (Configuration.getConfiguration().getConfigItem(
              "/IBM/DWLCommonServices/InternalValidation/enabled").getBooleanValue()) {
                	if (metaDataMap.get("StoreCloseDate") != null) {
                    	metaDataMap.put("StoreCloseDate", "");
                	}
                	isValidStoreCloseDate = false;
                	eObjMTTStore.setStoreCloseDate(null);
            	}
        	}
        }
     }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateTxId attribute.
     *
     * @generated
     */
    public String getMTTStoreLastUpdateTxId() {
        return DWLFunctionUtils.getStringFromLong(eObjMTTStore.getLastUpdateTxId());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateUser attribute.
     *
     * @generated
     */
    public String getMTTStoreLastUpdateUser() {
        return eObjMTTStore.getLastUpdateUser();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the LastUpdateDt attribute.
     *
     * @generated
     */
    public String getMTTStoreLastUpdateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjMTTStore.getLastUpdateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateTxId attribute.
     *
     * @param newLastUpdateTxId
     *     The new value of LastUpdateTxId.
     * @generated
     */
    public void setMTTStoreLastUpdateTxId(String newLastUpdateTxId) {
        metaDataMap.put("MTTStoreLastUpdateTxId", newLastUpdateTxId);

        if ((newLastUpdateTxId == null) || newLastUpdateTxId.equals("")) {
            newLastUpdateTxId = null;
        }
        eObjMTTStore.setLastUpdateTxId(DWLFunctionUtils.getLongFromString(newLastUpdateTxId));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateUser attribute.
     *
     * @param newLastUpdateUser
     *     The new value of LastUpdateUser.
     * @generated
     */
    public void setMTTStoreLastUpdateUser(String newLastUpdateUser) {
        metaDataMap.put("MTTStoreLastUpdateUser", newLastUpdateUser);

        if ((newLastUpdateUser == null) || newLastUpdateUser.equals("")) {
            newLastUpdateUser = null;
        }
        eObjMTTStore.setLastUpdateUser(newLastUpdateUser);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the LastUpdateDt attribute.
     *
     * @param newLastUpdateDt
     *     The new value of LastUpdateDt.
     * @throws Exception
     * @generated
     */
    public void setMTTStoreLastUpdateDate(String newLastUpdateDt) throws Exception {
        metaDataMap.put("MTTStoreLastUpdateDate", newLastUpdateDt);

        if ((newLastUpdateDt == null) || newLastUpdateDt.equals("")) {
            newLastUpdateDt = null;
        }

        eObjMTTStore.setLastUpdateDt(DWLFunctionUtils.getTimestampFromTimestampString(newLastUpdateDt));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTStoreHistActionCode history attribute.
     *
     * @generated
     */
    public String getMTTStoreHistActionCode() {
        return eObjMTTStore.getHistActionCode();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTStoreHistActionCode history attribute.
     *
     * @param aMTTStoreHistActionCode
     *     The new value of MTTStoreHistActionCode.
     * @generated
     */
    public void setMTTStoreHistActionCode(String aMTTStoreHistActionCode) {
        metaDataMap.put("MTTStoreHistActionCode", aMTTStoreHistActionCode);

        if ((aMTTStoreHistActionCode == null) || aMTTStoreHistActionCode.equals("")) {
            aMTTStoreHistActionCode = null;
        }
        eObjMTTStore.setHistActionCode(aMTTStoreHistActionCode);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTStoreHistCreateDate history attribute.
     *
     * @generated
     */
    public String getMTTStoreHistCreateDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjMTTStore.getHistCreateDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTStoreHistCreateDate history attribute.
     *
     * @param aMTTStoreHistCreateDate
     *     The new value of MTTStoreHistCreateDate.
     * @generated
     */
    public void setMTTStoreHistCreateDate(String aMTTStoreHistCreateDate) throws Exception{
        metaDataMap.put("MTTStoreHistCreateDate", aMTTStoreHistCreateDate);

        if ((aMTTStoreHistCreateDate == null) || aMTTStoreHistCreateDate.equals("")) {
            aMTTStoreHistCreateDate = null;
        }

        eObjMTTStore.setHistCreateDt(DWLFunctionUtils.getTimestampFromTimestampString(aMTTStoreHistCreateDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTStoreHistCreatedBy history attribute.
     *
     * @generated
     */
    public String getMTTStoreHistCreatedBy() {
        return eObjMTTStore.getHistCreatedBy();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTStoreHistCreatedBy history attribute.
     *
     * @param aMTTStoreHistCreatedBy
     *     The new value of MTTStoreHistCreatedBy.
     * @generated
     */
    public void setMTTStoreHistCreatedBy(String aMTTStoreHistCreatedBy) {
        metaDataMap.put("MTTStoreHistCreatedBy", aMTTStoreHistCreatedBy);

        if ((aMTTStoreHistCreatedBy == null) || aMTTStoreHistCreatedBy.equals("")) {
            aMTTStoreHistCreatedBy = null;
        }

        eObjMTTStore.setHistCreatedBy(aMTTStoreHistCreatedBy);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTStoreHistEndDate history attribute.
     *
     * @generated
     */
    public String getMTTStoreHistEndDate() {
        return DWLFunctionUtils.getStringFromTimestamp(eObjMTTStore.getHistEndDt());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTStoreHistEndDate history attribute.
     *
     * @param aMTTStoreHistEndDate
     *     The new value of MTTStoreHistEndDate.
     * @generated
     */
    public void setMTTStoreHistEndDate(String aMTTStoreHistEndDate) throws Exception{
        metaDataMap.put("MTTStoreHistEndDate", aMTTStoreHistEndDate);

        if ((aMTTStoreHistEndDate == null) || aMTTStoreHistEndDate.equals("")) {
            aMTTStoreHistEndDate = null;
        }
        eObjMTTStore.setHistEndDt(DWLFunctionUtils.getTimestampFromTimestampString(aMTTStoreHistEndDate));
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the MTTStoreHistoryIdPK history attribute.
     *
     * @generated
     */
    public String getMTTStoreHistoryIdPK() {
        return DWLFunctionUtils.getStringFromLong(eObjMTTStore.getHistoryIdPK());
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the MTTStoreHistoryIdPK history attribute.
     *
     * @param aMTTStoreHistoryIdPK
     *     The new value of MTTStoreHistoryIdPK.
     * @generated
     */
    public void setMTTStoreHistoryIdPK(String aMTTStoreHistoryIdPK) {
        metaDataMap.put("MTTStoreHistoryIdPK", aMTTStoreHistoryIdPK);

        if ((aMTTStoreHistoryIdPK == null) || aMTTStoreHistoryIdPK.equals("")) {
            aMTTStoreHistoryIdPK = null;
        }
        eObjMTTStore.setHistoryIdPK(DWLFunctionUtils.getLongFromString(aMTTStoreHistoryIdPK));
    }
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an add transaction.
     *
     * @generated
     */
    public DWLStatus validateAdd(int level, DWLStatus status) throws Exception {

        status = super.validateAdd(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0038I Add any controller-level custom validation logic to be
            // executed for this object during an "add" transaction

        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0039I Add any component-level custom validation logic to be
            // executed for this object during an "add" transaction
        }
        status = getValidationStatus(level, status);
        return status;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation during an update transaction.
     *
     * @generated
     */
    public DWLStatus validateUpdate(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER validateUpdate(int level, DWLStatus status)");

        status = super.validateUpdate(level, status);
        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0040I Add any controller-level custom validation logic to be
            // executed for this object during an "update" transaction

            if (eObjMTTStore.getMTTStoreIdPk() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(MTTDBCustomComponentID.MTTSTORE_BOBJ).longValue());
                err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.MTTSTORE_MTTSTOREIDPK_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No primary key for entity MTTStore, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
            if (eObjMTTStore.getLastUpdateDt() == null) {
                DWLError err = new DWLError();
                err.setComponentType(new Long(MTTDBCustomComponentID.MTTSTORE_BOBJ).longValue());
                err.setReasonCode(new Long(DWLUtilErrorReasonCode.LAST_UPDATED_DATE_NULL).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
                if (logger.isFinestEnabled()) {
                	String infoForLogging="Error: Validation error occured for update. No last update date for entity MTTStore, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("validateUpdate(int level, DWLStatus status) " + infoForLogging);
                }
                status.addError(err);
            }
        }

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            assignBeforeImageValues(metaDataMap);
            
            // MDM_TODO0: CDKWB0041I Add any component-level custom validation logic to be
            // executed for this object during an "update" transaction
        }
        status = getValidationStatus(level, status);
    if (logger.isFinestEnabled()) {
        	String returnValue = status.toString();
      logger.finest("RETURN validateUpdate(int level, DWLStatus status) " + returnValue);
    }
        return status;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Populate the before image of this business object.
     *
     * @see com.dwl.base.DWLCommon#populateBeforeImage()
     * @generated
     */
    public void populateBeforeImage() throws DWLBaseException {
    logger.finest("ENTER populateBeforeImage()");

        MTTDBCustom comp = null;
        try {
        
      comp = (MTTDBCustom)TCRMClassFactory.getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
        	
        } catch (Exception e) {
      if (logger.isFinestEnabled()) {
        String infoForLogging="Error: Fatal error while updating record " + e.getMessage();
      logger.finest("populateBeforeImage() " + infoForLogging);
      }
            DWLExceptionUtils.throwDWLBaseException(e, 
            									new DWLUpdateException(e.getMessage()), 
            									this.getStatus(), DWLStatus.FATAL,
                                  MTTDBCustomComponentID.MTTSTORE_BOBJ, 
                                  "DIERR",
                                  MTTDBCustomErrorReasonCode.MTTSTORE_BEFORE_IMAGE_NOT_POPULATED, 
                                  this.getControl());
        }
        
        comp.loadBeforeImage(this);
    logger.finest("RETURN populateBeforeImage()");
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform validation common to both add and update transactions.
     *
     * @generated
     */
     
    private DWLStatus getValidationStatus(int level, DWLStatus status) throws Exception {
    logger.finest("ENTER getValidationStatus(int level, DWLStatus status)");

        if (level == ITCRMValidation.CONTROLLER_LEVEL_VALIDATION) {
            // MDM_TODO0: CDKWB0034I Add any common controller-level custom validation
            // logic to be executed for this object during either "add" or
            // "update" transactions
    		controllerValidation_PartyId(status);
    		controllerValidation_MSO(status);
    		controllerValidation_StoreOpenDate(status);
    		controllerValidation_StoreCloseDate(status);
    	}

        if (level == ITCRMValidation.COMPONENT_LEVEL_VALIDATION){
            // MDM_TODO0: CDKWB0035I Add any common component-level custom validation logic
            // to be executed for this object during either "add" or "update"
            // transactions
    		componentValidation_PartyId(status);
    		componentValidation_MSO(status);
    		componentValidation_StoreOpenDate(status);
    		componentValidation_StoreCloseDate(status);
        }
        
        if (logger.isFinestEnabled()) {
            String returnValue = status.toString();
      logger.finest("RETURN getValidationStatus(int level, DWLStatus status) " + returnValue);
        }
    
        return status;
    }

    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "PartyId"
     *
     * @generated
     */
  private void componentValidation_PartyId(DWLStatus status) {
  
            boolean isPartyIdNull = (eObjMTTStore.getPartyId() == null);
            if (isPartyIdNull) {
                DWLError err = createDWLError("MTTStore", "PartyId", MTTDBCustomErrorReasonCode.MTTSTORE_PARTYID_NULL);
                status.addError(err); 
            }
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "MSO"
     *
     * @generated
     */
  private void componentValidation_MSO(DWLStatus status) {
  
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "StoreOpenDate"
     *
     * @generated
     */
	private void componentValidation_StoreOpenDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform component-level custom validation logic for attribute "StoreCloseDate"
     *
     * @generated
     */
	private void componentValidation_StoreCloseDate(DWLStatus status) {
  
  }
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "PartyId"
     *
     * @generated
     */
  private void controllerValidation_PartyId(DWLStatus status) throws Exception {
  
            boolean isPartyIdNull = (eObjMTTStore.getPartyId() == null);
            if (isPartyIdNull) {
                DWLError err = createDWLError("MTTStore", "PartyId", MTTDBCustomErrorReasonCode.MTTSTORE_PARTYID_NULL);
                status.addError(err); 
            }
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "MSO"
     *
     * @generated
     */
  private void controllerValidation_MSO(DWLStatus status) throws Exception {
  
      //persistent code type
            boolean isMSONull = false;
            if ((eObjMTTStore.getMSO() == null) &&
               ((getMSOValue() == null) || 
                 getMSOValue().trim().equals(""))) {
                isMSONull = true;
            }
            if (!isMSONull) {
                if (checkForInvalidMttstoreMso()) {
                    DWLError err = new DWLError();
                    err.setComponentType(new Long(MTTDBCustomComponentID.MTTSTORE_BOBJ).longValue());
                    err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTSTORE_MSO).longValue());
                err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
                    String infoForLogging="Error: Custom validation error occured for entity MTTStore, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
      logger.finest("controllerValidation_MSO " + infoForLogging);
        }
                status.addError(err);
            }

             }
    			
    	}


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "StoreOpenDate"
     *
     * @generated
     */
	private void controllerValidation_StoreOpenDate(DWLStatus status) throws Exception {
  
            boolean isStoreOpenDateNull = (eObjMTTStore.getStoreOpenDate() == null);
            if (!isValidStoreOpenDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(MTTDBCustomComponentID.MTTSTORE_BOBJ).longValue());
               	err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTSTORE_STOREOPENDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property StoreOpenDate in entity MTTStore, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_StoreOpenDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    	
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Perform controller-level custom validation logic for attribute "StoreCloseDate"
     *
     * @generated
     */
	private void controllerValidation_StoreCloseDate(DWLStatus status) throws Exception {
  
            boolean isStoreCloseDateNull = (eObjMTTStore.getStoreCloseDate() == null);
            if (!isValidStoreCloseDate) {
              	DWLError err = new DWLError();
               	err.setComponentType(new Long(MTTDBCustomComponentID.MTTSTORE_BOBJ).longValue());
               	err.setReasonCode(new Long(MTTDBCustomErrorReasonCode.INVALID_MTTSTORE_STORECLOSEDATE).longValue());
               	err.setErrorType(DWLErrorCode.DATA_INVALID_ERROR);
                String infoForLogging="Error: Validation error. Invalid time specified on property StoreCloseDate in entity MTTStore, component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode();
      logger.finest("controllerValidation_StoreCloseDate " + infoForLogging);
               	status.addError(err);
            } 
    	}
    private DWLError createDWLError(String entityName, String propertyName,String reasonCode){	
		DWLError err = new DWLError();
		err.setComponentType(new Long(MTTDBCustomComponentID.MTTSTORE_BOBJ).longValue());
		err.setReasonCode(new Long(reasonCode).longValue());
		err.setErrorType(DWLErrorCode.FIELD_VALIDATION_ERROR);
        if (logger.isFinestEnabled()) {
			String infoForLogging="Error: Validation error occured. Property " + propertyName + " is null, in entity " + entityName + ", component type " +err.getComponentType() + " ReasonCode " +err.getReasonCode() + "  ";
			logger.finest("createDWLError " + infoForLogging);
		}
		return err;
    }
    
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Check the value of the field MSO and return true if the error reason
     * INVALID_MTTSTORE_MSO should be returned.
     *
     * @generated
  **/
  private boolean checkForInvalidMttstoreMso() throws Exception {
    logger.finest("ENTER checkForInvalidMttstoreMso()");
        boolean notValid = false;
      	String langId = (String) this.getControl().get(DWLControlKeys.LANG_ID);
      	CodeTypeComponentHelper codeTypeCompHelper = DWLClassFactory.getCodeTypeComponentHelper();
    Long codeType = DWLFunctionUtils.getLongFromString( getMSOType() );
    String codeValue = getMSOValue();
    if( codeValue != null && codeValue.trim().equals("")){
      codeValue = null;
    }
     
        if ( codeType != null && codeValue == null ){

             if( codeTypeCompHelper.isCodeValid("xcdmso", langId, getMSOType(),
                 CodeTypeComponentHelper.ACTIVE, getControl())) {
                 CodeTypeBObj ctBObj = codeTypeCompHelper
                 					.getCodeTypeByCode("xcdmso", langId, getMSOType(),
                         								getControl());
               	if (ctBObj != null) {
                   	setMSOValue( ctBObj.getvalue() );
               	}
             }
             else{
             	if (logger.isFinestEnabled()) {
              	 	String infoForLogging="NotValid 1";
      logger.finest("checkForInvalidMttstoreMso() " + infoForLogging);
        }
                 notValid = true;
           }
        }
        else if (codeType == null && codeValue != null ){
          
             CodeTypeBObj ctBObj = codeTypeCompHelper
                      .getCodeTypeByValue("xcdmso", langId, codeValue,
                                 getControl());

             if (ctBObj != null) {
                 setMSOType(ctBObj.gettp_cd());
             } 
             else {
             	if (logger.isFinestEnabled()) {
              	  	String infoForLogging="NotValid 2";
      logger.finest("checkForInvalidMttstoreMso() " + infoForLogging);
        }
                  notValid = true;
             }
        }
        else if ( codeType != null && codeValue != null
             && !codeTypeCompHelper.isCodeValuePairValid("xcdmso", langId, getMSOType(), 
                     new String[] { codeValue }, CodeTypeComponentHelper.ACTIVE, getControl())) {	
       if (logger.isFinestEnabled()) {
       		String infoForLogging="NotValid 3";
      logger.finest("checkForInvalidMttstoreMso() " + infoForLogging);
       }
             notValid = true;
        }
        if (logger.isFinestEnabled()) {
      String returnValue ="" +notValid;
      logger.finest("RETURN checkForInvalidMttstoreMso() " + returnValue);
    }
    return notValid;
     } 
				 



}

