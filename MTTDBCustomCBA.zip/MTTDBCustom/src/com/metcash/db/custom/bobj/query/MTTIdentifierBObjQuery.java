
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[abeabdead1051eb726f56ce4979aef7c]
 */
package com.metcash.db.custom.bobj.query;




import com.dwl.base.DWLControl;
import com.dwl.bobj.query.BObjQueryException;
import com.dwl.base.DWLCommon;

import com.dwl.base.db.DataAccessFactory;


import com.dwl.base.error.DWLErrorCode;
import com.dwl.base.error.DWLStatus;

import com.dwl.base.exception.DWLDuplicateKeyException;

import com.dwl.base.interfaces.IGenericResultSetProcessor;

import com.dwl.base.util.DWLClassFactory;
import com.dwl.base.util.DWLExceptionUtils;

import com.metcash.db.custom.component.MTTIdentifierBObj;
import com.metcash.db.custom.component.MTTIdentifierResultSetProcessor;

import com.metcash.db.custom.constant.MTTDBCustomComponentID;
import com.metcash.db.custom.constant.MTTDBCustomErrorReasonCode;

import com.metcash.db.custom.entityObject.EObjMTTIdentifierData;
import com.metcash.db.custom.entityObject.MTTIdentifierInquiryData;


/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * This class provides query information for the business object
 * <code>MTTIdentifierBObj</code>.
 *
 * @generated
 */
public class MTTIdentifierBObjQuery  extends com.dwl.bobj.query.GenericBObjQuery {

     /**
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * @generated
      */
     public static final String MTTIDENTIFIER_QUERY = "getMTTIdentifier(Object[])";

     /**
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * @generated
      */
     public static final String MTTIDENTIFIER_HISTORY_QUERY = "getMTTIdentifierHistory(Object[])";

	/**
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * @generated
      */
     public static final String ALL_MTTIDENTIFIER_BY_ID_QUERY = "getAllMTTIdentifierByID(Object[])";

    /**
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * @generated
      */
     public static final String ALL_MTTIDENTIFIER_BY_ID_HISTORY_QUERY = "getAllMTTIdentifierByIDHistory(Object[])";

  /**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(MTTIdentifierBObjQuery.class);
     /**
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * @generated
      */
     public static final String MTTIDENTIFIER_ADD = "MTTIDENTIFIER_ADD";

     /**
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * @generated
      */
     public static final String MTTIDENTIFIER_DELETE = "MTTIDENTIFIER_DELETE";

     /**
      * <!-- begin-user-doc -->
      * <!-- end-user-doc -->
      *
      * @generated
      */
     public static final String MTTIDENTIFIER_UPDATE = "MTTIDENTIFIER_UPDATE";


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Default constructor.
     *
     * @param queryName
     * The name of the query.
     * @param control
     * The control object.
     *
     * @generated
     */
    public MTTIdentifierBObjQuery(String queryName, DWLControl control) {
        super(queryName, control);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Default constructor.
     *
     * @param persistenceStrategyName
     * The persistence strategy name.  This parameter indicates the type of
     * database action to be taken such as addition, update or deletion of
     * records.
     * @param objectToPersist
     * The business object to be persisted.
     *
     * @generated
     */
    public MTTIdentifierBObjQuery(String persistenceStrategyName, DWLCommon objectToPersist) {
        super(persistenceStrategyName, objectToPersist);
    }

	 
 	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
	protected void persist() throws Exception{
    logger.finest("ENTER persist()");
    if (logger.isFinestEnabled()) {
   		String infoForLogging="Persistence strategy is " + persistenceStrategyName;
      logger.finest("persist() " + infoForLogging);
        }
    if (persistenceStrategyName.equals(MTTIDENTIFIER_ADD)) {
      addMTTIdentifier();
    }else if(persistenceStrategyName.equals(MTTIDENTIFIER_UPDATE)) {
      updateMTTIdentifier();
    }else if(persistenceStrategyName.equals(MTTIDENTIFIER_DELETE)) {
      deleteMTTIdentifier();
    }
    logger.finest("RETURN persist()");
  }
  
 	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
      * Inserts mttidentifier data by calling
      * <code>EObjMTTIdentifierData.createEObjMTTIdentifier</code>
     *
     * @throws Exception
     *
     * @generated
     */
	protected void addMTTIdentifier() throws Exception{
    logger.finest("ENTER addMTTIdentifier()");
    
    EObjMTTIdentifierData theEObjMTTIdentifierData = (EObjMTTIdentifierData) DataAccessFactory
      .getQuery(EObjMTTIdentifierData.class, connection);
    theEObjMTTIdentifierData.createEObjMTTIdentifier(((MTTIdentifierBObj) objectToPersist).getEObjMTTIdentifier());
    logger.finest("RETURN addMTTIdentifier()");
  }

 	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
      * Updates mttidentifier data by calling
      * <code>EObjMTTIdentifierData.updateEObjMTTIdentifier</code>
     *
     * @throws Exception
     *
     * @generated
     */
	protected void updateMTTIdentifier() throws Exception{
    logger.finest("ENTER updateMTTIdentifier()");
    EObjMTTIdentifierData theEObjMTTIdentifierData = (EObjMTTIdentifierData) DataAccessFactory
      .getQuery(EObjMTTIdentifierData.class, connection);
    theEObjMTTIdentifierData.updateEObjMTTIdentifier(((MTTIdentifierBObj) objectToPersist).getEObjMTTIdentifier());
    logger.finest("RETURN updateMTTIdentifier()");
  }

 	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
      * Deletes {0} data by calling <{1}>{2}.{3}{4}</{1}>
   *
     * @throws Exception
     *
     * @generated
     */
	protected void deleteMTTIdentifier() throws Exception{
    logger.finest("ENTER deleteMTTIdentifier()");
         // MDM_TODO: CDKWB0018I Write customized business logic for the extension here.
    logger.finest("RETURN deleteMTTIdentifier()");
  } 
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
      * This method is overridden to construct
      * <code>DWLDuplicateKeyException</code> based on MTTIdentifier component
      * specific values.
     * 
     * @param errParams
     * The values to be substituted in the error message.
   *
     * @throws Exception
     *
     * @generated
     */
    protected void throwDuplicateKeyException(String[] errParams) throws Exception {
    if (logger.isFinestEnabled()) {
      	StringBuilder errParamsStringBuilder = new StringBuilder("Error: Duplicate key Exception parameters are ");
      	for(int i=0;i<errParams.length;i++) {
      		errParamsStringBuilder .append(errParams[i]);
      		if (i!=errParams.length-1) {
      			errParamsStringBuilder .append(" , ");
      		}
      	}
          String infoForLogging="Error: Duplicate key Exception parameters are " + errParamsStringBuilder;
      logger.finest("Unknown method " + infoForLogging);
    }
    	DWLExceptionUtils.throwDWLDuplicateKeyException(
    		new DWLDuplicateKeyException(buildDupThrowableMessage(errParams)),
    		objectToPersist.getStatus(), 
    		DWLStatus.FATAL,
    		MTTDBCustomComponentID.MTTDBCUSTOM_COMPONENT,
    		DWLErrorCode.DUPLICATE_KEY_ERROR, 
    		MTTDBCustomErrorReasonCode.DUPLICATE_PRIMARY_KEY_MTTIDENTIFIER,
    		objectToPersist.getControl(), 
    		DWLClassFactory.getErrorHandler()
    		);
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Provides the result set processor that is used to populate the business
     * object.
     *
     * @return
     * An instance of <code>MTTIdentifierResultSetProcessor</code>.
     *
     * @see com.dwl.bobj.query.AbstractBObjQuery#provideResultSetProcessor()
     * @see com.metcash.db.custom.component.MTTIdentifierResultSetProcessor
     *
     * @generated
     */
    protected IGenericResultSetProcessor provideResultSetProcessor()
            throws BObjQueryException {

        return new MTTIdentifierResultSetProcessor();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    @Override
    protected Class<MTTIdentifierInquiryData> provideQueryInterfaceClass() throws BObjQueryException {
        return MTTIdentifierInquiryData.class;
    }

}


