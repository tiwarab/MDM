/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[ea4a695801e3eaabd40cd1c00f327d70]
 */
package com.metcash.db.custom.constant;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * Defines the error message codes used in this module.
 *
 * @generated
 */
public class MTTDBCustomErrorReasonCode {

  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: MTTActReportingIdPk
     *
     * @generated
     */
    public final static String MTTACTREPORTING_MTTACTREPORTINGIDPK_NULL = "1000501";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * ChannelGroup is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTREPORTING_CHANNELGROUP = "1000793";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * AgentNumber is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTREPORTING_AGENTNUMBER = "1000830";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * UserLocality is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTREPORTING_USERLOCALITY = "1000843";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * CustomerClass is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTREPORTING_CUSTOMERCLASS = "1000856";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: ContractId
     *
     * @generated
     */
    public final static String MTTACTREPORTING_CONTRACTID_NULL = "1000876";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of MTTActReporting is empty.
     *
     * @generated
     */
    public final static String MTTACTREPORTING_BEFORE_IMAGE_NOT_POPULATED = "1000505";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the MTTActReporting failed.
     *
     * @generated
     */
    public final static String GETMTTACTREPORTING_FAILED = "1000522";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETMTTACTREPORTING_ID_NULL = "1000526";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETMTTACTREPORTING_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1000530";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the MTTActReporting failed.
     *
     * @generated
     */
    public final static String GETALLMTTREPORTBYID_FAILED = "1000895";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETALLMTTREPORTBYID_ID_NULL = "1000899";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETALLMTTREPORTBYID_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1000903";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * MTTActReporting insert failed.
     *
     * @generated
     */
    public final static String ADDMTTACTREPORTING_FAILED = "1000545";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_MTTACTREPORTING = "1000549";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * MTTActReporting update failed.
     *
     * @generated
     */
    public final static String UPDATEMTTACTREPORTING_FAILED = "1000562";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: MTTIdentifierIdPk
     *
     * @generated
     */
    public final static String MTTIDENTIFIER_MTTIDENTIFIERIDPK_NULL = "1000039";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: IdentifierId
     *
     * @generated
     */
    public final static String MTTIDENTIFIER_IDENTIFIERID_NULL = "1000106";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * IdentifierSub is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTIDENTIFIER_IDENTIFIERSUB = "1000115";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: IdentifierSub
     *
     * @generated
     */
    public final static String MTTIDENTIFIER_IDENTIFIERSUB_NULL = "1000119";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: StartDate
     *
     * @generated
     */
    public final static String MTTIDENTIFIER_STARTDATE_NULL = "1000180";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * StartDate is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTIDENTIFIER_STARTDATE = "1000186";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * EndDate is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTIDENTIFIER_ENDDATE = "1000198";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * ExpiryDate is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTIDENTIFIER_EXPIRYDATE = "1000210";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of MTTIdentifier is empty.
     *
     * @generated
     */
    public final static String MTTIDENTIFIER_BEFORE_IMAGE_NOT_POPULATED = "1000043";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the MTTIdentifier failed.
     *
     * @generated
     */
    public final static String GETMTTIDENTIFIER_FAILED = "1000060";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETMTTIDENTIFIER_ID_NULL = "1000064";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETMTTIDENTIFIER_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1000068";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the MTTIdentifier failed.
     *
     * @generated
     */
    public final static String GETALLMTTIDENTIFIERBYID_FAILED = "1000235";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETALLMTTIDENTIFIERBYID_ID_NULL = "1000239";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETALLMTTIDENTIFIERBYID_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1000243";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * MTTIdentifier insert failed.
     *
     * @generated
     */
    public final static String ADDMTTIDENTIFIER_FAILED = "1000083";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_MTTIDENTIFIER = "1000087";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * MTTIdentifier update failed.
     *
     * @generated
     */
    public final static String UPDATEMTTIDENTIFIER_FAILED = "1000100";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: MTTStoreIdPk
     *
     * @generated
     */
    public final static String MTTSTORE_MTTSTOREIDPK_NULL = "1000281";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: PartyId
     *
     * @generated
     */
    public final static String MTTSTORE_PARTYID_NULL = "1000401";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * MSO is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTSTORE_MSO = "1000410";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * StoreOpenDate is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTSTORE_STOREOPENDATE = "1000428";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * StoreCloseDate is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTSTORE_STORECLOSEDATE = "1000440";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of MTTStore is empty.
     *
     * @generated
     */
    public final static String MTTSTORE_BEFORE_IMAGE_NOT_POPULATED = "1000285";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the MTTStore failed.
     *
     * @generated
     */
    public final static String GETMTTSTORE_FAILED = "1000302";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETMTTSTORE_ID_NULL = "1000306";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETMTTSTORE_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1000310";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the MTTStore failed.
     *
     * @generated
     */
    public final static String GETALLSTOREBYID_FAILED = "1000457";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETALLSTOREBYID_ID_NULL = "1000461";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETALLSTOREBYID_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1000465";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * MTTStore insert failed.
     *
     * @generated
     */
    public final static String ADDMTTSTORE_FAILED = "1000325";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_MTTSTORE = "1000329";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * MTTStore update failed.
     *
     * @generated
     */
    public final static String UPDATEMTTSTORE_FAILED = "1000342";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: MTTActCreditTaxIdPk
     *
     * @generated
     */
    public final static String MTTACTCREDITTAX_MTTACTCREDITTAXIDPK_NULL = "1001140";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: ContractId
     *
     * @generated
     */
    public final static String MTTACTCREDITTAX_CONTRACTID_NULL = "1001207";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * InvoiceTerms is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTCREDITTAX_INVOICETERMS = "1001216";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * CustomerGroup is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTCREDITTAX_CUSTOMERGROUP = "1001237";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * BankGuaranteeEndDate is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTCREDITTAX_BANKGUARANTEEENDDATE = "1001263";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * CashDepositRecieveDate is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTCREDITTAX_CASHDEPOSITRECIEVEDATE = "1001283";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * CashDepositReleaseDate is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTCREDITTAX_CASHDEPOSITRELEASEDATE = "1001295";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * ChequeLimitCurrency is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTCREDITTAX_CHEQUELIMITCURRENCY = "1001398";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * SalesRep is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTCREDITTAX_SALESREP = "1003527";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of MTTActCreditTax is empty.
     *
     * @generated
     */
    public final static String MTTACTCREDITTAX_BEFORE_IMAGE_NOT_POPULATED = "1001144";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the MTTActCreditTax failed.
     *
     * @generated
     */
    public final static String GETMTTACTCREDITTAX_FAILED = "1001161";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETMTTACTCREDITTAX_ID_NULL = "1001165";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETMTTACTCREDITTAX_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1001169";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the MTTActCreditTax failed.
     *
     * @generated
     */
    public final static String GETALLMTTCREDITTAXBYID_FAILED = "1001445";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETALLMTTCREDITTAXBYID_ID_NULL = "1001449";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETALLMTTCREDITTAXBYID_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1001453";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * MTTActCreditTax insert failed.
     *
     * @generated
     */
    public final static String ADDMTTACTCREDITTAX_FAILED = "1001184";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_MTTACTCREDITTAX = "1001188";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * MTTActCreditTax update failed.
     *
     * @generated
     */
    public final static String UPDATEMTTACTCREDITTAX_FAILED = "1001201";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: MTTActOrderInvoiceIdPk
     *
     * @generated
     */
    public final static String MTTACTORDERINVOICE_MTTACTORDERINVOICEIDPK_NULL = "1001489";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: ContractId
     *
     * @generated
     */
    public final static String MTTACTORDERINVOICE_CONTRACTID_NULL = "1002033";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * InvoiceSequence is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTORDERINVOICE_INVOICESEQUENCE = "1002066";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * InvoiceMode is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTORDERINVOICE_INVOICEMODE = "1002087";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * OrderGuide is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTORDERINVOICE_ORDERGUIDE = "1002100";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * PrintCatInvoiceBreak is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTORDERINVOICE_PRINTCATINVOICEBREAK = "1002129";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * InvoiceRecapSummary is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTORDERINVOICE_INVOICERECAPSUMMARY = "1002142";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * PickupDeiver is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTORDERINVOICE_PICKUPDEIVER = "1002163";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Totes is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTORDERINVOICE_TOTES = "1002298";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * UnitCaseCostPrint is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTORDERINVOICE_UNITCASECOSTPRINT = "1002311";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * InvoiceFormat is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTORDERINVOICE_INVOICEFORMAT = "1002324";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Invoice is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTORDERINVOICE_INVOICE = "1002345";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * DelPickPackInvoice is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTORDERINVOICE_DELPICKPACKINVOICE = "1002366";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of MTTActOrderInvoice is empty.
     *
     * @generated
     */
    public final static String MTTACTORDERINVOICE_BEFORE_IMAGE_NOT_POPULATED = "1001493";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the MTTActOrderInvoice failed.
     *
     * @generated
     */
    public final static String GETMTTACTORDERINVOICE_FAILED = "1001510";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETMTTACTORDERINVOICE_ID_NULL = "1001514";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETMTTACTORDERINVOICE_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1001518";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the MTTActOrderInvoice failed.
     *
     * @generated
     */
    public final static String GETALLMTTORDERINVOICEBYID_FAILED = "1002429";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETALLMTTORDERINVOICEBYID_ID_NULL = "1002433";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETALLMTTORDERINVOICEBYID_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1002437";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * MTTActOrderInvoice insert failed.
     *
     * @generated
     */
    public final static String ADDMTTACTORDERINVOICE_FAILED = "1001533";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_MTTACTORDERINVOICE = "1001537";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * MTTActOrderInvoice update failed.
     *
     * @generated
     */
    public final static String UPDATEMTTACTORDERINVOICE_FAILED = "1001550";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: MTTActCostChargesIdPk
     *
     * @generated
     */
    public final static String MTTACTCOSTCHARGES_MTTACTCOSTCHARGESIDPK_NULL = "1002473";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: ContractId
     *
     * @generated
     */
    public final static String MTTACTCOSTCHARGES_CONTRACTID_NULL = "1002699";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * CostBase is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTCOSTCHARGES_COSTBASE = "1002708";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * SRPComplicance is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTCOSTCHARGES_SRPCOMPLICANCE = "1002737";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * BrokenCaseCal is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTCOSTCHARGES_BROKENCASECAL = "1002782";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * PSRP is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTCOSTCHARGES_PSRP = "1002803";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of MTTActCostCharges is empty.
     *
     * @generated
     */
    public final static String MTTACTCOSTCHARGES_BEFORE_IMAGE_NOT_POPULATED = "1002477";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the MTTActCostCharges failed.
     *
     * @generated
     */
    public final static String GETMTTACTCOSTCHARGES_FAILED = "1002494";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETMTTACTCOSTCHARGES_ID_NULL = "1002498";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETMTTACTCOSTCHARGES_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1002502";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the MTTActCostCharges failed.
     *
     * @generated
     */
    public final static String GETALLMTTACTCOSTCHARGESBYID_FAILED = "1003550";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETALLMTTACTCOSTCHARGESBYID_ID_NULL = "1003554";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETALLMTTACTCOSTCHARGESBYID_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1003558";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * MTTActCostCharges insert failed.
     *
     * @generated
     */
    public final static String ADDMTTACTCOSTCHARGES_FAILED = "1002517";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_MTTACTCOSTCHARGES = "1002521";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * MTTActCostCharges update failed.
     *
     * @generated
     */
    public final static String UPDATEMTTACTCOSTCHARGES_FAILED = "1002534";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: MTTActFinancialIdPk
     *
     * @generated
     */
    public final static String MTTACTFINANCIAL_MTTACTFINANCIALIDPK_NULL = "1002920";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: ContractId
     *
     * @generated
     */
    public final static String MTTACTFINANCIAL_CONTRACTID_NULL = "1003199";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * StatementMode is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTFINANCIAL_STATEMENTMODE = "1003208";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * DueGraceDays is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTFINANCIAL_DUEGRACEDAYS = "1003221";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * TobaccoGraceDays is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTFINANCIAL_TOBACCOGRACEDAYS = "1003234";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Bank is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTFINANCIAL_BANK = "1003300";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Collector is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTFINANCIAL_COLLECTOR = "1003337";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * BankAccount is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTFINANCIAL_BANKACCOUNT = "1003403";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * DiscountGraceDays is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTFINANCIAL_DISCOUNTGRACEDAYS = "1003440";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * PaymentMethod is not correct
     *
     * @generated
     */
    public final static String INVALID_MTTACTFINANCIAL_PAYMENTMETHOD = "1003453";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The before image of MTTActFinancial is empty.
     *
     * @generated
     */
    public final static String MTTACTFINANCIAL_BEFORE_IMAGE_NOT_POPULATED = "1002924";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the MTTActFinancial failed.
     *
     * @generated
     */
    public final static String GETMTTACTFINANCIAL_FAILED = "1002941";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETMTTACTFINANCIAL_ID_NULL = "1002945";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETMTTACTFINANCIAL_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1002949";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * An attempt to read the MTTActFinancial failed.
     *
     * @generated
     */
    public final static String GETALLMTTACTFINANCIALBYID_FAILED = "1003577";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The id is null.
     *
     * @generated
     */
    public final static String GETALLMTTACTFINANCIALBYID_ID_NULL = "1003581";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The format of inquireAsOfDate is not correct.
     *
     * @generated
     */
    public final static String GETALLMTTACTFINANCIALBYID_INVALID_INQUIRE_AS_OF_DATE_FORMAT = "1003585";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * MTTActFinancial insert failed.
     *
     * @generated
     */
    public final static String ADDMTTACTFINANCIAL_FAILED = "1002964";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Duplicate primary key already exists.
     *
     * @generated
     */
    public final static String DUPLICATE_PRIMARY_KEY_MTTACTFINANCIAL = "1002968";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * MTTActFinancial update failed.
     *
     * @generated
     */
    public final static String UPDATEMTTACTFINANCIAL_FAILED = "1002981";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: ChannelGroupType
     *
     * @generated
     */
    public final static String XCDCHANNELGRP_CHANNELGROUPTYPE_NULL = "1000607";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDCHANNELGRP_NAME_NULL = "1000615";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: AgentNumberType
     *
     * @generated
     */
    public final static String XCDAGENTNUM_AGENTNUMBERTYPE_NULL = "1000672";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDAGENTNUM_NAME_NULL = "1000680";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: UserLocalityType
     *
     * @generated
     */
    public final static String XCDUSERLOCALITY_USERLOCALITYTYPE_NULL = "1000725";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDUSERLOCALITY_NAME_NULL = "1000733";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: CustomerClassType
     *
     * @generated
     */
    public final static String XCDCUSCLASS_CUSTOMERCLASSTYPE_NULL = "1000778";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDCUSCLASS_NAME_NULL = "1000786";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: InvoiceTermsType
     *
     * @generated
     */
    public final static String XCDINVTERMS_INVOICETERMSTYPE_NULL = "1001045";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDINVTERMS_NAME_NULL = "1001053";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: CustomerGroupType
     *
     * @generated
     */
    public final static String XCDCUSTOMERGRP_CUSTOMERGROUPTYPE_NULL = "1001098";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDCUSTOMERGRP_NAME_NULL = "1001106";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: InvoiceSequenceType
     *
     * @generated
     */
    public final static String XCDINVOICESEQ_INVOICESEQUENCETYPE_NULL = "1001595";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDINVOICESEQ_NAME_NULL = "1001603";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: InvoiceModeType
     *
     * @generated
     */
    public final static String XCDINVOICEMODE_INVOICEMODETYPE_NULL = "1001648";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDINVOICEMODE_NAME_NULL = "1001656";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: OrderGuideType
     *
     * @generated
     */
    public final static String XCDORDERGUIDE_ORDERGUIDETYPE_NULL = "1001701";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDORDERGUIDE_NAME_NULL = "1001709";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: PrintCatInvoiceBreakType
     *
     * @generated
     */
    public final static String XCDPRNCATINVBRK_PRINTCATINVOICEBREAKTYPE_NULL = "1001754";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDPRNCATINVBRK_NAME_NULL = "1001762";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: InvoiceRecapSummaryType
     *
     * @generated
     */
    public final static String XCDINVRECAPSUMM_INVOICERECAPSUMMARYTYPE_NULL = "1001807";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDINVRECAPSUMM_NAME_NULL = "1001815";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: PickupDeliverType
     *
     * @generated
     */
    public final static String XCDPICKUPDELIVER_PICKUPDELIVERTYPE_NULL = "1001860";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDPICKUPDELIVER_NAME_NULL = "1001868";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: UnitCaseCostPrintType
     *
     * @generated
     */
    public final static String XCDUNITCASECOSTPRN_UNITCASECOSTPRINTTYPE_NULL = "1001913";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDUNITCASECOSTPRN_NAME_NULL = "1001921";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: InvoiceFormatType
     *
     * @generated
     */
    public final static String XCDINVFORMAT_INVOICEFORMATTYPE_NULL = "1001966";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDINVFORMAT_NAME_NULL = "1001974";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: DelPickPackInvoiceType
     *
     * @generated
     */
    public final static String XCDDELPICKPACKINV_DELPICKPACKINVOICETYPE_NULL = "1002019";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDDELPICKPACKINV_NAME_NULL = "1002027";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: TotesType
     *
     * @generated
     */
    public final static String XCDTOTES_TOTESTYPE_NULL = "1002230";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDTOTES_NAME_NULL = "1002238";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: InvoiceType
     *
     * @generated
     */
    public final static String XCDINV_INVOICETYPE_NULL = "1002283";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDINV_NAME_NULL = "1002291";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: CostBaseType
     *
     * @generated
     */
    public final static String XCDCOSTBASE_COSTBASETYPE_NULL = "1002579";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDCOSTBASE_NAME_NULL = "1002587";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: SRPComplianceType
     *
     * @generated
     */
    public final static String XCDSRPCOMPLIANCE_SRPCOMPLIANCETYPE_NULL = "1002632";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDSRPCOMPLIANCE_NAME_NULL = "1002640";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: BrokenCaseUpchargeType
     *
     * @generated
     */
    public final static String XCDBRKNCASECALC_BROKENCASEUPCHARGETYPE_NULL = "1002685";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDBRKNCASECALC_NAME_NULL = "1002693";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: PSRPType
     *
     * @generated
     */
    public final static String XCDPSRP_PSRPTYPE_NULL = "1002854";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDPSRP_NAME_NULL = "1002862";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: StatementModeType
     *
     * @generated
     */
    public final static String XCDSTATEMENTMODE_STATEMENTMODETYPE_NULL = "1003026";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDSTATEMENTMODE_NAME_NULL = "1003034";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: GraceDaysType
     *
     * @generated
     */
    public final static String XCDGRACEDAYS_GRACEDAYSTYPE_NULL = "1003079";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDGRACEDAYS_NAME_NULL = "1003087";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: CollectorType
     *
     * @generated
     */
    public final static String XCDCOLLECTOR_COLLECTORTYPE_NULL = "1003132";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDCOLLECTOR_NAME_NULL = "1003140";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: PaymentMethodType
     *
     * @generated
     */
    public final static String XCDPAYMENTMETHOD_PAYMENTMETHODTYPE_NULL = "1003185";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDPAYMENTMETHOD_NAME_NULL = "1003193";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: BankType
     *
     * @generated
     */
    public final static String XCDBANK_BANKTYPE_NULL = "1003285";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDBANK_NAME_NULL = "1003293";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: BankAccountType
     *
     * @generated
     */
    public final static String XCDBANKACCOUNT_BANKACCOUNTTYPE_NULL = "1003388";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDBANKACCOUNT_NAME_NULL = "1003396";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: tp_cd
     *
     * @generated
     */
    public final static String XCDSALESREP_TP_CD_NULL = "1003512";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDSALESREP_NAME_NULL = "1003520";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: IdentifierSubType
     *
     * @generated
     */
    public final static String XCDIDENTIFIERSUB_IDENTIFIERSUBTYPE_NULL = "1000166";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDIDENTIFIERSUB_NAME_NULL = "1000174";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: MSOType
     *
     * @generated
     */
    public final static String XCDMSOTP_MSOTYPE_NULL = "1000387";
  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * The following is required: name
     *
     * @generated
     */
    public final static String XCDMSOTP_NAME_NULL = "1000395";

}


