/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[4fbfb65b7e27d3cdef22867f75a3dca1]
 */

package com.metcash.db.custom.controller;


import com.dwl.base.DWLControl;
import com.dwl.base.IDWLErrorMessage;
import com.dwl.base.constant.DWLControlKeys;
import com.dwl.base.requestHandler.DWLTransaction;
import com.dwl.base.requestHandler.DWLTransactionInquiry;
import com.dwl.tcrm.common.TCRMCommonComponent;
import com.dwl.tcrm.common.TCRMErrorCode;
import com.dwl.base.DWLResponse;
import com.dwl.base.exception.DWLBaseException;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.ibm.mdm.annotations.Controller;
import com.ibm.mdm.annotations.TxMetadata;


import com.dwl.base.error.DWLStatus;

import com.dwl.base.util.DWLExceptionUtils;

import com.metcash.db.custom.constant.MTTDBCustomComponentID;
import com.metcash.db.custom.constant.MTTDBCustomErrorReasonCode;
import com.metcash.db.custom.constant.MTTDBCustomPropertyKeys;

import com.metcash.db.custom.interfaces.MTTDBCustom;
import com.metcash.db.custom.interfaces.MTTDBCustomFinder;

import java.util.Vector;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * Controller class to handle inquiry requests.
 * @generated
 */
 @Controller(errorComponentID = MTTDBCustomComponentID.MTTDBCUSTOM_CONTROLLER)
public class MTTDBCustomFinderImpl extends TCRMCommonComponent implements MTTDBCustomFinder {

    private IDWLErrorMessage errHandler;
	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(MTTDBCustomFinderImpl.class);

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Default constructor.
     * @generated
     */
    public MTTDBCustomFinderImpl() {
        super();
        errHandler = TCRMClassFactory.getErrorHandler();
    }

	
	/**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getMTTActReporting.
     *
     * @param MTTActReportingIdPk
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetMTTActReporting
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.GETMTTACTREPORTING_FAILED)
     public DWLResponse getMTTActReporting(String MTTActReportingIdPk,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getMTTActReporting(String MTTActReportingIdPk,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(MTTActReportingIdPk);
        DWLTransaction txObj = new DWLTransactionInquiry("getMTTActReporting", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getMTTActReporting";
      logger.finest("getMTTActReporting(String MTTActReportingIdPk,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getMTTActReporting";
      logger.finest("getMTTActReporting(String MTTActReportingIdPk,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getMTTActReporting(String MTTActReportingIdPk,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getMTTActReporting.
     * 
     * @param MTTActReportingIdPk
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetMTTActReporting(String MTTActReportingIdPk,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    MTTDBCustom comp = 
      (MTTDBCustom)TCRMClassFactory.getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
      
        response = comp.getMTTActReporting(MTTActReportingIdPk,  control);
        if (response.getData() == null) {
            String[] params = new String[] { MTTActReportingIdPk };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          MTTDBCustomComponentID.MTTDBCUSTOM_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          MTTDBCustomErrorReasonCode.GETMTTACTREPORTING_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllMTTReportByID.
     *
     * @param ContractId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllMTTReportByID
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.GETALLMTTREPORTBYID_FAILED)
     public DWLResponse getAllMTTReportByID(String ContractId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllMTTReportByID(String ContractId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContractId);
        DWLTransaction txObj = new DWLTransactionInquiry("getAllMTTReportByID", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getAllMTTReportByID";
      logger.finest("getAllMTTReportByID(String ContractId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getAllMTTReportByID";
      logger.finest("getAllMTTReportByID(String ContractId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllMTTReportByID(String ContractId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getAllMTTReportByID.
     * 
     * @param ContractId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated NOT
     */
    public DWLResponse  handleGetAllMTTReportByID(String ContractId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    MTTDBCustom comp = 
      (MTTDBCustom)TCRMClassFactory.getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
      
        response = comp.getAllMTTReportByID(ContractId,  control);
        if (response.getData() == null) {
           /* String[] params = new String[] { ContractId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          MTTDBCustomComponentID.MTTDBCUSTOM_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          MTTDBCustomErrorReasonCode.GETALLMTTREPORTBYID_FAILED,
          control, params, errHandler);		*/			
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getMTTIdentifier.
     *
     * @param MTTIdentifierIdPk
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetMTTIdentifier
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.GETMTTIDENTIFIER_FAILED)
     public DWLResponse getMTTIdentifier(String MTTIdentifierIdPk,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getMTTIdentifier(String MTTIdentifierIdPk,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(MTTIdentifierIdPk);
        DWLTransaction txObj = new DWLTransactionInquiry("getMTTIdentifier", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getMTTIdentifier";
      logger.finest("getMTTIdentifier(String MTTIdentifierIdPk,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getMTTIdentifier";
      logger.finest("getMTTIdentifier(String MTTIdentifierIdPk,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getMTTIdentifier(String MTTIdentifierIdPk,  DWLControl control) " + returnValue);
    }
        return retObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getMTTIdentifier.
     * 
     * @param MTTIdentifierIdPk
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetMTTIdentifier(String MTTIdentifierIdPk,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    MTTDBCustom comp = 
      (MTTDBCustom)TCRMClassFactory.getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
      
        response = comp.getMTTIdentifier(MTTIdentifierIdPk,  control);
        if (response.getData() == null) {
            String[] params = new String[] { MTTIdentifierIdPk };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          MTTDBCustomComponentID.MTTDBCUSTOM_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          MTTDBCustomErrorReasonCode.GETMTTIDENTIFIER_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllMTTIdentifierByID.
     *
     * @param IdentifierId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllMTTIdentifierByID
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.GETALLMTTIDENTIFIERBYID_FAILED)
     public DWLResponse getAllMTTIdentifierByID(String IdentifierId,  String filter,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllMTTIdentifierByID(String IdentifierId,  String filter,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(IdentifierId);
        params.add(filter);
        DWLTransaction txObj = new DWLTransactionInquiry("getAllMTTIdentifierByID", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getAllMTTIdentifierByID";
      logger.finest("getAllMTTIdentifierByID(String IdentifierId,  String filter,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getAllMTTIdentifierByID";
      logger.finest("getAllMTTIdentifierByID(String IdentifierId,  String filter,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllMTTIdentifierByID(String IdentifierId,  String filter,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getAllMTTIdentifierByID.
     * 
     * @param IdentifierId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetAllMTTIdentifierByID(String IdentifierId,  String filter,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    MTTDBCustom comp = 
      (MTTDBCustom)TCRMClassFactory.getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
      
        response = comp.getAllMTTIdentifierByID(IdentifierId,  filter,  control);
        if (response.getData() == null) {
            String[] params = new String[] { IdentifierId,  filter };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          MTTDBCustomComponentID.MTTDBCUSTOM_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          MTTDBCustomErrorReasonCode.GETALLMTTIDENTIFIERBYID_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getAllMTTIdentifierByID.
     * 
     * @param IdentifierId
     * @param EndDate
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated NOT
     */
    public DWLResponse  handleGetAllMTTIdentifierByID(String IdentifierId, String EndDate,  String filter,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    MTTDBCustom comp = 
      (MTTDBCustom)TCRMClassFactory.getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
      
        response = comp.getAllMTTIdentifierByID(IdentifierId, filter,  control);
        if (response.getData() == null) {
            /*String[] params = new String[] { IdentifierId, EndDate,  filter };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          MTTDBCustomComponentID.MTTDBCUSTOM_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          MTTDBCustomErrorReasonCode.GETALLMTTIDENTIFIERBYID_FAILED,
          control, params, errHandler);*/					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getMTTStore.
     *
     * @param MTTStoreIdPk
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetMTTStore
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.GETMTTSTORE_FAILED)
     public DWLResponse getMTTStore(String MTTStoreIdPk,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getMTTStore(String MTTStoreIdPk,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(MTTStoreIdPk);
        DWLTransaction txObj = new DWLTransactionInquiry("getMTTStore", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getMTTStore";
      logger.finest("getMTTStore(String MTTStoreIdPk,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getMTTStore";
      logger.finest("getMTTStore(String MTTStoreIdPk,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getMTTStore(String MTTStoreIdPk,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getMTTStore.
     * 
     * @param MTTStoreIdPk
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetMTTStore(String MTTStoreIdPk,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    MTTDBCustom comp = 
      (MTTDBCustom)TCRMClassFactory.getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
      
        response = comp.getMTTStore(MTTStoreIdPk,  control);
        if (response.getData() == null) {
            String[] params = new String[] { MTTStoreIdPk };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          MTTDBCustomComponentID.MTTDBCUSTOM_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          MTTDBCustomErrorReasonCode.GETMTTSTORE_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllStoreByID.
     *
     * @param PartyId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllStoreByID
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.GETALLSTOREBYID_FAILED)
     public DWLResponse getAllStoreByID(String PartyId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllStoreByID(String PartyId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(PartyId);
        DWLTransaction txObj = new DWLTransactionInquiry("getAllStoreByID", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getAllStoreByID";
      logger.finest("getAllStoreByID(String PartyId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getAllStoreByID";
      logger.finest("getAllStoreByID(String PartyId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllStoreByID(String PartyId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getAllStoreByID.
     * 
     * @param PartyId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetAllStoreByID(String PartyId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    MTTDBCustom comp = 
      (MTTDBCustom)TCRMClassFactory.getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
      
        response = comp.getAllStoreByID(PartyId,  control);
        if (response.getData() == null) {
            String[] params = new String[] { PartyId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          MTTDBCustomComponentID.MTTDBCUSTOM_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          MTTDBCustomErrorReasonCode.GETALLSTOREBYID_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getMTTActCreditTax.
     *
     * @param MTTActCreditTaxIdPk
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetMTTActCreditTax
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.GETMTTACTCREDITTAX_FAILED)
     public DWLResponse getMTTActCreditTax(String MTTActCreditTaxIdPk,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getMTTActCreditTax(String MTTActCreditTaxIdPk,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(MTTActCreditTaxIdPk);
        DWLTransaction txObj = new DWLTransactionInquiry("getMTTActCreditTax", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getMTTActCreditTax";
      logger.finest("getMTTActCreditTax(String MTTActCreditTaxIdPk,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getMTTActCreditTax";
      logger.finest("getMTTActCreditTax(String MTTActCreditTaxIdPk,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getMTTActCreditTax(String MTTActCreditTaxIdPk,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getMTTActCreditTax.
     * 
     * @param MTTActCreditTaxIdPk
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetMTTActCreditTax(String MTTActCreditTaxIdPk,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    MTTDBCustom comp = 
      (MTTDBCustom)TCRMClassFactory.getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
      
        response = comp.getMTTActCreditTax(MTTActCreditTaxIdPk,  control);
        if (response.getData() == null) {
            String[] params = new String[] { MTTActCreditTaxIdPk };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          MTTDBCustomComponentID.MTTDBCUSTOM_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          MTTDBCustomErrorReasonCode.GETMTTACTCREDITTAX_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllMTTCreditTaxByID.
     *
     * @param ContractId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllMTTCreditTaxByID
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.GETALLMTTCREDITTAXBYID_FAILED)
     public DWLResponse getAllMTTCreditTaxByID(String ContractId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllMTTCreditTaxByID(String ContractId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContractId);
        DWLTransaction txObj = new DWLTransactionInquiry("getAllMTTCreditTaxByID", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getAllMTTCreditTaxByID";
      logger.finest("getAllMTTCreditTaxByID(String ContractId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getAllMTTCreditTaxByID";
      logger.finest("getAllMTTCreditTaxByID(String ContractId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllMTTCreditTaxByID(String ContractId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getAllMTTCreditTaxByID.
     * 
     * @param ContractId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated NOT
     */
    public DWLResponse  handleGetAllMTTCreditTaxByID(String ContractId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    MTTDBCustom comp = 
      (MTTDBCustom)TCRMClassFactory.getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
      
        response = comp.getAllMTTCreditTaxByID(ContractId,  control);
        if (response.getData() == null) {
            /*String[] params = new String[] { ContractId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          MTTDBCustomComponentID.MTTDBCUSTOM_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          MTTDBCustomErrorReasonCode.GETALLMTTCREDITTAXBYID_FAILED,
          control, params, errHandler);*/					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getMTTActOrderInvoice.
     *
     * @param MTTActOrderInvoiceIdPk
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetMTTActOrderInvoice
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.GETMTTACTORDERINVOICE_FAILED)
     public DWLResponse getMTTActOrderInvoice(String MTTActOrderInvoiceIdPk,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getMTTActOrderInvoice(String MTTActOrderInvoiceIdPk,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(MTTActOrderInvoiceIdPk);
        DWLTransaction txObj = new DWLTransactionInquiry("getMTTActOrderInvoice", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getMTTActOrderInvoice";
      logger.finest("getMTTActOrderInvoice(String MTTActOrderInvoiceIdPk,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getMTTActOrderInvoice";
      logger.finest("getMTTActOrderInvoice(String MTTActOrderInvoiceIdPk,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getMTTActOrderInvoice(String MTTActOrderInvoiceIdPk,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getMTTActOrderInvoice.
     * 
     * @param MTTActOrderInvoiceIdPk
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetMTTActOrderInvoice(String MTTActOrderInvoiceIdPk,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    MTTDBCustom comp = 
      (MTTDBCustom)TCRMClassFactory.getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
      
        response = comp.getMTTActOrderInvoice(MTTActOrderInvoiceIdPk,  control);
        if (response.getData() == null) {
            String[] params = new String[] { MTTActOrderInvoiceIdPk };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          MTTDBCustomComponentID.MTTDBCUSTOM_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          MTTDBCustomErrorReasonCode.GETMTTACTORDERINVOICE_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllMTTOrderInvoiceByID.
     *
     * @param ContractId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllMTTOrderInvoiceByID
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.GETALLMTTORDERINVOICEBYID_FAILED)
     public DWLResponse getAllMTTOrderInvoiceByID(String ContractId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllMTTOrderInvoiceByID(String ContractId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContractId);
        DWLTransaction txObj = new DWLTransactionInquiry("getAllMTTOrderInvoiceByID", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getAllMTTOrderInvoiceByID";
      logger.finest("getAllMTTOrderInvoiceByID(String ContractId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getAllMTTOrderInvoiceByID";
      logger.finest("getAllMTTOrderInvoiceByID(String ContractId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllMTTOrderInvoiceByID(String ContractId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getAllMTTOrderInvoiceByID.
     * 
     * @param ContractId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated NOT
     */
    public DWLResponse  handleGetAllMTTOrderInvoiceByID(String ContractId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    MTTDBCustom comp = 
      (MTTDBCustom)TCRMClassFactory.getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
      
        response = comp.getAllMTTOrderInvoiceByID(ContractId,  control);
        if (response.getData() == null) {
            /*String[] params = new String[] { ContractId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          MTTDBCustomComponentID.MTTDBCUSTOM_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          MTTDBCustomErrorReasonCode.GETALLMTTORDERINVOICEBYID_FAILED,
          control, params, errHandler);		*/			
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getMTTActCostCharges.
     *
     * @param MTTActCostChargesIdPk
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetMTTActCostCharges
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.GETMTTACTCOSTCHARGES_FAILED)
     public DWLResponse getMTTActCostCharges(String MTTActCostChargesIdPk,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getMTTActCostCharges(String MTTActCostChargesIdPk,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(MTTActCostChargesIdPk);
        DWLTransaction txObj = new DWLTransactionInquiry("getMTTActCostCharges", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getMTTActCostCharges";
      logger.finest("getMTTActCostCharges(String MTTActCostChargesIdPk,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getMTTActCostCharges";
      logger.finest("getMTTActCostCharges(String MTTActCostChargesIdPk,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getMTTActCostCharges(String MTTActCostChargesIdPk,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getMTTActCostCharges.
     * 
     * @param MTTActCostChargesIdPk
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetMTTActCostCharges(String MTTActCostChargesIdPk,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    MTTDBCustom comp = 
      (MTTDBCustom)TCRMClassFactory.getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
      
        response = comp.getMTTActCostCharges(MTTActCostChargesIdPk,  control);
        if (response.getData() == null) {
            String[] params = new String[] { MTTActCostChargesIdPk };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          MTTDBCustomComponentID.MTTDBCUSTOM_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          MTTDBCustomErrorReasonCode.GETMTTACTCOSTCHARGES_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllMTTActCostChargesByID.
     *
     * @param ContractId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllMTTActCostChargesByID
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.GETALLMTTACTCOSTCHARGESBYID_FAILED)
     public DWLResponse getAllMTTActCostChargesByID(String ContractId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllMTTActCostChargesByID(String ContractId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContractId);
        DWLTransaction txObj = new DWLTransactionInquiry("getAllMTTActCostChargesByID", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getAllMTTActCostChargesByID";
      logger.finest("getAllMTTActCostChargesByID(String ContractId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getAllMTTActCostChargesByID";
      logger.finest("getAllMTTActCostChargesByID(String ContractId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllMTTActCostChargesByID(String ContractId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getAllMTTActCostChargesByID.
     * 
     * @param ContractId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated NOT
     */
    public DWLResponse  handleGetAllMTTActCostChargesByID(String ContractId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    MTTDBCustom comp = 
      (MTTDBCustom)TCRMClassFactory.getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
      
        response = comp.getAllMTTActCostChargesByID(ContractId,  control);
        if (response.getData() == null) {
            /*String[] params = new String[] { ContractId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          MTTDBCustomComponentID.MTTDBCUSTOM_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          MTTDBCustomErrorReasonCode.GETALLMTTACTCOSTCHARGESBYID_FAILED,
          control, params, errHandler);	*/				
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getMTTActFinancial.
     *
     * @param MTTActFinancialIdPk
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetMTTActFinancial
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.GETMTTACTFINANCIAL_FAILED)
     public DWLResponse getMTTActFinancial(String MTTActFinancialIdPk,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getMTTActFinancial(String MTTActFinancialIdPk,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(MTTActFinancialIdPk);
        DWLTransaction txObj = new DWLTransactionInquiry("getMTTActFinancial", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getMTTActFinancial";
      logger.finest("getMTTActFinancial(String MTTActFinancialIdPk,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getMTTActFinancial";
      logger.finest("getMTTActFinancial(String MTTActFinancialIdPk,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getMTTActFinancial(String MTTActFinancialIdPk,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getMTTActFinancial.
     * 
     * @param MTTActFinancialIdPk
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated
     */
    public DWLResponse  handleGetMTTActFinancial(String MTTActFinancialIdPk,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    MTTDBCustom comp = 
      (MTTDBCustom)TCRMClassFactory.getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
      
        response = comp.getMTTActFinancial(MTTActFinancialIdPk,  control);
        if (response.getData() == null) {
            String[] params = new String[] { MTTActFinancialIdPk };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          MTTDBCustomComponentID.MTTDBCUSTOM_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          MTTDBCustomErrorReasonCode.GETMTTACTFINANCIAL_FAILED,
          control, params, errHandler);					
        }
        return response;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Executes the transaction getAllMTTActFinancialbyID.
     *
     * @param ContractId
     * @return com.dwl.base.DWLResponse
     * @exception DWLBaseException
     * @see #handleGetAllMTTActFinancialbyID
     * @generated
     */
     @TxMetadata(actionCategory=DWLControlKeys.VIEW_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.READ_RECORD_ERROR,
       txErrorReasonCode = MTTDBCustomErrorReasonCode.GETALLMTTACTFINANCIALBYID_FAILED)
     public DWLResponse getAllMTTActFinancialbyID(String ContractId,  DWLControl control) throws DWLBaseException {
    logger.finest("ENTER getAllMTTActFinancialbyID(String ContractId,  DWLControl control)");
        Vector<String> params = new Vector<String>();
        params.add(ContractId);
        DWLTransaction txObj = new DWLTransactionInquiry("getAllMTTActFinancialbyID", params, control);
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
      String infoForLogging="Before finder transaction execution for getAllMTTActFinancialbyID";
      logger.finest("getAllMTTActFinancialbyID(String ContractId,  DWLControl control) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
       		String infoForLogging="After finder transaction execution for getAllMTTActFinancialbyID";
      logger.finest("getAllMTTActFinancialbyID(String ContractId,  DWLControl control) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN getAllMTTActFinancialbyID(String ContractId,  DWLControl control) " + returnValue);
    }
        return retObj;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction getAllMTTActFinancialbyID.
     * 
     * @param ContractId
     * @return com.dwl.base.DWLResponse
     * @exception Exception
     * @generated NOT
     */
    public DWLResponse  handleGetAllMTTActFinancialbyID(String ContractId,  DWLControl control) throws Exception {

        DWLResponse response = new DWLResponse();

    MTTDBCustom comp = 
      (MTTDBCustom)TCRMClassFactory.getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
      
        response = comp.getAllMTTActFinancialbyID(ContractId,  control);
        if (response.getData() == null) {
            /*String[] params = new String[] { ContractId };
            DWLExceptionUtils.addErrorToStatus(response.getStatus(), DWLStatus.FATAL,
          MTTDBCustomComponentID.MTTDBCUSTOM_CONTROLLER,
          TCRMErrorCode.READ_RECORD_ERROR,
          MTTDBCustomErrorReasonCode.GETALLMTTACTFINANCIALBYID_FAILED,
          control, params, errHandler);	*/				
        }
        return response;
    }
    

}


