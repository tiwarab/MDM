	
/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[ab214b503cf1744c2772fc6bf5863968]
 */

package com.metcash.db.custom.controller;

import com.dwl.base.requestHandler.DWLTransaction;
import com.dwl.base.requestHandler.DWLTransactionPersistent;
import com.dwl.tcrm.common.TCRMCommonComponent;
import com.dwl.tcrm.common.TCRMControlKeys;
import com.dwl.tcrm.common.TCRMErrorCode;
import com.dwl.tcrm.utilities.TCRMClassFactory;
import com.dwl.base.DWLResponse;
import com.dwl.base.exception.DWLBaseException;
import com.ibm.mdm.annotations.Controller;
import com.ibm.mdm.annotations.TxMetadata;


import com.metcash.db.custom.component.MTTActCostChargesBObj;
import com.metcash.db.custom.component.MTTActCreditTaxBObj;
import com.metcash.db.custom.component.MTTActFinancialBObj;
import com.metcash.db.custom.component.MTTActOrderInvoiceBObj;
import com.metcash.db.custom.component.MTTActReportingBObj;
import com.metcash.db.custom.component.MTTIdentifierBObj;

import com.metcash.db.custom.component.MTTStoreBObj;
import com.metcash.db.custom.constant.MTTDBCustomComponentID;
import com.metcash.db.custom.constant.MTTDBCustomErrorReasonCode;
import com.metcash.db.custom.constant.MTTDBCustomPropertyKeys;

import com.metcash.db.custom.interfaces.MTTDBCustom;
import com.metcash.db.custom.interfaces.MTTDBCustomTxn;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * Controller implementation for all persistent MTTDBCustom services.
 * @generated
 */
@Controller(errorComponentID = MTTDBCustomComponentID.MTTDBCUSTOM_CONTROLLER)
public class MTTDBCustomTxnBean  extends TCRMCommonComponent implements MTTDBCustomTxn {

	/**
    * <!-- begin-user-doc -->
	  * <!-- end-user-doc -->
    * @generated 
    */
	 private final static com.dwl.base.logging.IDWLLogger logger = com.dwl.base.logging.DWLLoggerManager.getLogger(MTTDBCustomTxnBean.class);
    

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleAddMTTActReporting.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddMTTActReporting
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = MTTDBCustomErrorReasonCode.ADDMTTACTREPORTING_FAILED)
    public DWLResponse addMTTActReporting(MTTActReportingBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addMTTActReporting(MTTActReportingBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addMTTActReporting", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addMTTActReporting execution";
      logger.finest("addMTTActReporting(MTTActReportingBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addMTTActReporting execution";
      logger.finest("addMTTActReporting(MTTActReportingBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addMTTActReporting(MTTActReportingBObj theBObj) " + returnValue);
    }
        return retObj;
    }

  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addMTTActReporting.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addMTTActReporting
     *
     * @generated
     */
    public DWLResponse handleAddMTTActReporting(MTTActReportingBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddMTTActReporting(MTTActReportingBObj theBObj)");
        DWLResponse response = new DWLResponse();
        MTTDBCustom aMTTDBCustomComponent = (MTTDBCustom) TCRMClassFactory
      .getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
        response = aMTTDBCustomComponent.addMTTActReporting(theBObj);
    logger.finest("RETURN handleAddMTTActReporting(MTTActReportingBObj theBObj)");
        return response;
    }

  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleUpdateMTTActReporting.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateMTTActReporting
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = MTTDBCustomErrorReasonCode.UPDATEMTTACTREPORTING_FAILED)
    public DWLResponse updateMTTActReporting(MTTActReportingBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateMTTActReporting(MTTActReportingBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateMTTActReporting", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateMTTActReporting execution";
      logger.finest("updateMTTActReporting(MTTActReportingBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateMTTActReporting execution";
      logger.finest("updateMTTActReporting(MTTActReportingBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateMTTActReporting(MTTActReportingBObj theBObj) " + returnValue);
    }
        return retObj;
    }

  /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateMTTActReporting.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateMTTActReporting
     *
     * @generated
     */
    public DWLResponse handleUpdateMTTActReporting(MTTActReportingBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateMTTActReporting(MTTActReportingBObj theBObj)");
        DWLResponse response = new DWLResponse();
        MTTDBCustom aMTTDBCustomComponent = (MTTDBCustom) TCRMClassFactory
      .getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
        response = aMTTDBCustomComponent.updateMTTActReporting(theBObj);
    logger.finest("RETURN handleUpdateMTTActReporting(MTTActReportingBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleAddMTTIdentifier.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddMTTIdentifier
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = MTTDBCustomErrorReasonCode.ADDMTTIDENTIFIER_FAILED)
    public DWLResponse addMTTIdentifier(MTTIdentifierBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addMTTIdentifier(MTTIdentifierBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addMTTIdentifier", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addMTTIdentifier execution";
      logger.finest("addMTTIdentifier(MTTIdentifierBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addMTTIdentifier execution";
      logger.finest("addMTTIdentifier(MTTIdentifierBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addMTTIdentifier(MTTIdentifierBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addMTTIdentifier.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addMTTIdentifier
     *
     * @generated
     */
    public DWLResponse handleAddMTTIdentifier(MTTIdentifierBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddMTTIdentifier(MTTIdentifierBObj theBObj)");
        DWLResponse response = new DWLResponse();
        MTTDBCustom aMTTDBCustomComponent = (MTTDBCustom) TCRMClassFactory
      .getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
        response = aMTTDBCustomComponent.addMTTIdentifier(theBObj);
    logger.finest("RETURN handleAddMTTIdentifier(MTTIdentifierBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleUpdateMTTIdentifier.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateMTTIdentifier
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = MTTDBCustomErrorReasonCode.UPDATEMTTIDENTIFIER_FAILED)
    public DWLResponse updateMTTIdentifier(MTTIdentifierBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateMTTIdentifier(MTTIdentifierBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateMTTIdentifier", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateMTTIdentifier execution";
      logger.finest("updateMTTIdentifier(MTTIdentifierBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateMTTIdentifier execution";
      logger.finest("updateMTTIdentifier(MTTIdentifierBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateMTTIdentifier(MTTIdentifierBObj theBObj) " + returnValue);
    }
        return retObj;
    }
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateMTTIdentifier.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateMTTIdentifier
     *
     * @generated
     */
    public DWLResponse handleUpdateMTTIdentifier(MTTIdentifierBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateMTTIdentifier(MTTIdentifierBObj theBObj)");
        DWLResponse response = new DWLResponse();
        MTTDBCustom aMTTDBCustomComponent = (MTTDBCustom) TCRMClassFactory
      .getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
        response = aMTTDBCustomComponent.updateMTTIdentifier(theBObj);
    logger.finest("RETURN handleUpdateMTTIdentifier(MTTIdentifierBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleAddMTTStore.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddMTTStore
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = MTTDBCustomErrorReasonCode.ADDMTTSTORE_FAILED)
    public DWLResponse addMTTStore(MTTStoreBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addMTTStore(MTTStoreBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addMTTStore", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addMTTStore execution";
      logger.finest("addMTTStore(MTTStoreBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addMTTStore execution";
      logger.finest("addMTTStore(MTTStoreBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addMTTStore(MTTStoreBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addMTTStore.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addMTTStore
     *
     * @generated
     */
    public DWLResponse handleAddMTTStore(MTTStoreBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddMTTStore(MTTStoreBObj theBObj)");
        DWLResponse response = new DWLResponse();
        MTTDBCustom aMTTDBCustomComponent = (MTTDBCustom) TCRMClassFactory
      .getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
        response = aMTTDBCustomComponent.addMTTStore(theBObj);
    logger.finest("RETURN handleAddMTTStore(MTTStoreBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleUpdateMTTStore.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateMTTStore
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = MTTDBCustomErrorReasonCode.UPDATEMTTSTORE_FAILED)
    public DWLResponse updateMTTStore(MTTStoreBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateMTTStore(MTTStoreBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateMTTStore", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateMTTStore execution";
      logger.finest("updateMTTStore(MTTStoreBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateMTTStore execution";
      logger.finest("updateMTTStore(MTTStoreBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateMTTStore(MTTStoreBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateMTTStore.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateMTTStore
     *
     * @generated
     */
    public DWLResponse handleUpdateMTTStore(MTTStoreBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateMTTStore(MTTStoreBObj theBObj)");
        DWLResponse response = new DWLResponse();
        MTTDBCustom aMTTDBCustomComponent = (MTTDBCustom) TCRMClassFactory
      .getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
        response = aMTTDBCustomComponent.updateMTTStore(theBObj);
    logger.finest("RETURN handleUpdateMTTStore(MTTStoreBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleAddMTTActCreditTax.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddMTTActCreditTax
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = MTTDBCustomErrorReasonCode.ADDMTTACTCREDITTAX_FAILED)
    public DWLResponse addMTTActCreditTax(MTTActCreditTaxBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addMTTActCreditTax(MTTActCreditTaxBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addMTTActCreditTax", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addMTTActCreditTax execution";
      logger.finest("addMTTActCreditTax(MTTActCreditTaxBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addMTTActCreditTax execution";
      logger.finest("addMTTActCreditTax(MTTActCreditTaxBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addMTTActCreditTax(MTTActCreditTaxBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addMTTActCreditTax.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addMTTActCreditTax
     *
     * @generated
     */
    public DWLResponse handleAddMTTActCreditTax(MTTActCreditTaxBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddMTTActCreditTax(MTTActCreditTaxBObj theBObj)");
        DWLResponse response = new DWLResponse();
        MTTDBCustom aMTTDBCustomComponent = (MTTDBCustom) TCRMClassFactory
      .getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
        response = aMTTDBCustomComponent.addMTTActCreditTax(theBObj);
    logger.finest("RETURN handleAddMTTActCreditTax(MTTActCreditTaxBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleUpdateMTTActCreditTax.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateMTTActCreditTax
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = MTTDBCustomErrorReasonCode.UPDATEMTTACTCREDITTAX_FAILED)
    public DWLResponse updateMTTActCreditTax(MTTActCreditTaxBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateMTTActCreditTax(MTTActCreditTaxBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateMTTActCreditTax", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateMTTActCreditTax execution";
      logger.finest("updateMTTActCreditTax(MTTActCreditTaxBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateMTTActCreditTax execution";
      logger.finest("updateMTTActCreditTax(MTTActCreditTaxBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateMTTActCreditTax(MTTActCreditTaxBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateMTTActCreditTax.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateMTTActCreditTax
     *
     * @generated
     */
    public DWLResponse handleUpdateMTTActCreditTax(MTTActCreditTaxBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateMTTActCreditTax(MTTActCreditTaxBObj theBObj)");
        DWLResponse response = new DWLResponse();
        MTTDBCustom aMTTDBCustomComponent = (MTTDBCustom) TCRMClassFactory
      .getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
        response = aMTTDBCustomComponent.updateMTTActCreditTax(theBObj);
    logger.finest("RETURN handleUpdateMTTActCreditTax(MTTActCreditTaxBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleAddMTTActOrderInvoice.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddMTTActOrderInvoice
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = MTTDBCustomErrorReasonCode.ADDMTTACTORDERINVOICE_FAILED)
    public DWLResponse addMTTActOrderInvoice(MTTActOrderInvoiceBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addMTTActOrderInvoice(MTTActOrderInvoiceBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addMTTActOrderInvoice", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addMTTActOrderInvoice execution";
      logger.finest("addMTTActOrderInvoice(MTTActOrderInvoiceBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addMTTActOrderInvoice execution";
      logger.finest("addMTTActOrderInvoice(MTTActOrderInvoiceBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addMTTActOrderInvoice(MTTActOrderInvoiceBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addMTTActOrderInvoice.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addMTTActOrderInvoice
     *
     * @generated
     */
    public DWLResponse handleAddMTTActOrderInvoice(MTTActOrderInvoiceBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddMTTActOrderInvoice(MTTActOrderInvoiceBObj theBObj)");
        DWLResponse response = new DWLResponse();
        MTTDBCustom aMTTDBCustomComponent = (MTTDBCustom) TCRMClassFactory
      .getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
        response = aMTTDBCustomComponent.addMTTActOrderInvoice(theBObj);
    logger.finest("RETURN handleAddMTTActOrderInvoice(MTTActOrderInvoiceBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * handleUpdateMTTActOrderInvoice.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateMTTActOrderInvoice
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = MTTDBCustomErrorReasonCode.UPDATEMTTACTORDERINVOICE_FAILED)
    public DWLResponse updateMTTActOrderInvoice(MTTActOrderInvoiceBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateMTTActOrderInvoice(MTTActOrderInvoiceBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateMTTActOrderInvoice", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateMTTActOrderInvoice execution";
      logger.finest("updateMTTActOrderInvoice(MTTActOrderInvoiceBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateMTTActOrderInvoice execution";
      logger.finest("updateMTTActOrderInvoice(MTTActOrderInvoiceBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateMTTActOrderInvoice(MTTActOrderInvoiceBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateMTTActOrderInvoice.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateMTTActOrderInvoice
     *
     * @generated
     */
    public DWLResponse handleUpdateMTTActOrderInvoice(MTTActOrderInvoiceBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateMTTActOrderInvoice(MTTActOrderInvoiceBObj theBObj)");
        DWLResponse response = new DWLResponse();
        MTTDBCustom aMTTDBCustomComponent = (MTTDBCustom) TCRMClassFactory
      .getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
        response = aMTTDBCustomComponent.updateMTTActOrderInvoice(theBObj);
    logger.finest("RETURN handleUpdateMTTActOrderInvoice(MTTActOrderInvoiceBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleAddMTTActCostCharges.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddMTTActCostCharges
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = MTTDBCustomErrorReasonCode.ADDMTTACTCOSTCHARGES_FAILED)
    public DWLResponse addMTTActCostCharges(MTTActCostChargesBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addMTTActCostCharges(MTTActCostChargesBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addMTTActCostCharges", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addMTTActCostCharges execution";
      logger.finest("addMTTActCostCharges(MTTActCostChargesBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addMTTActCostCharges execution";
      logger.finest("addMTTActCostCharges(MTTActCostChargesBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addMTTActCostCharges(MTTActCostChargesBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addMTTActCostCharges.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addMTTActCostCharges
     *
     * @generated
     */
    public DWLResponse handleAddMTTActCostCharges(MTTActCostChargesBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddMTTActCostCharges(MTTActCostChargesBObj theBObj)");
        DWLResponse response = new DWLResponse();
        MTTDBCustom aMTTDBCustomComponent = (MTTDBCustom) TCRMClassFactory
      .getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
        response = aMTTDBCustomComponent.addMTTActCostCharges(theBObj);
    logger.finest("RETURN handleAddMTTActCostCharges(MTTActCostChargesBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction
     * handleUpdateMTTActCostCharges.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateMTTActCostCharges
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = MTTDBCustomErrorReasonCode.UPDATEMTTACTCOSTCHARGES_FAILED)
    public DWLResponse updateMTTActCostCharges(MTTActCostChargesBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateMTTActCostCharges(MTTActCostChargesBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateMTTActCostCharges", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateMTTActCostCharges execution";
      logger.finest("updateMTTActCostCharges(MTTActCostChargesBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateMTTActCostCharges execution";
      logger.finest("updateMTTActCostCharges(MTTActCostChargesBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateMTTActCostCharges(MTTActCostChargesBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateMTTActCostCharges.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateMTTActCostCharges
     *
     * @generated
     */
    public DWLResponse handleUpdateMTTActCostCharges(MTTActCostChargesBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateMTTActCostCharges(MTTActCostChargesBObj theBObj)");
        DWLResponse response = new DWLResponse();
        MTTDBCustom aMTTDBCustomComponent = (MTTDBCustom) TCRMClassFactory
      .getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
        response = aMTTDBCustomComponent.updateMTTActCostCharges(theBObj);
    logger.finest("RETURN handleUpdateMTTActCostCharges(MTTActCostChargesBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleAddMTTActFinancial.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleaddMTTActFinancial
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.ADD_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.INSERT_RECORD_ERROR, 
       txErrorReasonCode = MTTDBCustomErrorReasonCode.ADDMTTACTFINANCIAL_FAILED)
    public DWLResponse addMTTActFinancial(MTTActFinancialBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER addMTTActFinancial(MTTActFinancialBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("addMTTActFinancial", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction addMTTActFinancial execution";
      logger.finest("addMTTActFinancial(MTTActFinancialBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction addMTTActFinancial execution";
      logger.finest("addMTTActFinancial(MTTActFinancialBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN addMTTActFinancial(MTTActFinancialBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction addMTTActFinancial.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #addMTTActFinancial
     *
     * @generated
     */
    public DWLResponse handleAddMTTActFinancial(MTTActFinancialBObj theBObj) throws Exception {
    logger.finest("ENTER handleAddMTTActFinancial(MTTActFinancialBObj theBObj)");
        DWLResponse response = new DWLResponse();
        MTTDBCustom aMTTDBCustomComponent = (MTTDBCustom) TCRMClassFactory
      .getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
        response = aMTTDBCustomComponent.addMTTActFinancial(theBObj);
    logger.finest("RETURN handleAddMTTActFinancial(MTTActFinancialBObj theBObj)");
        return response;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction handleUpdateMTTActFinancial.
     *
     * @return DWLResponse containing the added 
     * @throws DWLBaseException
     * @see #handleupdateMTTActFinancial
     *
     * @ejb.interface-method
     *    view-type="both"
     *
     * @generated
     */
     @TxMetadata(actionCategory=TCRMControlKeys.UPDATE_ACTION_CATEGORY,
       txErrorCode=TCRMErrorCode.UPDATE_RECORD_ERROR, 
       txErrorReasonCode = MTTDBCustomErrorReasonCode.UPDATEMTTACTFINANCIAL_FAILED)
    public DWLResponse updateMTTActFinancial(MTTActFinancialBObj theBObj) throws DWLBaseException {
    logger.finest("ENTER updateMTTActFinancial(MTTActFinancialBObj theBObj)");
        DWLTransaction txObj = new DWLTransactionPersistent("updateMTTActFinancial", theBObj, theBObj.getControl());
        DWLResponse retObj = null;
    if (logger.isFinestEnabled()) {
        	String infoForLogging="Before transaction updateMTTActFinancial execution";
      logger.finest("updateMTTActFinancial(MTTActFinancialBObj theBObj) " + infoForLogging);
    }
        retObj = executeTx(txObj);
    if (logger.isFinestEnabled()) {
        	String infoForLogging="After transaction updateMTTActFinancial execution";
      logger.finest("updateMTTActFinancial(MTTActFinancialBObj theBObj) " + infoForLogging);
        	String returnValue=retObj.toString();
      logger.finest("RETURN updateMTTActFinancial(MTTActFinancialBObj theBObj) " + returnValue);
    }
        return retObj;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Performs the business logic for transaction updateMTTActFinancial.
     * 
     * @return DWLResponse containing the added 
     * @throws Exception
     * @see #updateMTTActFinancial
     *
     * @generated
     */
    public DWLResponse handleUpdateMTTActFinancial(MTTActFinancialBObj theBObj) throws Exception {
    logger.finest("ENTER handleUpdateMTTActFinancial(MTTActFinancialBObj theBObj)");
        DWLResponse response = new DWLResponse();
        MTTDBCustom aMTTDBCustomComponent = (MTTDBCustom) TCRMClassFactory
      .getTCRMComponent(MTTDBCustomPropertyKeys.MTTDBCUSTOM_COMPONENT);
        response = aMTTDBCustomComponent.updateMTTActFinancial(theBObj);
    logger.finest("RETURN handleUpdateMTTActFinancial(MTTActFinancialBObj theBObj)");
        return response;
    }
}



