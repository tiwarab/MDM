/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[62162c4c89f3292431783bf56ccfccb3]
 */


package com.metcash.db.custom.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.metcash.db.custom.entityObject.EObjMTTStore;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjMTTStoreData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjMTTStoreSql = "select MTT_STORE_ID, CONT_ID, MSO_TP_CD, STORE_OPEN_DT, STORE_CLOSE_DT,  LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from MTT_STORE where MTT_STORE_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjMTTStoreSql = "insert into MTT_STORE (MTT_STORE_ID, CONT_ID, MSO_TP_CD, STORE_OPEN_DT, STORE_CLOSE_DT, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :mTTStoreIdPk, :partyId, :mSO, :storeOpenDate, :storeCloseDate, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjMTTStoreSql = "update MTT_STORE set CONT_ID = :partyId, MSO_TP_CD = :mSO, STORE_OPEN_DT = :storeOpenDate, STORE_CLOSE_DT = :storeCloseDate, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where MTT_STORE_ID = :mTTStoreIdPk and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjMTTStoreSql = "delete from MTT_STORE where MTT_STORE_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjMTTStoreKeyField = "EObjMTTStore.mTTStoreIdPk";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjMTTStoreGetFields =
    "EObjMTTStore.mTTStoreIdPk," +
    "EObjMTTStore.partyId," +
    "EObjMTTStore.mSO," +
    "EObjMTTStore.storeOpenDate," +
    "EObjMTTStore.storeCloseDate," +
    "EObjMTTStore.lastUpdateDt," +
    "EObjMTTStore.lastUpdateUser," +
    "EObjMTTStore.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjMTTStoreAllFields =
    "com.metcash.db.custom.entityObject.EObjMTTStore.mTTStoreIdPk," +
    "com.metcash.db.custom.entityObject.EObjMTTStore.partyId," +
    "com.metcash.db.custom.entityObject.EObjMTTStore.mSO," +
    "com.metcash.db.custom.entityObject.EObjMTTStore.storeOpenDate," +
    "com.metcash.db.custom.entityObject.EObjMTTStore.storeCloseDate," +
    "com.metcash.db.custom.entityObject.EObjMTTStore.lastUpdateDt," +
    "com.metcash.db.custom.entityObject.EObjMTTStore.lastUpdateUser," +
    "com.metcash.db.custom.entityObject.EObjMTTStore.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjMTTStoreUpdateFields =
    "com.metcash.db.custom.entityObject.EObjMTTStore.partyId," +
    "com.metcash.db.custom.entityObject.EObjMTTStore.mSO," +
    "com.metcash.db.custom.entityObject.EObjMTTStore.storeOpenDate," +
    "com.metcash.db.custom.entityObject.EObjMTTStore.storeCloseDate," +
    "com.metcash.db.custom.entityObject.EObjMTTStore.lastUpdateDt," +
    "com.metcash.db.custom.entityObject.EObjMTTStore.lastUpdateUser," +
    "com.metcash.db.custom.entityObject.EObjMTTStore.lastUpdateTxId," +
    "com.metcash.db.custom.entityObject.EObjMTTStore.mTTStoreIdPk," +
    "com.metcash.db.custom.entityObject.EObjMTTStore.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select MTTStore by parameters.
   * @generated
   */
  @Select(sql=getEObjMTTStoreSql)
  @EntityMapping(parameters=EObjMTTStoreKeyField, results=EObjMTTStoreGetFields)
  Iterator<EObjMTTStore> getEObjMTTStore(Long mTTStoreIdPk);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create MTTStore by EObjMTTStore Object.
   * @generated
   */
  @Update(sql=createEObjMTTStoreSql)
  @EntityMapping(parameters=EObjMTTStoreAllFields)
    int createEObjMTTStore(EObjMTTStore e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one MTTStore by EObjMTTStore object.
   * @generated
   */
  @Update(sql=updateEObjMTTStoreSql)
  @EntityMapping(parameters=EObjMTTStoreUpdateFields)
    int updateEObjMTTStore(EObjMTTStore e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete MTTStore by parameters.
   * @generated
   */
  @Update(sql=deleteEObjMTTStoreSql)
  @EntityMapping(parameters=EObjMTTStoreKeyField)
  int deleteEObjMTTStore(Long mTTStoreIdPk);

}

