/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[07d40c75fd02233f3cef75202942824e]
 */


package com.metcash.db.custom.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.metcash.db.custom.entityObject.EObjMTTActCreditTax;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjMTTActCreditTaxData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjMTTActCreditTaxSql = "select MTT_ACT_CREDIT_TAX_ID, CONTRACT_ID, INV_TERMS_TP_CD, GST_EXEMPT_IND, CUS_GRP_TP_CD, BANK_GUARANTEE_AMT, BANK_GUARANTEE_END_DT, CASH_DEPOSIT_AMT, CASH_DEPOSIT_RECV_DT, CASH_DEPOSIT_REL_DT, FIRST_MORTGAGE, SECOND_MORTGAGE, DEED_OF_PRIORITY, PPSR_DETAILS, PMSI_DETAILS, ALLPAP_DETAILS, ARREARS, CREDIT_HOLD, NATIONAL_HOLD, CREDIT_HOLD_DT, CREDIT_STATUS_OVERRIDE, CHEQUE_LIMIT_AMT, CHEQUE_LIMIT_CURRENCY_TP_CD, WET_EXEMPT_IND, DUTY_FREE_IND, CASH_ON_DELIVERY_IND, SALES_REP_TP_CD,  LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from MTT_ACCOUNT_CREDIT_TAX where MTT_ACT_CREDIT_TAX_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjMTTActCreditTaxSql = "insert into MTT_ACCOUNT_CREDIT_TAX (MTT_ACT_CREDIT_TAX_ID, CONTRACT_ID, INV_TERMS_TP_CD, GST_EXEMPT_IND, CUS_GRP_TP_CD, BANK_GUARANTEE_AMT, BANK_GUARANTEE_END_DT, CASH_DEPOSIT_AMT, CASH_DEPOSIT_RECV_DT, CASH_DEPOSIT_REL_DT, FIRST_MORTGAGE, SECOND_MORTGAGE, DEED_OF_PRIORITY, PPSR_DETAILS, PMSI_DETAILS, ALLPAP_DETAILS, ARREARS, CREDIT_HOLD, NATIONAL_HOLD, CREDIT_HOLD_DT, CREDIT_STATUS_OVERRIDE, CHEQUE_LIMIT_AMT, CHEQUE_LIMIT_CURRENCY_TP_CD, WET_EXEMPT_IND, DUTY_FREE_IND, CASH_ON_DELIVERY_IND, SALES_REP_TP_CD, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :mTTActCreditTaxIdPk, :contractId, :invoiceTerms, :gSTExemptInd, :customerGroup, :bankGuaranteeAmount, :bankGuaranteeEndDate, :cashDepositAmount, :cashDepositRecieveDate, :cashDepositReleaseDate, :firstMortgage, :secondMortgage, :deedOfPriority, :pPSRDetails, :pMSIDetails, :aLLPAPDetails, :arrears, :creditHold, :nationalHold, :creditHoldDate, :creditStatusOverride, :chequeLimitAmount, :chequeLimitCurrency, :wETExemptInd, :dutyFreeInd, :cashOnDeliveryInd, :salesRep, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjMTTActCreditTaxSql = "update MTT_ACCOUNT_CREDIT_TAX set CONTRACT_ID = :contractId, INV_TERMS_TP_CD = :invoiceTerms, GST_EXEMPT_IND = :gSTExemptInd, CUS_GRP_TP_CD = :customerGroup, BANK_GUARANTEE_AMT = :bankGuaranteeAmount, BANK_GUARANTEE_END_DT = :bankGuaranteeEndDate, CASH_DEPOSIT_AMT = :cashDepositAmount, CASH_DEPOSIT_RECV_DT = :cashDepositRecieveDate, CASH_DEPOSIT_REL_DT = :cashDepositReleaseDate, FIRST_MORTGAGE = :firstMortgage, SECOND_MORTGAGE = :secondMortgage, DEED_OF_PRIORITY = :deedOfPriority, PPSR_DETAILS = :pPSRDetails, PMSI_DETAILS = :pMSIDetails, ALLPAP_DETAILS = :aLLPAPDetails, ARREARS = :arrears, CREDIT_HOLD = :creditHold, NATIONAL_HOLD = :nationalHold, CREDIT_HOLD_DT = :creditHoldDate, CREDIT_STATUS_OVERRIDE = :creditStatusOverride, CHEQUE_LIMIT_AMT = :chequeLimitAmount, CHEQUE_LIMIT_CURRENCY_TP_CD = :chequeLimitCurrency, WET_EXEMPT_IND = :wETExemptInd, DUTY_FREE_IND = :dutyFreeInd, CASH_ON_DELIVERY_IND = :cashOnDeliveryInd, SALES_REP_TP_CD = :salesRep, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where MTT_ACT_CREDIT_TAX_ID = :mTTActCreditTaxIdPk and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjMTTActCreditTaxSql = "delete from MTT_ACCOUNT_CREDIT_TAX where MTT_ACT_CREDIT_TAX_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjMTTActCreditTaxKeyField = "EObjMTTActCreditTax.mTTActCreditTaxIdPk";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjMTTActCreditTaxGetFields =
    "EObjMTTActCreditTax.mTTActCreditTaxIdPk," +
    "EObjMTTActCreditTax.contractId," +
    "EObjMTTActCreditTax.invoiceTerms," +
    "EObjMTTActCreditTax.gSTExemptInd," +
    "EObjMTTActCreditTax.customerGroup," +
    "EObjMTTActCreditTax.bankGuaranteeAmount," +
    "EObjMTTActCreditTax.bankGuaranteeEndDate," +
    "EObjMTTActCreditTax.cashDepositAmount," +
    "EObjMTTActCreditTax.cashDepositRecieveDate," +
    "EObjMTTActCreditTax.cashDepositReleaseDate," +
    "EObjMTTActCreditTax.firstMortgage," +
    "EObjMTTActCreditTax.secondMortgage," +
    "EObjMTTActCreditTax.deedOfPriority," +
    "EObjMTTActCreditTax.pPSRDetails," +
    "EObjMTTActCreditTax.pMSIDetails," +
    "EObjMTTActCreditTax.aLLPAPDetails," +
    "EObjMTTActCreditTax.arrears," +
    "EObjMTTActCreditTax.creditHold," +
    "EObjMTTActCreditTax.nationalHold," +
    "EObjMTTActCreditTax.creditHoldDate," +
    "EObjMTTActCreditTax.creditStatusOverride," +
    "EObjMTTActCreditTax.chequeLimitAmount," +
    "EObjMTTActCreditTax.chequeLimitCurrency," +
    "EObjMTTActCreditTax.wETExemptInd," +
    "EObjMTTActCreditTax.dutyFreeInd," +
    "EObjMTTActCreditTax.cashOnDeliveryInd," +
    "EObjMTTActCreditTax.salesRep," +
    "EObjMTTActCreditTax.lastUpdateDt," +
    "EObjMTTActCreditTax.lastUpdateUser," +
    "EObjMTTActCreditTax.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjMTTActCreditTaxAllFields =
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.mTTActCreditTaxIdPk," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.contractId," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.invoiceTerms," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.gSTExemptInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.customerGroup," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.bankGuaranteeAmount," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.bankGuaranteeEndDate," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.cashDepositAmount," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.cashDepositRecieveDate," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.cashDepositReleaseDate," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.firstMortgage," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.secondMortgage," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.deedOfPriority," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.pPSRDetails," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.pMSIDetails," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.aLLPAPDetails," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.arrears," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.creditHold," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.nationalHold," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.creditHoldDate," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.creditStatusOverride," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.chequeLimitAmount," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.chequeLimitCurrency," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.wETExemptInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.dutyFreeInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.cashOnDeliveryInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.salesRep," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.lastUpdateDt," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.lastUpdateUser," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjMTTActCreditTaxUpdateFields =
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.contractId," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.invoiceTerms," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.gSTExemptInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.customerGroup," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.bankGuaranteeAmount," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.bankGuaranteeEndDate," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.cashDepositAmount," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.cashDepositRecieveDate," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.cashDepositReleaseDate," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.firstMortgage," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.secondMortgage," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.deedOfPriority," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.pPSRDetails," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.pMSIDetails," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.aLLPAPDetails," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.arrears," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.creditHold," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.nationalHold," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.creditHoldDate," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.creditStatusOverride," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.chequeLimitAmount," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.chequeLimitCurrency," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.wETExemptInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.dutyFreeInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.cashOnDeliveryInd," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.salesRep," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.lastUpdateDt," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.lastUpdateUser," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.lastUpdateTxId," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.mTTActCreditTaxIdPk," +
    "com.metcash.db.custom.entityObject.EObjMTTActCreditTax.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select MTTActCreditTax by parameters.
   * @generated
   */
  @Select(sql=getEObjMTTActCreditTaxSql)
  @EntityMapping(parameters=EObjMTTActCreditTaxKeyField, results=EObjMTTActCreditTaxGetFields)
  Iterator<EObjMTTActCreditTax> getEObjMTTActCreditTax(Long mTTActCreditTaxIdPk);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create MTTActCreditTax by EObjMTTActCreditTax Object.
   * @generated
   */
  @Update(sql=createEObjMTTActCreditTaxSql)
  @EntityMapping(parameters=EObjMTTActCreditTaxAllFields)
    int createEObjMTTActCreditTax(EObjMTTActCreditTax e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one MTTActCreditTax by EObjMTTActCreditTax object.
   * @generated
   */
  @Update(sql=updateEObjMTTActCreditTaxSql)
  @EntityMapping(parameters=EObjMTTActCreditTaxUpdateFields)
    int updateEObjMTTActCreditTax(EObjMTTActCreditTax e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete MTTActCreditTax by parameters.
   * @generated
   */
  @Update(sql=deleteEObjMTTActCreditTaxSql)
  @EntityMapping(parameters=EObjMTTActCreditTaxKeyField)
  int deleteEObjMTTActCreditTax(Long mTTActCreditTaxIdPk);

}

