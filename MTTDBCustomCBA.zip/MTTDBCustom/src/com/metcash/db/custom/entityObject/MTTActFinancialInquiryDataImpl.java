package com.metcash.db.custom.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.ibm.mdm.base.db.ResultQueue1;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import com.metcash.db.custom.entityObject.EObjMTTActFinancial;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


@SuppressWarnings("unchecked")

/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class MTTActFinancialInquiryDataImpl  extends BaseData implements MTTActFinancialInquiryData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "MTTActFinancialInquiryData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000015daaa4f142L;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public MTTActFinancialInquiryDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="SELECT r.MTT_ACT_FINANCIAL_ID MTT_ACT_FINANCIAL_ID, r.CONTRACT_ID CONTRACT_ID, r.STATEMENT_MODE_TP_CD STATEMENT_MODE_TP_CD, r.DUE_GRACE_DAYS_TP_CD DUE_GRACE_DAYS_TP_CD, r.TOBACCO_GRACE_DAYS_TP_CD TOBACCO_GRACE_DAYS_TP_CD, r.BANK_TP_CD BANK_TP_CD, r.BPAY_IND BPAY_IND, r.STATEMENT_PRN_HOLD_IND STATEMENT_PRN_HOLD_IND, r.BPAY_CUS_REF_NUM BPAY_CUS_REF_NUM, r.COLLECTOR_TP_CD COLLECTOR_TP_CD, r.BANK_ACCOUNT_TP_CD BANK_ACCOUNT_TP_CD, r.EXT_TERMS_BY_SHIPDATE_IND EXT_TERMS_BY_SHIPDATE_IND, r.SETTLEMENT_DISC_IND SETTLEMENT_DISC_IND, r.ACCOUNT_DETAILS ACCOUNT_DETAILS, r.DISC_GRACE_DAYS_TP_CD DISC_GRACE_DAYS_TP_CD, r.PAYMENT_METHOD_TP_CD PAYMENT_METHOD_TP_CD, r.LMAA_NUM LMAA_NUM, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM MTT_ACCOUNT_FINANCIAL r WHERE r.MTT_ACT_FINANCIAL_ID = ? ", pattern="tableAlias (MTT_ACCOUNT_FINANCIAL => com.metcash.db.custom.entityObject.EObjMTTActFinancial, H_MTT_ACCOUNT_FINANCIAL => com.metcash.db.custom.entityObject.EObjMTTActFinancial)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjMTTActFinancial>> getMTTActFinancial (Object[] parameters)
  {
    return queryIterator (getMTTActFinancialStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getMTTActFinancialStatementDescriptor = createStatementDescriptor (
    "getMTTActFinancial(Object[])",
    "SELECT r.MTT_ACT_FINANCIAL_ID MTT_ACT_FINANCIAL_ID, r.CONTRACT_ID CONTRACT_ID, r.STATEMENT_MODE_TP_CD STATEMENT_MODE_TP_CD, r.DUE_GRACE_DAYS_TP_CD DUE_GRACE_DAYS_TP_CD, r.TOBACCO_GRACE_DAYS_TP_CD TOBACCO_GRACE_DAYS_TP_CD, r.BANK_TP_CD BANK_TP_CD, r.BPAY_IND BPAY_IND, r.STATEMENT_PRN_HOLD_IND STATEMENT_PRN_HOLD_IND, r.BPAY_CUS_REF_NUM BPAY_CUS_REF_NUM, r.COLLECTOR_TP_CD COLLECTOR_TP_CD, r.BANK_ACCOUNT_TP_CD BANK_ACCOUNT_TP_CD, r.EXT_TERMS_BY_SHIPDATE_IND EXT_TERMS_BY_SHIPDATE_IND, r.SETTLEMENT_DISC_IND SETTLEMENT_DISC_IND, r.ACCOUNT_DETAILS ACCOUNT_DETAILS, r.DISC_GRACE_DAYS_TP_CD DISC_GRACE_DAYS_TP_CD, r.PAYMENT_METHOD_TP_CD PAYMENT_METHOD_TP_CD, r.LMAA_NUM LMAA_NUM, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM MTT_ACCOUNT_FINANCIAL r WHERE r.MTT_ACT_FINANCIAL_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"mtt_act_financial_id", "contract_id", "statement_mode_tp_cd", "due_grace_days_tp_cd", "tobacco_grace_days_tp_cd", "bank_tp_cd", "bpay_ind", "statement_prn_hold_ind", "bpay_cus_ref_num", "collector_tp_cd", "bank_account_tp_cd", "ext_terms_by_shipdate_ind", "settlement_disc_ind", "account_details", "disc_grace_days_tp_cd", "payment_method_tp_cd", "lmaa_num", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetMTTActFinancialParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetMTTActFinancialRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 19, 19, 1, 1, 10, 19, 19, 1, 1, 250, 19, 19, 100, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetMTTActFinancialParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetMTTActFinancialRowHandler extends BaseRowHandler<ResultQueue1<EObjMTTActFinancial>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjMTTActFinancial> handle (java.sql.ResultSet rs, ResultQueue1<EObjMTTActFinancial> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjMTTActFinancial> ();

      EObjMTTActFinancial returnObject1 = new EObjMTTActFinancial ();
      returnObject1.setMTTActFinancialIdPk(getLongObject (rs, 1)); 
      returnObject1.setContractId(getLongObject (rs, 2)); 
      returnObject1.setStatementMode(getLongObject (rs, 3)); 
      returnObject1.setDueGraceDays(getLongObject (rs, 4)); 
      returnObject1.setTobaccoGraceDays(getLongObject (rs, 5)); 
      returnObject1.setBank(getLongObject (rs, 6)); 
      returnObject1.setBPAYInd(getString (rs, 7)); 
      returnObject1.setStatementPrintHoldInd(getString (rs, 8)); 
      returnObject1.setBPAYCustomerRefNumber(getIntObject (rs, 9)); 
      returnObject1.setCollector(getLongObject (rs, 10)); 
      returnObject1.setBankAccount(getLongObject (rs, 11)); 
      returnObject1.setExtTermsByShipDateInd(getString (rs, 12)); 
      returnObject1.setSettlementDiscountInd(getString (rs, 13)); 
      returnObject1.setAccountDetails(getString (rs, 14)); 
      returnObject1.setDiscountGraceDays(getLongObject (rs, 15)); 
      returnObject1.setPaymentMethod(getLongObject (rs, 16)); 
      returnObject1.setLMAANumber(getString (rs, 17)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 18)); 
      returnObject1.setLastUpdateUser(getString (rs, 19)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 20)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_MTT_ACT_FINANCIAL_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.MTT_ACT_FINANCIAL_ID MTT_ACT_FINANCIAL_ID, r.CONTRACT_ID CONTRACT_ID, r.STATEMENT_MODE_TP_CD STATEMENT_MODE_TP_CD, r.DUE_GRACE_DAYS_TP_CD DUE_GRACE_DAYS_TP_CD, r.TOBACCO_GRACE_DAYS_TP_CD TOBACCO_GRACE_DAYS_TP_CD, r.BANK_TP_CD BANK_TP_CD, r.BPAY_IND BPAY_IND, r.STATEMENT_PRN_HOLD_IND STATEMENT_PRN_HOLD_IND, r.BPAY_CUS_REF_NUM BPAY_CUS_REF_NUM, r.COLLECTOR_TP_CD COLLECTOR_TP_CD, r.BANK_ACCOUNT_TP_CD BANK_ACCOUNT_TP_CD, r.EXT_TERMS_BY_SHIPDATE_IND EXT_TERMS_BY_SHIPDATE_IND, r.SETTLEMENT_DISC_IND SETTLEMENT_DISC_IND, r.ACCOUNT_DETAILS ACCOUNT_DETAILS, r.DISC_GRACE_DAYS_TP_CD DISC_GRACE_DAYS_TP_CD, r.PAYMENT_METHOD_TP_CD PAYMENT_METHOD_TP_CD, r.LMAA_NUM LMAA_NUM, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_MTT_ACCOUNT_FINANCIAL r WHERE r.H_MTT_ACT_FINANCIAL_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (MTT_ACCOUNT_FINANCIAL => com.metcash.db.custom.entityObject.EObjMTTActFinancial, H_MTT_ACCOUNT_FINANCIAL => com.metcash.db.custom.entityObject.EObjMTTActFinancial)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjMTTActFinancial>> getMTTActFinancialHistory (Object[] parameters)
  {
    return queryIterator (getMTTActFinancialHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getMTTActFinancialHistoryStatementDescriptor = createStatementDescriptor (
    "getMTTActFinancialHistory(Object[])",
    "SELECT r.H_MTT_ACT_FINANCIAL_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.MTT_ACT_FINANCIAL_ID MTT_ACT_FINANCIAL_ID, r.CONTRACT_ID CONTRACT_ID, r.STATEMENT_MODE_TP_CD STATEMENT_MODE_TP_CD, r.DUE_GRACE_DAYS_TP_CD DUE_GRACE_DAYS_TP_CD, r.TOBACCO_GRACE_DAYS_TP_CD TOBACCO_GRACE_DAYS_TP_CD, r.BANK_TP_CD BANK_TP_CD, r.BPAY_IND BPAY_IND, r.STATEMENT_PRN_HOLD_IND STATEMENT_PRN_HOLD_IND, r.BPAY_CUS_REF_NUM BPAY_CUS_REF_NUM, r.COLLECTOR_TP_CD COLLECTOR_TP_CD, r.BANK_ACCOUNT_TP_CD BANK_ACCOUNT_TP_CD, r.EXT_TERMS_BY_SHIPDATE_IND EXT_TERMS_BY_SHIPDATE_IND, r.SETTLEMENT_DISC_IND SETTLEMENT_DISC_IND, r.ACCOUNT_DETAILS ACCOUNT_DETAILS, r.DISC_GRACE_DAYS_TP_CD DISC_GRACE_DAYS_TP_CD, r.PAYMENT_METHOD_TP_CD PAYMENT_METHOD_TP_CD, r.LMAA_NUM LMAA_NUM, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_MTT_ACCOUNT_FINANCIAL r WHERE r.H_MTT_ACT_FINANCIAL_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "mtt_act_financial_id", "contract_id", "statement_mode_tp_cd", "due_grace_days_tp_cd", "tobacco_grace_days_tp_cd", "bank_tp_cd", "bpay_ind", "statement_prn_hold_ind", "bpay_cus_ref_num", "collector_tp_cd", "bank_account_tp_cd", "ext_terms_by_shipdate_ind", "settlement_disc_ind", "account_details", "disc_grace_days_tp_cd", "payment_method_tp_cd", "lmaa_num", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetMTTActFinancialHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetMTTActFinancialHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 19, 19, 19, 19, 19, 1, 1, 10, 19, 19, 1, 1, 250, 19, 19, 100, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class GetMTTActFinancialHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetMTTActFinancialHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjMTTActFinancial>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjMTTActFinancial> handle (java.sql.ResultSet rs, ResultQueue1<EObjMTTActFinancial> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjMTTActFinancial> ();

      EObjMTTActFinancial returnObject1 = new EObjMTTActFinancial ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setMTTActFinancialIdPk(getLongObject (rs, 6)); 
      returnObject1.setContractId(getLongObject (rs, 7)); 
      returnObject1.setStatementMode(getLongObject (rs, 8)); 
      returnObject1.setDueGraceDays(getLongObject (rs, 9)); 
      returnObject1.setTobaccoGraceDays(getLongObject (rs, 10)); 
      returnObject1.setBank(getLongObject (rs, 11)); 
      returnObject1.setBPAYInd(getString (rs, 12)); 
      returnObject1.setStatementPrintHoldInd(getString (rs, 13)); 
      returnObject1.setBPAYCustomerRefNumber(getIntObject (rs, 14)); 
      returnObject1.setCollector(getLongObject (rs, 15)); 
      returnObject1.setBankAccount(getLongObject (rs, 16)); 
      returnObject1.setExtTermsByShipDateInd(getString (rs, 17)); 
      returnObject1.setSettlementDiscountInd(getString (rs, 18)); 
      returnObject1.setAccountDetails(getString (rs, 19)); 
      returnObject1.setDiscountGraceDays(getLongObject (rs, 20)); 
      returnObject1.setPaymentMethod(getLongObject (rs, 21)); 
      returnObject1.setLMAANumber(getString (rs, 22)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 23)); 
      returnObject1.setLastUpdateUser(getString (rs, 24)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 25)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.MTT_ACT_FINANCIAL_ID MTT_ACT_FINANCIAL_ID, r.CONTRACT_ID CONTRACT_ID, r.STATEMENT_MODE_TP_CD STATEMENT_MODE_TP_CD, r.DUE_GRACE_DAYS_TP_CD DUE_GRACE_DAYS_TP_CD, r.TOBACCO_GRACE_DAYS_TP_CD TOBACCO_GRACE_DAYS_TP_CD, r.BANK_TP_CD BANK_TP_CD, r.BPAY_IND BPAY_IND, r.STATEMENT_PRN_HOLD_IND STATEMENT_PRN_HOLD_IND, r.BPAY_CUS_REF_NUM BPAY_CUS_REF_NUM, r.COLLECTOR_TP_CD COLLECTOR_TP_CD, r.BANK_ACCOUNT_TP_CD BANK_ACCOUNT_TP_CD, r.EXT_TERMS_BY_SHIPDATE_IND EXT_TERMS_BY_SHIPDATE_IND, r.SETTLEMENT_DISC_IND SETTLEMENT_DISC_IND, r.ACCOUNT_DETAILS ACCOUNT_DETAILS, r.DISC_GRACE_DAYS_TP_CD DISC_GRACE_DAYS_TP_CD, r.PAYMENT_METHOD_TP_CD PAYMENT_METHOD_TP_CD, r.LMAA_NUM LMAA_NUM, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM MTT_ACCOUNT_FINANCIAL r WHERE r.CONTRACT_ID = ? ", pattern="tableAlias (MTT_ACCOUNT_FINANCIAL => com.metcash.db.custom.entityObject.EObjMTTActFinancial, H_MTT_ACCOUNT_FINANCIAL => com.metcash.db.custom.entityObject.EObjMTTActFinancial)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjMTTActFinancial>> getAllMTTActFinancialbyID (Object[] parameters)
  {
    return queryIterator (getAllMTTActFinancialbyIDStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getAllMTTActFinancialbyIDStatementDescriptor = createStatementDescriptor (
    "getAllMTTActFinancialbyID(Object[])",
    "SELECT r.MTT_ACT_FINANCIAL_ID MTT_ACT_FINANCIAL_ID, r.CONTRACT_ID CONTRACT_ID, r.STATEMENT_MODE_TP_CD STATEMENT_MODE_TP_CD, r.DUE_GRACE_DAYS_TP_CD DUE_GRACE_DAYS_TP_CD, r.TOBACCO_GRACE_DAYS_TP_CD TOBACCO_GRACE_DAYS_TP_CD, r.BANK_TP_CD BANK_TP_CD, r.BPAY_IND BPAY_IND, r.STATEMENT_PRN_HOLD_IND STATEMENT_PRN_HOLD_IND, r.BPAY_CUS_REF_NUM BPAY_CUS_REF_NUM, r.COLLECTOR_TP_CD COLLECTOR_TP_CD, r.BANK_ACCOUNT_TP_CD BANK_ACCOUNT_TP_CD, r.EXT_TERMS_BY_SHIPDATE_IND EXT_TERMS_BY_SHIPDATE_IND, r.SETTLEMENT_DISC_IND SETTLEMENT_DISC_IND, r.ACCOUNT_DETAILS ACCOUNT_DETAILS, r.DISC_GRACE_DAYS_TP_CD DISC_GRACE_DAYS_TP_CD, r.PAYMENT_METHOD_TP_CD PAYMENT_METHOD_TP_CD, r.LMAA_NUM LMAA_NUM, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM MTT_ACCOUNT_FINANCIAL r WHERE r.CONTRACT_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"mtt_act_financial_id", "contract_id", "statement_mode_tp_cd", "due_grace_days_tp_cd", "tobacco_grace_days_tp_cd", "bank_tp_cd", "bpay_ind", "statement_prn_hold_ind", "bpay_cus_ref_num", "collector_tp_cd", "bank_account_tp_cd", "ext_terms_by_shipdate_ind", "settlement_disc_ind", "account_details", "disc_grace_days_tp_cd", "payment_method_tp_cd", "lmaa_num", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetAllMTTActFinancialbyIDParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetAllMTTActFinancialbyIDRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 19, 19, 19, 1, 1, 10, 19, 19, 1, 1, 250, 19, 19, 100, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class GetAllMTTActFinancialbyIDParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetAllMTTActFinancialbyIDRowHandler extends BaseRowHandler<ResultQueue1<EObjMTTActFinancial>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjMTTActFinancial> handle (java.sql.ResultSet rs, ResultQueue1<EObjMTTActFinancial> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjMTTActFinancial> ();

      EObjMTTActFinancial returnObject1 = new EObjMTTActFinancial ();
      returnObject1.setMTTActFinancialIdPk(getLongObject (rs, 1)); 
      returnObject1.setContractId(getLongObject (rs, 2)); 
      returnObject1.setStatementMode(getLongObject (rs, 3)); 
      returnObject1.setDueGraceDays(getLongObject (rs, 4)); 
      returnObject1.setTobaccoGraceDays(getLongObject (rs, 5)); 
      returnObject1.setBank(getLongObject (rs, 6)); 
      returnObject1.setBPAYInd(getString (rs, 7)); 
      returnObject1.setStatementPrintHoldInd(getString (rs, 8)); 
      returnObject1.setBPAYCustomerRefNumber(getIntObject (rs, 9)); 
      returnObject1.setCollector(getLongObject (rs, 10)); 
      returnObject1.setBankAccount(getLongObject (rs, 11)); 
      returnObject1.setExtTermsByShipDateInd(getString (rs, 12)); 
      returnObject1.setSettlementDiscountInd(getString (rs, 13)); 
      returnObject1.setAccountDetails(getString (rs, 14)); 
      returnObject1.setDiscountGraceDays(getLongObject (rs, 15)); 
      returnObject1.setPaymentMethod(getLongObject (rs, 16)); 
      returnObject1.setLMAANumber(getString (rs, 17)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 18)); 
      returnObject1.setLastUpdateUser(getString (rs, 19)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 20)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

  /**
   * @Select( sql="SELECT r.H_MTT_ACT_FINANCIAL_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.MTT_ACT_FINANCIAL_ID MTT_ACT_FINANCIAL_ID, r.CONTRACT_ID CONTRACT_ID, r.STATEMENT_MODE_TP_CD STATEMENT_MODE_TP_CD, r.DUE_GRACE_DAYS_TP_CD DUE_GRACE_DAYS_TP_CD, r.TOBACCO_GRACE_DAYS_TP_CD TOBACCO_GRACE_DAYS_TP_CD, r.BANK_TP_CD BANK_TP_CD, r.BPAY_IND BPAY_IND, r.STATEMENT_PRN_HOLD_IND STATEMENT_PRN_HOLD_IND, r.BPAY_CUS_REF_NUM BPAY_CUS_REF_NUM, r.COLLECTOR_TP_CD COLLECTOR_TP_CD, r.BANK_ACCOUNT_TP_CD BANK_ACCOUNT_TP_CD, r.EXT_TERMS_BY_SHIPDATE_IND EXT_TERMS_BY_SHIPDATE_IND, r.SETTLEMENT_DISC_IND SETTLEMENT_DISC_IND, r.ACCOUNT_DETAILS ACCOUNT_DETAILS, r.DISC_GRACE_DAYS_TP_CD DISC_GRACE_DAYS_TP_CD, r.PAYMENT_METHOD_TP_CD PAYMENT_METHOD_TP_CD, r.LMAA_NUM LMAA_NUM, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_MTT_ACCOUNT_FINANCIAL r WHERE r.CONTRACT_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))", pattern="tableAlias (MTT_ACCOUNT_FINANCIAL => com.metcash.db.custom.entityObject.EObjMTTActFinancial, H_MTT_ACCOUNT_FINANCIAL => com.metcash.db.custom.entityObject.EObjMTTActFinancial)" )
   * 
   * @generated
   */
  public Iterator<ResultQueue1<EObjMTTActFinancial>> getAllMTTActFinancialbyIDHistory (Object[] parameters)
  {
    return queryIterator (getAllMTTActFinancialbyIDHistoryStatementDescriptor, parameters);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getAllMTTActFinancialbyIDHistoryStatementDescriptor = createStatementDescriptor (
    "getAllMTTActFinancialbyIDHistory(Object[])",
    "SELECT r.H_MTT_ACT_FINANCIAL_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.MTT_ACT_FINANCIAL_ID MTT_ACT_FINANCIAL_ID, r.CONTRACT_ID CONTRACT_ID, r.STATEMENT_MODE_TP_CD STATEMENT_MODE_TP_CD, r.DUE_GRACE_DAYS_TP_CD DUE_GRACE_DAYS_TP_CD, r.TOBACCO_GRACE_DAYS_TP_CD TOBACCO_GRACE_DAYS_TP_CD, r.BANK_TP_CD BANK_TP_CD, r.BPAY_IND BPAY_IND, r.STATEMENT_PRN_HOLD_IND STATEMENT_PRN_HOLD_IND, r.BPAY_CUS_REF_NUM BPAY_CUS_REF_NUM, r.COLLECTOR_TP_CD COLLECTOR_TP_CD, r.BANK_ACCOUNT_TP_CD BANK_ACCOUNT_TP_CD, r.EXT_TERMS_BY_SHIPDATE_IND EXT_TERMS_BY_SHIPDATE_IND, r.SETTLEMENT_DISC_IND SETTLEMENT_DISC_IND, r.ACCOUNT_DETAILS ACCOUNT_DETAILS, r.DISC_GRACE_DAYS_TP_CD DISC_GRACE_DAYS_TP_CD, r.PAYMENT_METHOD_TP_CD PAYMENT_METHOD_TP_CD, r.LMAA_NUM LMAA_NUM, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_MTT_ACCOUNT_FINANCIAL r WHERE r.CONTRACT_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"historyidpk", "h_action_code", "h_created_by", "h_create_dt", "h_end_dt", "mtt_act_financial_id", "contract_id", "statement_mode_tp_cd", "due_grace_days_tp_cd", "tobacco_grace_days_tp_cd", "bank_tp_cd", "bpay_ind", "statement_prn_hold_ind", "bpay_cus_ref_num", "collector_tp_cd", "bank_account_tp_cd", "ext_terms_by_shipdate_ind", "settlement_disc_ind", "account_details", "disc_grace_days_tp_cd", "payment_method_tp_cd", "lmaa_num", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetAllMTTActFinancialbyIDHistoryParameterHandler (),
    new int[][]{{Types.BIGINT, Types.TIMESTAMP, Types.TIMESTAMP}, {19, 0, 0}, {0, 0, 0}, {1, 1, 1}},
    null,
    new GetAllMTTActFinancialbyIDHistoryRowHandler (),
    new int[][]{ {Types.BIGINT, Types.CHAR, Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 1, 20, 0, 0, 19, 19, 19, 19, 19, 19, 1, 1, 10, 19, 19, 1, 1, 250, 19, 19, 100, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class GetAllMTTActFinancialbyIDHistoryParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setObject (stmt, 1, Types.BIGINT, parameters[0], 0);
      setObject (stmt, 2, Types.TIMESTAMP, parameters[1], 0);
      setObject (stmt, 3, Types.TIMESTAMP, parameters[2], 0);
    }
  }

  /**
   * @generated
   */
  public static class GetAllMTTActFinancialbyIDHistoryRowHandler extends BaseRowHandler<ResultQueue1<EObjMTTActFinancial>>
  {
    /**
     * @generated
     */
    public ResultQueue1<EObjMTTActFinancial> handle (java.sql.ResultSet rs, ResultQueue1<EObjMTTActFinancial> returnObject) throws java.sql.SQLException
    {
      returnObject = new ResultQueue1<EObjMTTActFinancial> ();

      EObjMTTActFinancial returnObject1 = new EObjMTTActFinancial ();
      returnObject1.setHistoryIdPK(getLongObject (rs, 1)); 
      returnObject1.setHistActionCode(getString (rs, 2)); 
      returnObject1.setHistCreatedBy(getString (rs, 3)); 
      returnObject1.setHistCreateDt(getTimestamp (rs, 4)); 
      returnObject1.setHistEndDt(getTimestamp (rs, 5)); 
      returnObject1.setMTTActFinancialIdPk(getLongObject (rs, 6)); 
      returnObject1.setContractId(getLongObject (rs, 7)); 
      returnObject1.setStatementMode(getLongObject (rs, 8)); 
      returnObject1.setDueGraceDays(getLongObject (rs, 9)); 
      returnObject1.setTobaccoGraceDays(getLongObject (rs, 10)); 
      returnObject1.setBank(getLongObject (rs, 11)); 
      returnObject1.setBPAYInd(getString (rs, 12)); 
      returnObject1.setStatementPrintHoldInd(getString (rs, 13)); 
      returnObject1.setBPAYCustomerRefNumber(getIntObject (rs, 14)); 
      returnObject1.setCollector(getLongObject (rs, 15)); 
      returnObject1.setBankAccount(getLongObject (rs, 16)); 
      returnObject1.setExtTermsByShipDateInd(getString (rs, 17)); 
      returnObject1.setSettlementDiscountInd(getString (rs, 18)); 
      returnObject1.setAccountDetails(getString (rs, 19)); 
      returnObject1.setDiscountGraceDays(getLongObject (rs, 20)); 
      returnObject1.setPaymentMethod(getLongObject (rs, 21)); 
      returnObject1.setLMAANumber(getString (rs, 22)); 
      returnObject1.setLastUpdateDt(getTimestamp (rs, 23)); 
      returnObject1.setLastUpdateUser(getString (rs, 24)); 
      returnObject1.setLastUpdateTxId(getLongObject (rs, 25)); 
      returnObject.add (returnObject1);

    
      return returnObject;
    }
  }

}
