/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[063dded589ba05f63f6e953251ec0978]
 */

package com.metcash.db.custom.entityObject;

import com.dwl.base.EObjCommon;
import com.ibm.mdm.base.db.DataType;
import com.ibm.pdq.annotation.Column;
import com.ibm.pdq.annotation.Table;


import com.ibm.pdq.annotation.Id;

import java.sql.Timestamp;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * The entity object corresponding to the MTTActCreditTax business object. This
 * entity object should include all the attributes as defined by the business
 * object.
 * 
 * @generated
 */
@SuppressWarnings("serial")
@Table(name=EObjMTTActCreditTax.tableName)
public class EObjMTTActCreditTax extends EObjCommon {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public static final String tableName = "MTT_ACCOUNT_CREDIT_TAX";
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String mTTActCreditTaxIdPkColumn = "MTT_ACT_CREDIT_TAX_ID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String mTTActCreditTaxIdPkJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    mTTActCreditTaxIdPkPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String contractIdColumn = "CONTRACT_ID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String contractIdJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    contractIdPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String invoiceTermsColumn = "INV_TERMS_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String invoiceTermsJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    invoiceTermsPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String gSTExemptIndColumn = "GST_EXEMPT_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String gSTExemptIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    gSTExemptIndPrecision = 1;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String customerGroupColumn = "CUS_GRP_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String customerGroupJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    customerGroupPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String bankGuaranteeAmountColumn = "BANK_GUARANTEE_AMT";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String bankGuaranteeAmountJdbcType = "REAL";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String bankGuaranteeEndDateColumn = "BANK_GUARANTEE_END_DT";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String bankGuaranteeEndDateJdbcType = "TIMESTAMP";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String cashDepositAmountColumn = "CASH_DEPOSIT_AMT";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String cashDepositAmountJdbcType = "REAL";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String cashDepositRecieveDateColumn = "CASH_DEPOSIT_RECV_DT";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String cashDepositRecieveDateJdbcType = "TIMESTAMP";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String cashDepositReleaseDateColumn = "CASH_DEPOSIT_REL_DT";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String cashDepositReleaseDateJdbcType = "TIMESTAMP";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String firstMortgageColumn = "FIRST_MORTGAGE";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String firstMortgageJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    firstMortgagePrecision = 250;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String secondMortgageColumn = "SECOND_MORTGAGE";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String secondMortgageJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    secondMortgagePrecision = 250;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String deedOfPriorityColumn = "DEED_OF_PRIORITY";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String deedOfPriorityJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    deedOfPriorityPrecision = 250;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String pPSRDetailsColumn = "PPSR_DETAILS";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String pPSRDetailsJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    pPSRDetailsPrecision = 250;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String pMSIDetailsColumn = "PMSI_DETAILS";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String pMSIDetailsJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    pMSIDetailsPrecision = 250;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String aLLPAPDetailsColumn = "ALLPAP_DETAILS";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String aLLPAPDetailsJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    aLLPAPDetailsPrecision = 250;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String arrearsColumn = "ARREARS";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String arrearsJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    arrearsPrecision = 50;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String creditHoldColumn = "CREDIT_HOLD";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String creditHoldJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    creditHoldPrecision = 50;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String nationalHoldColumn = "NATIONAL_HOLD";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String nationalHoldJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    nationalHoldPrecision = 50;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String creditHoldDateColumn = "CREDIT_HOLD_DT";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String creditHoldDateJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    creditHoldDatePrecision = 250;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String creditStatusOverrideColumn = "CREDIT_STATUS_OVERRIDE";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String creditStatusOverrideJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    creditStatusOverridePrecision = 50;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String chequeLimitAmountColumn = "CHEQUE_LIMIT_AMT";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String chequeLimitAmountJdbcType = "REAL";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String chequeLimitCurrencyColumn = "CHEQUE_LIMIT_CURRENCY_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String chequeLimitCurrencyJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    chequeLimitCurrencyPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String wETExemptIndColumn = "WET_EXEMPT_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String wETExemptIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    wETExemptIndPrecision = 1;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String dutyFreeIndColumn = "DUTY_FREE_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String dutyFreeIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    dutyFreeIndPrecision = 1;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String cashOnDeliveryIndColumn = "CASH_ON_DELIVERY_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String cashOnDeliveryIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    cashOnDeliveryIndPrecision = 1;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String salesRepColumn = "SALES_REP_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String salesRepJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    salesRepPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long mTTActCreditTaxIdPk;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long contractId;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long invoiceTerms;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String gSTExemptInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long customerGroup;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Float bankGuaranteeAmount;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected  Timestamp bankGuaranteeEndDate;
    //inside if 

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Float cashDepositAmount;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected  Timestamp cashDepositRecieveDate;
    //inside if 

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected  Timestamp cashDepositReleaseDate;
    //inside if 

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String firstMortgage;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String secondMortgage;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String deedOfPriority;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String pPSRDetails;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String pMSIDetails;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String aLLPAPDetails;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String arrears;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String creditHold;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String nationalHold;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String creditHoldDate;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String creditStatusOverride;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Float chequeLimitAmount;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long chequeLimitCurrency;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String wETExemptInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String dutyFreeInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String cashOnDeliveryInd;



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long salesRep;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Default constructor.     
     *
     * @generated
     */
    public EObjMTTActCreditTax() {
        super();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the mTTActCreditTaxIdPk attribute. 
     *
     * @generated
     */
    @Id
    @Column(name=mTTActCreditTaxIdPkColumn)
    @DataType(jdbcType=mTTActCreditTaxIdPkJdbcType, precision=mTTActCreditTaxIdPkPrecision)
    public Long getMTTActCreditTaxIdPk (){
        return mTTActCreditTaxIdPk;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the mTTActCreditTaxIdPk attribute. 
     *
     * @param mTTActCreditTaxIdPk
     *     The new value of MTTActCreditTaxIdPk. 
     * @generated
     */
    public void setMTTActCreditTaxIdPk( Long mTTActCreditTaxIdPk ){
        this.mTTActCreditTaxIdPk = mTTActCreditTaxIdPk;
    
        super.setIdPK(mTTActCreditTaxIdPk);
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contractId attribute. 
     *
     * @generated
     */
    @Column(name=contractIdColumn)
    @DataType(jdbcType=contractIdJdbcType, precision=contractIdPrecision)
    public Long getContractId (){
        return contractId;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contractId attribute. 
     *
     * @param contractId
     *     The new value of ContractId. 
     * @generated
     */
    public void setContractId( Long contractId ){
        this.contractId = contractId;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the invoiceTerms attribute. 
     *
     * @generated
     */
    @Column(name=invoiceTermsColumn)
    @DataType(jdbcType=invoiceTermsJdbcType, precision=invoiceTermsPrecision)
    public Long getInvoiceTerms (){
        return invoiceTerms;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the invoiceTerms attribute. 
     *
     * @param invoiceTerms
     *     The new value of InvoiceTerms. 
     * @generated
     */
    public void setInvoiceTerms( Long invoiceTerms ){
        this.invoiceTerms = invoiceTerms;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the gSTExemptInd attribute. 
     *
     * @generated
     */
    @Column(name=gSTExemptIndColumn)
    @DataType(jdbcType=gSTExemptIndJdbcType, precision=gSTExemptIndPrecision)
    public String getGSTExemptInd (){
        return gSTExemptInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the gSTExemptInd attribute. 
     *
     * @param gSTExemptInd
     *     The new value of GSTExemptInd. 
     * @generated
     */
    public void setGSTExemptInd( String gSTExemptInd ){
        this.gSTExemptInd = gSTExemptInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the customerGroup attribute. 
     *
     * @generated
     */
    @Column(name=customerGroupColumn)
    @DataType(jdbcType=customerGroupJdbcType, precision=customerGroupPrecision)
    public Long getCustomerGroup (){
        return customerGroup;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the customerGroup attribute. 
     *
     * @param customerGroup
     *     The new value of CustomerGroup. 
     * @generated
     */
    public void setCustomerGroup( Long customerGroup ){
        this.customerGroup = customerGroup;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the bankGuaranteeAmount attribute. 
     *
     * @generated
     */
    @Column(name=bankGuaranteeAmountColumn)
    @DataType(jdbcType=bankGuaranteeAmountJdbcType)
    public Float getBankGuaranteeAmount (){
        return bankGuaranteeAmount;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the bankGuaranteeAmount attribute. 
     *
     * @param bankGuaranteeAmount
     *     The new value of BankGuaranteeAmount. 
     * @generated
     */
    public void setBankGuaranteeAmount( Float bankGuaranteeAmount ){
        this.bankGuaranteeAmount = bankGuaranteeAmount;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the bankGuaranteeEndDate attribute. 
     *
     * @generated
     */
    @Column(name=bankGuaranteeEndDateColumn)
    @DataType(jdbcType=bankGuaranteeEndDateJdbcType)
    public Timestamp getBankGuaranteeEndDate (){
        return bankGuaranteeEndDate;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the bankGuaranteeEndDate attribute. 
     *
     * @param bankGuaranteeEndDate
     *     The new value of BankGuaranteeEndDate. 
     * @generated
     */
    public void setBankGuaranteeEndDate( Timestamp bankGuaranteeEndDate ){
        this.bankGuaranteeEndDate = bankGuaranteeEndDate;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the cashDepositAmount attribute. 
     *
     * @generated
     */
    @Column(name=cashDepositAmountColumn)
    @DataType(jdbcType=cashDepositAmountJdbcType)
    public Float getCashDepositAmount (){
        return cashDepositAmount;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the cashDepositAmount attribute. 
     *
     * @param cashDepositAmount
     *     The new value of CashDepositAmount. 
     * @generated
     */
    public void setCashDepositAmount( Float cashDepositAmount ){
        this.cashDepositAmount = cashDepositAmount;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the cashDepositRecieveDate attribute. 
     *
     * @generated
     */
    @Column(name=cashDepositRecieveDateColumn)
    @DataType(jdbcType=cashDepositRecieveDateJdbcType)
    public Timestamp getCashDepositRecieveDate (){
        return cashDepositRecieveDate;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the cashDepositRecieveDate attribute. 
     *
     * @param cashDepositRecieveDate
     *     The new value of CashDepositRecieveDate. 
     * @generated
     */
    public void setCashDepositRecieveDate( Timestamp cashDepositRecieveDate ){
        this.cashDepositRecieveDate = cashDepositRecieveDate;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the cashDepositReleaseDate attribute. 
     *
     * @generated
     */
    @Column(name=cashDepositReleaseDateColumn)
    @DataType(jdbcType=cashDepositReleaseDateJdbcType)
    public Timestamp getCashDepositReleaseDate (){
        return cashDepositReleaseDate;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the cashDepositReleaseDate attribute. 
     *
     * @param cashDepositReleaseDate
     *     The new value of CashDepositReleaseDate. 
     * @generated
     */
    public void setCashDepositReleaseDate( Timestamp cashDepositReleaseDate ){
        this.cashDepositReleaseDate = cashDepositReleaseDate;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the firstMortgage attribute. 
     *
     * @generated
     */
    @Column(name=firstMortgageColumn)
    @DataType(jdbcType=firstMortgageJdbcType, precision=firstMortgagePrecision)
    public String getFirstMortgage (){
        return firstMortgage;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the firstMortgage attribute. 
     *
     * @param firstMortgage
     *     The new value of FirstMortgage. 
     * @generated
     */
    public void setFirstMortgage( String firstMortgage ){
        this.firstMortgage = firstMortgage;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the secondMortgage attribute. 
     *
     * @generated
     */
    @Column(name=secondMortgageColumn)
    @DataType(jdbcType=secondMortgageJdbcType, precision=secondMortgagePrecision)
    public String getSecondMortgage (){
        return secondMortgage;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the secondMortgage attribute. 
     *
     * @param secondMortgage
     *     The new value of SecondMortgage. 
     * @generated
     */
    public void setSecondMortgage( String secondMortgage ){
        this.secondMortgage = secondMortgage;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the deedOfPriority attribute. 
     *
     * @generated
     */
    @Column(name=deedOfPriorityColumn)
    @DataType(jdbcType=deedOfPriorityJdbcType, precision=deedOfPriorityPrecision)
    public String getDeedOfPriority (){
        return deedOfPriority;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the deedOfPriority attribute. 
     *
     * @param deedOfPriority
     *     The new value of DeedOfPriority. 
     * @generated
     */
    public void setDeedOfPriority( String deedOfPriority ){
        this.deedOfPriority = deedOfPriority;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the pPSRDetails attribute. 
     *
     * @generated
     */
    @Column(name=pPSRDetailsColumn)
    @DataType(jdbcType=pPSRDetailsJdbcType, precision=pPSRDetailsPrecision)
    public String getPPSRDetails (){
        return pPSRDetails;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the pPSRDetails attribute. 
     *
     * @param pPSRDetails
     *     The new value of PPSRDetails. 
     * @generated
     */
    public void setPPSRDetails( String pPSRDetails ){
        this.pPSRDetails = pPSRDetails;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the pMSIDetails attribute. 
     *
     * @generated
     */
    @Column(name=pMSIDetailsColumn)
    @DataType(jdbcType=pMSIDetailsJdbcType, precision=pMSIDetailsPrecision)
    public String getPMSIDetails (){
        return pMSIDetails;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the pMSIDetails attribute. 
     *
     * @param pMSIDetails
     *     The new value of PMSIDetails. 
     * @generated
     */
    public void setPMSIDetails( String pMSIDetails ){
        this.pMSIDetails = pMSIDetails;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the aLLPAPDetails attribute. 
     *
     * @generated
     */
    @Column(name=aLLPAPDetailsColumn)
    @DataType(jdbcType=aLLPAPDetailsJdbcType, precision=aLLPAPDetailsPrecision)
    public String getALLPAPDetails (){
        return aLLPAPDetails;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the aLLPAPDetails attribute. 
     *
     * @param aLLPAPDetails
     *     The new value of ALLPAPDetails. 
     * @generated
     */
    public void setALLPAPDetails( String aLLPAPDetails ){
        this.aLLPAPDetails = aLLPAPDetails;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the arrears attribute. 
     *
     * @generated
     */
    @Column(name=arrearsColumn)
    @DataType(jdbcType=arrearsJdbcType, precision=arrearsPrecision)
    public String getArrears (){
        return arrears;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the arrears attribute. 
     *
     * @param arrears
     *     The new value of Arrears. 
     * @generated
     */
    public void setArrears( String arrears ){
        this.arrears = arrears;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the creditHold attribute. 
     *
     * @generated
     */
    @Column(name=creditHoldColumn)
    @DataType(jdbcType=creditHoldJdbcType, precision=creditHoldPrecision)
    public String getCreditHold (){
        return creditHold;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the creditHold attribute. 
     *
     * @param creditHold
     *     The new value of CreditHold. 
     * @generated
     */
    public void setCreditHold( String creditHold ){
        this.creditHold = creditHold;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the nationalHold attribute. 
     *
     * @generated
     */
    @Column(name=nationalHoldColumn)
    @DataType(jdbcType=nationalHoldJdbcType, precision=nationalHoldPrecision)
    public String getNationalHold (){
        return nationalHold;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the nationalHold attribute. 
     *
     * @param nationalHold
     *     The new value of NationalHold. 
     * @generated
     */
    public void setNationalHold( String nationalHold ){
        this.nationalHold = nationalHold;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the creditHoldDate attribute. 
     *
     * @generated
     */
    @Column(name=creditHoldDateColumn)
    @DataType(jdbcType=creditHoldDateJdbcType, precision=creditHoldDatePrecision)
    public String getCreditHoldDate (){
        return creditHoldDate;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the creditHoldDate attribute. 
     *
     * @param creditHoldDate
     *     The new value of CreditHoldDate. 
     * @generated
     */
    public void setCreditHoldDate( String creditHoldDate ){
        this.creditHoldDate = creditHoldDate;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the creditStatusOverride attribute. 
     *
     * @generated
     */
    @Column(name=creditStatusOverrideColumn)
    @DataType(jdbcType=creditStatusOverrideJdbcType, precision=creditStatusOverridePrecision)
    public String getCreditStatusOverride (){
        return creditStatusOverride;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the creditStatusOverride attribute. 
     *
     * @param creditStatusOverride
     *     The new value of CreditStatusOverride. 
     * @generated
     */
    public void setCreditStatusOverride( String creditStatusOverride ){
        this.creditStatusOverride = creditStatusOverride;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the chequeLimitAmount attribute. 
     *
     * @generated
     */
    @Column(name=chequeLimitAmountColumn)
    @DataType(jdbcType=chequeLimitAmountJdbcType)
    public Float getChequeLimitAmount (){
        return chequeLimitAmount;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the chequeLimitAmount attribute. 
     *
     * @param chequeLimitAmount
     *     The new value of ChequeLimitAmount. 
     * @generated
     */
    public void setChequeLimitAmount( Float chequeLimitAmount ){
        this.chequeLimitAmount = chequeLimitAmount;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the chequeLimitCurrency attribute. 
     *
     * @generated
     */
    @Column(name=chequeLimitCurrencyColumn)
    @DataType(jdbcType=chequeLimitCurrencyJdbcType, precision=chequeLimitCurrencyPrecision)
    public Long getChequeLimitCurrency (){
        return chequeLimitCurrency;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the chequeLimitCurrency attribute. 
     *
     * @param chequeLimitCurrency
     *     The new value of ChequeLimitCurrency. 
     * @generated
     */
    public void setChequeLimitCurrency( Long chequeLimitCurrency ){
        this.chequeLimitCurrency = chequeLimitCurrency;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the wETExemptInd attribute. 
     *
     * @generated
     */
    @Column(name=wETExemptIndColumn)
    @DataType(jdbcType=wETExemptIndJdbcType, precision=wETExemptIndPrecision)
    public String getWETExemptInd (){
        return wETExemptInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the wETExemptInd attribute. 
     *
     * @param wETExemptInd
     *     The new value of WETExemptInd. 
     * @generated
     */
    public void setWETExemptInd( String wETExemptInd ){
        this.wETExemptInd = wETExemptInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the dutyFreeInd attribute. 
     *
     * @generated
     */
    @Column(name=dutyFreeIndColumn)
    @DataType(jdbcType=dutyFreeIndJdbcType, precision=dutyFreeIndPrecision)
    public String getDutyFreeInd (){
        return dutyFreeInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the dutyFreeInd attribute. 
     *
     * @param dutyFreeInd
     *     The new value of DutyFreeInd. 
     * @generated
     */
    public void setDutyFreeInd( String dutyFreeInd ){
        this.dutyFreeInd = dutyFreeInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the cashOnDeliveryInd attribute. 
     *
     * @generated
     */
    @Column(name=cashOnDeliveryIndColumn)
    @DataType(jdbcType=cashOnDeliveryIndJdbcType, precision=cashOnDeliveryIndPrecision)
    public String getCashOnDeliveryInd (){
        return cashOnDeliveryInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the cashOnDeliveryInd attribute. 
     *
     * @param cashOnDeliveryInd
     *     The new value of CashOnDeliveryInd. 
     * @generated
     */
    public void setCashOnDeliveryInd( String cashOnDeliveryInd ){
        this.cashOnDeliveryInd = cashOnDeliveryInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the salesRep attribute. 
     *
     * @generated
     */
    @Column(name=salesRepColumn)
    @DataType(jdbcType=salesRepJdbcType, precision=salesRepPrecision)
    public Long getSalesRep (){
        return salesRep;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the salesRep attribute. 
     *
     * @param salesRep
     *     The new value of SalesRep. 
     * @generated
     */
    public void setSalesRep( Long salesRep ){
        this.salesRep = salesRep;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the primary key. 
     *
     * @param aUniqueId
     *     The new value of the primary key. 
     * @generated
   */
	public void setPrimaryKey(Object aUniqueId) {
    this.setMTTActCreditTaxIdPk((Long)aUniqueId);
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the primary key.
     *
     * @generated
     */
	public Object getPrimaryKey() {
    return this.getMTTActCreditTaxIdPk();
  }
	 
}


