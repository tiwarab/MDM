/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[57aaa64b8052fa2e931b9b28af8a3e6b]
 */

package com.metcash.db.custom.entityObject;

import com.dwl.base.EObjCommon;
import com.ibm.mdm.base.db.DataType;
import com.ibm.pdq.annotation.Column;
import com.ibm.pdq.annotation.Table;


import com.ibm.pdq.annotation.Id;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * The entity object corresponding to the MTTActCostCharges business object.
 * This entity object should include all the attributes as defined by the
 * business object.
 * 
 * @generated
 */
@SuppressWarnings("serial")
@Table(name=EObjMTTActCostCharges.tableName)
public class EObjMTTActCostCharges extends EObjCommon {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public static final String tableName = "MTT_ACCOUNT_COST_CHARGES";
    
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String mTTActCostChargesIdPkColumn = "MTT_ACT_COST_CHARGES_ID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String mTTActCostChargesIdPkJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    mTTActCostChargesIdPkPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String contractIdColumn = "CONTRACT_ID";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String contractIdJdbcType = "BIGINT";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    contractIdPrecision = 19;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String costBaseColumn = "COST_BASE_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String costBaseJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    costBasePrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String directShipApprovedIndColumn = "DIRECT_SHIP_APPROVED_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String directShipApprovedIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    directShipApprovedIndPrecision = 1;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String doNotApplyDirectDiscountIndColumn = "DO_NOT_APPLY_DIRECT_DISC_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String doNotApplyDirectDiscountIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    doNotApplyDirectDiscountIndPrecision = 1;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String sRPComplicanceColumn = "SRP_COMPLIANCE_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String sRPComplicanceJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    sRPComplicancePrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String priceMatchGapFeeIndColumn = "PRICE_MATCH_GAP_FEE_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String priceMatchGapFeeIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    priceMatchGapFeeIndPrecision = 1;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String brokenCaseUpchargePercentageColumn = "BRKN_CASE_UPCHARGE_PCT";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String brokenCaseUpchargePercentageJdbcType = "REAL";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String brokenCaseUpchargeCapColumn = "BRKN_CASE_UPCHARGE_CAP";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String brokenCaseUpchargeCapJdbcType = "REAL";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String brokenCaseUpchargeIndColumn = "BRKN_CASE_UPCHARGE_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String brokenCaseUpchargeIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    brokenCaseUpchargeIndPrecision = 1;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String brokenCaseCalColumn = "BRKN_CASE_CALC_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String brokenCaseCalJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    brokenCaseCalPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String shelfLabelPricedIndColumn = "SHELF_LABEL_PRICED_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String shelfLabelPricedIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    shelfLabelPricedIndPrecision = 1;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String pSRPColumn = "PSRP_TP_CD";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String pSRPJdbcType = "BIGINT";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    pSRPPrecision = 19;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String addFRTRecoverySRPIndColumn = "ADD_FRT_RECOVERY_SRP_IND";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String addFRTRecoverySRPIndJdbcType = "VARCHAR";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final int    addFRTRecoverySRPIndPrecision = 1;
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String sRPFRTRecoveryValueColumn = "SRP_FRT_RECOVERY_VAL";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String sRPFRTRecoveryValueJdbcType = "REAL";
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String sRPFRTRecoveryDirectValueColumn = "SRP_FRT_RECOVERY_DIR_VAL";
  
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    private static final String sRPFRTRecoveryDirectValueJdbcType = "REAL";

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long mTTActCostChargesIdPk;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long contractId;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long costBase;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String directShipApprovedInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String doNotApplyDirectDiscountInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long sRPComplicance;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String priceMatchGapFeeInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Float brokenCaseUpchargePercentage;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Float brokenCaseUpchargeCap;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String brokenCaseUpchargeInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long brokenCaseCal;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String shelfLabelPricedInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Long pSRP;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected String addFRTRecoverySRPInd;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Float sRPFRTRecoveryValue;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * 
     * @generated
     */
    protected Float sRPFRTRecoveryDirectValue;



    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Default constructor.     
     *
     * @generated
     */
    public EObjMTTActCostCharges() {
        super();
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the mTTActCostChargesIdPk attribute. 
     *
     * @generated
     */
    @Id
    @Column(name=mTTActCostChargesIdPkColumn)
    @DataType(jdbcType=mTTActCostChargesIdPkJdbcType, precision=mTTActCostChargesIdPkPrecision)
    public Long getMTTActCostChargesIdPk (){
        return mTTActCostChargesIdPk;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the mTTActCostChargesIdPk attribute. 
     *
     * @param mTTActCostChargesIdPk
     *     The new value of MTTActCostChargesIdPk. 
     * @generated
     */
    public void setMTTActCostChargesIdPk( Long mTTActCostChargesIdPk ){
        this.mTTActCostChargesIdPk = mTTActCostChargesIdPk;
    
        super.setIdPK(mTTActCostChargesIdPk);
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the contractId attribute. 
     *
     * @generated
     */
    @Column(name=contractIdColumn)
    @DataType(jdbcType=contractIdJdbcType, precision=contractIdPrecision)
    public Long getContractId (){
        return contractId;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the contractId attribute. 
     *
     * @param contractId
     *     The new value of ContractId. 
     * @generated
     */
    public void setContractId( Long contractId ){
        this.contractId = contractId;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the costBase attribute. 
     *
     * @generated
     */
    @Column(name=costBaseColumn)
    @DataType(jdbcType=costBaseJdbcType, precision=costBasePrecision)
    public Long getCostBase (){
        return costBase;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the costBase attribute. 
     *
     * @param costBase
     *     The new value of CostBase. 
     * @generated
     */
    public void setCostBase( Long costBase ){
        this.costBase = costBase;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the directShipApprovedInd attribute. 
     *
     * @generated
     */
    @Column(name=directShipApprovedIndColumn)
    @DataType(jdbcType=directShipApprovedIndJdbcType, precision=directShipApprovedIndPrecision)
    public String getDirectShipApprovedInd (){
        return directShipApprovedInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the directShipApprovedInd attribute. 
     *
     * @param directShipApprovedInd
     *     The new value of DirectShipApprovedInd. 
     * @generated
     */
    public void setDirectShipApprovedInd( String directShipApprovedInd ){
        this.directShipApprovedInd = directShipApprovedInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the doNotApplyDirectDiscountInd attribute. 
     *
     * @generated
     */
    @Column(name=doNotApplyDirectDiscountIndColumn)
    @DataType(jdbcType=doNotApplyDirectDiscountIndJdbcType, precision=doNotApplyDirectDiscountIndPrecision)
    public String getDoNotApplyDirectDiscountInd (){
        return doNotApplyDirectDiscountInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the doNotApplyDirectDiscountInd attribute. 
     *
     * @param doNotApplyDirectDiscountInd
     *     The new value of DoNotApplyDirectDiscountInd. 
     * @generated
     */
    public void setDoNotApplyDirectDiscountInd( String doNotApplyDirectDiscountInd ){
        this.doNotApplyDirectDiscountInd = doNotApplyDirectDiscountInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sRPComplicance attribute. 
     *
     * @generated
     */
    @Column(name=sRPComplicanceColumn)
    @DataType(jdbcType=sRPComplicanceJdbcType, precision=sRPComplicancePrecision)
    public Long getSRPComplicance (){
        return sRPComplicance;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sRPComplicance attribute. 
     *
     * @param sRPComplicance
     *     The new value of SRPComplicance. 
     * @generated
     */
    public void setSRPComplicance( Long sRPComplicance ){
        this.sRPComplicance = sRPComplicance;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the priceMatchGapFeeInd attribute. 
     *
     * @generated
     */
    @Column(name=priceMatchGapFeeIndColumn)
    @DataType(jdbcType=priceMatchGapFeeIndJdbcType, precision=priceMatchGapFeeIndPrecision)
    public String getPriceMatchGapFeeInd (){
        return priceMatchGapFeeInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the priceMatchGapFeeInd attribute. 
     *
     * @param priceMatchGapFeeInd
     *     The new value of PriceMatchGapFeeInd. 
     * @generated
     */
    public void setPriceMatchGapFeeInd( String priceMatchGapFeeInd ){
        this.priceMatchGapFeeInd = priceMatchGapFeeInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the brokenCaseUpchargePercentage attribute. 
     *
     * @generated
     */
    @Column(name=brokenCaseUpchargePercentageColumn)
    @DataType(jdbcType=brokenCaseUpchargePercentageJdbcType)
    public Float getBrokenCaseUpchargePercentage (){
        return brokenCaseUpchargePercentage;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the brokenCaseUpchargePercentage attribute. 
     *
     * @param brokenCaseUpchargePercentage
     *     The new value of BrokenCaseUpchargePercentage. 
     * @generated
     */
    public void setBrokenCaseUpchargePercentage( Float brokenCaseUpchargePercentage ){
        this.brokenCaseUpchargePercentage = brokenCaseUpchargePercentage;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the brokenCaseUpchargeCap attribute. 
     *
     * @generated
     */
    @Column(name=brokenCaseUpchargeCapColumn)
    @DataType(jdbcType=brokenCaseUpchargeCapJdbcType)
    public Float getBrokenCaseUpchargeCap (){
        return brokenCaseUpchargeCap;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the brokenCaseUpchargeCap attribute. 
     *
     * @param brokenCaseUpchargeCap
     *     The new value of BrokenCaseUpchargeCap. 
     * @generated
     */
    public void setBrokenCaseUpchargeCap( Float brokenCaseUpchargeCap ){
        this.brokenCaseUpchargeCap = brokenCaseUpchargeCap;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the brokenCaseUpchargeInd attribute. 
     *
     * @generated
     */
    @Column(name=brokenCaseUpchargeIndColumn)
    @DataType(jdbcType=brokenCaseUpchargeIndJdbcType, precision=brokenCaseUpchargeIndPrecision)
    public String getBrokenCaseUpchargeInd (){
        return brokenCaseUpchargeInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the brokenCaseUpchargeInd attribute. 
     *
     * @param brokenCaseUpchargeInd
     *     The new value of BrokenCaseUpchargeInd. 
     * @generated
     */
    public void setBrokenCaseUpchargeInd( String brokenCaseUpchargeInd ){
        this.brokenCaseUpchargeInd = brokenCaseUpchargeInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the brokenCaseCal attribute. 
     *
     * @generated
     */
    @Column(name=brokenCaseCalColumn)
    @DataType(jdbcType=brokenCaseCalJdbcType, precision=brokenCaseCalPrecision)
    public Long getBrokenCaseCal (){
        return brokenCaseCal;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the brokenCaseCal attribute. 
     *
     * @param brokenCaseCal
     *     The new value of BrokenCaseCal. 
     * @generated
     */
    public void setBrokenCaseCal( Long brokenCaseCal ){
        this.brokenCaseCal = brokenCaseCal;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the shelfLabelPricedInd attribute. 
     *
     * @generated
     */
    @Column(name=shelfLabelPricedIndColumn)
    @DataType(jdbcType=shelfLabelPricedIndJdbcType, precision=shelfLabelPricedIndPrecision)
    public String getShelfLabelPricedInd (){
        return shelfLabelPricedInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the shelfLabelPricedInd attribute. 
     *
     * @param shelfLabelPricedInd
     *     The new value of ShelfLabelPricedInd. 
     * @generated
     */
    public void setShelfLabelPricedInd( String shelfLabelPricedInd ){
        this.shelfLabelPricedInd = shelfLabelPricedInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the pSRP attribute. 
     *
     * @generated
     */
    @Column(name=pSRPColumn)
    @DataType(jdbcType=pSRPJdbcType, precision=pSRPPrecision)
    public Long getPSRP (){
        return pSRP;
    }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the pSRP attribute. 
     *
     * @param pSRP
     *     The new value of PSRP. 
     * @generated
     */
    public void setPSRP( Long pSRP ){
        this.pSRP = pSRP;
    
  }


    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the addFRTRecoverySRPInd attribute. 
     *
     * @generated
     */
    @Column(name=addFRTRecoverySRPIndColumn)
    @DataType(jdbcType=addFRTRecoverySRPIndJdbcType, precision=addFRTRecoverySRPIndPrecision)
    public String getAddFRTRecoverySRPInd (){
        return addFRTRecoverySRPInd;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the addFRTRecoverySRPInd attribute. 
     *
     * @param addFRTRecoverySRPInd
     *     The new value of AddFRTRecoverySRPInd. 
     * @generated
     */
    public void setAddFRTRecoverySRPInd( String addFRTRecoverySRPInd ){
        this.addFRTRecoverySRPInd = addFRTRecoverySRPInd;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sRPFRTRecoveryValue attribute. 
     *
     * @generated
     */
    @Column(name=sRPFRTRecoveryValueColumn)
    @DataType(jdbcType=sRPFRTRecoveryValueJdbcType)
    public Float getSRPFRTRecoveryValue (){
        return sRPFRTRecoveryValue;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sRPFRTRecoveryValue attribute. 
     *
     * @param sRPFRTRecoveryValue
     *     The new value of SRPFRTRecoveryValue. 
     * @generated
     */
    public void setSRPFRTRecoveryValue( Float sRPFRTRecoveryValue ){
        this.sRPFRTRecoveryValue = sRPFRTRecoveryValue;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the sRPFRTRecoveryDirectValue attribute. 
     *
     * @generated
     */
    @Column(name=sRPFRTRecoveryDirectValueColumn)
    @DataType(jdbcType=sRPFRTRecoveryDirectValueJdbcType)
    public Float getSRPFRTRecoveryDirectValue (){
        return sRPFRTRecoveryDirectValue;
    }
     
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the sRPFRTRecoveryDirectValue attribute. 
     *
     * @param sRPFRTRecoveryDirectValue
     *     The new value of SRPFRTRecoveryDirectValue. 
     * @generated
     */
    public void setSRPFRTRecoveryDirectValue( Float sRPFRTRecoveryDirectValue ){
        this.sRPFRTRecoveryDirectValue = sRPFRTRecoveryDirectValue;
    
  }
	 
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Sets the primary key. 
     *
     * @param aUniqueId
     *     The new value of the primary key. 
     * @generated
   */
	public void setPrimaryKey(Object aUniqueId) {
    this.setMTTActCostChargesIdPk((Long)aUniqueId);
  }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * Gets the primary key.
     *
     * @generated
     */
	public Object getPrimaryKey() {
    return this.getMTTActCostChargesIdPk();
  }
	 
}


