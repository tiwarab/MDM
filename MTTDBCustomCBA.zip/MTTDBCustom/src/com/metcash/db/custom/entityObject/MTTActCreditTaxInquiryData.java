/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[fa06e60974a15e1a28db672b209d280f]
 */

package com.metcash.db.custom.entityObject;


import com.ibm.mdm.base.db.ResultQueue1;
import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface MTTActCreditTaxInquiryData {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String tableAliasString = "tableAlias (" + 
                                            "MTT_ACCOUNT_CREDIT_TAX => com.metcash.db.custom.entityObject.EObjMTTActCreditTax, " +
                                            "H_MTT_ACCOUNT_CREDIT_TAX => com.metcash.db.custom.entityObject.EObjMTTActCreditTax" +
                                            ")";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getMTTActCreditTaxSql = "SELECT r.MTT_ACT_CREDIT_TAX_ID MTT_ACT_CREDIT_TAX_ID, r.CONTRACT_ID CONTRACT_ID, r.INV_TERMS_TP_CD INV_TERMS_TP_CD, r.GST_EXEMPT_IND GST_EXEMPT_IND, r.CUS_GRP_TP_CD CUS_GRP_TP_CD, r.BANK_GUARANTEE_AMT BANK_GUARANTEE_AMT, r.BANK_GUARANTEE_END_DT BANK_GUARANTEE_END_DT, r.CASH_DEPOSIT_AMT CASH_DEPOSIT_AMT, r.CASH_DEPOSIT_RECV_DT CASH_DEPOSIT_RECV_DT, r.CASH_DEPOSIT_REL_DT CASH_DEPOSIT_REL_DT, r.FIRST_MORTGAGE FIRST_MORTGAGE, r.SECOND_MORTGAGE SECOND_MORTGAGE, r.DEED_OF_PRIORITY DEED_OF_PRIORITY, r.PPSR_DETAILS PPSR_DETAILS, r.PMSI_DETAILS PMSI_DETAILS, r.ALLPAP_DETAILS ALLPAP_DETAILS, r.ARREARS ARREARS, r.CREDIT_HOLD CREDIT_HOLD, r.NATIONAL_HOLD NATIONAL_HOLD, r.CREDIT_HOLD_DT CREDIT_HOLD_DT, r.CREDIT_STATUS_OVERRIDE CREDIT_STATUS_OVERRIDE, r.CHEQUE_LIMIT_AMT CHEQUE_LIMIT_AMT, r.CHEQUE_LIMIT_CURRENCY_TP_CD CHEQUE_LIMIT_CURRENCY_TP_CD, r.WET_EXEMPT_IND WET_EXEMPT_IND, r.DUTY_FREE_IND DUTY_FREE_IND, r.CASH_ON_DELIVERY_IND CASH_ON_DELIVERY_IND, r.SALES_REP_TP_CD SALES_REP_TP_CD, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM MTT_ACCOUNT_CREDIT_TAX r WHERE r.MTT_ACT_CREDIT_TAX_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getMTTActCreditTaxParameters =
    "EObjMTTActCreditTax.MTTActCreditTaxIdPk";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getMTTActCreditTaxResults =
    "EObjMTTActCreditTax.MTTActCreditTaxIdPk," +
    "EObjMTTActCreditTax.ContractId," +
    "EObjMTTActCreditTax.InvoiceTerms," +
    "EObjMTTActCreditTax.GSTExemptInd," +
    "EObjMTTActCreditTax.CustomerGroup," +
    "EObjMTTActCreditTax.BankGuaranteeAmount," +
    "EObjMTTActCreditTax.BankGuaranteeEndDate," +
    "EObjMTTActCreditTax.CashDepositAmount," +
    "EObjMTTActCreditTax.CashDepositRecieveDate," +
    "EObjMTTActCreditTax.CashDepositReleaseDate," +
    "EObjMTTActCreditTax.FirstMortgage," +
    "EObjMTTActCreditTax.SecondMortgage," +
    "EObjMTTActCreditTax.DeedOfPriority," +
    "EObjMTTActCreditTax.PPSRDetails," +
    "EObjMTTActCreditTax.PMSIDetails," +
    "EObjMTTActCreditTax.ALLPAPDetails," +
    "EObjMTTActCreditTax.Arrears," +
    "EObjMTTActCreditTax.CreditHold," +
    "EObjMTTActCreditTax.NationalHold," +
    "EObjMTTActCreditTax.CreditHoldDate," +
    "EObjMTTActCreditTax.CreditStatusOverride," +
    "EObjMTTActCreditTax.ChequeLimitAmount," +
    "EObjMTTActCreditTax.ChequeLimitCurrency," +
    "EObjMTTActCreditTax.WETExemptInd," +
    "EObjMTTActCreditTax.DutyFreeInd," +
    "EObjMTTActCreditTax.CashOnDeliveryInd," +
    "EObjMTTActCreditTax.SalesRep," +
    "EObjMTTActCreditTax.lastUpdateDt," +
    "EObjMTTActCreditTax.lastUpdateUser," +
    "EObjMTTActCreditTax.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getMTTActCreditTaxHistorySql = "SELECT r.H_MTT_ACT_CREDIT_TAX_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.MTT_ACT_CREDIT_TAX_ID MTT_ACT_CREDIT_TAX_ID, r.CONTRACT_ID CONTRACT_ID, r.INV_TERMS_TP_CD INV_TERMS_TP_CD, r.GST_EXEMPT_IND GST_EXEMPT_IND, r.CUS_GRP_TP_CD CUS_GRP_TP_CD, r.BANK_GUARANTEE_AMT BANK_GUARANTEE_AMT, r.BANK_GUARANTEE_END_DT BANK_GUARANTEE_END_DT, r.CASH_DEPOSIT_AMT CASH_DEPOSIT_AMT, r.CASH_DEPOSIT_RECV_DT CASH_DEPOSIT_RECV_DT, r.CASH_DEPOSIT_REL_DT CASH_DEPOSIT_REL_DT, r.FIRST_MORTGAGE FIRST_MORTGAGE, r.SECOND_MORTGAGE SECOND_MORTGAGE, r.DEED_OF_PRIORITY DEED_OF_PRIORITY, r.PPSR_DETAILS PPSR_DETAILS, r.PMSI_DETAILS PMSI_DETAILS, r.ALLPAP_DETAILS ALLPAP_DETAILS, r.ARREARS ARREARS, r.CREDIT_HOLD CREDIT_HOLD, r.NATIONAL_HOLD NATIONAL_HOLD, r.CREDIT_HOLD_DT CREDIT_HOLD_DT, r.CREDIT_STATUS_OVERRIDE CREDIT_STATUS_OVERRIDE, r.CHEQUE_LIMIT_AMT CHEQUE_LIMIT_AMT, r.CHEQUE_LIMIT_CURRENCY_TP_CD CHEQUE_LIMIT_CURRENCY_TP_CD, r.WET_EXEMPT_IND WET_EXEMPT_IND, r.DUTY_FREE_IND DUTY_FREE_IND, r.CASH_ON_DELIVERY_IND CASH_ON_DELIVERY_IND, r.SALES_REP_TP_CD SALES_REP_TP_CD, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_MTT_ACCOUNT_CREDIT_TAX r WHERE r.H_MTT_ACT_CREDIT_TAX_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getMTTActCreditTaxHistoryParameters =
    "EObjMTTActCreditTax.MTTActCreditTaxIdPk," +
    "EObjMTTActCreditTax.lastUpdateDt," +
    "EObjMTTActCreditTax.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getMTTActCreditTaxHistoryResults =
    "EObjMTTActCreditTax.historyIdPK," +
    "EObjMTTActCreditTax.histActionCode," +
    "EObjMTTActCreditTax.histCreatedBy," +
    "EObjMTTActCreditTax.histCreateDt," +
    "EObjMTTActCreditTax.histEndDt," +
    "EObjMTTActCreditTax.MTTActCreditTaxIdPk," +
    "EObjMTTActCreditTax.ContractId," +
    "EObjMTTActCreditTax.InvoiceTerms," +
    "EObjMTTActCreditTax.GSTExemptInd," +
    "EObjMTTActCreditTax.CustomerGroup," +
    "EObjMTTActCreditTax.BankGuaranteeAmount," +
    "EObjMTTActCreditTax.BankGuaranteeEndDate," +
    "EObjMTTActCreditTax.CashDepositAmount," +
    "EObjMTTActCreditTax.CashDepositRecieveDate," +
    "EObjMTTActCreditTax.CashDepositReleaseDate," +
    "EObjMTTActCreditTax.FirstMortgage," +
    "EObjMTTActCreditTax.SecondMortgage," +
    "EObjMTTActCreditTax.DeedOfPriority," +
    "EObjMTTActCreditTax.PPSRDetails," +
    "EObjMTTActCreditTax.PMSIDetails," +
    "EObjMTTActCreditTax.ALLPAPDetails," +
    "EObjMTTActCreditTax.Arrears," +
    "EObjMTTActCreditTax.CreditHold," +
    "EObjMTTActCreditTax.NationalHold," +
    "EObjMTTActCreditTax.CreditHoldDate," +
    "EObjMTTActCreditTax.CreditStatusOverride," +
    "EObjMTTActCreditTax.ChequeLimitAmount," +
    "EObjMTTActCreditTax.ChequeLimitCurrency," +
    "EObjMTTActCreditTax.WETExemptInd," +
    "EObjMTTActCreditTax.DutyFreeInd," +
    "EObjMTTActCreditTax.CashOnDeliveryInd," +
    "EObjMTTActCreditTax.SalesRep," +
    "EObjMTTActCreditTax.lastUpdateDt," +
    "EObjMTTActCreditTax.lastUpdateUser," +
    "EObjMTTActCreditTax.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllMTTCreditTaxByIDSql = "SELECT r.MTT_ACT_CREDIT_TAX_ID MTT_ACT_CREDIT_TAX_ID, r.CONTRACT_ID CONTRACT_ID, r.INV_TERMS_TP_CD INV_TERMS_TP_CD, r.GST_EXEMPT_IND GST_EXEMPT_IND, r.CUS_GRP_TP_CD CUS_GRP_TP_CD, r.BANK_GUARANTEE_AMT BANK_GUARANTEE_AMT, r.BANK_GUARANTEE_END_DT BANK_GUARANTEE_END_DT, r.CASH_DEPOSIT_AMT CASH_DEPOSIT_AMT, r.CASH_DEPOSIT_RECV_DT CASH_DEPOSIT_RECV_DT, r.CASH_DEPOSIT_REL_DT CASH_DEPOSIT_REL_DT, r.FIRST_MORTGAGE FIRST_MORTGAGE, r.SECOND_MORTGAGE SECOND_MORTGAGE, r.DEED_OF_PRIORITY DEED_OF_PRIORITY, r.PPSR_DETAILS PPSR_DETAILS, r.PMSI_DETAILS PMSI_DETAILS, r.ALLPAP_DETAILS ALLPAP_DETAILS, r.ARREARS ARREARS, r.CREDIT_HOLD CREDIT_HOLD, r.NATIONAL_HOLD NATIONAL_HOLD, r.CREDIT_HOLD_DT CREDIT_HOLD_DT, r.CREDIT_STATUS_OVERRIDE CREDIT_STATUS_OVERRIDE, r.CHEQUE_LIMIT_AMT CHEQUE_LIMIT_AMT, r.CHEQUE_LIMIT_CURRENCY_TP_CD CHEQUE_LIMIT_CURRENCY_TP_CD, r.WET_EXEMPT_IND WET_EXEMPT_IND, r.DUTY_FREE_IND DUTY_FREE_IND, r.CASH_ON_DELIVERY_IND CASH_ON_DELIVERY_IND, r.SALES_REP_TP_CD SALES_REP_TP_CD, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM MTT_ACCOUNT_CREDIT_TAX r WHERE r.CONTRACT_ID = ? ";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllMTTCreditTaxByIDParameters =
    "EObjMTTActCreditTax.ContractId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllMTTCreditTaxByIDResults =
    "EObjMTTActCreditTax.MTTActCreditTaxIdPk," +
    "EObjMTTActCreditTax.ContractId," +
    "EObjMTTActCreditTax.InvoiceTerms," +
    "EObjMTTActCreditTax.GSTExemptInd," +
    "EObjMTTActCreditTax.CustomerGroup," +
    "EObjMTTActCreditTax.BankGuaranteeAmount," +
    "EObjMTTActCreditTax.BankGuaranteeEndDate," +
    "EObjMTTActCreditTax.CashDepositAmount," +
    "EObjMTTActCreditTax.CashDepositRecieveDate," +
    "EObjMTTActCreditTax.CashDepositReleaseDate," +
    "EObjMTTActCreditTax.FirstMortgage," +
    "EObjMTTActCreditTax.SecondMortgage," +
    "EObjMTTActCreditTax.DeedOfPriority," +
    "EObjMTTActCreditTax.PPSRDetails," +
    "EObjMTTActCreditTax.PMSIDetails," +
    "EObjMTTActCreditTax.ALLPAPDetails," +
    "EObjMTTActCreditTax.Arrears," +
    "EObjMTTActCreditTax.CreditHold," +
    "EObjMTTActCreditTax.NationalHold," +
    "EObjMTTActCreditTax.CreditHoldDate," +
    "EObjMTTActCreditTax.CreditStatusOverride," +
    "EObjMTTActCreditTax.ChequeLimitAmount," +
    "EObjMTTActCreditTax.ChequeLimitCurrency," +
    "EObjMTTActCreditTax.WETExemptInd," +
    "EObjMTTActCreditTax.DutyFreeInd," +
    "EObjMTTActCreditTax.CashOnDeliveryInd," +
    "EObjMTTActCreditTax.SalesRep," +
    "EObjMTTActCreditTax.lastUpdateDt," +
    "EObjMTTActCreditTax.lastUpdateUser," +
    "EObjMTTActCreditTax.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  static final String getAllMTTCreditTaxByIDHistorySql = "SELECT r.H_MTT_ACT_CREDIT_TAX_ID hist_id_pk, r.H_ACTION_CODE h_action_code, r.H_CREATED_BY h_created_by, r.H_CREATE_DT h_create_dt, r.H_END_DT h_end_dt, r.MTT_ACT_CREDIT_TAX_ID MTT_ACT_CREDIT_TAX_ID, r.CONTRACT_ID CONTRACT_ID, r.INV_TERMS_TP_CD INV_TERMS_TP_CD, r.GST_EXEMPT_IND GST_EXEMPT_IND, r.CUS_GRP_TP_CD CUS_GRP_TP_CD, r.BANK_GUARANTEE_AMT BANK_GUARANTEE_AMT, r.BANK_GUARANTEE_END_DT BANK_GUARANTEE_END_DT, r.CASH_DEPOSIT_AMT CASH_DEPOSIT_AMT, r.CASH_DEPOSIT_RECV_DT CASH_DEPOSIT_RECV_DT, r.CASH_DEPOSIT_REL_DT CASH_DEPOSIT_REL_DT, r.FIRST_MORTGAGE FIRST_MORTGAGE, r.SECOND_MORTGAGE SECOND_MORTGAGE, r.DEED_OF_PRIORITY DEED_OF_PRIORITY, r.PPSR_DETAILS PPSR_DETAILS, r.PMSI_DETAILS PMSI_DETAILS, r.ALLPAP_DETAILS ALLPAP_DETAILS, r.ARREARS ARREARS, r.CREDIT_HOLD CREDIT_HOLD, r.NATIONAL_HOLD NATIONAL_HOLD, r.CREDIT_HOLD_DT CREDIT_HOLD_DT, r.CREDIT_STATUS_OVERRIDE CREDIT_STATUS_OVERRIDE, r.CHEQUE_LIMIT_AMT CHEQUE_LIMIT_AMT, r.CHEQUE_LIMIT_CURRENCY_TP_CD CHEQUE_LIMIT_CURRENCY_TP_CD, r.WET_EXEMPT_IND WET_EXEMPT_IND, r.DUTY_FREE_IND DUTY_FREE_IND, r.CASH_ON_DELIVERY_IND CASH_ON_DELIVERY_IND, r.SALES_REP_TP_CD SALES_REP_TP_CD, r.LAST_UPDATE_DT LAST_UPDATE_DT, r.LAST_UPDATE_USER LAST_UPDATE_USER, r.LAST_UPDATE_TX_ID LAST_UPDATE_TX_ID FROM H_MTT_ACCOUNT_CREDIT_TAX r WHERE r.CONTRACT_ID = ?  AND (( ? BETWEEN r.H_CREATE_DT AND r.H_END_DT ) OR ( ? >= r.H_CREATE_DT AND r.H_END_DT IS NULL ))";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllMTTCreditTaxByIDHistoryParameters =
    "EObjMTTActCreditTax.ContractId," +
    "EObjMTTActCreditTax.lastUpdateDt," +
    "EObjMTTActCreditTax.lastUpdateDt";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getAllMTTCreditTaxByIDHistoryResults =
    "EObjMTTActCreditTax.historyIdPK," +
    "EObjMTTActCreditTax.histActionCode," +
    "EObjMTTActCreditTax.histCreatedBy," +
    "EObjMTTActCreditTax.histCreateDt," +
    "EObjMTTActCreditTax.histEndDt," +
    "EObjMTTActCreditTax.MTTActCreditTaxIdPk," +
    "EObjMTTActCreditTax.ContractId," +
    "EObjMTTActCreditTax.InvoiceTerms," +
    "EObjMTTActCreditTax.GSTExemptInd," +
    "EObjMTTActCreditTax.CustomerGroup," +
    "EObjMTTActCreditTax.BankGuaranteeAmount," +
    "EObjMTTActCreditTax.BankGuaranteeEndDate," +
    "EObjMTTActCreditTax.CashDepositAmount," +
    "EObjMTTActCreditTax.CashDepositRecieveDate," +
    "EObjMTTActCreditTax.CashDepositReleaseDate," +
    "EObjMTTActCreditTax.FirstMortgage," +
    "EObjMTTActCreditTax.SecondMortgage," +
    "EObjMTTActCreditTax.DeedOfPriority," +
    "EObjMTTActCreditTax.PPSRDetails," +
    "EObjMTTActCreditTax.PMSIDetails," +
    "EObjMTTActCreditTax.ALLPAPDetails," +
    "EObjMTTActCreditTax.Arrears," +
    "EObjMTTActCreditTax.CreditHold," +
    "EObjMTTActCreditTax.NationalHold," +
    "EObjMTTActCreditTax.CreditHoldDate," +
    "EObjMTTActCreditTax.CreditStatusOverride," +
    "EObjMTTActCreditTax.ChequeLimitAmount," +
    "EObjMTTActCreditTax.ChequeLimitCurrency," +
    "EObjMTTActCreditTax.WETExemptInd," +
    "EObjMTTActCreditTax.DutyFreeInd," +
    "EObjMTTActCreditTax.CashOnDeliveryInd," +
    "EObjMTTActCreditTax.SalesRep," +
    "EObjMTTActCreditTax.lastUpdateDt," +
    "EObjMTTActCreditTax.lastUpdateUser," +
    "EObjMTTActCreditTax.lastUpdateTxId";
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getMTTActCreditTaxSql, pattern=tableAliasString)
  @EntityMapping(parameters=getMTTActCreditTaxParameters, results=getMTTActCreditTaxResults)
  Iterator<ResultQueue1<EObjMTTActCreditTax>> getMTTActCreditTax(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getMTTActCreditTaxHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getMTTActCreditTaxHistoryParameters, results=getMTTActCreditTaxHistoryResults)
  Iterator<ResultQueue1<EObjMTTActCreditTax>> getMTTActCreditTaxHistory(Object[] parameters);  


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllMTTCreditTaxByIDSql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllMTTCreditTaxByIDParameters, results=getAllMTTCreditTaxByIDResults)
  Iterator<ResultQueue1<EObjMTTActCreditTax>> getAllMTTCreditTaxByID(Object[] parameters);


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  @Select(sql=getAllMTTCreditTaxByIDHistorySql, pattern=tableAliasString)
  @EntityMapping(parameters=getAllMTTCreditTaxByIDHistoryParameters, results=getAllMTTCreditTaxByIDHistoryResults)
  Iterator<ResultQueue1<EObjMTTActCreditTax>> getAllMTTCreditTaxByIDHistory(Object[] parameters);  


}


