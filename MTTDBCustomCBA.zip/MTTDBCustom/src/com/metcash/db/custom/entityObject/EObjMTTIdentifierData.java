/*
 * The following source code ("Code") may only be used in accordance with the terms
 * and conditions of the license agreement you have with IBM Corporation. The Code 
 * is provided to you on an "AS IS" basis, without warranty of any kind.  
 * SUBJECT TO ANY STATUTORY WARRANTIES WHICH CAN NOT BE EXCLUDED, IBM MAKES NO 
 * WARRANTIES OR CONDITIONS EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT, REGARDING THE CODE. IN NO EVENT WILL 
 * IBM BE LIABLE TO YOU OR ANY PARTY FOR ANY DIRECT, INDIRECT, SPECIAL OR OTHER 
 * CONSEQUENTIAL DAMAGES FOR ANY USE OF THE CODE, INCLUDING, WITHOUT LIMITATION, 
 * LOSS OF, OR DAMAGE TO, DATA, OR LOST PROFITS, BUSINESS, REVENUE, GOODWILL, OR 
 * ANTICIPATED SAVINGS, EVEN IF IBM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH 
 * DAMAGES. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF 
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY 
 * NOT APPLY TO YOU.
 */

/*
 * IBM-MDMWB-1.0-[ddc4850e9f555b2073bf7afca48d204e]
 */


package com.metcash.db.custom.entityObject;

import java.util.Iterator;
import com.ibm.mdm.base.db.EntityMapping;
import com.ibm.pdq.annotation.Select;
import com.ibm.pdq.annotation.Update;

import com.metcash.db.custom.entityObject.EObjMTTIdentifier;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 *
 * @generated
 */
public interface EObjMTTIdentifierData {


  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String getEObjMTTIdentifierSql = "select MTT_IDENTIFIER_ID, IDENTIFIER_ID, IDENTIFIER_SUB_TP_CD, START_DT, END_DT, EXPIRY_DT, DESCRIPTION,  LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from MTT_IDENTIFIER where MTT_IDENTIFIER_ID = ? ";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String createEObjMTTIdentifierSql = "insert into MTT_IDENTIFIER (MTT_IDENTIFIER_ID, IDENTIFIER_ID, IDENTIFIER_SUB_TP_CD, START_DT, END_DT, EXPIRY_DT, DESCRIPTION, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :mTTIdentifierIdPk, :identifierId, :identifierSub, :startDate, :endDate, :expiryDate, :description, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String updateEObjMTTIdentifierSql = "update MTT_IDENTIFIER set IDENTIFIER_ID = :identifierId, IDENTIFIER_SUB_TP_CD = :identifierSub, START_DT = :startDate, END_DT = :endDate, EXPIRY_DT = :expiryDate, DESCRIPTION = :description, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where MTT_IDENTIFIER_ID = :mTTIdentifierIdPk and LAST_UPDATE_DT = :oldLastUpdateDt";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String deleteEObjMTTIdentifierSql = "delete from MTT_IDENTIFIER where MTT_IDENTIFIER_ID = ?";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjMTTIdentifierKeyField = "EObjMTTIdentifier.mTTIdentifierIdPk";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjMTTIdentifierGetFields =
    "EObjMTTIdentifier.mTTIdentifierIdPk," +
    "EObjMTTIdentifier.identifierId," +
    "EObjMTTIdentifier.identifierSub," +
    "EObjMTTIdentifier.startDate," +
    "EObjMTTIdentifier.endDate," +
    "EObjMTTIdentifier.expiryDate," +
    "EObjMTTIdentifier.description," +
    "EObjMTTIdentifier.lastUpdateDt," +
    "EObjMTTIdentifier.lastUpdateUser," +
    "EObjMTTIdentifier.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjMTTIdentifierAllFields =
    "com.metcash.db.custom.entityObject.EObjMTTIdentifier.mTTIdentifierIdPk," +
    "com.metcash.db.custom.entityObject.EObjMTTIdentifier.identifierId," +
    "com.metcash.db.custom.entityObject.EObjMTTIdentifier.identifierSub," +
    "com.metcash.db.custom.entityObject.EObjMTTIdentifier.startDate," +
    "com.metcash.db.custom.entityObject.EObjMTTIdentifier.endDate," +
    "com.metcash.db.custom.entityObject.EObjMTTIdentifier.expiryDate," +
    "com.metcash.db.custom.entityObject.EObjMTTIdentifier.description," +
    "com.metcash.db.custom.entityObject.EObjMTTIdentifier.lastUpdateDt," +
    "com.metcash.db.custom.entityObject.EObjMTTIdentifier.lastUpdateUser," +
    "com.metcash.db.custom.entityObject.EObjMTTIdentifier.lastUpdateTxId";

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
   * @generated
   */
  public static final String EObjMTTIdentifierUpdateFields =
    "com.metcash.db.custom.entityObject.EObjMTTIdentifier.identifierId," +
    "com.metcash.db.custom.entityObject.EObjMTTIdentifier.identifierSub," +
    "com.metcash.db.custom.entityObject.EObjMTTIdentifier.startDate," +
    "com.metcash.db.custom.entityObject.EObjMTTIdentifier.endDate," +
    "com.metcash.db.custom.entityObject.EObjMTTIdentifier.expiryDate," +
    "com.metcash.db.custom.entityObject.EObjMTTIdentifier.description," +
    "com.metcash.db.custom.entityObject.EObjMTTIdentifier.lastUpdateDt," +
    "com.metcash.db.custom.entityObject.EObjMTTIdentifier.lastUpdateUser," +
    "com.metcash.db.custom.entityObject.EObjMTTIdentifier.lastUpdateTxId," +
    "com.metcash.db.custom.entityObject.EObjMTTIdentifier.mTTIdentifierIdPk," +
    "com.metcash.db.custom.entityObject.EObjMTTIdentifier.oldLastUpdateDt";   

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Select MTTIdentifier by parameters.
   * @generated
   */
  @Select(sql=getEObjMTTIdentifierSql)
  @EntityMapping(parameters=EObjMTTIdentifierKeyField, results=EObjMTTIdentifierGetFields)
  Iterator<EObjMTTIdentifier> getEObjMTTIdentifier(Long mTTIdentifierIdPk);  
   
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Create MTTIdentifier by EObjMTTIdentifier Object.
   * @generated
   */
  @Update(sql=createEObjMTTIdentifierSql)
  @EntityMapping(parameters=EObjMTTIdentifierAllFields)
    int createEObjMTTIdentifier(EObjMTTIdentifier e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Update one MTTIdentifier by EObjMTTIdentifier object.
   * @generated
   */
  @Update(sql=updateEObjMTTIdentifierSql)
  @EntityMapping(parameters=EObjMTTIdentifierUpdateFields)
    int updateEObjMTTIdentifier(EObjMTTIdentifier e); 

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   *
    * Delete MTTIdentifier by parameters.
   * @generated
   */
  @Update(sql=deleteEObjMTTIdentifierSql)
  @EntityMapping(parameters=EObjMTTIdentifierKeyField)
  int deleteEObjMTTIdentifier(Long mTTIdentifierIdPk);

}

