package com.metcash.db.custom.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.metcash.db.custom.entityObject.EObjMTTActCostCharges;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjMTTActCostChargesDataImpl  extends BaseData implements EObjMTTActCostChargesData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjMTTActCostChargesData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000015daaa4eb0dL;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjMTTActCostChargesDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select MTT_ACT_COST_CHARGES_ID, CONTRACT_ID, COST_BASE_TP_CD, DIRECT_SHIP_APPROVED_IND, DO_NOT_APPLY_DIRECT_DISC_IND, SRP_COMPLIANCE_TP_CD, PRICE_MATCH_GAP_FEE_IND, BRKN_CASE_UPCHARGE_PCT, BRKN_CASE_UPCHARGE_CAP, BRKN_CASE_UPCHARGE_IND, BRKN_CASE_CALC_TP_CD, SHELF_LABEL_PRICED_IND, PSRP_TP_CD, ADD_FRT_RECOVERY_SRP_IND, SRP_FRT_RECOVERY_VAL, SRP_FRT_RECOVERY_DIR_VAL,  LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from MTT_ACCOUNT_COST_CHARGES where MTT_ACT_COST_CHARGES_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjMTTActCostCharges> getEObjMTTActCostCharges (Long mTTActCostChargesIdPk)
  {
    return queryIterator (getEObjMTTActCostChargesStatementDescriptor, mTTActCostChargesIdPk);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjMTTActCostChargesStatementDescriptor = createStatementDescriptor (
    "getEObjMTTActCostCharges(Long)",
    "select MTT_ACT_COST_CHARGES_ID, CONTRACT_ID, COST_BASE_TP_CD, DIRECT_SHIP_APPROVED_IND, DO_NOT_APPLY_DIRECT_DISC_IND, SRP_COMPLIANCE_TP_CD, PRICE_MATCH_GAP_FEE_IND, BRKN_CASE_UPCHARGE_PCT, BRKN_CASE_UPCHARGE_CAP, BRKN_CASE_UPCHARGE_IND, BRKN_CASE_CALC_TP_CD, SHELF_LABEL_PRICED_IND, PSRP_TP_CD, ADD_FRT_RECOVERY_SRP_IND, SRP_FRT_RECOVERY_VAL, SRP_FRT_RECOVERY_DIR_VAL,  LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from MTT_ACCOUNT_COST_CHARGES where MTT_ACT_COST_CHARGES_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"mtt_act_cost_charges_id", "contract_id", "cost_base_tp_cd", "direct_ship_approved_ind", "do_not_apply_direct_disc_ind", "srp_compliance_tp_cd", "price_match_gap_fee_ind", "brkn_case_upcharge_pct", "brkn_case_upcharge_cap", "brkn_case_upcharge_ind", "brkn_case_calc_tp_cd", "shelf_label_priced_ind", "psrp_tp_cd", "add_frt_recovery_srp_ind", "srp_frt_recovery_val", "srp_frt_recovery_dir_val", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjMTTActCostChargesParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjMTTActCostChargesRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.REAL, Types.REAL, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.REAL, Types.REAL, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 1, 1, 19, 1, 16, 16, 1, 19, 1, 19, 1, 16, 16, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjMTTActCostChargesParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjMTTActCostChargesRowHandler extends BaseRowHandler<EObjMTTActCostCharges>
  {
    /**
     * @generated
     */
    public EObjMTTActCostCharges handle (java.sql.ResultSet rs, EObjMTTActCostCharges returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjMTTActCostCharges ();
      returnObject.setMTTActCostChargesIdPk(getLongObject (rs, 1)); 
      returnObject.setContractId(getLongObject (rs, 2)); 
      returnObject.setCostBase(getLongObject (rs, 3)); 
      returnObject.setDirectShipApprovedInd(getString (rs, 4)); 
      returnObject.setDoNotApplyDirectDiscountInd(getString (rs, 5)); 
      returnObject.setSRPComplicance(getLongObject (rs, 6)); 
      returnObject.setPriceMatchGapFeeInd(getString (rs, 7)); 
      returnObject.setBrokenCaseUpchargePercentage(getFloatObject (rs, 8)); 
      returnObject.setBrokenCaseUpchargeCap(getFloatObject (rs, 9)); 
      returnObject.setBrokenCaseUpchargeInd(getString (rs, 10)); 
      returnObject.setBrokenCaseCal(getLongObject (rs, 11)); 
      returnObject.setShelfLabelPricedInd(getString (rs, 12)); 
      returnObject.setPSRP(getLongObject (rs, 13)); 
      returnObject.setAddFRTRecoverySRPInd(getString (rs, 14)); 
      returnObject.setSRPFRTRecoveryValue(getFloatObject (rs, 15)); 
      returnObject.setSRPFRTRecoveryDirectValue(getFloatObject (rs, 16)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 17)); 
      returnObject.setLastUpdateUser(getString (rs, 18)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 19)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into MTT_ACCOUNT_COST_CHARGES (MTT_ACT_COST_CHARGES_ID, CONTRACT_ID, COST_BASE_TP_CD, DIRECT_SHIP_APPROVED_IND, DO_NOT_APPLY_DIRECT_DISC_IND, SRP_COMPLIANCE_TP_CD, PRICE_MATCH_GAP_FEE_IND, BRKN_CASE_UPCHARGE_PCT, BRKN_CASE_UPCHARGE_CAP, BRKN_CASE_UPCHARGE_IND, BRKN_CASE_CALC_TP_CD, SHELF_LABEL_PRICED_IND, PSRP_TP_CD, ADD_FRT_RECOVERY_SRP_IND, SRP_FRT_RECOVERY_VAL, SRP_FRT_RECOVERY_DIR_VAL, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :mTTActCostChargesIdPk, :contractId, :costBase, :directShipApprovedInd, :doNotApplyDirectDiscountInd, :sRPComplicance, :priceMatchGapFeeInd, :brokenCaseUpchargePercentage, :brokenCaseUpchargeCap, :brokenCaseUpchargeInd, :brokenCaseCal, :shelfLabelPricedInd, :pSRP, :addFRTRecoverySRPInd, :sRPFRTRecoveryValue, :sRPFRTRecoveryDirectValue, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjMTTActCostCharges (EObjMTTActCostCharges e)
  {
    return update (createEObjMTTActCostChargesStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjMTTActCostChargesStatementDescriptor = createStatementDescriptor (
    "createEObjMTTActCostCharges(com.metcash.db.custom.entityObject.EObjMTTActCostCharges)",
    "insert into MTT_ACCOUNT_COST_CHARGES (MTT_ACT_COST_CHARGES_ID, CONTRACT_ID, COST_BASE_TP_CD, DIRECT_SHIP_APPROVED_IND, DO_NOT_APPLY_DIRECT_DISC_IND, SRP_COMPLIANCE_TP_CD, PRICE_MATCH_GAP_FEE_IND, BRKN_CASE_UPCHARGE_PCT, BRKN_CASE_UPCHARGE_CAP, BRKN_CASE_UPCHARGE_IND, BRKN_CASE_CALC_TP_CD, SHELF_LABEL_PRICED_IND, PSRP_TP_CD, ADD_FRT_RECOVERY_SRP_IND, SRP_FRT_RECOVERY_VAL, SRP_FRT_RECOVERY_DIR_VAL, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjMTTActCostChargesParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.REAL, Types.REAL, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.REAL, Types.REAL, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 19, 1, 1, 19, 1, 16, 16, 1, 19, 1, 19, 1, 16, 16, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjMTTActCostChargesParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjMTTActCostCharges bean0 = (EObjMTTActCostCharges) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getMTTActCostChargesIdPk());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getContractId());
      setLong (stmt, 3, Types.BIGINT, (Long)bean0.getCostBase());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getDirectShipApprovedInd());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getDoNotApplyDirectDiscountInd());
      setLong (stmt, 6, Types.BIGINT, (Long)bean0.getSRPComplicance());
      setString (stmt, 7, Types.VARCHAR, (String)bean0.getPriceMatchGapFeeInd());
      setFloat (stmt, 8, Types.REAL, (Float)bean0.getBrokenCaseUpchargePercentage());
      setFloat (stmt, 9, Types.REAL, (Float)bean0.getBrokenCaseUpchargeCap());
      setString (stmt, 10, Types.VARCHAR, (String)bean0.getBrokenCaseUpchargeInd());
      setLong (stmt, 11, Types.BIGINT, (Long)bean0.getBrokenCaseCal());
      setString (stmt, 12, Types.VARCHAR, (String)bean0.getShelfLabelPricedInd());
      setLong (stmt, 13, Types.BIGINT, (Long)bean0.getPSRP());
      setString (stmt, 14, Types.VARCHAR, (String)bean0.getAddFRTRecoverySRPInd());
      setFloat (stmt, 15, Types.REAL, (Float)bean0.getSRPFRTRecoveryValue());
      setFloat (stmt, 16, Types.REAL, (Float)bean0.getSRPFRTRecoveryDirectValue());
      setTimestamp (stmt, 17, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 18, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 19, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update MTT_ACCOUNT_COST_CHARGES set CONTRACT_ID = :contractId, COST_BASE_TP_CD = :costBase, DIRECT_SHIP_APPROVED_IND = :directShipApprovedInd, DO_NOT_APPLY_DIRECT_DISC_IND = :doNotApplyDirectDiscountInd, SRP_COMPLIANCE_TP_CD = :sRPComplicance, PRICE_MATCH_GAP_FEE_IND = :priceMatchGapFeeInd, BRKN_CASE_UPCHARGE_PCT = :brokenCaseUpchargePercentage, BRKN_CASE_UPCHARGE_CAP = :brokenCaseUpchargeCap, BRKN_CASE_UPCHARGE_IND = :brokenCaseUpchargeInd, BRKN_CASE_CALC_TP_CD = :brokenCaseCal, SHELF_LABEL_PRICED_IND = :shelfLabelPricedInd, PSRP_TP_CD = :pSRP, ADD_FRT_RECOVERY_SRP_IND = :addFRTRecoverySRPInd, SRP_FRT_RECOVERY_VAL = :sRPFRTRecoveryValue, SRP_FRT_RECOVERY_DIR_VAL = :sRPFRTRecoveryDirectValue, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where MTT_ACT_COST_CHARGES_ID = :mTTActCostChargesIdPk and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjMTTActCostCharges (EObjMTTActCostCharges e)
  {
    return update (updateEObjMTTActCostChargesStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjMTTActCostChargesStatementDescriptor = createStatementDescriptor (
    "updateEObjMTTActCostCharges(com.metcash.db.custom.entityObject.EObjMTTActCostCharges)",
    "update MTT_ACCOUNT_COST_CHARGES set CONTRACT_ID =  ? , COST_BASE_TP_CD =  ? , DIRECT_SHIP_APPROVED_IND =  ? , DO_NOT_APPLY_DIRECT_DISC_IND =  ? , SRP_COMPLIANCE_TP_CD =  ? , PRICE_MATCH_GAP_FEE_IND =  ? , BRKN_CASE_UPCHARGE_PCT =  ? , BRKN_CASE_UPCHARGE_CAP =  ? , BRKN_CASE_UPCHARGE_IND =  ? , BRKN_CASE_CALC_TP_CD =  ? , SHELF_LABEL_PRICED_IND =  ? , PSRP_TP_CD =  ? , ADD_FRT_RECOVERY_SRP_IND =  ? , SRP_FRT_RECOVERY_VAL =  ? , SRP_FRT_RECOVERY_DIR_VAL =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where MTT_ACT_COST_CHARGES_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjMTTActCostChargesParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.REAL, Types.REAL, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.REAL, Types.REAL, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 19, 1, 1, 19, 1, 16, 16, 1, 19, 1, 19, 1, 16, 16, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjMTTActCostChargesParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjMTTActCostCharges bean0 = (EObjMTTActCostCharges) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getContractId());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getCostBase());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getDirectShipApprovedInd());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getDoNotApplyDirectDiscountInd());
      setLong (stmt, 5, Types.BIGINT, (Long)bean0.getSRPComplicance());
      setString (stmt, 6, Types.VARCHAR, (String)bean0.getPriceMatchGapFeeInd());
      setFloat (stmt, 7, Types.REAL, (Float)bean0.getBrokenCaseUpchargePercentage());
      setFloat (stmt, 8, Types.REAL, (Float)bean0.getBrokenCaseUpchargeCap());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getBrokenCaseUpchargeInd());
      setLong (stmt, 10, Types.BIGINT, (Long)bean0.getBrokenCaseCal());
      setString (stmt, 11, Types.VARCHAR, (String)bean0.getShelfLabelPricedInd());
      setLong (stmt, 12, Types.BIGINT, (Long)bean0.getPSRP());
      setString (stmt, 13, Types.VARCHAR, (String)bean0.getAddFRTRecoverySRPInd());
      setFloat (stmt, 14, Types.REAL, (Float)bean0.getSRPFRTRecoveryValue());
      setFloat (stmt, 15, Types.REAL, (Float)bean0.getSRPFRTRecoveryDirectValue());
      setTimestamp (stmt, 16, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 17, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 18, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 19, Types.BIGINT, (Long)bean0.getMTTActCostChargesIdPk());
      setTimestamp (stmt, 20, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from MTT_ACCOUNT_COST_CHARGES where MTT_ACT_COST_CHARGES_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjMTTActCostCharges (Long mTTActCostChargesIdPk)
  {
    return update (deleteEObjMTTActCostChargesStatementDescriptor, mTTActCostChargesIdPk);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjMTTActCostChargesStatementDescriptor = createStatementDescriptor (
    "deleteEObjMTTActCostCharges(Long)",
    "delete from MTT_ACCOUNT_COST_CHARGES where MTT_ACT_COST_CHARGES_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjMTTActCostChargesParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjMTTActCostChargesParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
