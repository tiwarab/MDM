package com.metcash.db.custom.entityObject;

import com.ibm.pdq.runtime.generator.BaseParameterHandler;
import java.util.Iterator;
import com.metcash.db.custom.entityObject.EObjMTTActReporting;
import java.sql.PreparedStatement;
import com.ibm.pdq.runtime.statement.StatementDescriptor;
import com.ibm.pdq.runtime.generator.BaseData;
import java.sql.SQLException;
import com.ibm.pdq.annotation.Metadata;
import com.ibm.pdq.runtime.generator.BaseRowHandler;
import com.ibm.pdq.runtime.statement.SqlStatementType;
import java.sql.Types;


/**
 * <!-- begin-user-doc -->
 * 
 * <!-- end-user-doc -->
 * 
 * @generated
 */
public class EObjMTTActReportingDataImpl  extends BaseData implements EObjMTTActReportingData
{

  /**
   * @generated
   */
  public static final String generatorVersion = "3.200.75";

  /**
   * @generated
   */
  public static final String identifier = "EObjMTTActReportingData";

  /**
   * @generated
   */
  public static final long generationTime = 0x0000015dac380bbcL;

  /**
   * @generated
   */
  public static final String collection = "NULLID";

  /**
   * @generated
   */
  public static final String packageVersion = null;

  /**
   * @generated
   */
  public static final boolean forceSingleBindIsolation = false;

  /**
   * @generated
   */
  public EObjMTTActReportingDataImpl()
  {
    super();
  } 

  /**
   * @generated
   */
  public String getGeneratorVersion()
  {
    return generatorVersion;
  }

  /**
   * @Select( sql="select MTT_ACT_REPORTING_ID, CHANNEL_GRP_TP_CD, GOV_CONTRACT_IND, CAPRICORN_NUM, IGAD_PERISHABLE_IND, AGENT_NUM_TP_CD, USER_LOCALITY_TP_CD, CUS_CLASS_TP_CD, SHOW_PRICES_ON_WEB_IND, CONTRACT_ID, EXPORT_CUS_IND,  LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from MTT_ACCOUNT_REPORTING where MTT_ACT_REPORTING_ID = ? " )
   * 
   * @generated
   */
  public Iterator<EObjMTTActReporting> getEObjMTTActReporting (Long mTTActReportingIdPk)
  {
    return queryIterator (getEObjMTTActReportingStatementDescriptor, mTTActReportingIdPk);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor getEObjMTTActReportingStatementDescriptor = createStatementDescriptor (
    "getEObjMTTActReporting(Long)",
    "select MTT_ACT_REPORTING_ID, CHANNEL_GRP_TP_CD, GOV_CONTRACT_IND, CAPRICORN_NUM, IGAD_PERISHABLE_IND, AGENT_NUM_TP_CD, USER_LOCALITY_TP_CD, CUS_CLASS_TP_CD, SHOW_PRICES_ON_WEB_IND, CONTRACT_ID, EXPORT_CUS_IND,  LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID from MTT_ACCOUNT_REPORTING where MTT_ACT_REPORTING_ID = ? ",
    new int[] {SINGLE_ROW_PARAMETERS, MULTI_ROW_RESULT, java.sql.ResultSet.CONCUR_READ_ONLY, java.sql.ResultSet.CLOSE_CURSORS_AT_COMMIT, java.sql.ResultSet.TYPE_FORWARD_ONLY, DISALLOW_STATIC_ROWSET_CURSORS},
    SqlStatementType.QUERY,
    new String[]{"mtt_act_reporting_id", "channel_grp_tp_cd", "gov_contract_ind", "capricorn_num", "igad_perishable_ind", "agent_num_tp_cd", "user_locality_tp_cd", "cus_class_tp_cd", "show_prices_on_web_ind", "contract_id", "export_cus_ind", "last_update_dt", "last_update_user", "last_update_tx_id"},
    new GetEObjMTTActReportingParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    new GetEObjMTTActReportingRowHandler (),
    new int[][]{ {Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.INTEGER, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 1, 10, 1, 19, 19, 19, 1, 19, 1, 0, 20, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    1);

  /**
   * @generated
   */
  public static class GetEObjMTTActReportingParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

  /**
   * @generated
   */
  public static class GetEObjMTTActReportingRowHandler extends BaseRowHandler<EObjMTTActReporting>
  {
    /**
     * @generated
     */
    public EObjMTTActReporting handle (java.sql.ResultSet rs, EObjMTTActReporting returnObject) throws java.sql.SQLException
    {
      returnObject = new EObjMTTActReporting ();
      returnObject.setMTTActReportingIdPk(getLongObject (rs, 1)); 
      returnObject.setChannelGroup(getLongObject (rs, 2)); 
      returnObject.setGovtContractInd(getString (rs, 3)); 
      returnObject.setCapricornNumber(getIntObject (rs, 4)); 
      returnObject.setIGADPerishableInd(getString (rs, 5)); 
      returnObject.setAgentNumber(getLongObject (rs, 6)); 
      returnObject.setUserLocality(getLongObject (rs, 7)); 
      returnObject.setCustomerClass(getLongObject (rs, 8)); 
      returnObject.setShowPricesOnWebInd(getString (rs, 9)); 
      returnObject.setContractId(getLongObject (rs, 10)); 
      returnObject.setExportCustomerInd(getString (rs, 11)); 
      returnObject.setLastUpdateDt(getTimestamp (rs, 12)); 
      returnObject.setLastUpdateUser(getString (rs, 13)); 
      returnObject.setLastUpdateTxId(getLongObject (rs, 14)); 
    
      return returnObject;
    }
  }

  /**
   * @Update( sql="insert into MTT_ACCOUNT_REPORTING (MTT_ACT_REPORTING_ID, CHANNEL_GRP_TP_CD, GOV_CONTRACT_IND, CAPRICORN_NUM, IGAD_PERISHABLE_IND, AGENT_NUM_TP_CD, USER_LOCALITY_TP_CD, CUS_CLASS_TP_CD, SHOW_PRICES_ON_WEB_IND, CONTRACT_ID, EXPORT_CUS_IND, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values( :mTTActReportingIdPk, :channelGroup, :govtContractInd, :capricornNumber, :iGADPerishableInd, :agentNumber, :userLocality, :customerClass, :showPricesOnWebInd, :contractId, :exportCustomerInd, :lastUpdateDt, :lastUpdateUser, :lastUpdateTxId)" )
   * 
   * @generated
   */
  public int createEObjMTTActReporting (EObjMTTActReporting e)
  {
    return update (createEObjMTTActReportingStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor createEObjMTTActReportingStatementDescriptor = createStatementDescriptor (
    "createEObjMTTActReporting(com.metcash.db.custom.entityObject.EObjMTTActReporting)",
    "insert into MTT_ACCOUNT_REPORTING (MTT_ACT_REPORTING_ID, CHANNEL_GRP_TP_CD, GOV_CONTRACT_IND, CAPRICORN_NUM, IGAD_PERISHABLE_IND, AGENT_NUM_TP_CD, USER_LOCALITY_TP_CD, CUS_CLASS_TP_CD, SHOW_PRICES_ON_WEB_IND, CONTRACT_ID, EXPORT_CUS_IND, LAST_UPDATE_DT, LAST_UPDATE_USER, LAST_UPDATE_TX_ID) values(  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? ,  ? )",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.INSERT,
    null,
    new CreateEObjMTTActReportingParameterHandler (),
    new int[][]{{Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.INTEGER, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT}, {19, 19, 1, 10, 1, 19, 19, 19, 1, 19, 1, 0, 0, 19}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    2);

  /**
   * @generated
   */
  public static class CreateEObjMTTActReportingParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjMTTActReporting bean0 = (EObjMTTActReporting) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getMTTActReportingIdPk());
      setLong (stmt, 2, Types.BIGINT, (Long)bean0.getChannelGroup());
      setString (stmt, 3, Types.VARCHAR, (String)bean0.getGovtContractInd());
      setInteger (stmt, 4, Types.INTEGER, (Integer)bean0.getCapricornNumber());
      setString (stmt, 5, Types.VARCHAR, (String)bean0.getIGADPerishableInd());
      setLong (stmt, 6, Types.BIGINT, (Long)bean0.getAgentNumber());
      setLong (stmt, 7, Types.BIGINT, (Long)bean0.getUserLocality());
      setLong (stmt, 8, Types.BIGINT, (Long)bean0.getCustomerClass());
      setString (stmt, 9, Types.VARCHAR, (String)bean0.getShowPricesOnWebInd());
      setLong (stmt, 10, Types.BIGINT, (Long)bean0.getContractId());
      setString (stmt, 11, Types.VARCHAR, (String)bean0.getExportCustomerInd());
      setTimestamp (stmt, 12, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 13, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 14, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
    }
  }

  /**
   * @Update( sql="update MTT_ACCOUNT_REPORTING set CHANNEL_GRP_TP_CD = :channelGroup, GOV_CONTRACT_IND = :govtContractInd, CAPRICORN_NUM = :capricornNumber, IGAD_PERISHABLE_IND = :iGADPerishableInd, AGENT_NUM_TP_CD = :agentNumber, USER_LOCALITY_TP_CD = :userLocality, CUS_CLASS_TP_CD = :customerClass, SHOW_PRICES_ON_WEB_IND = :showPricesOnWebInd, CONTRACT_ID = :contractId, EXPORT_CUS_IND = :exportCustomerInd, LAST_UPDATE_DT = :lastUpdateDt, LAST_UPDATE_USER = :lastUpdateUser, LAST_UPDATE_TX_ID = :lastUpdateTxId where MTT_ACT_REPORTING_ID = :mTTActReportingIdPk and LAST_UPDATE_DT = :oldLastUpdateDt" )
   * 
   * @generated
   */
  public int updateEObjMTTActReporting (EObjMTTActReporting e)
  {
    return update (updateEObjMTTActReportingStatementDescriptor, e);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor updateEObjMTTActReportingStatementDescriptor = createStatementDescriptor (
    "updateEObjMTTActReporting(com.metcash.db.custom.entityObject.EObjMTTActReporting)",
    "update MTT_ACCOUNT_REPORTING set CHANNEL_GRP_TP_CD =  ? , GOV_CONTRACT_IND =  ? , CAPRICORN_NUM =  ? , IGAD_PERISHABLE_IND =  ? , AGENT_NUM_TP_CD =  ? , USER_LOCALITY_TP_CD =  ? , CUS_CLASS_TP_CD =  ? , SHOW_PRICES_ON_WEB_IND =  ? , CONTRACT_ID =  ? , EXPORT_CUS_IND =  ? , LAST_UPDATE_DT =  ? , LAST_UPDATE_USER =  ? , LAST_UPDATE_TX_ID =  ?  where MTT_ACT_REPORTING_ID =  ?  and LAST_UPDATE_DT =  ? ",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.UPDATE,
    null,
    new UpdateEObjMTTActReportingParameterHandler (),
    new int[][]{{Types.BIGINT, Types.VARCHAR, Types.INTEGER, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.BIGINT, Types.VARCHAR, Types.BIGINT, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.BIGINT, Types.BIGINT, Types.TIMESTAMP}, {19, 1, 10, 1, 19, 19, 19, 1, 19, 1, 0, 0, 19, 19, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    3);

  /**
   * @generated
   */
  public static class UpdateEObjMTTActReportingParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      EObjMTTActReporting bean0 = (EObjMTTActReporting) parameters[0];
      setLong (stmt, 1, Types.BIGINT, (Long)bean0.getChannelGroup());
      setString (stmt, 2, Types.VARCHAR, (String)bean0.getGovtContractInd());
      setInteger (stmt, 3, Types.INTEGER, (Integer)bean0.getCapricornNumber());
      setString (stmt, 4, Types.VARCHAR, (String)bean0.getIGADPerishableInd());
      setLong (stmt, 5, Types.BIGINT, (Long)bean0.getAgentNumber());
      setLong (stmt, 6, Types.BIGINT, (Long)bean0.getUserLocality());
      setLong (stmt, 7, Types.BIGINT, (Long)bean0.getCustomerClass());
      setString (stmt, 8, Types.VARCHAR, (String)bean0.getShowPricesOnWebInd());
      setLong (stmt, 9, Types.BIGINT, (Long)bean0.getContractId());
      setString (stmt, 10, Types.VARCHAR, (String)bean0.getExportCustomerInd());
      setTimestamp (stmt, 11, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getLastUpdateDt());
      setString (stmt, 12, Types.VARCHAR, (String)bean0.getLastUpdateUser());
      setLong (stmt, 13, Types.BIGINT, (Long)bean0.getLastUpdateTxId());
      setLong (stmt, 14, Types.BIGINT, (Long)bean0.getMTTActReportingIdPk());
      setTimestamp (stmt, 15, Types.TIMESTAMP, (java.sql.Timestamp)bean0.getOldLastUpdateDt());
    }
  }

  /**
   * @Update( sql="delete from MTT_ACCOUNT_REPORTING where MTT_ACT_REPORTING_ID = ?" )
   * 
   * @generated
   */
  public int deleteEObjMTTActReporting (Long mTTActReportingIdPk)
  {
    return update (deleteEObjMTTActReportingStatementDescriptor, mTTActReportingIdPk);
  }

  /**
   * @generated
   */
  @Metadata ()
  public static final StatementDescriptor deleteEObjMTTActReportingStatementDescriptor = createStatementDescriptor (
    "deleteEObjMTTActReporting(Long)",
    "delete from MTT_ACCOUNT_REPORTING where MTT_ACT_REPORTING_ID = ?",
    new int[] {SINGLE_ROW_PARAMETERS},
    SqlStatementType.DELETE,
    null,
    new DeleteEObjMTTActReportingParameterHandler (),
    new int[][]{{Types.BIGINT}, {19}, {0}, {1}},
    null,
    null,
    null,
    null,
    identifier,
    generationTime,
    collection,
    forceSingleBindIsolation,
    null,
    4);

  /**
   * @generated
   */
  public static class DeleteEObjMTTActReportingParameterHandler extends BaseParameterHandler 
  {
    /**
     * @generated
     */
    public void handleParameters (PreparedStatement stmt, Object... parameters) throws SQLException
    {
      setLong (stmt, 1, Types.BIGINT, (Long)parameters[0]);
    }
  }

}
